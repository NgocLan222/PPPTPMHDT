﻿using System;
using System.Data;
using System.IO;
using System.Windows.Forms;
using QuanLyHoSoBenhAn.Data;
using QuanLyHoSoBenhAn.Services;

namespace QuanLyHoSoBenhAn.Forms
{
    public partial class FrmTiepNhanHoSo : Form
    {
        private readonly TiepNhanService svc = new TiepNhanService();
        private readonly DanhMucService dm = new DanhMucService();
        private readonly KhamBenhService kham = new KhamBenhService();

        public FrmTiepNhanHoSo()
        {
            InitializeComponent();
        }

        private void FrmTiepNhanHoSo_Load(object sender, EventArgs e)
        {
            cboGioiTinh.SelectedIndex = 0;
            cboLoaiKham.SelectedIndex = 0;
            dtNgayGioHen.Value = DateTime.Now.AddDays(1);
            TaiDuLieu();
        }

        private void TaiDuLieu()
        {
            var dtHS = svc.LayDanhSachHoSo();
            dgvHoSo.DataSource = dtHS;

            FormHelper.Nap(cboHoSoHen, dtHS, "HoTen", "MaHoSo");
            FormHelper.Nap(cboHoSoKham, dtHS, "HoTen", "MaHoSo");
            FormHelper.Nap(cboKhoa, dm.LayKhoa(), "TenKhoa", "MaK");

            dgvLichHen.DataSource = Db.Query(@"SELECT l.MaLK, l.MaHoSo, h.HoTen, l.NgayGioHen, l.TrangThai, l.GhiChu 
                                              FROM LichKhamDinhKy l 
                                              JOIN HoSoBenhAn h ON l.MaHoSo = h.MaHoSo 
                                              ORDER BY l.NgayGioHen DESC");

            dgvPhieuKham.DataSource = kham.LayPhieuChoKham();
            cboKhoa_SelectedIndexChanged(null, null);
        }

        private void cboKhoa_SelectedIndexChanged(object sender, EventArgs e)
        {
            string maK = FormHelper.Gia(cboKhoa);
            if (!string.IsNullOrEmpty(maK))
                FormHelper.Nap(cboBacSi, dm.LayBacSiTheoKhoa(maK), "HienThi", "MaBS");
        }

        private void btnChonAnh_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog ofd = new OpenFileDialog())
            {
                ofd.Title = "Chọn ảnh chụp 3x4 của bệnh nhân";
                ofd.Filter = "File ảnh (*.jpg;*.jpeg;*.png)|*.jpg;*.jpeg;*.png|Tất cả file (*.*)|*.*";
                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    txtAnh.Text = Path.GetFileName(ofd.FileName);
                }
            }
        }

        private void btnDangKy_Click(object sender, EventArgs e)
        {
            var k = svc.DangKyMoi(txtMaBN.Text, txtHoTen.Text, txtDiaChi.Text, dtNgaySinh.Value,
                cboGioiTinh.Text, txtDienThoai.Text, txtAnh.Text, txtMaHoSo.Text, numLePhi.Value);

            if (FormHelper.Bao(k))
            {
                txtMaBN.Clear(); txtHoTen.Clear(); txtDiaChi.Clear();
                txtDienThoai.Clear(); txtMaHoSo.Clear();
                TaiDuLieu();
            }
        }

        private void btnDatHen_Click(object sender, EventArgs e)
        {
            var k = svc.DatLichKhamDinhKy(txtMaLK.Text, FormHelper.Gia(cboHoSoHen), dtNgayGioHen.Value, txtGhiChuHen.Text);
            if (FormHelper.Bao(k))
            {
                txtMaLK.Clear(); txtGhiChuHen.Clear();
                TaiDuLieu();
            }
        }

        private void btnLapPhieu_Click(object sender, EventArgs e)
        {
            var k = svc.LapPhieuKham(txtMaPK.Text, FormHelper.Gia(cboHoSoKham), FormHelper.Gia(cboBacSi),
                FormHelper.Gia(cboKhoa), cboLoaiKham.Text, txtTrieuChung.Text, numThanNhiet.Value, txtHuyetAp.Text);

            if (FormHelper.Bao(k))
            {
                txtMaPK.Clear(); txtTrieuChung.Clear();
                TaiDuLieu();
            }
        }

        private void btnDong_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}