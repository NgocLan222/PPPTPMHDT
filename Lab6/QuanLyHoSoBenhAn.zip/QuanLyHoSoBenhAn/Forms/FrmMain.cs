﻿using System;
using System.Windows.Forms;

namespace QuanLyHoSoBenhAn.Forms
{
    public partial class FrmMain : Form
    {
        public FrmMain()
        {
            InitializeComponent();
        }

        private void Mo(Form f)
        {
            using (f) f.ShowDialog(this);
        }

        private void btnDanhMuc_Click(object sender, EventArgs e)
        {
            Mo(new FrmDanhMuc());
        }

        private void btnTiepNhan_Click(object sender, EventArgs e)
        {
            Mo(new FrmTiepNhanHoSo());
        }

        private void btnKhamBenh_Click(object sender, EventArgs e)
        {
            Mo(new FrmKhamBenh());
        }

        private void btnXetNghiem_Click(object sender, EventArgs e)
        {
            Mo(new FrmXetNghiem());
        }

        private void btnVienPhi_Click(object sender, EventArgs e)
        {
            Mo(new FrmVienPhi());
        }

        private void btnTheoDoi_Click(object sender, EventArgs e)
        {
            Mo(new FrmTheoDoiSauKham());
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Bạn có thực sự muốn thoát?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                Close();
        }
    }
}