﻿namespace QuanLyHoSoBenhAn.Forms
{
    partial class FrmVienPhi
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblChoThanhToan = new System.Windows.Forms.Label();
            this.dgvChoThanhToan = new System.Windows.Forms.DataGridView();
            this.lblMaHD = new System.Windows.Forms.Label();
            this.txtMaHD = new System.Windows.Forms.TextBox();
            this.lblMaPK = new System.Windows.Forms.Label();
            this.txtMaPK = new System.Windows.Forms.TextBox();
            this.lblHoTen = new System.Windows.Forms.Label();
            this.txtHoTen = new System.Windows.Forms.TextBox();
            this.lblLoaiKham = new System.Windows.Forms.Label();
            this.txtLoaiKham = new System.Windows.Forms.TextBox();
            this.lblTienKham = new System.Windows.Forms.Label();
            this.txtTienKham = new System.Windows.Forms.TextBox();
            this.lblTienXN = new System.Windows.Forms.Label();
            this.txtTienXN = new System.Windows.Forms.TextBox();
            this.lblTienThuoc = new System.Windows.Forms.Label();
            this.txtTienThuoc = new System.Windows.Forms.TextBox();
            this.lblTongTienTieuDe = new System.Windows.Forms.Label();
            this.lblTongTien = new System.Windows.Forms.Label();
            this.btnThanhToan = new System.Windows.Forms.Button();
            this.lblLichSu = new System.Windows.Forms.Label();
            this.dgvLichSu = new System.Windows.Forms.DataGridView();
            this.btnDong = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvChoThanhToan)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLichSu)).BeginInit();
            this.SuspendLayout();
            // 
            // lblChoThanhToan
            // 
            this.lblChoThanhToan.AutoSize = true;
            this.lblChoThanhToan.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblChoThanhToan.Location = new System.Drawing.Point(15, 12);
            this.lblChoThanhToan.Name = "lblChoThanhToan";
            this.lblChoThanhToan.Size = new System.Drawing.Size(262, 20);
            this.lblChoThanhToan.TabIndex = 0;
            this.lblChoThanhToan.Text = "Danh sách đợt khám chờ thanh toán:";
            // 
            // dgvChoThanhToan
            // 
            this.dgvChoThanhToan.AllowUserToAddRows = false;
            this.dgvChoThanhToan.AllowUserToDeleteRows = false;
            this.dgvChoThanhToan.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvChoThanhToan.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvChoThanhToan.BackgroundColor = System.Drawing.Color.White;
            this.dgvChoThanhToan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvChoThanhToan.Location = new System.Drawing.Point(15, 35);
            this.dgvChoThanhToan.Name = "dgvChoThanhToan";
            this.dgvChoThanhToan.ReadOnly = true;
            this.dgvChoThanhToan.RowHeadersWidth = 51;
            this.dgvChoThanhToan.RowTemplate.Height = 24;
            this.dgvChoThanhToan.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvChoThanhToan.Size = new System.Drawing.Size(945, 165);
            this.dgvChoThanhToan.TabIndex = 1;
            this.dgvChoThanhToan.SelectionChanged += new System.EventHandler(this.dgvChoThanhToan_SelectionChanged);
            // 
            // lblMaHD
            // 
            this.lblMaHD.AutoSize = true;
            this.lblMaHD.Location = new System.Drawing.Point(15, 218);
            this.lblMaHD.Name = "lblMaHD";
            this.lblMaHD.Size = new System.Drawing.Size(87, 17);
            this.lblMaHD.TabIndex = 2;
            this.lblMaHD.Text = "Mã hóa đơn:";
            // 
            // txtMaHD
            // 
            this.txtMaHD.Location = new System.Drawing.Point(105, 215);
            this.txtMaHD.Name = "txtMaHD";
            this.txtMaHD.Size = new System.Drawing.Size(120, 22);
            this.txtMaHD.TabIndex = 3;
            // 
            // lblMaPK
            // 
            this.lblMaPK.AutoSize = true;
            this.lblMaPK.Location = new System.Drawing.Point(245, 218);
            this.lblMaPK.Name = "lblMaPK";
            this.lblMaPK.Size = new System.Drawing.Size(89, 17);
            this.lblMaPK.TabIndex = 4;
            this.lblMaPK.Text = "Phiếu khám:";
            // 
            // txtMaPK
            // 
            this.txtMaPK.Location = new System.Drawing.Point(335, 215);
            this.txtMaPK.Name = "txtMaPK";
            this.txtMaPK.ReadOnly = true;
            this.txtMaPK.Size = new System.Drawing.Size(120, 22);
            this.txtMaPK.TabIndex = 5;
            // 
            // lblHoTen
            // 
            this.lblHoTen.AutoSize = true;
            this.lblHoTen.Location = new System.Drawing.Point(475, 218);
            this.lblHoTen.Name = "lblHoTen";
            this.lblHoTen.Size = new System.Drawing.Size(81, 17);
            this.lblHoTen.TabIndex = 6;
            this.lblHoTen.Text = "Bệnh nhân:";
            // 
            // txtHoTen
            // 
            this.txtHoTen.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtHoTen.Location = new System.Drawing.Point(560, 215);
            this.txtHoTen.Name = "txtHoTen";
            this.txtHoTen.ReadOnly = true;
            this.txtHoTen.Size = new System.Drawing.Size(200, 22);
            this.txtHoTen.TabIndex = 7;
            // 
            // lblLoaiKham
            // 
            this.lblLoaiKham.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblLoaiKham.AutoSize = true;
            this.lblLoaiKham.Location = new System.Drawing.Point(775, 218);
            this.lblLoaiKham.Name = "lblLoaiKham";
            this.lblLoaiKham.Size = new System.Drawing.Size(78, 17);
            this.lblLoaiKham.TabIndex = 8;
            this.lblLoaiKham.Text = "Loại khám:";
            // 
            // txtLoaiKham
            // 
            this.txtLoaiKham.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtLoaiKham.Location = new System.Drawing.Point(855, 215);
            this.txtLoaiKham.Name = "txtLoaiKham";
            this.txtLoaiKham.ReadOnly = true;
            this.txtLoaiKham.Size = new System.Drawing.Size(105, 22);
            this.txtLoaiKham.TabIndex = 9;
            // 
            // lblTienKham
            // 
            this.lblTienKham.AutoSize = true;
            this.lblTienKham.Location = new System.Drawing.Point(15, 258);
            this.lblTienKham.Name = "lblTienKham";
            this.lblTienKham.Size = new System.Drawing.Size(79, 17);
            this.lblTienKham.TabIndex = 10;
            this.lblTienKham.Text = "Tiền khám:";
            // 
            // txtTienKham
            // 
            this.txtTienKham.Location = new System.Drawing.Point(105, 255);
            this.txtTienKham.Name = "txtTienKham";
            this.txtTienKham.ReadOnly = true;
            this.txtTienKham.Size = new System.Drawing.Size(120, 22);
            this.txtTienKham.TabIndex = 11;
            this.txtTienKham.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblTienXN
            // 
            this.lblTienXN.AutoSize = true;
            this.lblTienXN.Location = new System.Drawing.Point(245, 258);
            this.lblTienXN.Name = "lblTienXN";
            this.lblTienXN.Size = new System.Drawing.Size(63, 17);
            this.lblTienXN.TabIndex = 12;
            this.lblTienXN.Text = "Tiền XN:";
            // 
            // txtTienXN
            // 
            this.txtTienXN.Location = new System.Drawing.Point(335, 255);
            this.txtTienXN.Name = "txtTienXN";
            this.txtTienXN.ReadOnly = true;
            this.txtTienXN.Size = new System.Drawing.Size(120, 22);
            this.txtTienXN.TabIndex = 13;
            this.txtTienXN.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblTienThuoc
            // 
            this.lblTienThuoc.AutoSize = true;
            this.lblTienThuoc.Location = new System.Drawing.Point(475, 258);
            this.lblTienThuoc.Name = "lblTienThuoc";
            this.lblTienThuoc.Size = new System.Drawing.Size(79, 17);
            this.lblTienThuoc.TabIndex = 14;
            this.lblTienThuoc.Text = "Tiền thuốc:";
            // 
            // txtTienThuoc
            // 
            this.txtTienThuoc.Location = new System.Drawing.Point(560, 255);
            this.txtTienThuoc.Name = "txtTienThuoc";
            this.txtTienThuoc.ReadOnly = true;
            this.txtTienThuoc.Size = new System.Drawing.Size(120, 22);
            this.txtTienThuoc.TabIndex = 15;
            this.txtTienThuoc.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblTongTienTieuDe
            // 
            this.lblTongTienTieuDe.AutoSize = true;
            this.lblTongTienTieuDe.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.lblTongTienTieuDe.Location = new System.Drawing.Point(15, 298);
            this.lblTongTienTieuDe.Name = "lblTongTienTieuDe";
            this.lblTongTienTieuDe.Size = new System.Drawing.Size(142, 23);
            this.lblTongTienTieuDe.TabIndex = 16;
            this.lblTongTienTieuDe.Text = "Tổng viện phí thu:";
            // 
            // lblTongTien
            // 
            this.lblTongTien.AutoSize = true;
            this.lblTongTien.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold);
            this.lblTongTien.ForeColor = System.Drawing.Color.DarkRed;
            this.lblTongTien.Location = new System.Drawing.Point(165, 294);
            this.lblTongTien.Name = "lblTongTien";
            this.lblTongTien.Size = new System.Drawing.Size(49, 30);
            this.lblTongTien.TabIndex = 17;
            this.lblTongTien.Text = "0 đ";
            // 
            // btnThanhToan
            // 
            this.btnThanhToan.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnThanhToan.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnThanhToan.Location = new System.Drawing.Point(740, 275);
            this.btnThanhToan.Name = "btnThanhToan";
            this.btnThanhToan.Size = new System.Drawing.Size(220, 48);
            this.btnThanhToan.TabIndex = 18;
            this.btnThanhToan.Text = "Thanh toán & Xuất viện";
            this.btnThanhToan.UseVisualStyleBackColor = true;
            this.btnThanhToan.Click += new System.EventHandler(this.btnThanhToan_Click);
            // 
            // lblLichSu
            // 
            this.lblLichSu.AutoSize = true;
            this.lblLichSu.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblLichSu.Location = new System.Drawing.Point(15, 340);
            this.lblLichSu.Name = "lblLichSu";
            this.lblLichSu.Size = new System.Drawing.Size(211, 20);
            this.lblLichSu.TabIndex = 19;
            this.lblLichSu.Text = "Lịch sử hóa đơn đã thu tiền:";
            // 
            // dgvLichSu
            // 
            this.dgvLichSu.AllowUserToAddRows = false;
            this.dgvLichSu.AllowUserToDeleteRows = false;
            this.dgvLichSu.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvLichSu.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvLichSu.BackgroundColor = System.Drawing.Color.White;
            this.dgvLichSu.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvLichSu.Location = new System.Drawing.Point(15, 365);
            this.dgvLichSu.Name = "dgvLichSu";
            this.dgvLichSu.ReadOnly = true;
            this.dgvLichSu.RowHeadersWidth = 51;
            this.dgvLichSu.RowTemplate.Height = 24;
            this.dgvLichSu.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvLichSu.Size = new System.Drawing.Size(945, 185);
            this.dgvLichSu.TabIndex = 20;
            // 
            // btnDong
            // 
            this.btnDong.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDong.Location = new System.Drawing.Point(850, 560);
            this.btnDong.Name = "btnDong";
            this.btnDong.Size = new System.Drawing.Size(110, 35);
            this.btnDong.TabIndex = 21;
            this.btnDong.Text = "Đóng";
            this.btnDong.UseVisualStyleBackColor = true;
            this.btnDong.Click += new System.EventHandler(this.btnDong_Click);
            // 
            // FrmVienPhi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(975, 605);
            this.Controls.Add(this.btnDong);
            this.Controls.Add(this.dgvLichSu);
            this.Controls.Add(this.lblLichSu);
            this.Controls.Add(this.btnThanhToan);
            this.Controls.Add(this.lblTongTien);
            this.Controls.Add(this.lblTongTienTieuDe);
            this.Controls.Add(this.txtTienThuoc);
            this.Controls.Add(this.lblTienThuoc);
            this.Controls.Add(this.txtTienXN);
            this.Controls.Add(this.lblTienXN);
            this.Controls.Add(this.txtTienKham);
            this.Controls.Add(this.lblTienKham);
            this.Controls.Add(this.txtLoaiKham);
            this.Controls.Add(this.lblLoaiKham);
            this.Controls.Add(this.txtHoTen);
            this.Controls.Add(this.lblHoTen);
            this.Controls.Add(this.txtMaPK);
            this.Controls.Add(this.lblMaPK);
            this.Controls.Add(this.txtMaHD);
            this.Controls.Add(this.lblMaHD);
            this.Controls.Add(this.dgvChoThanhToan);
            this.Controls.Add(this.lblChoThanhToan);
            this.Name = "FrmVienPhi";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Thanh toán viện phí & Xuất viện";
            this.Load += new System.EventHandler(this.FrmVienPhi_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvChoThanhToan)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLichSu)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Label lblChoThanhToan;
        private System.Windows.Forms.DataGridView dgvChoThanhToan;
        private System.Windows.Forms.Label lblMaHD;
        private System.Windows.Forms.TextBox txtMaHD;
        private System.Windows.Forms.Label lblMaPK;
        private System.Windows.Forms.TextBox txtMaPK;
        private System.Windows.Forms.Label lblHoTen;
        private System.Windows.Forms.TextBox txtHoTen;
        private System.Windows.Forms.Label lblLoaiKham;
        private System.Windows.Forms.TextBox txtLoaiKham;
        private System.Windows.Forms.Label lblTienKham;
        private System.Windows.Forms.TextBox txtTienKham;
        private System.Windows.Forms.Label lblTienXN;
        private System.Windows.Forms.TextBox txtTienXN;
        private System.Windows.Forms.Label lblTienThuoc;
        private System.Windows.Forms.TextBox txtTienThuoc;
        private System.Windows.Forms.Label lblTongTienTieuDe;
        private System.Windows.Forms.Label lblTongTien;
        private System.Windows.Forms.Button btnThanhToan;
        private System.Windows.Forms.Label lblLichSu;
        private System.Windows.Forms.DataGridView dgvLichSu;
        private System.Windows.Forms.Button btnDong;
    }
}