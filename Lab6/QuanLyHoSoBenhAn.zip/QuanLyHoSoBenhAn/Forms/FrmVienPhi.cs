﻿using System;
using System.Windows.Forms;
using QuanLyHoSoBenhAn.Data;
using QuanLyHoSoBenhAn.Services;

namespace QuanLyHoSoBenhAn.Forms
{
    public partial class FrmVienPhi : Form
    {
        private readonly VienPhiService vpSvc = new VienPhiService();

        public FrmVienPhi()
        {
            InitializeComponent();
        }

        private void FrmVienPhi_Load(object sender, EventArgs e)
        {
            TaiDuLieu();
        }

        private void TaiDuLieu()
        {
            dgvChoThanhToan.DataSource = vpSvc.LayDanhSachChoThanhToan();
            dgvLichSu.DataSource = Db.Query(@"SELECT hd.MaHD, hd.MaPK, h.HoTen, p.LoaiKham, hd.NgayThanhToan, 
                                                     hd.TienKham, hd.TienXetNghiem, hd.TienThuoc, hd.TongTien, hd.TrangThai 
                                              FROM HoaDonVienPhi hd 
                                              JOIN PhieuKhamBenh p ON hd.MaPK = p.MaPK 
                                              JOIN HoSoBenhAn h ON p.MaHoSo = h.MaHoSo 
                                              ORDER BY hd.NgayThanhToan DESC");
        }

        private void dgvChoThanhToan_SelectionChanged(object sender, EventArgs e)
        {
            string pk = FormHelper.O(dgvChoThanhToan, "MaPK");
            if (string.IsNullOrEmpty(pk)) return;

            txtMaPK.Text = pk;
            txtMaHD.Text = "HD_" + pk;
            txtHoTen.Text = FormHelper.O(dgvChoThanhToan, "HoTen");
            txtLoaiKham.Text = FormHelper.O(dgvChoThanhToan, "LoaiKham");

            decimal tienKham = Convert.ToDecimal(FormHelper.O(dgvChoThanhToan, "TienKham"));
            decimal tienXN = Convert.ToDecimal(FormHelper.O(dgvChoThanhToan, "TienXetNghiem"));
            decimal tienThuoc = Convert.ToDecimal(FormHelper.O(dgvChoThanhToan, "TienThuoc"));
            decimal tong = tienKham + tienXN + tienThuoc;

            txtTienKham.Text = tienKham.ToString("N0") + " đ";
            txtTienXN.Text = tienXN.ToString("N0") + " đ";
            txtTienThuoc.Text = tienThuoc.ToString("N0") + " đ";
            lblTongTien.Text = tong.ToString("N0") + " đ";
        }

        private void btnThanhToan_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtMaPK.Text))
            {
                MessageBox.Show("Vui lòng chọn đợt khám cần thanh toán.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            decimal tienKham = Convert.ToDecimal(FormHelper.O(dgvChoThanhToan, "TienKham"));
            decimal tienXN = Convert.ToDecimal(FormHelper.O(dgvChoThanhToan, "TienXetNghiem"));
            decimal tienThuoc = Convert.ToDecimal(FormHelper.O(dgvChoThanhToan, "TienThuoc"));

            var k = vpSvc.ThanhToan(txtMaHD.Text, txtMaPK.Text, tienKham, tienXN, tienThuoc);
            if (FormHelper.Bao(k))
            {
                txtMaPK.Clear(); txtMaHD.Clear(); txtHoTen.Clear(); txtLoaiKham.Clear();
                txtTienKham.Clear(); txtTienXN.Clear(); txtTienThuoc.Clear();
                lblTongTien.Text = "0 đ";
                TaiDuLieu();
            }
        }

        private void btnDong_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}