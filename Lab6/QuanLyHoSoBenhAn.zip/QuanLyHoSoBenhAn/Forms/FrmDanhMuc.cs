﻿using System;
using System.Windows.Forms;
using QuanLyHoSoBenhAn.Services;

namespace QuanLyHoSoBenhAn.Forms
{
    public partial class FrmDanhMuc : Form
    {
        private readonly DanhMucService svc = new DanhMucService();

        public FrmDanhMuc()
        {
            InitializeComponent();
        }

        private void FrmDanhMuc_Load(object sender, EventArgs e)
        {
            Tai();
        }

        private void Tai()
        {
            dgvKhoa.DataSource = svc.LayKhoa();
            FormHelper.Nap(cboKhoaBS, svc.LayKhoa(), "TenKhoa", "MaK");
            dgvBS.DataSource = svc.LayBacSi();
            dgvLXN.DataSource = svc.LayLoaiXetNghiem();
            dgvThuoc.DataSource = svc.LayThuoc();
        }

        private void btnThemKhoa_Click(object sender, EventArgs e)
        {
            if (FormHelper.Bao(svc.ThemKhoa(txtMaK.Text, txtTenKhoa.Text)))
            {
                txtMaK.Clear(); txtTenKhoa.Clear();
                Tai();
            }
        }

        private void btnThemBS_Click(object sender, EventArgs e)
        {
            if (FormHelper.Bao(svc.ThemBacSi(txtMaBS.Text, txtTenBS.Text, FormHelper.Gia(cboKhoaBS), txtDTBS.Text)))
            {
                txtMaBS.Clear(); txtTenBS.Clear(); txtDTBS.Clear();
                Tai();
            }
        }

        private void btnThemLXN_Click(object sender, EventArgs e)
        {
            if (FormHelper.Bao(svc.ThemLoaiXN(txtMaLXN.Text, txtTenLXN.Text, numGiaLXN.Value)))
            {
                txtMaLXN.Clear(); txtTenLXN.Clear(); numGiaLXN.Value = 0;
                Tai();
            }
        }

        private void btnThemThuoc_Click(object sender, EventArgs e)
        {
            if (FormHelper.Bao(svc.ThemThuoc(txtMaThuoc.Text, txtTenThuoc.Text, txtDVT.Text, numGiaThuoc.Value, txtCongDung.Text, txtChongChiDinh.Text)))
            {
                txtMaThuoc.Clear(); txtTenThuoc.Clear(); txtDVT.Clear(); txtCongDung.Clear(); txtChongChiDinh.Clear();
                Tai();
            }
        }

        private void btnDong_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}