﻿namespace QuanLyHoSoBenhAn.Forms
{
    partial class FrmTheoDoiSauKham
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblXuatVien = new System.Windows.Forms.Label();
            this.dgvXuatVien = new System.Windows.Forms.DataGridView();
            this.lblMaTD = new System.Windows.Forms.Label();
            this.txtMaTD = new System.Windows.Forms.TextBox();
            this.lblMaPK = new System.Windows.Forms.Label();
            this.txtMaPK = new System.Windows.Forms.TextBox();
            this.lblHoTen = new System.Windows.Forms.Label();
            this.txtHoTen = new System.Windows.Forms.TextBox();
            this.lblNgayTheoDoi = new System.Windows.Forms.Label();
            this.dtNgayTheoDoi = new System.Windows.Forms.DateTimePicker();
            this.lblDienBien = new System.Windows.Forms.Label();
            this.txtDienBien = new System.Windows.Forms.TextBox();
            this.lblPhanUngPhu = new System.Windows.Forms.Label();
            this.txtPhanUngPhu = new System.Windows.Forms.TextBox();
            this.lblHieuQua = new System.Windows.Forms.Label();
            this.cboHieuQua = new System.Windows.Forms.ComboBox();
            this.btnGhiNhan = new System.Windows.Forms.Button();
            this.lblLichSu = new System.Windows.Forms.Label();
            this.dgvLichSu = new System.Windows.Forms.DataGridView();
            this.btnDong = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvXuatVien)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLichSu)).BeginInit();
            this.SuspendLayout();
            // 
            // lblXuatVien
            // 
            this.lblXuatVien.AutoSize = true;
            this.lblXuatVien.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblXuatVien.Location = new System.Drawing.Point(15, 12);
            this.lblXuatVien.Name = "lblXuatVien";
            this.lblXuatVien.Size = new System.Drawing.Size(350, 20);
            this.lblXuatVien.TabIndex = 0;
            this.lblXuatVien.Text = "Danh sách bệnh nhân đã thanh toán xuất viện chờ theo dõi:";
            // 
            // dgvXuatVien
            // 
            this.dgvXuatVien.AllowUserToAddRows = false;
            this.dgvXuatVien.AllowUserToDeleteRows = false;
            this.dgvXuatVien.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvXuatVien.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvXuatVien.BackgroundColor = System.Drawing.Color.White;
            this.dgvXuatVien.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvXuatVien.Location = new System.Drawing.Point(15, 35);
            this.dgvXuatVien.Name = "dgvXuatVien";
            this.dgvXuatVien.ReadOnly = true;
            this.dgvXuatVien.RowHeadersWidth = 51;
            this.dgvXuatVien.RowTemplate.Height = 24;
            this.dgvXuatVien.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvXuatVien.Size = new System.Drawing.Size(950, 160);
            this.dgvXuatVien.TabIndex = 1;
            this.dgvXuatVien.SelectionChanged += new System.EventHandler(this.dgvXuatVien_SelectionChanged);
            // 
            // lblMaTD
            // 
            this.lblMaTD.AutoSize = true;
            this.lblMaTD.Location = new System.Drawing.Point(15, 215);
            this.lblMaTD.Name = "lblMaTD";
            this.lblMaTD.Size = new System.Drawing.Size(84, 17);
            this.lblMaTD.TabIndex = 2;
            this.lblMaTD.Text = "Mã theo dõi:";
            // 
            // txtMaTD
            // 
            this.txtMaTD.Location = new System.Drawing.Point(105, 212);
            this.txtMaTD.Name = "txtMaTD";
            this.txtMaTD.Size = new System.Drawing.Size(120, 22);
            this.txtMaTD.TabIndex = 3;
            // 
            // lblMaPK
            // 
            this.lblMaPK.AutoSize = true;
            this.lblMaPK.Location = new System.Drawing.Point(245, 215);
            this.lblMaPK.Name = "lblMaPK";
            this.lblMaPK.Size = new System.Drawing.Size(89, 17);
            this.lblMaPK.TabIndex = 4;
            this.lblMaPK.Text = "Phiếu khám:";
            // 
            // txtMaPK
            // 
            this.txtMaPK.Location = new System.Drawing.Point(340, 212);
            this.txtMaPK.Name = "txtMaPK";
            this.txtMaPK.ReadOnly = true;
            this.txtMaPK.Size = new System.Drawing.Size(120, 22);
            this.txtMaPK.TabIndex = 5;
            // 
            // lblHoTen
            // 
            this.lblHoTen.AutoSize = true;
            this.lblHoTen.Location = new System.Drawing.Point(480, 215);
            this.lblHoTen.Name = "lblHoTen";
            this.lblHoTen.Size = new System.Drawing.Size(81, 17);
            this.lblHoTen.TabIndex = 6;
            this.lblHoTen.Text = "Bệnh nhân:";
            // 
            // txtHoTen
            // 
            this.txtHoTen.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtHoTen.Location = new System.Drawing.Point(565, 212);
            this.txtHoTen.Name = "txtHoTen";
            this.txtHoTen.ReadOnly = true;
            this.txtHoTen.Size = new System.Drawing.Size(210, 22);
            this.txtHoTen.TabIndex = 7;
            // 
            // lblNgayTheoDoi
            // 
            this.lblNgayTheoDoi.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblNgayTheoDoi.AutoSize = true;
            this.lblNgayTheoDoi.Location = new System.Drawing.Point(790, 215);
            this.lblNgayTheoDoi.Name = "lblNgayTheoDoi";
            this.lblNgayTheoDoi.Size = new System.Drawing.Size(45, 17);
            this.lblNgayTheoDoi.TabIndex = 8;
            this.lblNgayTheoDoi.Text = "Ngày:";
            // 
            // dtNgayTheoDoi
            // 
            this.dtNgayTheoDoi.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.dtNgayTheoDoi.CustomFormat = "dd/MM/yyyy";
            this.dtNgayTheoDoi.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtNgayTheoDoi.Location = new System.Drawing.Point(840, 212);
            this.dtNgayTheoDoi.Name = "dtNgayTheoDoi";
            this.dtNgayTheoDoi.Size = new System.Drawing.Size(125, 22);
            this.dtNgayTheoDoi.TabIndex = 9;
            // 
            // lblDienBien
            // 
            this.lblDienBien.AutoSize = true;
            this.lblDienBien.Location = new System.Drawing.Point(15, 255);
            this.lblDienBien.Name = "lblDienBien";
            this.lblDienBien.Size = new System.Drawing.Size(107, 17);
            this.lblDienBien.TabIndex = 10;
            this.lblDienBien.Text = "Diễn biến bệnh:";
            // 
            // txtDienBien
            // 
            this.txtDienBien.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtDienBien.Location = new System.Drawing.Point(135, 252);
            this.txtDienBien.Name = "txtDienBien";
            this.txtDienBien.Size = new System.Drawing.Size(830, 22);
            this.txtDienBien.TabIndex = 11;
            // 
            // lblPhanUngPhu
            // 
            this.lblPhanUngPhu.AutoSize = true;
            this.lblPhanUngPhu.Location = new System.Drawing.Point(15, 295);
            this.lblPhanUngPhu.Name = "lblPhanUngPhu";
            this.lblPhanUngPhu.Size = new System.Drawing.Size(134, 17);
            this.lblPhanUngPhu.TabIndex = 12;
            this.lblPhanUngPhu.Text = "Phản ứng phụ thuốc:";
            // 
            // txtPhanUngPhu
            // 
            this.txtPhanUngPhu.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtPhanUngPhu.Location = new System.Drawing.Point(160, 292);
            this.txtPhanUngPhu.Name = "txtPhanUngPhu";
            this.txtPhanUngPhu.Size = new System.Drawing.Size(430, 22);
            this.txtPhanUngPhu.TabIndex = 13;
            // 
            // lblHieuQua
            // 
            this.lblHieuQua.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblHieuQua.AutoSize = true;
            this.lblHieuQua.Location = new System.Drawing.Point(605, 295);
            this.lblHieuQua.Name = "lblHieuQua";
            this.lblHieuQua.Size = new System.Drawing.Size(70, 17);
            this.lblHieuQua.TabIndex = 14;
            this.lblHieuQua.Text = "Hiệu quả:";
            // 
            // cboHieuQua
            // 
            this.cboHieuQua.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.cboHieuQua.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboHieuQua.FormattingEnabled = true;
            this.cboHieuQua.Items.AddRange(new object[] {
            "Đạt hiệu quả điều trị tốt",
            "Bệnh thuyên giảm rõ rệt",
            "Không thuyên giảm / Cần tái khám",
            "Có phản ứng phụ do thuốc"});
            this.cboHieuQua.Location = new System.Drawing.Point(685, 292);
            this.cboHieuQua.Name = "cboHieuQua";
            this.cboHieuQua.Size = new System.Drawing.Size(280, 24);
            this.cboHieuQua.TabIndex = 15;
            // 
            // btnGhiNhan
            // 
            this.btnGhiNhan.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnGhiNhan.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnGhiNhan.Location = new System.Drawing.Point(745, 330);
            this.btnGhiNhan.Name = "btnGhiNhan";
            this.btnGhiNhan.Size = new System.Drawing.Size(220, 42);
            this.btnGhiNhan.TabIndex = 16;
            this.btnGhiNhan.Text = "Ghi nhận theo dõi";
            this.btnGhiNhan.UseVisualStyleBackColor = true;
            this.btnGhiNhan.Click += new System.EventHandler(this.btnGhiNhan_Click);
            // 
            // lblLichSu
            // 
            this.lblLichSu.AutoSize = true;
            this.lblLichSu.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblLichSu.Location = new System.Drawing.Point(15, 360);
            this.lblLichSu.Name = "lblLichSu";
            this.lblLichSu.Size = new System.Drawing.Size(271, 20);
            this.lblLichSu.TabIndex = 17;
            this.lblLichSu.Text = "Lịch sử đã ghi nhận theo dõi sau khám:";
            // 
            // dgvLichSu
            // 
            this.dgvLichSu.AllowUserToAddRows = false;
            this.dgvLichSu.AllowUserToDeleteRows = false;
            this.dgvLichSu.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvLichSu.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvLichSu.BackgroundColor = System.Drawing.Color.White;
            this.dgvLichSu.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvLichSu.Location = new System.Drawing.Point(15, 385);
            this.dgvLichSu.Name = "dgvLichSu";
            this.dgvLichSu.ReadOnly = true;
            this.dgvLichSu.RowHeadersWidth = 51;
            this.dgvLichSu.RowTemplate.Height = 24;
            this.dgvLichSu.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvLichSu.Size = new System.Drawing.Size(950, 175);
            this.dgvLichSu.TabIndex = 18;
            // 
            // btnDong
            // 
            this.btnDong.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDong.Location = new System.Drawing.Point(855, 570);
            this.btnDong.Name = "btnDong";
            this.btnDong.Size = new System.Drawing.Size(110, 35);
            this.btnDong.TabIndex = 19;
            this.btnDong.Text = "Đóng";
            this.btnDong.UseVisualStyleBackColor = true;
            this.btnDong.Click += new System.EventHandler(this.btnDong_Click);
            // 
            // FrmTheoDoiSauKham
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(980, 615);
            this.Controls.Add(this.btnDong);
            this.Controls.Add(this.dgvLichSu);
            this.Controls.Add(this.lblLichSu);
            this.Controls.Add(this.btnGhiNhan);
            this.Controls.Add(this.cboHieuQua);
            this.Controls.Add(this.lblHieuQua);
            this.Controls.Add(this.txtPhanUngPhu);
            this.Controls.Add(this.lblPhanUngPhu);
            this.Controls.Add(this.txtDienBien);
            this.Controls.Add(this.lblDienBien);
            this.Controls.Add(this.dtNgayTheoDoi);
            this.Controls.Add(this.lblNgayTheoDoi);
            this.Controls.Add(this.txtHoTen);
            this.Controls.Add(this.lblHoTen);
            this.Controls.Add(this.txtMaPK);
            this.Controls.Add(this.lblMaPK);
            this.Controls.Add(this.txtMaTD);
            this.Controls.Add(this.lblMaTD);
            this.Controls.Add(this.dgvXuatVien);
            this.Controls.Add(this.lblXuatVien);
            this.Name = "FrmTheoDoiSauKham";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Chăm sóc khách hàng - Theo dõi sau khám";
            this.Load += new System.EventHandler(this.FrmTheoDoiSauKham_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvXuatVien)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLichSu)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Label lblXuatVien;
        private System.Windows.Forms.DataGridView dgvXuatVien;
        private System.Windows.Forms.Label lblMaTD;
        private System.Windows.Forms.TextBox txtMaTD;
        private System.Windows.Forms.Label lblMaPK;
        private System.Windows.Forms.TextBox txtMaPK;
        private System.Windows.Forms.Label lblHoTen;
        private System.Windows.Forms.TextBox txtHoTen;
        private System.Windows.Forms.Label lblNgayTheoDoi;
        private System.Windows.Forms.DateTimePicker dtNgayTheoDoi;
        private System.Windows.Forms.Label lblDienBien;
        private System.Windows.Forms.TextBox txtDienBien;
        private System.Windows.Forms.Label lblPhanUngPhu;
        private System.Windows.Forms.TextBox txtPhanUngPhu;
        private System.Windows.Forms.Label lblHieuQua;
        private System.Windows.Forms.ComboBox cboHieuQua;
        private System.Windows.Forms.Button btnGhiNhan;
        private System.Windows.Forms.Label lblLichSu;
        private System.Windows.Forms.DataGridView dgvLichSu;
        private System.Windows.Forms.Button btnDong;
    }
}