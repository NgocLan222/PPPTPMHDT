﻿namespace QuanLyHoSoBenhAn.Forms
{
    partial class FrmDanhMuc
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.tabDanhMuc = new System.Windows.Forms.TabControl();
            this.tabKhoa = new System.Windows.Forms.TabPage();
            this.btnThemKhoa = new System.Windows.Forms.Button();
            this.txtTenKhoa = new System.Windows.Forms.TextBox();
            this.lblTenKhoa = new System.Windows.Forms.Label();
            this.txtMaK = new System.Windows.Forms.TextBox();
            this.lblMaK = new System.Windows.Forms.Label();
            this.dgvKhoa = new System.Windows.Forms.DataGridView();
            this.tabBacSi = new System.Windows.Forms.TabPage();
            this.cboKhoaBS = new System.Windows.Forms.ComboBox();
            this.lblKhoaBS = new System.Windows.Forms.Label();
            this.btnThemBS = new System.Windows.Forms.Button();
            this.txtDTBS = new System.Windows.Forms.TextBox();
            this.lblDTBS = new System.Windows.Forms.Label();
            this.txtTenBS = new System.Windows.Forms.TextBox();
            this.lblTenBS = new System.Windows.Forms.Label();
            this.txtMaBS = new System.Windows.Forms.TextBox();
            this.lblMaBS = new System.Windows.Forms.Label();
            this.dgvBS = new System.Windows.Forms.DataGridView();
            this.tabLXN = new System.Windows.Forms.TabPage();
            this.numGiaLXN = new System.Windows.Forms.NumericUpDown();
            this.btnThemLXN = new System.Windows.Forms.Button();
            this.lblGiaLXN = new System.Windows.Forms.Label();
            this.txtTenLXN = new System.Windows.Forms.TextBox();
            this.lblTenLXN = new System.Windows.Forms.Label();
            this.txtMaLXN = new System.Windows.Forms.TextBox();
            this.lblMaLXN = new System.Windows.Forms.Label();
            this.dgvLXN = new System.Windows.Forms.DataGridView();
            this.tabThuoc = new System.Windows.Forms.TabPage();
            this.txtChongChiDinh = new System.Windows.Forms.TextBox();
            this.lblChongChiDinh = new System.Windows.Forms.Label();
            this.txtCongDung = new System.Windows.Forms.TextBox();
            this.lblCongDung = new System.Windows.Forms.Label();
            this.numGiaThuoc = new System.Windows.Forms.NumericUpDown();
            this.lblGiaThuoc = new System.Windows.Forms.Label();
            this.txtDVT = new System.Windows.Forms.TextBox();
            this.lblDVT = new System.Windows.Forms.Label();
            this.btnThemThuoc = new System.Windows.Forms.Button();
            this.txtTenThuoc = new System.Windows.Forms.TextBox();
            this.lblTenThuoc = new System.Windows.Forms.Label();
            this.txtMaThuoc = new System.Windows.Forms.TextBox();
            this.lblMaThuoc = new System.Windows.Forms.Label();
            this.dgvThuoc = new System.Windows.Forms.DataGridView();
            this.btnDong = new System.Windows.Forms.Button();
            this.tabDanhMuc.SuspendLayout();
            this.tabKhoa.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvKhoa)).BeginInit();
            this.tabBacSi.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBS)).BeginInit();
            this.tabLXN.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numGiaLXN)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLXN)).BeginInit();
            this.tabThuoc.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numGiaThuoc)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvThuoc)).BeginInit();
            this.SuspendLayout();
            // 
            // tabDanhMuc
            // 
            this.tabDanhMuc.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabDanhMuc.Controls.Add(this.tabKhoa);
            this.tabDanhMuc.Controls.Add(this.tabBacSi);
            this.tabDanhMuc.Controls.Add(this.tabLXN);
            this.tabDanhMuc.Controls.Add(this.tabThuoc);
            this.tabDanhMuc.Location = new System.Drawing.Point(20, 15);
            this.tabDanhMuc.Name = "tabDanhMuc";
            this.tabDanhMuc.SelectedIndex = 0;
            this.tabDanhMuc.Size = new System.Drawing.Size(920, 520);
            this.tabDanhMuc.TabIndex = 0;
            // 
            // tabKhoa
            // 
            this.tabKhoa.Controls.Add(this.btnThemKhoa);
            this.tabKhoa.Controls.Add(this.txtTenKhoa);
            this.tabKhoa.Controls.Add(this.lblTenKhoa);
            this.tabKhoa.Controls.Add(this.txtMaK);
            this.tabKhoa.Controls.Add(this.lblMaK);
            this.tabKhoa.Controls.Add(this.dgvKhoa);
            this.tabKhoa.Location = new System.Drawing.Point(4, 25);
            this.tabKhoa.Name = "tabKhoa";
            this.tabKhoa.Padding = new System.Windows.Forms.Padding(3);
            this.tabKhoa.Size = new System.Drawing.Size(912, 491);
            this.tabKhoa.TabIndex = 0;
            this.tabKhoa.Text = "Khoa điều trị";
            this.tabKhoa.UseVisualStyleBackColor = true;
            // 
            // btnThemKhoa
            // 
            this.btnThemKhoa.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnThemKhoa.Location = new System.Drawing.Point(775, 420);
            this.btnThemKhoa.Name = "btnThemKhoa";
            this.btnThemKhoa.Size = new System.Drawing.Size(120, 35);
            this.btnThemKhoa.TabIndex = 5;
            this.btnThemKhoa.Text = "Thêm";
            this.btnThemKhoa.UseVisualStyleBackColor = true;
            this.btnThemKhoa.Click += new System.EventHandler(this.btnThemKhoa_Click);
            // 
            // txtTenKhoa
            // 
            this.txtTenKhoa.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtTenKhoa.Location = new System.Drawing.Point(380, 426);
            this.txtTenKhoa.Name = "txtTenKhoa";
            this.txtTenKhoa.Size = new System.Drawing.Size(360, 22);
            this.txtTenKhoa.TabIndex = 4;
            // 
            // lblTenKhoa
            // 
            this.lblTenKhoa.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblTenKhoa.AutoSize = true;
            this.lblTenKhoa.Location = new System.Drawing.Point(300, 429);
            this.lblTenKhoa.Name = "lblTenKhoa";
            this.lblTenKhoa.Size = new System.Drawing.Size(72, 17);
            this.lblTenKhoa.TabIndex = 3;
            this.lblTenKhoa.Text = "Tên khoa:";
            // 
            // txtMaK
            // 
            this.txtMaK.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.txtMaK.Location = new System.Drawing.Point(100, 426);
            this.txtMaK.Name = "txtMaK";
            this.txtMaK.Size = new System.Drawing.Size(170, 22);
            this.txtMaK.TabIndex = 2;
            // 
            // lblMaK
            // 
            this.lblMaK.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblMaK.AutoSize = true;
            this.lblMaK.Location = new System.Drawing.Point(20, 429);
            this.lblMaK.Name = "lblMaK";
            this.lblMaK.Size = new System.Drawing.Size(66, 17);
            this.lblMaK.TabIndex = 1;
            this.lblMaK.Text = "Mã khoa:";
            // 
            // dgvKhoa
            // 
            this.dgvKhoa.AllowUserToAddRows = false;
            this.dgvKhoa.AllowUserToDeleteRows = false;
            this.dgvKhoa.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvKhoa.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvKhoa.BackgroundColor = System.Drawing.Color.White;
            this.dgvKhoa.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvKhoa.Location = new System.Drawing.Point(15, 15);
            this.dgvKhoa.Name = "dgvKhoa";
            this.dgvKhoa.ReadOnly = true;
            this.dgvKhoa.RowHeadersWidth = 51;
            this.dgvKhoa.RowTemplate.Height = 24;
            this.dgvKhoa.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvKhoa.Size = new System.Drawing.Size(880, 385);
            this.dgvKhoa.TabIndex = 0;
            // 
            // tabBacSi
            // 
            this.tabBacSi.Controls.Add(this.cboKhoaBS);
            this.tabBacSi.Controls.Add(this.lblKhoaBS);
            this.tabBacSi.Controls.Add(this.btnThemBS);
            this.tabBacSi.Controls.Add(this.txtDTBS);
            this.tabBacSi.Controls.Add(this.lblDTBS);
            this.tabBacSi.Controls.Add(this.txtTenBS);
            this.tabBacSi.Controls.Add(this.lblTenBS);
            this.tabBacSi.Controls.Add(this.txtMaBS);
            this.tabBacSi.Controls.Add(this.lblMaBS);
            this.tabBacSi.Controls.Add(this.dgvBS);
            this.tabBacSi.Location = new System.Drawing.Point(4, 25);
            this.tabBacSi.Name = "tabBacSi";
            this.tabBacSi.Padding = new System.Windows.Forms.Padding(3);
            this.tabBacSi.Size = new System.Drawing.Size(912, 491);
            this.tabBacSi.TabIndex = 1;
            this.tabBacSi.Text = "Bác sĩ";
            this.tabBacSi.UseVisualStyleBackColor = true;
            // 
            // cboKhoaBS
            // 
            this.cboKhoaBS.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.cboKhoaBS.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboKhoaBS.FormattingEnabled = true;
            this.cboKhoaBS.Location = new System.Drawing.Point(100, 442);
            this.cboKhoaBS.Name = "cboKhoaBS";
            this.cboKhoaBS.Size = new System.Drawing.Size(240, 24);
            this.cboKhoaBS.TabIndex = 7;
            // 
            // lblKhoaBS
            // 
            this.lblKhoaBS.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblKhoaBS.AutoSize = true;
            this.lblKhoaBS.Location = new System.Drawing.Point(20, 445);
            this.lblKhoaBS.Name = "lblKhoaBS";
            this.lblKhoaBS.Size = new System.Drawing.Size(45, 17);
            this.lblKhoaBS.TabIndex = 6;
            this.lblKhoaBS.Text = "Khoa:";
            // 
            // btnThemBS
            // 
            this.btnThemBS.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnThemBS.Location = new System.Drawing.Point(775, 415);
            this.btnThemBS.Name = "btnThemBS";
            this.btnThemBS.Size = new System.Drawing.Size(120, 45);
            this.btnThemBS.TabIndex = 9;
            this.btnThemBS.Text = "Thêm";
            this.btnThemBS.UseVisualStyleBackColor = true;
            this.btnThemBS.Click += new System.EventHandler(this.btnThemBS_Click);
            // 
            // txtDTBS
            // 
            this.txtDTBS.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtDTBS.Location = new System.Drawing.Point(440, 442);
            this.txtDTBS.Name = "txtDTBS";
            this.txtDTBS.Size = new System.Drawing.Size(300, 22);
            this.txtDTBS.TabIndex = 8;
            // 
            // lblDTBS
            // 
            this.lblDTBS.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblDTBS.AutoSize = true;
            this.lblDTBS.Location = new System.Drawing.Point(360, 445);
            this.lblDTBS.Name = "lblDTBS";
            this.lblDTBS.Size = new System.Drawing.Size(76, 17);
            this.lblDTBS.TabIndex = 5;
            this.lblDTBS.Text = "Điện thoại:";
            // 
            // txtTenBS
            // 
            this.txtTenBS.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtTenBS.Location = new System.Drawing.Point(380, 400);
            this.txtTenBS.Name = "txtTenBS";
            this.txtTenBS.Size = new System.Drawing.Size(360, 22);
            this.txtTenBS.TabIndex = 4;
            // 
            // lblTenBS
            // 
            this.lblTenBS.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblTenBS.AutoSize = true;
            this.lblTenBS.Location = new System.Drawing.Point(300, 403);
            this.lblTenBS.Name = "lblTenBS";
            this.lblTenBS.Size = new System.Drawing.Size(54, 17);
            this.lblTenBS.TabIndex = 3;
            this.lblTenBS.Text = "Họ tên:";
            // 
            // txtMaBS
            // 
            this.txtMaBS.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.txtMaBS.Location = new System.Drawing.Point(100, 400);
            this.txtMaBS.Name = "txtMaBS";
            this.txtMaBS.Size = new System.Drawing.Size(170, 22);
            this.txtMaBS.TabIndex = 2;
            // 
            // lblMaBS
            // 
            this.lblMaBS.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblMaBS.AutoSize = true;
            this.lblMaBS.Location = new System.Drawing.Point(20, 403);
            this.lblMaBS.Name = "lblMaBS";
            this.lblMaBS.Size = new System.Drawing.Size(53, 17);
            this.lblMaBS.TabIndex = 1;
            this.lblMaBS.Text = "Mã BS:";
            // 
            // dgvBS
            // 
            this.dgvBS.AllowUserToAddRows = false;
            this.dgvBS.AllowUserToDeleteRows = false;
            this.dgvBS.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvBS.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvBS.BackgroundColor = System.Drawing.Color.White;
            this.dgvBS.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvBS.Location = new System.Drawing.Point(15, 15);
            this.dgvBS.Name = "dgvBS";
            this.dgvBS.ReadOnly = true;
            this.dgvBS.RowHeadersWidth = 51;
            this.dgvBS.RowTemplate.Height = 24;
            this.dgvBS.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvBS.Size = new System.Drawing.Size(880, 365);
            this.dgvBS.TabIndex = 0;
            // 
            // tabLXN
            // 
            this.tabLXN.Controls.Add(this.numGiaLXN);
            this.tabLXN.Controls.Add(this.btnThemLXN);
            this.tabLXN.Controls.Add(this.lblGiaLXN);
            this.tabLXN.Controls.Add(this.txtTenLXN);
            this.tabLXN.Controls.Add(this.lblTenLXN);
            this.tabLXN.Controls.Add(this.txtMaLXN);
            this.tabLXN.Controls.Add(this.lblMaLXN);
            this.tabLXN.Controls.Add(this.dgvLXN);
            this.tabLXN.Location = new System.Drawing.Point(4, 25);
            this.tabLXN.Name = "tabLXN";
            this.tabLXN.Padding = new System.Windows.Forms.Padding(3);
            this.tabLXN.Size = new System.Drawing.Size(912, 491);
            this.tabLXN.TabIndex = 2;
            this.tabLXN.Text = "Loại xét nghiệm";
            this.tabLXN.UseVisualStyleBackColor = true;
            // 
            // numGiaLXN
            // 
            this.numGiaLXN.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.numGiaLXN.Location = new System.Drawing.Point(625, 426);
            this.numGiaLXN.Maximum = new decimal(new int[] { 1000000000, 0, 0, 0 });
            this.numGiaLXN.Name = "numGiaLXN";
            this.numGiaLXN.Size = new System.Drawing.Size(125, 22);
            this.numGiaLXN.TabIndex = 6;
            this.numGiaLXN.ThousandsSeparator = true;
            // 
            // btnThemLXN
            // 
            this.btnThemLXN.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnThemLXN.Location = new System.Drawing.Point(775, 420);
            this.btnThemLXN.Name = "btnThemLXN";
            this.btnThemLXN.Size = new System.Drawing.Size(120, 35);
            this.btnThemLXN.TabIndex = 7;
            this.btnThemLXN.Text = "Thêm";
            this.btnThemLXN.UseVisualStyleBackColor = true;
            this.btnThemLXN.Click += new System.EventHandler(this.btnThemLXN_Click);
            // 
            // lblGiaLXN
            // 
            this.lblGiaLXN.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.lblGiaLXN.AutoSize = true;
            this.lblGiaLXN.Location = new System.Drawing.Point(555, 429);
            this.lblGiaLXN.Name = "lblGiaLXN";
            this.lblGiaLXN.Size = new System.Drawing.Size(61, 17);
            this.lblGiaLXN.TabIndex = 5;
            this.lblGiaLXN.Text = "Đơn giá:";
            // 
            // txtTenLXN
            // 
            this.txtTenLXN.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtTenLXN.Location = new System.Drawing.Point(370, 426);
            this.txtTenLXN.Name = "txtTenLXN";
            this.txtTenLXN.Size = new System.Drawing.Size(165, 22);
            this.txtTenLXN.TabIndex = 4;
            // 
            // lblTenLXN
            // 
            this.lblTenLXN.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblTenLXN.AutoSize = true;
            this.lblTenLXN.Location = new System.Drawing.Point(260, 429);
            this.lblTenLXN.Name = "lblTenLXN";
            this.lblTenLXN.Size = new System.Drawing.Size(107, 17);
            this.lblTenLXN.TabIndex = 3;
            this.lblTenLXN.Text = "Tên xét nghiệm:";
            // 
            // txtMaLXN
            // 
            this.txtMaLXN.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.txtMaLXN.Location = new System.Drawing.Point(130, 426);
            this.txtMaLXN.Name = "txtMaLXN";
            this.txtMaLXN.Size = new System.Drawing.Size(110, 22);
            this.txtMaLXN.TabIndex = 2;
            // 
            // lblMaLXN
            // 
            this.lblMaLXN.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblMaLXN.AutoSize = true;
            this.lblMaLXN.Location = new System.Drawing.Point(20, 429);
            this.lblMaLXN.Name = "lblMaLXN";
            this.lblMaLXN.Size = new System.Drawing.Size(101, 17);
            this.lblMaLXN.TabIndex = 1;
            this.lblMaLXN.Text = "Mã xét nghiệm:";
            // 
            // dgvLXN
            // 
            this.dgvLXN.AllowUserToAddRows = false;
            this.dgvLXN.AllowUserToDeleteRows = false;
            this.dgvLXN.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvLXN.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvLXN.BackgroundColor = System.Drawing.Color.White;
            this.dgvLXN.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvLXN.Location = new System.Drawing.Point(15, 15);
            this.dgvLXN.Name = "dgvLXN";
            this.dgvLXN.ReadOnly = true;
            this.dgvLXN.RowHeadersWidth = 51;
            this.dgvLXN.RowTemplate.Height = 24;
            this.dgvLXN.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvLXN.Size = new System.Drawing.Size(880, 385);
            this.dgvLXN.TabIndex = 0;
            // 
            // tabThuoc
            // 
            this.tabThuoc.Controls.Add(this.txtChongChiDinh);
            this.tabThuoc.Controls.Add(this.lblChongChiDinh);
            this.tabThuoc.Controls.Add(this.txtCongDung);
            this.tabThuoc.Controls.Add(this.lblCongDung);
            this.tabThuoc.Controls.Add(this.numGiaThuoc);
            this.tabThuoc.Controls.Add(this.lblGiaThuoc);
            this.tabThuoc.Controls.Add(this.txtDVT);
            this.tabThuoc.Controls.Add(this.lblDVT);
            this.tabThuoc.Controls.Add(this.btnThemThuoc);
            this.tabThuoc.Controls.Add(this.txtTenThuoc);
            this.tabThuoc.Controls.Add(this.lblTenThuoc);
            this.tabThuoc.Controls.Add(this.txtMaThuoc);
            this.tabThuoc.Controls.Add(this.lblMaThuoc);
            this.tabThuoc.Controls.Add(this.dgvThuoc);
            this.tabThuoc.Location = new System.Drawing.Point(4, 25);
            this.tabThuoc.Name = "tabThuoc";
            this.tabThuoc.Padding = new System.Windows.Forms.Padding(3);
            this.tabThuoc.Size = new System.Drawing.Size(912, 491);
            this.tabThuoc.TabIndex = 3;
            this.tabThuoc.Text = "Thuốc";
            this.tabThuoc.UseVisualStyleBackColor = true;
            // 
            // txtChongChiDinh
            // 
            this.txtChongChiDinh.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.txtChongChiDinh.Location = new System.Drawing.Point(475, 445);
            this.txtChongChiDinh.Name = "txtChongChiDinh";
            this.txtChongChiDinh.Size = new System.Drawing.Size(265, 22);
            this.txtChongChiDinh.TabIndex = 12;
            // 
            // lblChongChiDinh
            // 
            this.lblChongChiDinh.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.lblChongChiDinh.AutoSize = true;
            this.lblChongChiDinh.Location = new System.Drawing.Point(385, 448);
            this.lblChongChiDinh.Name = "lblChongChiDinh";
            this.lblChongChiDinh.Size = new System.Drawing.Size(78, 17);
            this.lblChongChiDinh.TabIndex = 11;
            this.lblChongChiDinh.Text = "Chống CĐ:";
            // 
            // txtCongDung
            // 
            this.txtCongDung.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtCongDung.Location = new System.Drawing.Point(105, 445);
            this.txtCongDung.Name = "txtCongDung";
            this.txtCongDung.Size = new System.Drawing.Size(260, 22);
            this.txtCongDung.TabIndex = 10;
            // 
            // lblCongDung
            // 
            this.lblCongDung.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblCongDung.AutoSize = true;
            this.lblCongDung.Location = new System.Drawing.Point(15, 448);
            this.lblCongDung.Name = "lblCongDung";
            this.lblCongDung.Size = new System.Drawing.Size(80, 17);
            this.lblCongDung.TabIndex = 9;
            this.lblCongDung.Text = "Công dụng:";
            // 
            // numGiaThuoc
            // 
            this.numGiaThuoc.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.numGiaThuoc.Location = new System.Drawing.Point(625, 405);
            this.numGiaThuoc.Maximum = new decimal(new int[] { 1000000000, 0, 0, 0 });
            this.numGiaThuoc.Name = "numGiaThuoc";
            this.numGiaThuoc.Size = new System.Drawing.Size(115, 22);
            this.numGiaThuoc.TabIndex = 8;
            this.numGiaThuoc.ThousandsSeparator = true;
            // 
            // lblGiaThuoc
            // 
            this.lblGiaThuoc.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.lblGiaThuoc.AutoSize = true;
            this.lblGiaThuoc.Location = new System.Drawing.Point(585, 408);
            this.lblGiaThuoc.Name = "lblGiaThuoc";
            this.lblGiaThuoc.Size = new System.Drawing.Size(34, 17);
            this.lblGiaThuoc.TabIndex = 7;
            this.lblGiaThuoc.Text = "Giá:";
            // 
            // txtDVT
            // 
            this.txtDVT.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.txtDVT.Location = new System.Drawing.Point(500, 405);
            this.txtDVT.Name = "txtDVT";
            this.txtDVT.Size = new System.Drawing.Size(70, 22);
            this.txtDVT.TabIndex = 6;
            // 
            // lblDVT
            // 
            this.lblDVT.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.lblDVT.AutoSize = true;
            this.lblDVT.Location = new System.Drawing.Point(455, 408);
            this.lblDVT.Name = "lblDVT";
            this.lblDVT.Size = new System.Drawing.Size(40, 17);
            this.lblDVT.TabIndex = 5;
            this.lblDVT.Text = "ĐVT:";
            // 
            // btnThemThuoc
            // 
            this.btnThemThuoc.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnThemThuoc.Location = new System.Drawing.Point(775, 415);
            this.btnThemThuoc.Name = "btnThemThuoc";
            this.btnThemThuoc.Size = new System.Drawing.Size(120, 45);
            this.btnThemThuoc.TabIndex = 13;
            this.btnThemThuoc.Text = "Thêm";
            this.btnThemThuoc.UseVisualStyleBackColor = true;
            this.btnThemThuoc.Click += new System.EventHandler(this.btnThemThuoc_Click);
            // 
            // txtTenThuoc
            // 
            this.txtTenThuoc.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtTenThuoc.Location = new System.Drawing.Point(280, 405);
            this.txtTenThuoc.Name = "txtTenThuoc";
            this.txtTenThuoc.Size = new System.Drawing.Size(160, 22);
            this.txtTenThuoc.TabIndex = 4;
            // 
            // lblTenThuoc
            // 
            this.lblTenThuoc.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblTenThuoc.AutoSize = true;
            this.lblTenThuoc.Location = new System.Drawing.Point(210, 408);
            this.lblTenThuoc.Name = "lblTenThuoc";
            this.lblTenThuoc.Size = new System.Drawing.Size(64, 17);
            this.lblTenThuoc.TabIndex = 3;
            this.lblTenThuoc.Text = "Tên thuốc:";
            // 
            // txtMaThuoc
            // 
            this.txtMaThuoc.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.txtMaThuoc.Location = new System.Drawing.Point(90, 405);
            this.txtMaThuoc.Name = "txtMaThuoc";
            this.txtMaThuoc.Size = new System.Drawing.Size(110, 22);
            this.txtMaThuoc.TabIndex = 2;
            // 
            // lblMaThuoc
            // 
            this.lblMaThuoc.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblMaThuoc.AutoSize = true;
            this.lblMaThuoc.Location = new System.Drawing.Point(15, 408);
            this.lblMaThuoc.Name = "lblMaThuoc";
            this.lblMaThuoc.Size = new System.Drawing.Size(58, 17);
            this.lblMaThuoc.TabIndex = 1;
            this.lblMaThuoc.Text = "Mã thuốc:";
            // 
            // dgvThuoc
            // 
            this.dgvThuoc.AllowUserToAddRows = false;
            this.dgvThuoc.AllowUserToDeleteRows = false;
            this.dgvThuoc.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvThuoc.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvThuoc.BackgroundColor = System.Drawing.Color.White;
            this.dgvThuoc.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvThuoc.Location = new System.Drawing.Point(15, 15);
            this.dgvThuoc.Name = "dgvThuoc";
            this.dgvThuoc.ReadOnly = true;
            this.dgvThuoc.RowHeadersWidth = 51;
            this.dgvThuoc.RowTemplate.Height = 24;
            this.dgvThuoc.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvThuoc.Size = new System.Drawing.Size(880, 370);
            this.dgvThuoc.TabIndex = 0;
            // 
            // btnDong
            // 
            this.btnDong.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDong.Location = new System.Drawing.Point(825, 545);
            this.btnDong.Name = "btnDong";
            this.btnDong.Size = new System.Drawing.Size(110, 35);
            this.btnDong.TabIndex = 1;
            this.btnDong.Text = "Đóng";
            this.btnDong.UseVisualStyleBackColor = true;
            this.btnDong.Click += new System.EventHandler(this.btnDong_Click);
            // 
            // FrmDanhMuc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(960, 595);
            this.Controls.Add(this.btnDong);
            this.Controls.Add(this.tabDanhMuc);
            this.Name = "FrmDanhMuc";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Danh mục hệ thống";
            this.Load += new System.EventHandler(this.FrmDanhMuc_Load);
            this.tabDanhMuc.ResumeLayout(false);
            this.tabKhoa.ResumeLayout(false);
            this.tabKhoa.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvKhoa)).EndInit();
            this.tabBacSi.ResumeLayout(false);
            this.tabBacSi.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBS)).EndInit();
            this.tabLXN.ResumeLayout(false);
            this.tabLXN.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numGiaLXN)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLXN)).EndInit();
            this.tabThuoc.ResumeLayout(false);
            this.tabThuoc.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numGiaThuoc)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvThuoc)).EndInit();
            this.ResumeLayout(false);
        }

        private System.Windows.Forms.TabControl tabDanhMuc;
        private System.Windows.Forms.TabPage tabKhoa;
        private System.Windows.Forms.TabPage tabBacSi;
        private System.Windows.Forms.TabPage tabLXN;
        private System.Windows.Forms.TabPage tabThuoc;
        private System.Windows.Forms.DataGridView dgvKhoa;
        private System.Windows.Forms.Label lblMaK;
        private System.Windows.Forms.TextBox txtMaK;
        private System.Windows.Forms.Label lblTenKhoa;
        private System.Windows.Forms.TextBox txtTenKhoa;
        private System.Windows.Forms.Button btnThemKhoa;
        private System.Windows.Forms.DataGridView dgvBS;
        private System.Windows.Forms.Label lblMaBS;
        private System.Windows.Forms.TextBox txtMaBS;
        private System.Windows.Forms.Label lblTenBS;
        private System.Windows.Forms.TextBox txtTenBS;
        private System.Windows.Forms.Label lblKhoaBS;
        private System.Windows.Forms.ComboBox cboKhoaBS;
        private System.Windows.Forms.Label lblDTBS;
        private System.Windows.Forms.TextBox txtDTBS;
        private System.Windows.Forms.Button btnThemBS;
        private System.Windows.Forms.DataGridView dgvLXN;
        private System.Windows.Forms.Label lblMaLXN;
        private System.Windows.Forms.TextBox txtMaLXN;
        private System.Windows.Forms.Label lblTenLXN;
        private System.Windows.Forms.TextBox txtTenLXN;
        private System.Windows.Forms.Label lblGiaLXN;
        private System.Windows.Forms.NumericUpDown numGiaLXN;
        private System.Windows.Forms.Button btnThemLXN;
        private System.Windows.Forms.DataGridView dgvThuoc;
        private System.Windows.Forms.Label lblMaThuoc;
        private System.Windows.Forms.TextBox txtMaThuoc;
        private System.Windows.Forms.Label lblTenThuoc;
        private System.Windows.Forms.TextBox txtTenThuoc;
        private System.Windows.Forms.Label lblDVT;
        private System.Windows.Forms.TextBox txtDVT;
        private System.Windows.Forms.Label lblGiaThuoc;
        private System.Windows.Forms.NumericUpDown numGiaThuoc;
        private System.Windows.Forms.Label lblCongDung;
        private System.Windows.Forms.TextBox txtCongDung;
        private System.Windows.Forms.Label lblChongChiDinh;
        private System.Windows.Forms.TextBox txtChongChiDinh;
        private System.Windows.Forms.Button btnThemThuoc;
        private System.Windows.Forms.Button btnDong;
    }
}