﻿using System;
using System.Windows.Forms;
using QuanLyHoSoBenhAn.Services;

namespace QuanLyHoSoBenhAn.Forms
{
    public partial class FrmTheoDoiSauKham : Form
    {
        private readonly TheoDoiService tdSvc = new TheoDoiService();
        private string maHoSoHienTai = "";

        public FrmTheoDoiSauKham()
        {
            InitializeComponent();
        }

        private void FrmTheoDoiSauKham_Load(object sender, EventArgs e)
        {
            cboHieuQua.SelectedIndex = 0;
            dtNgayTheoDoi.Value = DateTime.Today;
            TaiDuLieu();
        }

        private void TaiDuLieu()
        {
            dgvXuatVien.DataSource = tdSvc.LayDanhSachDaXuatVien();
            dgvLichSu.DataSource = tdSvc.LayLichSuTheoDoi();
        }

        private void dgvXuatVien_SelectionChanged(object sender, EventArgs e)
        {
            string pk = FormHelper.O(dgvXuatVien, "MaPK");
            if (string.IsNullOrEmpty(pk)) return;

            txtMaPK.Text = pk;
            txtMaTD.Text = "TD_" + pk;
            maHoSoHienTai = FormHelper.O(dgvXuatVien, "MaHoSo");
            txtHoTen.Text = FormHelper.O(dgvXuatVien, "HoTen");

            txtDienBien.Clear();
            txtPhanUngPhu.Clear();
        }

        private void btnGhiNhan_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtMaPK.Text))
            {
                MessageBox.Show("Vui lòng chọn đợt khám của bệnh nhân cần ghi nhận theo dõi.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var k = tdSvc.GhiNhan(txtMaTD.Text, txtMaPK.Text, maHoSoHienTai, dtNgayTheoDoi.Value,
                txtDienBien.Text, txtPhanUngPhu.Text, cboHieuQua.Text);

            if (FormHelper.Bao(k))
            {
                txtMaTD.Clear(); txtMaPK.Clear(); txtHoTen.Clear();
                txtDienBien.Clear(); txtPhanUngPhu.Clear();
                TaiDuLieu();
            }
        }

        private void btnDong_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}