﻿namespace QuanLyHoSoBenhAn.Forms
{
    partial class FrmTiepNhanHoSo
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.tabTiepNhan = new System.Windows.Forms.TabControl();
            this.tabCapHoSo = new System.Windows.Forms.TabPage();
            this.btnChonAnh = new System.Windows.Forms.Button();
            this.btnDangKy = new System.Windows.Forms.Button();
            this.numLePhi = new System.Windows.Forms.NumericUpDown();
            this.lblLePhi = new System.Windows.Forms.Label();
            this.txtMaHoSo = new System.Windows.Forms.TextBox();
            this.lblMaHoSo = new System.Windows.Forms.Label();
            this.txtAnh = new System.Windows.Forms.TextBox();
            this.lblAnh = new System.Windows.Forms.Label();
            this.txtDienThoai = new System.Windows.Forms.TextBox();
            this.lblDienThoai = new System.Windows.Forms.Label();
            this.cboGioiTinh = new System.Windows.Forms.ComboBox();
            this.lblGioiTinh = new System.Windows.Forms.Label();
            this.dtNgaySinh = new System.Windows.Forms.DateTimePicker();
            this.lblNgaySinh = new System.Windows.Forms.Label();
            this.txtDiaChi = new System.Windows.Forms.TextBox();
            this.lblDiaChi = new System.Windows.Forms.Label();
            this.txtHoTen = new System.Windows.Forms.TextBox();
            this.lblHoTen = new System.Windows.Forms.Label();
            this.txtMaBN = new System.Windows.Forms.TextBox();
            this.lblMaBN = new System.Windows.Forms.Label();
            this.dgvHoSo = new System.Windows.Forms.DataGridView();
            this.tabHenDinhKy = new System.Windows.Forms.TabPage();
            this.btnDatHen = new System.Windows.Forms.Button();
            this.txtGhiChuHen = new System.Windows.Forms.TextBox();
            this.lblGhiChuHen = new System.Windows.Forms.Label();
            this.dtNgayGioHen = new System.Windows.Forms.DateTimePicker();
            this.lblNgayGioHen = new System.Windows.Forms.Label();
            this.cboHoSoHen = new System.Windows.Forms.ComboBox();
            this.lblHoSoHen = new System.Windows.Forms.Label();
            this.txtMaLK = new System.Windows.Forms.TextBox();
            this.lblMaLK = new System.Windows.Forms.Label();
            this.dgvLichHen = new System.Windows.Forms.DataGridView();
            this.tabLapPhieuKham = new System.Windows.Forms.TabPage();
            this.btnLapPhieu = new System.Windows.Forms.Button();
            this.txtHuyetAp = new System.Windows.Forms.TextBox();
            this.lblHuyetAp = new System.Windows.Forms.Label();
            this.numThanNhiet = new System.Windows.Forms.NumericUpDown();
            this.lblThanNhiet = new System.Windows.Forms.Label();
            this.txtTrieuChung = new System.Windows.Forms.TextBox();
            this.lblTrieuChung = new System.Windows.Forms.Label();
            this.cboLoaiKham = new System.Windows.Forms.ComboBox();
            this.lblLoaiKham = new System.Windows.Forms.Label();
            this.cboBacSi = new System.Windows.Forms.ComboBox();
            this.lblBacSi = new System.Windows.Forms.Label();
            this.cboKhoa = new System.Windows.Forms.ComboBox();
            this.lblKhoa = new System.Windows.Forms.Label();
            this.cboHoSoKham = new System.Windows.Forms.ComboBox();
            this.lblHoSoKham = new System.Windows.Forms.Label();
            this.txtMaPK = new System.Windows.Forms.TextBox();
            this.lblMaPK = new System.Windows.Forms.Label();
            this.dgvPhieuKham = new System.Windows.Forms.DataGridView();
            this.btnDong = new System.Windows.Forms.Button();
            this.tabTiepNhan.SuspendLayout();
            this.tabCapHoSo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numLePhi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHoSo)).BeginInit();
            this.tabHenDinhKy.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLichHen)).BeginInit();
            this.tabLapPhieuKham.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numThanNhiet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPhieuKham)).BeginInit();
            this.SuspendLayout();
            // 
            // tabTiepNhan
            // 
            this.tabTiepNhan.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabTiepNhan.Controls.Add(this.tabCapHoSo);
            this.tabTiepNhan.Controls.Add(this.tabHenDinhKy);
            this.tabTiepNhan.Controls.Add(this.tabLapPhieuKham);
            this.tabTiepNhan.Location = new System.Drawing.Point(15, 15);
            this.tabTiepNhan.Name = "tabTiepNhan";
            this.tabTiepNhan.SelectedIndex = 0;
            this.tabTiepNhan.Size = new System.Drawing.Size(950, 540);
            this.tabTiepNhan.TabIndex = 0;
            // 
            // tabCapHoSo
            // 
            this.tabCapHoSo.Controls.Add(this.btnChonAnh);
            this.tabCapHoSo.Controls.Add(this.btnDangKy);
            this.tabCapHoSo.Controls.Add(this.numLePhi);
            this.tabCapHoSo.Controls.Add(this.lblLePhi);
            this.tabCapHoSo.Controls.Add(this.txtMaHoSo);
            this.tabCapHoSo.Controls.Add(this.lblMaHoSo);
            this.tabCapHoSo.Controls.Add(this.txtAnh);
            this.tabCapHoSo.Controls.Add(this.lblAnh);
            this.tabCapHoSo.Controls.Add(this.txtDienThoai);
            this.tabCapHoSo.Controls.Add(this.lblDienThoai);
            this.tabCapHoSo.Controls.Add(this.cboGioiTinh);
            this.tabCapHoSo.Controls.Add(this.lblGioiTinh);
            this.tabCapHoSo.Controls.Add(this.dtNgaySinh);
            this.tabCapHoSo.Controls.Add(this.lblNgaySinh);
            this.tabCapHoSo.Controls.Add(this.txtDiaChi);
            this.tabCapHoSo.Controls.Add(this.lblDiaChi);
            this.tabCapHoSo.Controls.Add(this.txtHoTen);
            this.tabCapHoSo.Controls.Add(this.lblHoTen);
            this.tabCapHoSo.Controls.Add(this.txtMaBN);
            this.tabCapHoSo.Controls.Add(this.lblMaBN);
            this.tabCapHoSo.Controls.Add(this.dgvHoSo);
            this.tabCapHoSo.Location = new System.Drawing.Point(4, 25);
            this.tabCapHoSo.Name = "tabCapHoSo";
            this.tabCapHoSo.Padding = new System.Windows.Forms.Padding(3);
            this.tabCapHoSo.Size = new System.Drawing.Size(942, 511);
            this.tabCapHoSo.TabIndex = 0;
            this.tabCapHoSo.Text = "Cấp hồ sơ bệnh án mới";
            this.tabCapHoSo.UseVisualStyleBackColor = true;
            // 
            // btnChonAnh
            // 
            this.btnChonAnh.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnChonAnh.Location = new System.Drawing.Point(200, 452);
            this.btnChonAnh.Name = "btnChonAnh";
            this.btnChonAnh.Size = new System.Drawing.Size(55, 28);
            this.btnChonAnh.TabIndex = 20;
            this.btnChonAnh.Text = "Chọn";
            this.btnChonAnh.UseVisualStyleBackColor = true;
            this.btnChonAnh.Click += new System.EventHandler(this.btnChonAnh_Click);
            // 
            // btnDangKy
            // 
            this.btnDangKy.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDangKy.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnDangKy.Location = new System.Drawing.Point(745, 442);
            this.btnDangKy.Name = "btnDangKy";
            this.btnDangKy.Size = new System.Drawing.Size(180, 45);
            this.btnDangKy.TabIndex = 19;
            this.btnDangKy.Text = "Đăng ký & Cấp HSBA";
            this.btnDangKy.UseMnemonic = false;
            this.btnDangKy.UseVisualStyleBackColor = true;
            this.btnDangKy.Click += new System.EventHandler(this.btnDangKy_Click);
            // 
            // numLePhi
            // 
            this.numLePhi.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.numLePhi.Location = new System.Drawing.Point(575, 455);
            this.numLePhi.Maximum = new decimal(new int[] { 1000000000, 0, 0, 0 });
            this.numLePhi.Name = "numLePhi";
            this.numLePhi.Size = new System.Drawing.Size(150, 22);
            this.numLePhi.TabIndex = 18;
            this.numLePhi.ThousandsSeparator = true;
            this.numLePhi.Value = new decimal(new int[] { 1200000, 0, 0, 0 });
            // 
            // lblLePhi
            // 
            this.lblLePhi.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.lblLePhi.AutoSize = true;
            this.lblLePhi.Location = new System.Drawing.Point(485, 458);
            this.lblLePhi.Name = "lblLePhi";
            this.lblLePhi.Size = new System.Drawing.Size(83, 17);
            this.lblLePhi.TabIndex = 17;
            this.lblLePhi.Text = "Lệ phí năm:";
            // 
            // txtMaHoSo
            // 
            this.txtMaHoSo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.txtMaHoSo.Location = new System.Drawing.Point(340, 455);
            this.txtMaHoSo.Name = "txtMaHoSo";
            this.txtMaHoSo.Size = new System.Drawing.Size(125, 22);
            this.txtMaHoSo.TabIndex = 16;
            // 
            // lblMaHoSo
            // 
            this.lblMaHoSo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblMaHoSo.AutoSize = true;
            this.lblMaHoSo.Location = new System.Drawing.Point(265, 458);
            this.lblMaHoSo.Name = "lblMaHoSo";
            this.lblMaHoSo.Size = new System.Drawing.Size(70, 17);
            this.lblMaHoSo.TabIndex = 15;
            this.lblMaHoSo.Text = "Mã hồ sơ:";
            // 
            // txtAnh
            // 
            this.txtAnh.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.txtAnh.Location = new System.Drawing.Point(85, 455);
            this.txtAnh.Name = "txtAnh";
            this.txtAnh.Size = new System.Drawing.Size(110, 22);
            this.txtAnh.TabIndex = 14;
            this.txtAnh.Text = "anh3x4.jpg";
            // 
            // lblAnh
            // 
            this.lblAnh.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblAnh.AutoSize = true;
            this.lblAnh.Location = new System.Drawing.Point(15, 458);
            this.lblAnh.Name = "lblAnh";
            this.lblAnh.Size = new System.Drawing.Size(65, 17);
            this.lblAnh.TabIndex = 13;
            this.lblAnh.Text = "Ảnh 3x4:";
            // 
            // txtDienThoai
            // 
            this.txtDienThoai.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.txtDienThoai.Location = new System.Drawing.Point(775, 415);
            this.txtDienThoai.Name = "txtDienThoai";
            this.txtDienThoai.Size = new System.Drawing.Size(150, 22);
            this.txtDienThoai.TabIndex = 12;
            // 
            // lblDienThoai
            // 
            this.lblDienThoai.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.lblDienThoai.AutoSize = true;
            this.lblDienThoai.Location = new System.Drawing.Point(725, 418);
            this.lblDienThoai.Name = "lblDienThoai";
            this.lblDienThoai.Size = new System.Drawing.Size(40, 17);
            this.lblDienThoai.TabIndex = 11;
            this.lblDienThoai.Text = "SĐT:";
            // 
            // cboGioiTinh
            // 
            this.cboGioiTinh.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.cboGioiTinh.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboGioiTinh.FormattingEnabled = true;
            this.cboGioiTinh.Items.AddRange(new object[] { "Nữ", "Nam" });
            this.cboGioiTinh.Location = new System.Drawing.Point(620, 415);
            this.cboGioiTinh.Name = "cboGioiTinh";
            this.cboGioiTinh.Size = new System.Drawing.Size(85, 24);
            this.cboGioiTinh.TabIndex = 10;
            // 
            // lblGioiTinh
            // 
            this.lblGioiTinh.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.lblGioiTinh.AutoSize = true;
            this.lblGioiTinh.Location = new System.Drawing.Point(550, 418);
            this.lblGioiTinh.Name = "lblGioiTinh";
            this.lblGioiTinh.Size = new System.Drawing.Size(64, 17);
            this.lblGioiTinh.TabIndex = 9;
            this.lblGioiTinh.Text = "Giới tính:";
            // 
            // dtNgaySinh
            // 
            this.dtNgaySinh.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.dtNgaySinh.CustomFormat = "dd/MM/yyyy";
            this.dtNgaySinh.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtNgaySinh.Location = new System.Drawing.Point(400, 415);
            this.dtNgaySinh.Name = "dtNgaySinh";
            this.dtNgaySinh.Size = new System.Drawing.Size(130, 22);
            this.dtNgaySinh.TabIndex = 8;
            // 
            // lblNgaySinh
            // 
            this.lblNgaySinh.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.lblNgaySinh.AutoSize = true;
            this.lblNgaySinh.Location = new System.Drawing.Point(320, 418);
            this.lblNgaySinh.Name = "lblNgaySinh";
            this.lblNgaySinh.Size = new System.Drawing.Size(75, 17);
            this.lblNgaySinh.TabIndex = 7;
            this.lblNgaySinh.Text = "Ngày sinh:";
            // 
            // txtDiaChi
            // 
            this.txtDiaChi.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtDiaChi.Location = new System.Drawing.Point(100, 415);
            this.txtDiaChi.Name = "txtDiaChi";
            this.txtDiaChi.Size = new System.Drawing.Size(200, 22);
            this.txtDiaChi.TabIndex = 6;
            // 
            // lblDiaChi
            // 
            this.lblDiaChi.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblDiaChi.AutoSize = true;
            this.lblDiaChi.Location = new System.Drawing.Point(15, 418);
            this.lblDiaChi.Name = "lblDiaChi";
            this.lblDiaChi.Size = new System.Drawing.Size(55, 17);
            this.lblDiaChi.TabIndex = 5;
            this.lblDiaChi.Text = "Địa chỉ:";
            // 
            // txtHoTen
            // 
            this.txtHoTen.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtHoTen.Location = new System.Drawing.Point(340, 375);
            this.txtHoTen.Name = "txtHoTen";
            this.txtHoTen.Size = new System.Drawing.Size(585, 22);
            this.txtHoTen.TabIndex = 4;
            // 
            // lblHoTen
            // 
            this.lblHoTen.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblHoTen.AutoSize = true;
            this.lblHoTen.Location = new System.Drawing.Point(265, 378);
            this.lblHoTen.Name = "lblHoTen";
            this.lblHoTen.Size = new System.Drawing.Size(54, 17);
            this.lblHoTen.TabIndex = 3;
            this.lblHoTen.Text = "Họ tên:";
            // 
            // txtMaBN
            // 
            this.txtMaBN.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.txtMaBN.Location = new System.Drawing.Point(100, 375);
            this.txtMaBN.Name = "txtMaBN";
            this.txtMaBN.Size = new System.Drawing.Size(145, 22);
            this.txtMaBN.TabIndex = 2;
            // 
            // lblMaBN
            // 
            this.lblMaBN.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblMaBN.AutoSize = true;
            this.lblMaBN.Location = new System.Drawing.Point(15, 378);
            this.lblMaBN.Name = "lblMaBN";
            this.lblMaBN.Size = new System.Drawing.Size(54, 17);
            this.lblMaBN.TabIndex = 1;
            this.lblMaBN.Text = "Mã BN:";
            // 
            // dgvHoSo
            // 
            this.dgvHoSo.AllowUserToAddRows = false;
            this.dgvHoSo.AllowUserToDeleteRows = false;
            this.dgvHoSo.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvHoSo.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvHoSo.BackgroundColor = System.Drawing.Color.White;
            this.dgvHoSo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvHoSo.Location = new System.Drawing.Point(15, 15);
            this.dgvHoSo.Name = "dgvHoSo";
            this.dgvHoSo.ReadOnly = true;
            this.dgvHoSo.RowHeadersWidth = 51;
            this.dgvHoSo.RowTemplate.Height = 24;
            this.dgvHoSo.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvHoSo.Size = new System.Drawing.Size(910, 340);
            this.dgvHoSo.TabIndex = 0;
            // 
            // tabHenDinhKy
            // 
            this.tabHenDinhKy.Controls.Add(this.btnDatHen);
            this.tabHenDinhKy.Controls.Add(this.txtGhiChuHen);
            this.tabHenDinhKy.Controls.Add(this.lblGhiChuHen);
            this.tabHenDinhKy.Controls.Add(this.dtNgayGioHen);
            this.tabHenDinhKy.Controls.Add(this.lblNgayGioHen);
            this.tabHenDinhKy.Controls.Add(this.cboHoSoHen);
            this.tabHenDinhKy.Controls.Add(this.lblHoSoHen);
            this.tabHenDinhKy.Controls.Add(this.txtMaLK);
            this.tabHenDinhKy.Controls.Add(this.lblMaLK);
            this.tabHenDinhKy.Controls.Add(this.dgvLichHen);
            this.tabHenDinhKy.Location = new System.Drawing.Point(4, 25);
            this.tabHenDinhKy.Name = "tabHenDinhKy";
            this.tabHenDinhKy.Padding = new System.Windows.Forms.Padding(3);
            this.tabHenDinhKy.Size = new System.Drawing.Size(942, 511);
            this.tabHenDinhKy.TabIndex = 1;
            this.tabHenDinhKy.Text = "Đặt lịch hẹn khám định kỳ";
            this.tabHenDinhKy.UseVisualStyleBackColor = true;
            // 
            // btnDatHen
            // 
            this.btnDatHen.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDatHen.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnDatHen.Location = new System.Drawing.Point(775, 425);
            this.btnDatHen.Name = "btnDatHen";
            this.btnDatHen.Size = new System.Drawing.Size(150, 45);
            this.btnDatHen.TabIndex = 9;
            this.btnDatHen.Text = "Đặt lịch hẹn";
            this.btnDatHen.UseVisualStyleBackColor = true;
            this.btnDatHen.Click += new System.EventHandler(this.btnDatHen_Click);
            // 
            // txtGhiChuHen
            // 
            this.txtGhiChuHen.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtGhiChuHen.Location = new System.Drawing.Point(120, 448);
            this.txtGhiChuHen.Name = "txtGhiChuHen";
            this.txtGhiChuHen.Size = new System.Drawing.Size(620, 22);
            this.txtGhiChuHen.TabIndex = 8;
            // 
            // lblGhiChuHen
            // 
            this.lblGhiChuHen.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblGhiChuHen.AutoSize = true;
            this.lblGhiChuHen.Location = new System.Drawing.Point(20, 451);
            this.lblGhiChuHen.Name = "lblGhiChuHen";
            this.lblGhiChuHen.Size = new System.Drawing.Size(61, 17);
            this.lblGhiChuHen.TabIndex = 7;
            this.lblGhiChuHen.Text = "Ghi chú:";
            // 
            // dtNgayGioHen
            // 
            this.dtNgayGioHen.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.dtNgayGioHen.CustomFormat = "dd/MM/yyyy HH:mm";
            this.dtNgayGioHen.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtNgayGioHen.Location = new System.Drawing.Point(565, 405);
            this.dtNgayGioHen.Name = "dtNgayGioHen";
            this.dtNgayGioHen.Size = new System.Drawing.Size(175, 22);
            this.dtNgayGioHen.TabIndex = 6;
            // 
            // lblNgayGioHen
            // 
            this.lblNgayGioHen.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.lblNgayGioHen.AutoSize = true;
            this.lblNgayGioHen.Location = new System.Drawing.Point(465, 408);
            this.lblNgayGioHen.Name = "lblNgayGioHen";
            this.lblNgayGioHen.Size = new System.Drawing.Size(95, 17);
            this.lblNgayGioHen.TabIndex = 5;
            this.lblNgayGioHen.Text = "Ngày giờ hẹn:";
            // 
            // cboHoSoHen
            // 
            this.cboHoSoHen.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cboHoSoHen.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboHoSoHen.FormattingEnabled = true;
            this.cboHoSoHen.Location = new System.Drawing.Point(235, 405);
            this.cboHoSoHen.Name = "cboHoSoHen";
            this.cboHoSoHen.Size = new System.Drawing.Size(210, 24);
            this.cboHoSoHen.TabIndex = 4;
            // 
            // lblHoSoHen
            // 
            this.lblHoSoHen.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblHoSoHen.AutoSize = true;
            this.lblHoSoHen.Location = new System.Drawing.Point(175, 408);
            this.lblHoSoHen.Name = "lblHoSoHen";
            this.lblHoSoHen.Size = new System.Drawing.Size(49, 17);
            this.lblHoSoHen.TabIndex = 3;
            this.lblHoSoHen.Text = "Hồ sơ:";
            // 
            // txtMaLK
            // 
            this.txtMaLK.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.txtMaLK.Location = new System.Drawing.Point(75, 405);
            this.txtMaLK.Name = "txtMaLK";
            this.txtMaLK.Size = new System.Drawing.Size(85, 22);
            this.txtMaLK.TabIndex = 2;
            // 
            // lblMaLK
            // 
            this.lblMaLK.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblMaLK.AutoSize = true;
            this.lblMaLK.Location = new System.Drawing.Point(20, 408);
            this.lblMaLK.Name = "lblMaLK";
            this.lblMaLK.Size = new System.Drawing.Size(52, 17);
            this.lblMaLK.TabIndex = 1;
            this.lblMaLK.Text = "Mã LK:";
            // 
            // dgvLichHen
            // 
            this.dgvLichHen.AllowUserToAddRows = false;
            this.dgvLichHen.AllowUserToDeleteRows = false;
            this.dgvLichHen.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvLichHen.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvLichHen.BackgroundColor = System.Drawing.Color.White;
            this.dgvLichHen.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvLichHen.Location = new System.Drawing.Point(15, 15);
            this.dgvLichHen.Name = "dgvLichHen";
            this.dgvLichHen.ReadOnly = true;
            this.dgvLichHen.RowHeadersWidth = 51;
            this.dgvLichHen.RowTemplate.Height = 24;
            this.dgvLichHen.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvLichHen.Size = new System.Drawing.Size(910, 365);
            this.dgvLichHen.TabIndex = 0;
            // 
            // tabLapPhieuKham
            // 
            this.tabLapPhieuKham.Controls.Add(this.btnLapPhieu);
            this.tabLapPhieuKham.Controls.Add(this.txtHuyetAp);
            this.tabLapPhieuKham.Controls.Add(this.lblHuyetAp);
            this.tabLapPhieuKham.Controls.Add(this.numThanNhiet);
            this.tabLapPhieuKham.Controls.Add(this.lblThanNhiet);
            this.tabLapPhieuKham.Controls.Add(this.txtTrieuChung);
            this.tabLapPhieuKham.Controls.Add(this.lblTrieuChung);
            this.tabLapPhieuKham.Controls.Add(this.cboLoaiKham);
            this.tabLapPhieuKham.Controls.Add(this.lblLoaiKham);
            this.tabLapPhieuKham.Controls.Add(this.cboBacSi);
            this.tabLapPhieuKham.Controls.Add(this.lblBacSi);
            this.tabLapPhieuKham.Controls.Add(this.cboKhoa);
            this.tabLapPhieuKham.Controls.Add(this.lblKhoa);
            this.tabLapPhieuKham.Controls.Add(this.cboHoSoKham);
            this.tabLapPhieuKham.Controls.Add(this.lblHoSoKham);
            this.tabLapPhieuKham.Controls.Add(this.txtMaPK);
            this.tabLapPhieuKham.Controls.Add(this.lblMaPK);
            this.tabLapPhieuKham.Controls.Add(this.dgvPhieuKham);
            this.tabLapPhieuKham.Location = new System.Drawing.Point(4, 25);
            this.tabLapPhieuKham.Name = "tabLapPhieuKham";
            this.tabLapPhieuKham.Padding = new System.Windows.Forms.Padding(3);
            this.tabLapPhieuKham.Size = new System.Drawing.Size(942, 511);
            this.tabLapPhieuKham.TabIndex = 2;
            this.tabLapPhieuKham.Text = "Lập phiếu khám bệnh";
            this.tabLapPhieuKham.UseVisualStyleBackColor = true;
            // 
            // btnLapPhieu
            // 
            this.btnLapPhieu.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnLapPhieu.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnLapPhieu.Location = new System.Drawing.Point(775, 420);
            this.btnLapPhieu.Name = "btnLapPhieu";
            this.btnLapPhieu.Size = new System.Drawing.Size(150, 50);
            this.btnLapPhieu.TabIndex = 17;
            this.btnLapPhieu.Text = "Lập phiếu khám";
            this.btnLapPhieu.UseVisualStyleBackColor = true;
            this.btnLapPhieu.Click += new System.EventHandler(this.btnLapPhieu_Click);
            // 
            // txtHuyetAp
            // 
            this.txtHuyetAp.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.txtHuyetAp.Location = new System.Drawing.Point(645, 452);
            this.txtHuyetAp.Name = "txtHuyetAp";
            this.txtHuyetAp.Size = new System.Drawing.Size(105, 22);
            this.txtHuyetAp.TabIndex = 16;
            this.txtHuyetAp.Text = "120/80";
            // 
            // lblHuyetAp
            // 
            this.lblHuyetAp.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.lblHuyetAp.AutoSize = true;
            this.lblHuyetAp.Location = new System.Drawing.Point(575, 455);
            this.lblHuyetAp.Name = "lblHuyetAp";
            this.lblHuyetAp.Size = new System.Drawing.Size(69, 17);
            this.lblHuyetAp.TabIndex = 15;
            this.lblHuyetAp.Text = "Huyết áp:";
            // 
            // numThanNhiet
            // 
            this.numThanNhiet.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.numThanNhiet.DecimalPlaces = 1;
            this.numThanNhiet.Increment = new decimal(new int[] { 1, 0, 0, 65536 });
            this.numThanNhiet.Location = new System.Drawing.Point(495, 452);
            this.numThanNhiet.Maximum = new decimal(new int[] { 43, 0, 0, 0 });
            this.numThanNhiet.Minimum = new decimal(new int[] { 34, 0, 0, 0 });
            this.numThanNhiet.Name = "numThanNhiet";
            this.numThanNhiet.Size = new System.Drawing.Size(65, 22);
            this.numThanNhiet.TabIndex = 14;
            this.numThanNhiet.Value = new decimal(new int[] { 370, 0, 0, 65536 });
            // 
            // lblThanNhiet
            // 
            this.lblThanNhiet.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.lblThanNhiet.AutoSize = true;
            this.lblThanNhiet.Location = new System.Drawing.Point(415, 455);
            this.lblThanNhiet.Name = "lblThanNhiet";
            this.lblThanNhiet.Size = new System.Drawing.Size(80, 17);
            this.lblThanNhiet.TabIndex = 13;
            this.lblThanNhiet.Text = "Thân nhiệt:";
            // 
            // txtTrieuChung
            // 
            this.txtTrieuChung.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtTrieuChung.Location = new System.Drawing.Point(105, 452);
            this.txtTrieuChung.Name = "txtTrieuChung";
            this.txtTrieuChung.Size = new System.Drawing.Size(295, 22);
            this.txtTrieuChung.TabIndex = 12;
            // 
            // lblTrieuChung
            // 
            this.lblTrieuChung.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblTrieuChung.AutoSize = true;
            this.lblTrieuChung.Location = new System.Drawing.Point(15, 455);
            this.lblTrieuChung.Name = "lblTrieuChung";
            this.lblTrieuChung.Size = new System.Drawing.Size(88, 17);
            this.lblTrieuChung.TabIndex = 11;
            this.lblTrieuChung.Text = "Triệu chứng:";
            // 
            // cboLoaiKham
            // 
            this.cboLoaiKham.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.cboLoaiKham.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboLoaiKham.FormattingEnabled = true;
            this.cboLoaiKham.Items.AddRange(new object[] { "Khám bệnh", "Khám định kỳ" });
            this.cboLoaiKham.Location = new System.Drawing.Point(795, 395);
            this.cboLoaiKham.Name = "cboLoaiKham";
            this.cboLoaiKham.Size = new System.Drawing.Size(130, 24);
            this.cboLoaiKham.TabIndex = 10;
            // 
            // lblLoaiKham
            // 
            this.lblLoaiKham.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.lblLoaiKham.AutoSize = true;
            this.lblLoaiKham.Location = new System.Drawing.Point(715, 398);
            this.lblLoaiKham.Name = "lblLoaiKham";
            this.lblLoaiKham.Size = new System.Drawing.Size(78, 17);
            this.lblLoaiKham.TabIndex = 9;
            this.lblLoaiKham.Text = "Loại khám:";
            // 
            // cboBacSi
            // 
            this.cboBacSi.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.cboBacSi.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboBacSi.FormattingEnabled = true;
            this.cboBacSi.Location = new System.Drawing.Point(535, 395);
            this.cboBacSi.Name = "cboBacSi";
            this.cboBacSi.Size = new System.Drawing.Size(165, 24);
            this.cboBacSi.TabIndex = 8;
            // 
            // lblBacSi
            // 
            this.lblBacSi.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.lblBacSi.AutoSize = true;
            this.lblBacSi.Location = new System.Drawing.Point(480, 398);
            this.lblBacSi.Name = "lblBacSi";
            this.lblBacSi.Size = new System.Drawing.Size(51, 17);
            this.lblBacSi.TabIndex = 7;
            this.lblBacSi.Text = "Bác sĩ:";
            // 
            // cboKhoa
            // 
            this.cboKhoa.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cboKhoa.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboKhoa.FormattingEnabled = true;
            this.cboKhoa.Location = new System.Drawing.Point(315, 395);
            this.cboKhoa.Name = "cboKhoa";
            this.cboKhoa.Size = new System.Drawing.Size(155, 24);
            this.cboKhoa.TabIndex = 6;
            this.cboKhoa.SelectedIndexChanged += new System.EventHandler(this.cboKhoa_SelectedIndexChanged);
            // 
            // lblKhoa
            // 
            this.lblKhoa.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblKhoa.AutoSize = true;
            this.lblKhoa.Location = new System.Drawing.Point(265, 398);
            this.lblKhoa.Name = "lblKhoa";
            this.lblKhoa.Size = new System.Drawing.Size(45, 17);
            this.lblKhoa.TabIndex = 5;
            this.lblKhoa.Text = "Khoa:";
            // 
            // cboHoSoKham
            // 
            this.cboHoSoKham.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.cboHoSoKham.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboHoSoKham.FormattingEnabled = true;
            this.cboHoSoKham.Location = new System.Drawing.Point(165, 395);
            this.cboHoSoKham.Name = "cboHoSoKham";
            this.cboHoSoKham.Size = new System.Drawing.Size(90, 24);
            this.cboHoSoKham.TabIndex = 4;
            // 
            // lblHoSoKham
            // 
            this.lblHoSoKham.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblHoSoKham.AutoSize = true;
            this.lblHoSoKham.Location = new System.Drawing.Point(115, 398);
            this.lblHoSoKham.Name = "lblHoSoKham";
            this.lblHoSoKham.Size = new System.Drawing.Size(49, 17);
            this.lblHoSoKham.TabIndex = 3;
            this.lblHoSoKham.Text = "Hồ sơ:";
            // 
            // txtMaPK
            // 
            this.txtMaPK.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.txtMaPK.Location = new System.Drawing.Point(65, 395);
            this.txtMaPK.Name = "txtMaPK";
            this.txtMaPK.Size = new System.Drawing.Size(45, 22);
            this.txtMaPK.TabIndex = 2;
            // 
            // lblMaPK
            // 
            this.lblMaPK.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblMaPK.AutoSize = true;
            this.lblMaPK.Location = new System.Drawing.Point(15, 398);
            this.lblMaPK.Name = "lblMaPK";
            this.lblMaPK.Size = new System.Drawing.Size(53, 17);
            this.lblMaPK.TabIndex = 1;
            this.lblMaPK.Text = "Mã PK:";
            // 
            // dgvPhieuKham
            // 
            this.dgvPhieuKham.AllowUserToAddRows = false;
            this.dgvPhieuKham.AllowUserToDeleteRows = false;
            this.dgvPhieuKham.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvPhieuKham.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvPhieuKham.BackgroundColor = System.Drawing.Color.White;
            this.dgvPhieuKham.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPhieuKham.Location = new System.Drawing.Point(15, 15);
            this.dgvPhieuKham.Name = "dgvPhieuKham";
            this.dgvPhieuKham.ReadOnly = true;
            this.dgvPhieuKham.RowHeadersWidth = 51;
            this.dgvPhieuKham.RowTemplate.Height = 24;
            this.dgvPhieuKham.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvPhieuKham.Size = new System.Drawing.Size(910, 360);
            this.dgvPhieuKham.TabIndex = 0;
            // 
            // btnDong
            // 
            this.btnDong.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDong.Location = new System.Drawing.Point(850, 565);
            this.btnDong.Name = "btnDong";
            this.btnDong.Size = new System.Drawing.Size(110, 35);
            this.btnDong.TabIndex = 1;
            this.btnDong.Text = "Đóng";
            this.btnDong.UseVisualStyleBackColor = true;
            this.btnDong.Click += new System.EventHandler(this.btnDong_Click);
            // 
            // FrmTiepNhanHoSo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(980, 610);
            this.Controls.Add(this.btnDong);
            this.Controls.Add(this.tabTiepNhan);
            this.Name = "FrmTiepNhanHoSo";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Tiếp nhận bệnh nhân & Cấp hồ sơ bệnh án";
            this.Load += new System.EventHandler(this.FrmTiepNhanHoSo_Load);
            this.tabTiepNhan.ResumeLayout(false);
            this.tabCapHoSo.ResumeLayout(false);
            this.tabCapHoSo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numLePhi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHoSo)).EndInit();
            this.tabHenDinhKy.ResumeLayout(false);
            this.tabHenDinhKy.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLichHen)).EndInit();
            this.tabLapPhieuKham.ResumeLayout(false);
            this.tabLapPhieuKham.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numThanNhiet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPhieuKham)).EndInit();
            this.ResumeLayout(false);
        }

        private System.Windows.Forms.TabControl tabTiepNhan;
        private System.Windows.Forms.TabPage tabCapHoSo;
        private System.Windows.Forms.TabPage tabHenDinhKy;
        private System.Windows.Forms.TabPage tabLapPhieuKham;
        private System.Windows.Forms.DataGridView dgvHoSo;
        private System.Windows.Forms.Label lblMaBN;
        private System.Windows.Forms.TextBox txtMaBN;
        private System.Windows.Forms.Label lblHoTen;
        private System.Windows.Forms.TextBox txtHoTen;
        private System.Windows.Forms.Label lblDiaChi;
        private System.Windows.Forms.TextBox txtDiaChi;
        private System.Windows.Forms.Label lblNgaySinh;
        private System.Windows.Forms.DateTimePicker dtNgaySinh;
        private System.Windows.Forms.Label lblGioiTinh;
        private System.Windows.Forms.ComboBox cboGioiTinh;
        private System.Windows.Forms.Label lblDienThoai;
        private System.Windows.Forms.TextBox txtDienThoai;
        private System.Windows.Forms.Label lblAnh;
        private System.Windows.Forms.TextBox txtAnh;
        private System.Windows.Forms.Button btnChonAnh;
        private System.Windows.Forms.Label lblMaHoSo;
        private System.Windows.Forms.TextBox txtMaHoSo;
        private System.Windows.Forms.Label lblLePhi;
        private System.Windows.Forms.NumericUpDown numLePhi;
        private System.Windows.Forms.Button btnDangKy;
        private System.Windows.Forms.DataGridView dgvLichHen;
        private System.Windows.Forms.Label lblMaLK;
        private System.Windows.Forms.TextBox txtMaLK;
        private System.Windows.Forms.Label lblHoSoHen;
        private System.Windows.Forms.ComboBox cboHoSoHen;
        private System.Windows.Forms.Label lblNgayGioHen;
        private System.Windows.Forms.DateTimePicker dtNgayGioHen;
        private System.Windows.Forms.Label lblGhiChuHen;
        private System.Windows.Forms.TextBox txtGhiChuHen;
        private System.Windows.Forms.Button btnDatHen;
        private System.Windows.Forms.DataGridView dgvPhieuKham;
        private System.Windows.Forms.Label lblMaPK;
        private System.Windows.Forms.TextBox txtMaPK;
        private System.Windows.Forms.Label lblHoSoKham;
        private System.Windows.Forms.ComboBox cboHoSoKham;
        private System.Windows.Forms.Label lblKhoa;
        private System.Windows.Forms.ComboBox cboKhoa;
        private System.Windows.Forms.Label lblBacSi;
        private System.Windows.Forms.ComboBox cboBacSi;
        private System.Windows.Forms.Label lblLoaiKham;
        private System.Windows.Forms.ComboBox cboLoaiKham;
        private System.Windows.Forms.Label lblTrieuChung;
        private System.Windows.Forms.TextBox txtTrieuChung;
        private System.Windows.Forms.Label lblThanNhiet;
        private System.Windows.Forms.NumericUpDown numThanNhiet;
        private System.Windows.Forms.Label lblHuyetAp;
        private System.Windows.Forms.TextBox txtHuyetAp;
        private System.Windows.Forms.Button btnLapPhieu;
        private System.Windows.Forms.Button btnDong;
    }
}