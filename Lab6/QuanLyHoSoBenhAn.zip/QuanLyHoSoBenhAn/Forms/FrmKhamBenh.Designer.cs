﻿namespace QuanLyHoSoBenhAn.Forms
{
    partial class FrmKhamBenh
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.tabKhamBenh = new System.Windows.Forms.TabControl();
            this.tabChanDoan = new System.Windows.Forms.TabPage();
            this.lblLichSu = new System.Windows.Forms.Label();
            this.dgvLichSu = new System.Windows.Forms.DataGridView();
            this.btnLuuChanDoan = new System.Windows.Forms.Button();
            this.txtKetLuan = new System.Windows.Forms.TextBox();
            this.lblKetLuan = new System.Windows.Forms.Label();
            this.txtHuyetAp = new System.Windows.Forms.TextBox();
            this.lblHuyetAp = new System.Windows.Forms.Label();
            this.numThanNhiet = new System.Windows.Forms.NumericUpDown();
            this.lblThanNhiet = new System.Windows.Forms.Label();
            this.txtTrieuChung = new System.Windows.Forms.TextBox();
            this.lblTrieuChung = new System.Windows.Forms.Label();
            this.txtHoTen = new System.Windows.Forms.TextBox();
            this.lblHoTen = new System.Windows.Forms.Label();
            this.txtMaPK = new System.Windows.Forms.TextBox();
            this.lblMaPK = new System.Windows.Forms.Label();
            this.lblDanhSachCho = new System.Windows.Forms.Label();
            this.dgvChoKham = new System.Windows.Forms.DataGridView();
            this.tabKeToa = new System.Windows.Forms.TabPage();
            this.lblTongTien = new System.Windows.Forms.Label();
            this.lblTongTienTieuDe = new System.Windows.Forms.Label();
            this.btnLuuToa = new System.Windows.Forms.Button();
            this.txtLoiDan = new System.Windows.Forms.TextBox();
            this.lblLoiDan = new System.Windows.Forms.Label();
            this.dgvChiTietToa = new System.Windows.Forms.DataGridView();
            this.btnThemThuoc = new System.Windows.Forms.Button();
            this.txtCachDung = new System.Windows.Forms.TextBox();
            this.lblCachDung = new System.Windows.Forms.Label();
            this.txtLieuLuong = new System.Windows.Forms.TextBox();
            this.lblLieuLuong = new System.Windows.Forms.Label();
            this.numSoLuong = new System.Windows.Forms.NumericUpDown();
            this.lblSoLuong = new System.Windows.Forms.Label();
            this.cboThuoc = new System.Windows.Forms.ComboBox();
            this.lblThuoc = new System.Windows.Forms.Label();
            this.txtDiUng = new System.Windows.Forms.TextBox();
            this.lblDiUng = new System.Windows.Forms.Label();
            this.txtMaToa = new System.Windows.Forms.TextBox();
            this.lblMaToa = new System.Windows.Forms.Label();
            this.cboPhieuKham = new System.Windows.Forms.ComboBox();
            this.lblPhieuKham = new System.Windows.Forms.Label();
            this.btnDong = new System.Windows.Forms.Button();
            this.tabKhamBenh.SuspendLayout();
            this.tabChanDoan.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLichSu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numThanNhiet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvChoKham)).BeginInit();
            this.tabKeToa.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvChiTietToa)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numSoLuong)).BeginInit();
            this.SuspendLayout();
            // 
            // tabKhamBenh
            // 
            this.tabKhamBenh.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabKhamBenh.Controls.Add(this.tabChanDoan);
            this.tabKhamBenh.Controls.Add(this.tabKeToa);
            this.tabKhamBenh.Location = new System.Drawing.Point(15, 15);
            this.tabKhamBenh.Name = "tabKhamBenh";
            this.tabKhamBenh.SelectedIndex = 0;
            this.tabKhamBenh.Size = new System.Drawing.Size(950, 545);
            this.tabKhamBenh.TabIndex = 0;
            // 
            // tabChanDoan
            // 
            this.tabChanDoan.Controls.Add(this.lblLichSu);
            this.tabChanDoan.Controls.Add(this.dgvLichSu);
            this.tabChanDoan.Controls.Add(this.btnLuuChanDoan);
            this.tabChanDoan.Controls.Add(this.txtKetLuan);
            this.tabChanDoan.Controls.Add(this.lblKetLuan);
            this.tabChanDoan.Controls.Add(this.txtHuyetAp);
            this.tabChanDoan.Controls.Add(this.lblHuyetAp);
            this.tabChanDoan.Controls.Add(this.numThanNhiet);
            this.tabChanDoan.Controls.Add(this.lblThanNhiet);
            this.tabChanDoan.Controls.Add(this.txtTrieuChung);
            this.tabChanDoan.Controls.Add(this.lblTrieuChung);
            this.tabChanDoan.Controls.Add(this.txtHoTen);
            this.tabChanDoan.Controls.Add(this.lblHoTen);
            this.tabChanDoan.Controls.Add(this.txtMaPK);
            this.tabChanDoan.Controls.Add(this.lblMaPK);
            this.tabChanDoan.Controls.Add(this.lblDanhSachCho);
            this.tabChanDoan.Controls.Add(this.dgvChoKham);
            this.tabChanDoan.Location = new System.Drawing.Point(4, 25);
            this.tabChanDoan.Name = "tabChanDoan";
            this.tabChanDoan.Padding = new System.Windows.Forms.Padding(3);
            this.tabChanDoan.Size = new System.Drawing.Size(942, 516);
            this.tabChanDoan.TabIndex = 0;
            this.tabChanDoan.Text = "Khám bệnh lâm sàng & Chẩn đoán";
            this.tabChanDoan.UseVisualStyleBackColor = true;
            // 
            // lblLichSu
            // 
            this.lblLichSu.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblLichSu.AutoSize = true;
            this.lblLichSu.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblLichSu.ForeColor = System.Drawing.Color.DarkBlue;
            this.lblLichSu.Location = new System.Drawing.Point(15, 345);
            this.lblLichSu.Name = "lblLichSu";
            this.lblLichSu.Size = new System.Drawing.Size(262, 20);
            this.lblLichSu.TabIndex = 15;
            this.lblLichSu.Text = "Lịch sử các đợt khám bệnh trước đây:";
            // 
            // dgvLichSu
            // 
            this.dgvLichSu.AllowUserToAddRows = false;
            this.dgvLichSu.AllowUserToDeleteRows = false;
            this.dgvLichSu.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvLichSu.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvLichSu.BackgroundColor = System.Drawing.Color.White;
            this.dgvLichSu.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvLichSu.Location = new System.Drawing.Point(15, 370);
            this.dgvLichSu.Name = "dgvLichSu";
            this.dgvLichSu.ReadOnly = true;
            this.dgvLichSu.RowHeadersWidth = 51;
            this.dgvLichSu.RowTemplate.Height = 24;
            this.dgvLichSu.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvLichSu.Size = new System.Drawing.Size(910, 130);
            this.dgvLichSu.TabIndex = 16;
            // 
            // btnLuuChanDoan
            // 
            this.btnLuuChanDoan.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnLuuChanDoan.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnLuuChanDoan.Location = new System.Drawing.Point(765, 275);
            this.btnLuuChanDoan.Name = "btnLuuChanDoan";
            this.btnLuuChanDoan.Size = new System.Drawing.Size(160, 50);
            this.btnLuuChanDoan.TabIndex = 14;
            this.btnLuuChanDoan.Text = "Lưu kết luận";
            this.btnLuuChanDoan.UseVisualStyleBackColor = true;
            this.btnLuuChanDoan.Click += new System.EventHandler(this.btnLuuChanDoan_Click);
            // 
            // txtKetLuan
            // 
            this.txtKetLuan.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtKetLuan.Location = new System.Drawing.Point(105, 303);
            this.txtKetLuan.Name = "txtKetLuan";
            this.txtKetLuan.Size = new System.Drawing.Size(635, 22);
            this.txtKetLuan.TabIndex = 13;
            // 
            // lblKetLuan
            // 
            this.lblKetLuan.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblKetLuan.AutoSize = true;
            this.lblKetLuan.Location = new System.Drawing.Point(15, 306);
            this.lblKetLuan.Name = "lblKetLuan";
            this.lblKetLuan.Size = new System.Drawing.Size(64, 17);
            this.lblKetLuan.TabIndex = 12;
            this.lblKetLuan.Text = "Kết luận:";
            // 
            // txtHuyetAp
            // 
            this.txtHuyetAp.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.txtHuyetAp.Location = new System.Drawing.Point(630, 268);
            this.txtHuyetAp.Name = "txtHuyetAp";
            this.txtHuyetAp.Size = new System.Drawing.Size(110, 22);
            this.txtHuyetAp.TabIndex = 11;
            // 
            // lblHuyetAp
            // 
            this.lblHuyetAp.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.lblHuyetAp.AutoSize = true;
            this.lblHuyetAp.Location = new System.Drawing.Point(555, 271);
            this.lblHuyetAp.Name = "lblHuyetAp";
            this.lblHuyetAp.Size = new System.Drawing.Size(69, 17);
            this.lblHuyetAp.TabIndex = 10;
            this.lblHuyetAp.Text = "Huyết áp:";
            // 
            // numThanNhiet
            // 
            this.numThanNhiet.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.numThanNhiet.DecimalPlaces = 1;
            this.numThanNhiet.Increment = new decimal(new int[] { 1, 0, 0, 65536 });
            this.numThanNhiet.Location = new System.Drawing.Point(475, 268);
            this.numThanNhiet.Maximum = new decimal(new int[] { 43, 0, 0, 0 });
            this.numThanNhiet.Minimum = new decimal(new int[] { 34, 0, 0, 0 });
            this.numThanNhiet.Name = "numThanNhiet";
            this.numThanNhiet.Size = new System.Drawing.Size(65, 22);
            this.numThanNhiet.TabIndex = 9;
            this.numThanNhiet.Value = new decimal(new int[] { 370, 0, 0, 65536 });
            // 
            // lblThanNhiet
            // 
            this.lblThanNhiet.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.lblThanNhiet.AutoSize = true;
            this.lblThanNhiet.Location = new System.Drawing.Point(395, 271);
            this.lblThanNhiet.Name = "lblThanNhiet";
            this.lblThanNhiet.Size = new System.Drawing.Size(80, 17);
            this.lblThanNhiet.TabIndex = 8;
            this.lblThanNhiet.Text = "Thân nhiệt:";
            // 
            // txtTrieuChung
            // 
            this.txtTrieuChung.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtTrieuChung.Location = new System.Drawing.Point(105, 268);
            this.txtTrieuChung.Name = "txtTrieuChung";
            this.txtTrieuChung.Size = new System.Drawing.Size(275, 22);
            this.txtTrieuChung.TabIndex = 7;
            // 
            // lblTrieuChung
            // 
            this.lblTrieuChung.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblTrieuChung.AutoSize = true;
            this.lblTrieuChung.Location = new System.Drawing.Point(15, 271);
            this.lblTrieuChung.Name = "lblTrieuChung";
            this.lblTrieuChung.Size = new System.Drawing.Size(88, 17);
            this.lblTrieuChung.TabIndex = 6;
            this.lblTrieuChung.Text = "Triệu chứng:";
            // 
            // txtHoTen
            // 
            this.txtHoTen.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtHoTen.Location = new System.Drawing.Point(330, 230);
            this.txtHoTen.Name = "txtHoTen";
            this.txtHoTen.ReadOnly = true;
            this.txtHoTen.Size = new System.Drawing.Size(595, 22);
            this.txtHoTen.TabIndex = 5;
            // 
            // lblHoTen
            // 
            this.lblHoTen.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblHoTen.AutoSize = true;
            this.lblHoTen.Location = new System.Drawing.Point(245, 233);
            this.lblHoTen.Name = "lblHoTen";
            this.lblHoTen.Size = new System.Drawing.Size(81, 17);
            this.lblHoTen.TabIndex = 4;
            this.lblHoTen.Text = "Bệnh nhân:";
            // 
            // txtMaPK
            // 
            this.txtMaPK.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.txtMaPK.Location = new System.Drawing.Point(105, 230);
            this.txtMaPK.Name = "txtMaPK";
            this.txtMaPK.ReadOnly = true;
            this.txtMaPK.Size = new System.Drawing.Size(120, 22);
            this.txtMaPK.TabIndex = 3;
            // 
            // lblMaPK
            // 
            this.lblMaPK.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblMaPK.AutoSize = true;
            this.lblMaPK.Location = new System.Drawing.Point(15, 233);
            this.lblMaPK.Name = "lblMaPK";
            this.lblMaPK.Size = new System.Drawing.Size(89, 17);
            this.lblMaPK.TabIndex = 2;
            this.lblMaPK.Text = "Phiếu khám:";
            // 
            // lblDanhSachCho
            // 
            this.lblDanhSachCho.AutoSize = true;
            this.lblDanhSachCho.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblDanhSachCho.Location = new System.Drawing.Point(15, 10);
            this.lblDanhSachCho.Name = "lblDanhSachCho";
            this.lblDanhSachCho.Size = new System.Drawing.Size(224, 20);
            this.lblDanhSachCho.TabIndex = 0;
            this.lblDanhSachCho.Text = "Danh sách bệnh nhân chờ khám:";
            // 
            // dgvChoKham
            // 
            this.dgvChoKham.AllowUserToAddRows = false;
            this.dgvChoKham.AllowUserToDeleteRows = false;
            this.dgvChoKham.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvChoKham.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvChoKham.BackgroundColor = System.Drawing.Color.White;
            this.dgvChoKham.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvChoKham.Location = new System.Drawing.Point(15, 33);
            this.dgvChoKham.Name = "dgvChoKham";
            this.dgvChoKham.ReadOnly = true;
            this.dgvChoKham.RowHeadersWidth = 51;
            this.dgvChoKham.RowTemplate.Height = 24;
            this.dgvChoKham.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvChoKham.Size = new System.Drawing.Size(910, 180);
            this.dgvChoKham.TabIndex = 1;
            this.dgvChoKham.SelectionChanged += new System.EventHandler(this.dgvChoKham_SelectionChanged);
            // 
            // tabKeToa
            // 
            this.tabKeToa.Controls.Add(this.lblTongTien);
            this.tabKeToa.Controls.Add(this.lblTongTienTieuDe);
            this.tabKeToa.Controls.Add(this.btnLuuToa);
            this.tabKeToa.Controls.Add(this.txtLoiDan);
            this.tabKeToa.Controls.Add(this.lblLoiDan);
            this.tabKeToa.Controls.Add(this.dgvChiTietToa);
            this.tabKeToa.Controls.Add(this.btnThemThuoc);
            this.tabKeToa.Controls.Add(this.txtCachDung);
            this.tabKeToa.Controls.Add(this.lblCachDung);
            this.tabKeToa.Controls.Add(this.txtLieuLuong);
            this.tabKeToa.Controls.Add(this.lblLieuLuong);
            this.tabKeToa.Controls.Add(this.numSoLuong);
            this.tabKeToa.Controls.Add(this.lblSoLuong);
            this.tabKeToa.Controls.Add(this.cboThuoc);
            this.tabKeToa.Controls.Add(this.lblThuoc);
            this.tabKeToa.Controls.Add(this.txtDiUng);
            this.tabKeToa.Controls.Add(this.lblDiUng);
            this.tabKeToa.Controls.Add(this.txtMaToa);
            this.tabKeToa.Controls.Add(this.lblMaToa);
            this.tabKeToa.Controls.Add(this.cboPhieuKham);
            this.tabKeToa.Controls.Add(this.lblPhieuKham);
            this.tabKeToa.Location = new System.Drawing.Point(4, 25);
            this.tabKeToa.Name = "tabKeToa";
            this.tabKeToa.Padding = new System.Windows.Forms.Padding(3);
            this.tabKeToa.Size = new System.Drawing.Size(942, 516);
            this.tabKeToa.TabIndex = 1;
            this.tabKeToa.Text = "Kê toa thuốc điều trị";
            this.tabKeToa.UseVisualStyleBackColor = true;
            // 
            // lblTongTien
            // 
            this.lblTongTien.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblTongTien.AutoSize = true;
            this.lblTongTien.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.lblTongTien.ForeColor = System.Drawing.Color.DarkRed;
            this.lblTongTien.Location = new System.Drawing.Point(530, 470);
            this.lblTongTien.Name = "lblTongTien";
            this.lblTongTien.Size = new System.Drawing.Size(43, 25);
            this.lblTongTien.TabIndex = 20;
            this.lblTongTien.Text = "0 đ";
            // 
            // lblTongTienTieuDe
            // 
            this.lblTongTienTieuDe.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblTongTienTieuDe.AutoSize = true;
            this.lblTongTienTieuDe.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.lblTongTienTieuDe.Location = new System.Drawing.Point(385, 472);
            this.lblTongTienTieuDe.Name = "lblTongTienTieuDe";
            this.lblTongTienTieuDe.Size = new System.Drawing.Size(143, 23);
            this.lblTongTienTieuDe.TabIndex = 19;
            this.lblTongTienTieuDe.Text = "Tổng tiền thuốc:";
            // 
            // btnLuuToa
            // 
            this.btnLuuToa.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnLuuToa.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnLuuToa.Location = new System.Drawing.Point(745, 460);
            this.btnLuuToa.Name = "btnLuuToa";
            this.btnLuuToa.Size = new System.Drawing.Size(180, 45);
            this.btnLuuToa.TabIndex = 18;
            this.btnLuuToa.Text = "Lập toa thuốc";
            this.btnLuuToa.UseVisualStyleBackColor = true;
            this.btnLuuToa.Click += new System.EventHandler(this.btnLuuToa_Click);
            // 
            // txtLoiDan
            // 
            this.txtLoiDan.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtLoiDan.Location = new System.Drawing.Point(110, 430);
            this.txtLoiDan.Name = "txtLoiDan";
            this.txtLoiDan.Size = new System.Drawing.Size(815, 22);
            this.txtLoiDan.TabIndex = 17;
            // 
            // lblLoiDan
            // 
            this.lblLoiDan.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblLoiDan.AutoSize = true;
            this.lblLoiDan.Location = new System.Drawing.Point(15, 433);
            this.lblLoiDan.Name = "lblLoiDan";
            this.lblLoiDan.Size = new System.Drawing.Size(59, 17);
            this.lblLoiDan.TabIndex = 16;
            this.lblLoiDan.Text = "Lời dặn:";
            // 
            // dgvChiTietToa
            // 
            this.dgvChiTietToa.AllowUserToAddRows = false;
            this.dgvChiTietToa.AllowUserToDeleteRows = false;
            this.dgvChiTietToa.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvChiTietToa.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvChiTietToa.BackgroundColor = System.Drawing.Color.White;
            this.dgvChiTietToa.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvChiTietToa.Location = new System.Drawing.Point(15, 145);
            this.dgvChiTietToa.Name = "dgvChiTietToa";
            this.dgvChiTietToa.ReadOnly = true;
            this.dgvChiTietToa.RowHeadersWidth = 51;
            this.dgvChiTietToa.RowTemplate.Height = 24;
            this.dgvChiTietToa.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvChiTietToa.Size = new System.Drawing.Size(910, 270);
            this.dgvChiTietToa.TabIndex = 15;
            // 
            // btnThemThuoc
            // 
            this.btnThemThuoc.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnThemThuoc.Location = new System.Drawing.Point(795, 98);
            this.btnThemThuoc.Name = "btnThemThuoc";
            this.btnThemThuoc.Size = new System.Drawing.Size(130, 32);
            this.btnThemThuoc.TabIndex = 14;
            this.btnThemThuoc.Text = "Thêm vào toa";
            this.btnThemThuoc.UseVisualStyleBackColor = true;
            this.btnThemThuoc.Click += new System.EventHandler(this.btnThemThuoc_Click);
            // 
            // txtCachDung
            // 
            this.txtCachDung.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtCachDung.Location = new System.Drawing.Point(465, 102);
            this.txtCachDung.Name = "txtCachDung";
            this.txtCachDung.Size = new System.Drawing.Size(315, 22);
            this.txtCachDung.TabIndex = 13;
            // 
            // lblCachDung
            // 
            this.lblCachDung.AutoSize = true;
            this.lblCachDung.Location = new System.Drawing.Point(385, 105);
            this.lblCachDung.Name = "lblCachDung";
            this.lblCachDung.Size = new System.Drawing.Size(79, 17);
            this.lblCachDung.TabIndex = 12;
            this.lblCachDung.Text = "Cách dùng:";
            // 
            // txtLieuLuong
            // 
            this.txtLieuLuong.Location = new System.Drawing.Point(110, 102);
            this.txtLieuLuong.Name = "txtLieuLuong";
            this.txtLieuLuong.Size = new System.Drawing.Size(255, 22);
            this.txtLieuLuong.TabIndex = 11;
            // 
            // lblLieuLuong
            // 
            this.lblLieuLuong.AutoSize = true;
            this.lblLieuLuong.Location = new System.Drawing.Point(15, 105);
            this.lblLieuLuong.Name = "lblLieuLuong";
            this.lblLieuLuong.Size = new System.Drawing.Size(78, 17);
            this.lblLieuLuong.TabIndex = 10;
            this.lblLieuLuong.Text = "Liều lượng:";
            // 
            // numSoLuong
            // 
            this.numSoLuong.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.numSoLuong.Location = new System.Drawing.Point(825, 62);
            this.numSoLuong.Maximum = new decimal(new int[] { 1000, 0, 0, 0 });
            this.numSoLuong.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
            this.numSoLuong.Name = "numSoLuong";
            this.numSoLuong.Size = new System.Drawing.Size(100, 22);
            this.numSoLuong.TabIndex = 9;
            this.numSoLuong.Value = new decimal(new int[] { 10, 0, 0, 0 });
            // 
            // lblSoLuong
            // 
            this.lblSoLuong.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblSoLuong.AutoSize = true;
            this.lblSoLuong.Location = new System.Drawing.Point(750, 65);
            this.lblSoLuong.Name = "lblSoLuong";
            this.lblSoLuong.Size = new System.Drawing.Size(68, 17);
            this.lblSoLuong.TabIndex = 8;
            this.lblSoLuong.Text = "Số lượng:";
            // 
            // cboThuoc
            // 
            this.cboThuoc.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cboThuoc.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboThuoc.FormattingEnabled = true;
            this.cboThuoc.Location = new System.Drawing.Point(110, 62);
            this.cboThuoc.Name = "cboThuoc";
            this.cboThuoc.Size = new System.Drawing.Size(620, 24);
            this.cboThuoc.TabIndex = 7;
            // 
            // lblThuoc
            // 
            this.lblThuoc.AutoSize = true;
            this.lblThuoc.Location = new System.Drawing.Point(15, 65);
            this.lblThuoc.Name = "lblThuoc";
            this.lblThuoc.Size = new System.Drawing.Size(84, 17);
            this.lblThuoc.TabIndex = 6;
            this.lblThuoc.Text = "Chọn thuốc:";
            // 
            // txtDiUng
            // 
            this.txtDiUng.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtDiUng.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.txtDiUng.ForeColor = System.Drawing.Color.DarkRed;
            this.txtDiUng.Location = new System.Drawing.Point(530, 22);
            this.txtDiUng.Name = "txtDiUng";
            this.txtDiUng.ReadOnly = true;
            this.txtDiUng.Size = new System.Drawing.Size(395, 22);
            this.txtDiUng.TabIndex = 5;
            // 
            // lblDiUng
            // 
            this.lblDiUng.AutoSize = true;
            this.lblDiUng.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblDiUng.ForeColor = System.Drawing.Color.DarkRed;
            this.lblDiUng.Location = new System.Drawing.Point(405, 25);
            this.lblDiUng.Name = "lblDiUng";
            this.lblDiUng.Size = new System.Drawing.Size(121, 20);
            this.lblDiUng.TabIndex = 4;
            this.lblDiUng.Text = "Tiền sử dị ứng:";
            // 
            // txtMaToa
            // 
            this.txtMaToa.Location = new System.Drawing.Point(295, 22);
            this.txtMaToa.Name = "txtMaToa";
            this.txtMaToa.Size = new System.Drawing.Size(95, 22);
            this.txtMaToa.TabIndex = 3;
            // 
            // lblMaToa
            // 
            this.lblMaToa.AutoSize = true;
            this.lblMaToa.Location = new System.Drawing.Point(235, 25);
            this.lblMaToa.Name = "lblMaToa";
            this.lblMaToa.Size = new System.Drawing.Size(55, 17);
            this.lblMaToa.TabIndex = 2;
            this.lblMaToa.Text = "Mã toa:";
            // 
            // cboPhieuKham
            // 
            this.cboPhieuKham.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboPhieuKham.FormattingEnabled = true;
            this.cboPhieuKham.Location = new System.Drawing.Point(110, 22);
            this.cboPhieuKham.Name = "cboPhieuKham";
            this.cboPhieuKham.Size = new System.Drawing.Size(115, 24);
            this.cboPhieuKham.TabIndex = 1;
            this.cboPhieuKham.SelectedIndexChanged += new System.EventHandler(this.cboPhieuKham_SelectedIndexChanged);
            // 
            // lblPhieuKham
            // 
            this.lblPhieuKham.AutoSize = true;
            this.lblPhieuKham.Location = new System.Drawing.Point(15, 25);
            this.lblPhieuKham.Name = "lblPhieuKham";
            this.lblPhieuKham.Size = new System.Drawing.Size(89, 17);
            this.lblPhieuKham.TabIndex = 0;
            this.lblPhieuKham.Text = "Phiếu khám:";
            // 
            // btnDong
            // 
            this.btnDong.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDong.Location = new System.Drawing.Point(850, 568);
            this.btnDong.Name = "btnDong";
            this.btnDong.Size = new System.Drawing.Size(110, 35);
            this.btnDong.TabIndex = 1;
            this.btnDong.Text = "Đóng";
            this.btnDong.UseVisualStyleBackColor = true;
            this.btnDong.Click += new System.EventHandler(this.btnDong_Click);
            // 
            // FrmKhamBenh
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(980, 615);
            this.Controls.Add(this.btnDong);
            this.Controls.Add(this.tabKhamBenh);
            this.Name = "FrmKhamBenh";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Khám bệnh lâm sàng & Kê toa thuốc";
            this.Load += new System.EventHandler(this.FrmKhamBenh_Load);
            this.tabKhamBenh.ResumeLayout(false);
            this.tabChanDoan.ResumeLayout(false);
            this.tabChanDoan.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLichSu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numThanNhiet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvChoKham)).EndInit();
            this.tabKeToa.ResumeLayout(false);
            this.tabKeToa.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvChiTietToa)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numSoLuong)).EndInit();
            this.ResumeLayout(false);
        }

        private System.Windows.Forms.TabControl tabKhamBenh;
        private System.Windows.Forms.TabPage tabChanDoan;
        private System.Windows.Forms.TabPage tabKeToa;
        private System.Windows.Forms.Label lblDanhSachCho;
        private System.Windows.Forms.DataGridView dgvChoKham;
        private System.Windows.Forms.Label lblMaPK;
        private System.Windows.Forms.TextBox txtMaPK;
        private System.Windows.Forms.Label lblHoTen;
        private System.Windows.Forms.TextBox txtHoTen;
        private System.Windows.Forms.Label lblTrieuChung;
        private System.Windows.Forms.TextBox txtTrieuChung;
        private System.Windows.Forms.Label lblThanNhiet;
        private System.Windows.Forms.NumericUpDown numThanNhiet;
        private System.Windows.Forms.Label lblHuyetAp;
        private System.Windows.Forms.TextBox txtHuyetAp;
        private System.Windows.Forms.Label lblKetLuan;
        private System.Windows.Forms.TextBox txtKetLuan;
        private System.Windows.Forms.Button btnLuuChanDoan;
        private System.Windows.Forms.Label lblLichSu;
        private System.Windows.Forms.DataGridView dgvLichSu;
        private System.Windows.Forms.Label lblPhieuKham;
        private System.Windows.Forms.ComboBox cboPhieuKham;
        private System.Windows.Forms.Label lblMaToa;
        private System.Windows.Forms.TextBox txtMaToa;
        private System.Windows.Forms.Label lblDiUng;
        private System.Windows.Forms.TextBox txtDiUng;
        private System.Windows.Forms.Label lblThuoc;
        private System.Windows.Forms.ComboBox cboThuoc;
        private System.Windows.Forms.Label lblSoLuong;
        private System.Windows.Forms.NumericUpDown numSoLuong;
        private System.Windows.Forms.Label lblLieuLuong;
        private System.Windows.Forms.TextBox txtLieuLuong;
        private System.Windows.Forms.Label lblCachDung;
        private System.Windows.Forms.TextBox txtCachDung;
        private System.Windows.Forms.Button btnThemThuoc;
        private System.Windows.Forms.DataGridView dgvChiTietToa;
        private System.Windows.Forms.Label lblLoiDan;
        private System.Windows.Forms.TextBox txtLoiDan;
        private System.Windows.Forms.Button btnLuuToa;
        private System.Windows.Forms.Label lblTongTienTieuDe;
        private System.Windows.Forms.Label lblTongTien;
        private System.Windows.Forms.Button btnDong;
    }
}