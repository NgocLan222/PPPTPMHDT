﻿using System;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using QuanLyHoSoBenhAn.Services;

namespace QuanLyHoSoBenhAn.Forms
{
    public partial class FrmKhamBenh : Form
    {
        private readonly KhamBenhService khamSvc = new KhamBenhService();
        private readonly ToaThuocService toaSvc = new ToaThuocService();
        private readonly DanhMucService dmSvc = new DanhMucService();

        private readonly BindingList<ChiTietToaThuocItem> dsThuocKe = new BindingList<ChiTietToaThuocItem>();
        private string maHoSoHienTai = "";

        public FrmKhamBenh()
        {
            InitializeComponent();
        }

        private void FrmKhamBenh_Load(object sender, EventArgs e)
        {
            dgvChiTietToa.DataSource = dsThuocKe;
            FormHelper.Nap(cboThuoc, dmSvc.LayThuoc(), "TenThuoc", "MaThuoc");
            TaiDanhSachCho();
        }

        private void TaiDanhSachCho()
        {
            var dtCho = khamSvc.LayPhieuChoKham();
            dgvChoKham.DataSource = dtCho;
            FormHelper.Nap(cboPhieuKham, dtCho, "MaPK", "MaPK");
        }

        private void dgvChoKham_SelectionChanged(object sender, EventArgs e)
        {
            txtMaPK.Text = FormHelper.O(dgvChoKham, "MaPK");
            txtHoTen.Text = FormHelper.O(dgvChoKham, "HoTen");
            txtTrieuChung.Text = FormHelper.O(dgvChoKham, "TrieuChung");
            txtKetLuan.Text = FormHelper.O(dgvChoKham, "KetLuan");

            string tn = FormHelper.O(dgvChoKham, "ThanNhiet");
            if (!string.IsNullOrEmpty(tn)) numThanNhiet.Value = Convert.ToDecimal(tn);

            txtHuyetAp.Text = FormHelper.O(dgvChoKham, "HuyetAp");

            maHoSoHienTai = FormHelper.O(dgvChoKham, "MaHoSo");
            if (!string.IsNullOrEmpty(maHoSoHienTai))
            {
                dgvLichSu.DataSource = khamSvc.LayLichSuKham(maHoSoHienTai);
            }
        }

        private void btnLuuChanDoan_Click(object sender, EventArgs e)
        {
            var k = khamSvc.CapNhatKetLuan(txtMaPK.Text, txtTrieuChung.Text, numThanNhiet.Value, txtHuyetAp.Text, txtKetLuan.Text);
            if (FormHelper.Bao(k))
            {
                TaiDanhSachCho();
            }
        }

        private void cboPhieuKham_SelectedIndexChanged(object sender, EventArgs e)
        {
            string pk = FormHelper.Gia(cboPhieuKham);
            if (string.IsNullOrEmpty(pk)) return;

            txtMaToa.Text = "TOA_" + pk;
            dsThuocKe.Clear();
            CapNhatTongTien();

            var dtCho = dgvChoKham.DataSource as DataTable;
            if (dtCho != null)
            {
                var r = dtCho.Select("MaPK = '" + pk + "'").FirstOrDefault();
                if (r != null)
                {
                    string hs = Convert.ToString(r["MaHoSo"]);
                    var dtDiUng = toaSvc.LayTienSuPhanUngThuoc(hs);
                    if (dtDiUng.Rows.Count > 0)
                    {
                        string ds = "";
                        foreach (DataRow row in dtDiUng.Rows)
                            ds += row["PhanUngPhu"] + "; ";
                        txtDiUng.Text = ds.TrimEnd(' ', ';');
                    }
                    else
                    {
                        txtDiUng.Text = "Không có tiền sử dị ứng thuốc ghi nhận.";
                    }
                }
            }
        }

        private void btnThemThuoc_Click(object sender, EventArgs e)
        {
            var r = cboThuoc.SelectedItem as DataRowView;
            if (r == null) return;

            string maT = Convert.ToString(r["MaThuoc"]);
            string tenT = Convert.ToString(r["TenThuoc"]);
            decimal gia = Convert.ToDecimal(r["DonGia"]);

            if (txtDiUng.Text.ToLower().Contains(tenT.ToLower()))
            {
                if (MessageBox.Show("Cảnh báo: Bệnh nhân có tiền sử dị ứng/phản ứng phụ với " + tenT + "! Bạn có chắc chắn muốn kê không?",
                    "Cảnh báo dị ứng thuốc", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes)
                    return;
            }

            var item = dsThuocKe.FirstOrDefault(x => x.MaThuoc == maT);
            if (item != null)
            {
                item.SoLuong += (int)numSoLuong.Value;
                item.LieuLuong = txtLieuLuong.Text;
                item.CachDung = txtCachDung.Text;
                dgvChiTietToa.Refresh();
            }
            else
            {
                dsThuocKe.Add(new ChiTietToaThuocItem
                {
                    MaThuoc = maT,
                    TenThuoc = tenT,
                    SoLuong = (int)numSoLuong.Value,
                    LieuLuong = txtLieuLuong.Text,
                    CachDung = txtCachDung.Text,
                    DonGia = gia
                });
            }

            CapNhatTongTien();
        }

        private void CapNhatTongTien()
        {
            decimal tong = dsThuocKe.Sum(x => x.ThanhTien);
            lblTongTien.Text = tong.ToString("N0") + " đ";
        }

        private void btnLuuToa_Click(object sender, EventArgs e)
        {
            string pk = FormHelper.Gia(cboPhieuKham);
            var k = toaSvc.KeToa(txtMaToa.Text, pk, maHoSoHienTai, txtLoiDan.Text, dsThuocKe.ToList());
            if (FormHelper.Bao(k))
            {
                dsThuocKe.Clear();
                CapNhatTongTien();
                txtLoiDan.Clear();
            }
        }

        private void btnDong_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}