﻿namespace QuanLyHoSoBenhAn.Forms
{
    partial class FrmMain
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblTieuDe = new System.Windows.Forms.Label();
            this.btnDanhMuc = new System.Windows.Forms.Button();
            this.btnTiepNhan = new System.Windows.Forms.Button();
            this.btnKhamBenh = new System.Windows.Forms.Button();
            this.btnXetNghiem = new System.Windows.Forms.Button();
            this.btnVienPhi = new System.Windows.Forms.Button();
            this.btnTheoDoi = new System.Windows.Forms.Button();
            this.btnThoat = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblTieuDe
            // 
            this.lblTieuDe.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblTieuDe.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTieuDe.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(70)))), ((int)(((byte)(140)))));
            this.lblTieuDe.Location = new System.Drawing.Point(0, 0);
            this.lblTieuDe.Name = "lblTieuDe";
            this.lblTieuDe.Size = new System.Drawing.Size(764, 80);
            this.lblTieuDe.TabIndex = 0;
            this.lblTieuDe.Text = "HỆ THỐNG QUẢN LÝ HỒ SƠ BỆNH ÁN";
            this.lblTieuDe.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnDanhMuc
            // 
            this.btnDanhMuc.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnDanhMuc.Location = new System.Drawing.Point(80, 100);
            this.btnDanhMuc.Name = "btnDanhMuc";
            this.btnDanhMuc.Size = new System.Drawing.Size(270, 55);
            this.btnDanhMuc.TabIndex = 1;
            this.btnDanhMuc.Text = "Danh mục hệ thống";
            this.btnDanhMuc.UseVisualStyleBackColor = true;
            this.btnDanhMuc.Click += new System.EventHandler(this.btnDanhMuc_Click);
            // 
            // btnTiepNhan
            // 
            this.btnTiepNhan.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnTiepNhan.Location = new System.Drawing.Point(410, 100);
            this.btnTiepNhan.Name = "btnTiepNhan";
            this.btnTiepNhan.Size = new System.Drawing.Size(270, 55);
            this.btnTiepNhan.TabIndex = 2;
            this.btnTiepNhan.Text = "Tiếp nhận & Cấp hồ sơ";
            this.btnTiepNhan.UseVisualStyleBackColor = true;
            this.btnTiepNhan.Click += new System.EventHandler(this.btnTiepNhan_Click);
            // 
            // btnKhamBenh
            // 
            this.btnKhamBenh.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnKhamBenh.Location = new System.Drawing.Point(80, 180);
            this.btnKhamBenh.Name = "btnKhamBenh";
            this.btnKhamBenh.Size = new System.Drawing.Size(270, 55);
            this.btnKhamBenh.TabIndex = 3;
            this.btnKhamBenh.Text = "Khám bệnh & Kê toa";
            this.btnKhamBenh.UseVisualStyleBackColor = true;
            this.btnKhamBenh.Click += new System.EventHandler(this.btnKhamBenh_Click);
            // 
            // btnXetNghiem
            // 
            this.btnXetNghiem.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnXetNghiem.Location = new System.Drawing.Point(410, 180);
            this.btnXetNghiem.Name = "btnXetNghiem";
            this.btnXetNghiem.Size = new System.Drawing.Size(270, 55);
            this.btnXetNghiem.TabIndex = 4;
            this.btnXetNghiem.Text = "Xét nghiệm";
            this.btnXetNghiem.UseVisualStyleBackColor = true;
            this.btnXetNghiem.Click += new System.EventHandler(this.btnXetNghiem_Click);
            // 
            // btnVienPhi
            // 
            this.btnVienPhi.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnVienPhi.Location = new System.Drawing.Point(80, 260);
            this.btnVienPhi.Name = "btnVienPhi";
            this.btnVienPhi.Size = new System.Drawing.Size(270, 55);
            this.btnVienPhi.TabIndex = 5;
            this.btnVienPhi.Text = "Thanh toán viện phí";
            this.btnVienPhi.UseVisualStyleBackColor = true;
            this.btnVienPhi.Click += new System.EventHandler(this.btnVienPhi_Click);
            // 
            // btnTheoDoi
            // 
            this.btnTheoDoi.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnTheoDoi.Location = new System.Drawing.Point(410, 260);
            this.btnTheoDoi.Name = "btnTheoDoi";
            this.btnTheoDoi.Size = new System.Drawing.Size(270, 55);
            this.btnTheoDoi.TabIndex = 6;
            this.btnTheoDoi.Text = "Chăm sóc & Theo dõi sau khám";
            this.btnTheoDoi.UseVisualStyleBackColor = true;
            this.btnTheoDoi.Click += new System.EventHandler(this.btnTheoDoi_Click);
            // 
            // btnThoat
            // 
            this.btnThoat.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnThoat.Location = new System.Drawing.Point(245, 345);
            this.btnThoat.Name = "btnThoat";
            this.btnThoat.Size = new System.Drawing.Size(270, 50);
            this.btnThoat.TabIndex = 7;
            this.btnThoat.Text = "Thoát";
            this.btnThoat.UseVisualStyleBackColor = true;
            this.btnThoat.Click += new System.EventHandler(this.btnThoat_Click);
            // 
            // FrmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(764, 425);
            this.Controls.Add(this.btnThoat);
            this.Controls.Add(this.btnTheoDoi);
            this.Controls.Add(this.btnVienPhi);
            this.Controls.Add(this.btnXetNghiem);
            this.Controls.Add(this.btnKhamBenh);
            this.Controls.Add(this.btnTiepNhan);
            this.Controls.Add(this.btnDanhMuc);
            this.Controls.Add(this.lblTieuDe);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "FrmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quản lý hồ sơ bệnh án";
            this.ResumeLayout(false);
        }

        private System.Windows.Forms.Label lblTieuDe;
        private System.Windows.Forms.Button btnDanhMuc;
        private System.Windows.Forms.Button btnTiepNhan;
        private System.Windows.Forms.Button btnKhamBenh;
        private System.Windows.Forms.Button btnXetNghiem;
        private System.Windows.Forms.Button btnVienPhi;
        private System.Windows.Forms.Button btnTheoDoi;
        private System.Windows.Forms.Button btnThoat;
    }
}