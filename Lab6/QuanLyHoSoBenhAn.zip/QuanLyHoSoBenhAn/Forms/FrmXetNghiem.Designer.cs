﻿namespace QuanLyHoSoBenhAn.Forms
{
    partial class FrmXetNghiem
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.tabXetNghiem = new System.Windows.Forms.TabControl();
            this.tabChiDinh = new System.Windows.Forms.TabPage();
            this.btnChiDinh = new System.Windows.Forms.Button();
            this.cboLoaiXN = new System.Windows.Forms.ComboBox();
            this.lblLoaiXN = new System.Windows.Forms.Label();
            this.txtMaPXN = new System.Windows.Forms.TextBox();
            this.lblMaPXN = new System.Windows.Forms.Label();
            this.cboPhieuKham = new System.Windows.Forms.ComboBox();
            this.lblPhieuKham = new System.Windows.Forms.Label();
            this.dgvChiDinhTheoPK = new System.Windows.Forms.DataGridView();
            this.tabCapNhatKQ = new System.Windows.Forms.TabPage();
            this.btnLuuKQ = new System.Windows.Forms.Button();
            this.txtKetQua = new System.Windows.Forms.TextBox();
            this.lblKetQua = new System.Windows.Forms.Label();
            this.txtTenLXN_KQ = new System.Windows.Forms.TextBox();
            this.lblTenLXN_KQ = new System.Windows.Forms.Label();
            this.txtMaPXN_KQ = new System.Windows.Forms.TextBox();
            this.lblMaPXN_KQ = new System.Windows.Forms.Label();
            this.dgvChoXN = new System.Windows.Forms.DataGridView();
            this.btnDong = new System.Windows.Forms.Button();
            this.tabXetNghiem.SuspendLayout();
            this.tabChiDinh.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvChiDinhTheoPK)).BeginInit();
            this.tabCapNhatKQ.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvChoXN)).BeginInit();
            this.SuspendLayout();
            // 
            // tabXetNghiem
            // 
            this.tabXetNghiem.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabXetNghiem.Controls.Add(this.tabChiDinh);
            this.tabXetNghiem.Controls.Add(this.tabCapNhatKQ);
            this.tabXetNghiem.Location = new System.Drawing.Point(15, 15);
            this.tabXetNghiem.Name = "tabXetNghiem";
            this.tabXetNghiem.SelectedIndex = 0;
            this.tabXetNghiem.Size = new System.Drawing.Size(950, 520);
            this.tabXetNghiem.TabIndex = 0;
            // 
            // tabChiDinh
            // 
            this.tabChiDinh.Controls.Add(this.btnChiDinh);
            this.tabChiDinh.Controls.Add(this.cboLoaiXN);
            this.tabChiDinh.Controls.Add(this.lblLoaiXN);
            this.tabChiDinh.Controls.Add(this.txtMaPXN);
            this.tabChiDinh.Controls.Add(this.lblMaPXN);
            this.tabChiDinh.Controls.Add(this.cboPhieuKham);
            this.tabChiDinh.Controls.Add(this.lblPhieuKham);
            this.tabChiDinh.Controls.Add(this.dgvChiDinhTheoPK);
            this.tabChiDinh.Location = new System.Drawing.Point(4, 25);
            this.tabChiDinh.Name = "tabChiDinh";
            this.tabChiDinh.Padding = new System.Windows.Forms.Padding(3);
            this.tabChiDinh.Size = new System.Drawing.Size(942, 491);
            this.tabChiDinh.TabIndex = 0;
            this.tabChiDinh.Text = "Chỉ định cận lâm sàng (Bác sĩ)";
            this.tabChiDinh.UseVisualStyleBackColor = true;
            // 
            // btnChiDinh
            // 
            this.btnChiDinh.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnChiDinh.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnChiDinh.Location = new System.Drawing.Point(775, 17);
            this.btnChiDinh.Name = "btnChiDinh";
            this.btnChiDinh.Size = new System.Drawing.Size(150, 34);
            this.btnChiDinh.TabIndex = 7;
            this.btnChiDinh.Text = "Tạo chỉ định";
            this.btnChiDinh.UseVisualStyleBackColor = true;
            this.btnChiDinh.Click += new System.EventHandler(this.btnChiDinh_Click);
            // 
            // cboLoaiXN
            // 
            this.cboLoaiXN.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cboLoaiXN.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboLoaiXN.FormattingEnabled = true;
            this.cboLoaiXN.Location = new System.Drawing.Point(525, 22);
            this.cboLoaiXN.Name = "cboLoaiXN";
            this.cboLoaiXN.Size = new System.Drawing.Size(235, 24);
            this.cboLoaiXN.TabIndex = 6;
            // 
            // lblLoaiXN
            // 
            this.lblLoaiXN.AutoSize = true;
            this.lblLoaiXN.Location = new System.Drawing.Point(455, 25);
            this.lblLoaiXN.Name = "lblLoaiXN";
            this.lblLoaiXN.Size = new System.Drawing.Size(61, 17);
            this.lblLoaiXN.TabIndex = 5;
            this.lblLoaiXN.Text = "Loại XN:";
            // 
            // txtMaPXN
            // 
            this.txtMaPXN.Location = new System.Drawing.Point(315, 22);
            this.txtMaPXN.Name = "txtMaPXN";
            this.txtMaPXN.Size = new System.Drawing.Size(120, 22);
            this.txtMaPXN.TabIndex = 4;
            // 
            // lblMaPXN
            // 
            this.lblMaPXN.AutoSize = true;
            this.lblMaPXN.Location = new System.Drawing.Point(245, 25);
            this.lblMaPXN.Name = "lblMaPXN";
            this.lblMaPXN.Size = new System.Drawing.Size(63, 17);
            this.lblMaPXN.TabIndex = 3;
            this.lblMaPXN.Text = "Mã PXN:";
            // 
            // cboPhieuKham
            // 
            this.cboPhieuKham.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboPhieuKham.FormattingEnabled = true;
            this.cboPhieuKham.Location = new System.Drawing.Point(105, 22);
            this.cboPhieuKham.Name = "cboPhieuKham";
            this.cboPhieuKham.Size = new System.Drawing.Size(120, 24);
            this.cboPhieuKham.TabIndex = 2;
            this.cboPhieuKham.SelectedIndexChanged += new System.EventHandler(this.cboPhieuKham_SelectedIndexChanged);
            // 
            // lblPhieuKham
            // 
            this.lblPhieuKham.AutoSize = true;
            this.lblPhieuKham.Location = new System.Drawing.Point(15, 25);
            this.lblPhieuKham.Name = "lblPhieuKham";
            this.lblPhieuKham.Size = new System.Drawing.Size(89, 17);
            this.lblPhieuKham.TabIndex = 1;
            this.lblPhieuKham.Text = "Phiếu khám:";
            // 
            // dgvChiDinhTheoPK
            // 
            this.dgvChiDinhTheoPK.AllowUserToAddRows = false;
            this.dgvChiDinhTheoPK.AllowUserToDeleteRows = false;
            this.dgvChiDinhTheoPK.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvChiDinhTheoPK.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvChiDinhTheoPK.BackgroundColor = System.Drawing.Color.White;
            this.dgvChiDinhTheoPK.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvChiDinhTheoPK.Location = new System.Drawing.Point(15, 65);
            this.dgvChiDinhTheoPK.Name = "dgvChiDinhTheoPK";
            this.dgvChiDinhTheoPK.ReadOnly = true;
            this.dgvChiDinhTheoPK.RowHeadersWidth = 51;
            this.dgvChiDinhTheoPK.RowTemplate.Height = 24;
            this.dgvChiDinhTheoPK.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvChiDinhTheoPK.Size = new System.Drawing.Size(910, 410);
            this.dgvChiDinhTheoPK.TabIndex = 0;
            // 
            // tabCapNhatKQ
            // 
            this.tabCapNhatKQ.Controls.Add(this.btnLuuKQ);
            this.tabCapNhatKQ.Controls.Add(this.txtKetQua);
            this.tabCapNhatKQ.Controls.Add(this.lblKetQua);
            this.tabCapNhatKQ.Controls.Add(this.txtTenLXN_KQ);
            this.tabCapNhatKQ.Controls.Add(this.lblTenLXN_KQ);
            this.tabCapNhatKQ.Controls.Add(this.txtMaPXN_KQ);
            this.tabCapNhatKQ.Controls.Add(this.lblMaPXN_KQ);
            this.tabCapNhatKQ.Controls.Add(this.dgvChoXN);
            this.tabCapNhatKQ.Location = new System.Drawing.Point(4, 25);
            this.tabCapNhatKQ.Name = "tabCapNhatKQ";
            this.tabCapNhatKQ.Padding = new System.Windows.Forms.Padding(3);
            this.tabCapNhatKQ.Size = new System.Drawing.Size(942, 491);
            this.tabCapNhatKQ.TabIndex = 1;
            this.tabCapNhatKQ.Text = "Cập nhật kết quả xét nghiệm (KTV)";
            this.tabCapNhatKQ.UseVisualStyleBackColor = true;
            // 
            // btnLuuKQ
            // 
            this.btnLuuKQ.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnLuuKQ.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnLuuKQ.Location = new System.Drawing.Point(775, 430);
            this.btnLuuKQ.Name = "btnLuuKQ";
            this.btnLuuKQ.Size = new System.Drawing.Size(150, 45);
            this.btnLuuKQ.TabIndex = 7;
            this.btnLuuKQ.Text = "Lưu kết quả";
            this.btnLuuKQ.UseVisualStyleBackColor = true;
            this.btnLuuKQ.Click += new System.EventHandler(this.btnLuuKQ_Click);
            // 
            // txtKetQua
            // 
            this.txtKetQua.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtKetQua.Location = new System.Drawing.Point(105, 442);
            this.txtKetQua.Name = "txtKetQua";
            this.txtKetQua.Size = new System.Drawing.Size(650, 22);
            this.txtKetQua.TabIndex = 6;
            // 
            // lblKetQua
            // 
            this.lblKetQua.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblKetQua.AutoSize = true;
            this.lblKetQua.Location = new System.Drawing.Point(15, 445);
            this.lblKetQua.Name = "lblKetQua";
            this.lblKetQua.Size = new System.Drawing.Size(61, 17);
            this.lblKetQua.TabIndex = 5;
            this.lblKetQua.Text = "Kết quả:";
            // 
            // txtTenLXN_KQ
            // 
            this.txtTenLXN_KQ.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtTenLXN_KQ.Location = new System.Drawing.Point(340, 400);
            this.txtTenLXN_KQ.Name = "txtTenLXN_KQ";
            this.txtTenLXN_KQ.ReadOnly = true;
            this.txtTenLXN_KQ.Size = new System.Drawing.Size(415, 22);
            this.txtTenLXN_KQ.TabIndex = 4;
            // 
            // lblTenLXN_KQ
            // 
            this.lblTenLXN_KQ.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblTenLXN_KQ.AutoSize = true;
            this.lblTenLXN_KQ.Location = new System.Drawing.Point(265, 403);
            this.lblTenLXN_KQ.Name = "lblTenLXN_KQ";
            this.lblTenLXN_KQ.Size = new System.Drawing.Size(61, 17);
            this.lblTenLXN_KQ.TabIndex = 3;
            this.lblTenLXN_KQ.Text = "Loại XN:";
            // 
            // txtMaPXN_KQ
            // 
            this.txtMaPXN_KQ.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.txtMaPXN_KQ.Location = new System.Drawing.Point(105, 400);
            this.txtMaPXN_KQ.Name = "txtMaPXN_KQ";
            this.txtMaPXN_KQ.ReadOnly = true;
            this.txtMaPXN_KQ.Size = new System.Drawing.Size(130, 22);
            this.txtMaPXN_KQ.TabIndex = 2;
            // 
            // lblMaPXN_KQ
            // 
            this.lblMaPXN_KQ.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblMaPXN_KQ.AutoSize = true;
            this.lblMaPXN_KQ.Location = new System.Drawing.Point(15, 403);
            this.lblMaPXN_KQ.Name = "lblMaPXN_KQ";
            this.lblMaPXN_KQ.Size = new System.Drawing.Size(63, 17);
            this.lblMaPXN_KQ.TabIndex = 1;
            this.lblMaPXN_KQ.Text = "Mã PXN:";
            // 
            // dgvChoXN
            // 
            this.dgvChoXN.AllowUserToAddRows = false;
            this.dgvChoXN.AllowUserToDeleteRows = false;
            this.dgvChoXN.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvChoXN.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvChoXN.BackgroundColor = System.Drawing.Color.White;
            this.dgvChoXN.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvChoXN.Location = new System.Drawing.Point(15, 15);
            this.dgvChoXN.Name = "dgvChoXN";
            this.dgvChoXN.ReadOnly = true;
            this.dgvChoXN.RowHeadersWidth = 51;
            this.dgvChoXN.RowTemplate.Height = 24;
            this.dgvChoXN.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvChoXN.Size = new System.Drawing.Size(910, 365);
            this.dgvChoXN.TabIndex = 0;
            this.dgvChoXN.SelectionChanged += new System.EventHandler(this.dgvChoXN_SelectionChanged);
            // 
            // btnDong
            // 
            this.btnDong.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDong.Location = new System.Drawing.Point(850, 545);
            this.btnDong.Name = "btnDong";
            this.btnDong.Size = new System.Drawing.Size(110, 35);
            this.btnDong.TabIndex = 1;
            this.btnDong.Text = "Đóng";
            this.btnDong.UseVisualStyleBackColor = true;
            this.btnDong.Click += new System.EventHandler(this.btnDong_Click);
            // 
            // FrmXetNghiem
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(980, 595);
            this.Controls.Add(this.btnDong);
            this.Controls.Add(this.tabXetNghiem);
            this.Name = "FrmXetNghiem";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Cận lâm sàng - Xét nghiệm";
            this.Load += new System.EventHandler(this.FrmXetNghiem_Load);
            this.tabXetNghiem.ResumeLayout(false);
            this.tabChiDinh.ResumeLayout(false);
            this.tabChiDinh.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvChiDinhTheoPK)).EndInit();
            this.tabCapNhatKQ.ResumeLayout(false);
            this.tabCapNhatKQ.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvChoXN)).EndInit();
            this.ResumeLayout(false);
        }

        private System.Windows.Forms.TabControl tabXetNghiem;
        private System.Windows.Forms.TabPage tabChiDinh;
        private System.Windows.Forms.TabPage tabCapNhatKQ;
        private System.Windows.Forms.DataGridView dgvChiDinhTheoPK;
        private System.Windows.Forms.Label lblPhieuKham;
        private System.Windows.Forms.ComboBox cboPhieuKham;
        private System.Windows.Forms.Label lblMaPXN;
        private System.Windows.Forms.TextBox txtMaPXN;
        private System.Windows.Forms.Label lblLoaiXN;
        private System.Windows.Forms.ComboBox cboLoaiXN;
        private System.Windows.Forms.Button btnChiDinh;
        private System.Windows.Forms.DataGridView dgvChoXN;
        private System.Windows.Forms.Label lblMaPXN_KQ;
        private System.Windows.Forms.TextBox txtMaPXN_KQ;
        private System.Windows.Forms.Label lblTenLXN_KQ;
        private System.Windows.Forms.TextBox txtTenLXN_KQ;
        private System.Windows.Forms.Label lblKetQua;
        private System.Windows.Forms.TextBox txtKetQua;
        private System.Windows.Forms.Button btnLuuKQ;
        private System.Windows.Forms.Button btnDong;
    }
}