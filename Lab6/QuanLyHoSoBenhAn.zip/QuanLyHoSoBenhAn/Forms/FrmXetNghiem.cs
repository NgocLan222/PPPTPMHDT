﻿using System;
using System.Windows.Forms;
using QuanLyHoSoBenhAn.Services;

namespace QuanLyHoSoBenhAn.Forms
{
    public partial class FrmXetNghiem : Form
    {
        private readonly XetNghiemService xnSvc = new XetNghiemService();
        private readonly DanhMucService dmSvc = new DanhMucService();
        private readonly KhamBenhService khamSvc = new KhamBenhService();

        public FrmXetNghiem()
        {
            InitializeComponent();
        }

        private void FrmXetNghiem_Load(object sender, EventArgs e)
        {
            FormHelper.Nap(cboPhieuKham, khamSvc.LayPhieuChoKham(), "MaPK", "MaPK");
            FormHelper.Nap(cboLoaiXN, dmSvc.LayLoaiXetNghiem(), "TenLXN", "MaLXN");
            TaiDanhSachChoXN();
            cboPhieuKham_SelectedIndexChanged(null, null);
        }

        private void TaiDanhSachChoXN()
        {
            dgvChoXN.DataSource = xnSvc.LayDanhSachChoXetNghiem();
        }

        private void cboPhieuKham_SelectedIndexChanged(object sender, EventArgs e)
        {
            string pk = FormHelper.Gia(cboPhieuKham);
            if (!string.IsNullOrEmpty(pk))
            {
                dgvChiDinhTheoPK.DataSource = xnSvc.LayXetNghiemTheoPhieuKham(pk);
                txtMaPXN.Text = "PXN_" + pk + "_" + (dgvChiDinhTheoPK.Rows.Count + 1);
            }
        }

        private void btnChiDinh_Click(object sender, EventArgs e)
        {
            string pk = FormHelper.Gia(cboPhieuKham);
            string lxn = FormHelper.Gia(cboLoaiXN);

            var k = xnSvc.ChiDinhXetNghiem(txtMaPXN.Text, pk, lxn);
            if (FormHelper.Bao(k))
            {
                cboPhieuKham_SelectedIndexChanged(null, null);
                TaiDanhSachChoXN();
            }
        }

        private void dgvChoXN_SelectionChanged(object sender, EventArgs e)
        {
            txtMaPXN_KQ.Text = FormHelper.O(dgvChoXN, "MaPXN");
            txtTenLXN_KQ.Text = FormHelper.O(dgvChoXN, "TenLXN");
            txtKetQua.Clear();
        }

        private void btnLuuKQ_Click(object sender, EventArgs e)
        {
            var k = xnSvc.CapNhatKetQua(txtMaPXN_KQ.Text, txtKetQua.Text);
            if (FormHelper.Bao(k))
            {
                txtKetQua.Clear();
                TaiDanhSachChoXN();
                cboPhieuKham_SelectedIndexChanged(null, null);
            }
        }

        private void btnDong_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}