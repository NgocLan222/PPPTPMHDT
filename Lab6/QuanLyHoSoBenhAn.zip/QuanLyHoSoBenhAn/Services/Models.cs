﻿using System;

namespace QuanLyHoSoBenhAn.Services
{
    public class KetQuaXuLy
    {
        public bool ThanhCong { get; private set; }
        public string ThongBao { get; private set; }
        public static KetQuaXuLy Ok(string thongBao) { return new KetQuaXuLy { ThanhCong = true, ThongBao = thongBao }; }
        public static KetQuaXuLy Fail(string thongBao) { return new KetQuaXuLy { ThanhCong = false, ThongBao = thongBao }; }
    }

    public class ChiTietToaThuocItem
    {
        public string MaCTT { get; set; }
        public string MaThuoc { get; set; }
        public string TenThuoc { get; set; }
        public int SoLuong { get; set; }
        public string LieuLuong { get; set; }
        public string CachDung { get; set; }
        public decimal DonGia { get; set; }
        public decimal ThanhTien { get { return SoLuong * DonGia; } }
    }

    public static class QuyDinh
    {
        public const string ConHieuLuc = "Còn hiệu lực";
        public const string HetHan = "Hết hạn lệ phí";
        public const string DaKhoa = "Đã khóa";
        public const string KhamBenh = "Khám bệnh";
        public const string KhamDinhKy = "Khám định kỳ";
        public const string ChoXetNghiem = "Chờ xét nghiệm";
        public const string DaCoKetQua = "Đã có kết quả";
        public const string ChoThanhToan = "Chờ thanh toán";
        public const string DaThanhToan = "Đã thanh toán";
    }
}