﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using QuanLyHoSoBenhAn.Data;

namespace QuanLyHoSoBenhAn.Services
{
    public class ToaThuocService
    {
        public DataTable LayTienSuPhanUngThuoc(string maHoSo)
        {
            return Db.Query(@"SELECT DISTINCT td.PhanUngPhu, p.NgayGioKham 
                              FROM TheoDoiSauKham td 
                              JOIN PhieuKhamBenh p ON td.MaPK = p.MaPK 
                              WHERE td.MaHoSo = @h AND td.PhanUngPhu IS NOT NULL AND LEN(RTRIM(LTRIM(td.PhanUngPhu))) > 0",
                Db.P("@h", maHoSo));
        }

        public DataTable LayToaThuocTheoPK(string maPK)
        {
            return Db.Query("SELECT MaToa, NgayKe, LoiDan, TongTien FROM ToaThuoc WHERE MaPK = @pk", Db.P("@pk", maPK));
        }

        public DataTable LayChiTietToa(string maToa)
        {
            return Db.Query(@"SELECT c.MaCTT, t.TenThuoc, c.SoLuong, t.DVT, c.DonGia, (c.SoLuong * c.DonGia) AS ThanhTien, c.LieuLuong, c.CachDung 
                              FROM ChiTietToaThuoc c 
                              JOIN Thuoc t ON c.MaThuoc = t.MaThuoc 
                              WHERE c.MaToa = @toa", Db.P("@toa", maToa));
        }

        public KetQuaXuLy KeToa(string maToa, string maPK, string maHoSo, string loiDan, List<ChiTietToaThuocItem> dsChiTiet)
        {
            if (string.IsNullOrWhiteSpace(maToa) || string.IsNullOrWhiteSpace(maPK))
                return KetQuaXuLy.Fail("Chưa có mã toa hoặc mã phiếu khám.");
            if (dsChiTiet == null || dsChiTiet.Count == 0)
                return KetQuaXuLy.Fail("Toa thuốc phải có ít nhất một loại thuốc.");

            var dtDiUng = LayTienSuPhanUngThuoc(maHoSo);
            foreach (var item in dsChiTiet)
            {
                foreach (DataRow r in dtDiUng.Rows)
                {
                    string phanUng = Convert.ToString(r["PhanUngPhu"]).ToLower();
                    if (phanUng.Contains(item.TenThuoc.ToLower()))
                        return KetQuaXuLy.Fail("Cảnh báo: Bệnh nhân có tiền sử phản ứng phụ/dị ứng với thuốc " + item.TenThuoc + ".");
                }
            }

            decimal tongTien = 0;
            foreach (var x in dsChiTiet) tongTien += x.ThanhTien;

            using (var cn = Db.OpenConnection())
            using (var tr = cn.BeginTransaction())
            {
                try
                {
                    using (var cmd = new SqlCommand(@"INSERT INTO ToaThuoc(MaToa, MaPK, NgayKe, LoiDan, TongTien) 
                                                      VALUES(@t, @pk, SYSDATETIME(), @ld, @tt)", cn, tr))
                    {
                        cmd.Parameters.Add(Db.P("@t", maToa));
                        cmd.Parameters.Add(Db.P("@pk", maPK));
                        cmd.Parameters.Add(Db.P("@ld", loiDan));
                        cmd.Parameters.Add(Db.P("@tt", tongTien));
                        cmd.ExecuteNonQuery();
                    }

                    int stt = 1;
                    foreach (var x in dsChiTiet)
                    {
                        string maCTT = string.IsNullOrWhiteSpace(x.MaCTT) ? (maToa + "_CT" + stt) : x.MaCTT;
                        using (var cmd = new SqlCommand(@"INSERT INTO ChiTietToaThuoc(MaCTT, MaToa, MaThuoc, SoLuong, LieuLuong, CachDung, DonGia) 
                                                          VALUES(@ctt, @t, @m, @sl, @ll, @cd, @dg)", cn, tr))
                        {
                            cmd.Parameters.Add(Db.P("@ctt", maCTT));
                            cmd.Parameters.Add(Db.P("@t", maToa));
                            cmd.Parameters.Add(Db.P("@m", x.MaThuoc));
                            cmd.Parameters.Add(Db.P("@sl", x.SoLuong));
                            cmd.Parameters.Add(Db.P("@ll", x.LieuLuong));
                            cmd.Parameters.Add(Db.P("@cd", x.CachDung));
                            cmd.Parameters.Add(Db.P("@dg", x.DonGia));
                            cmd.ExecuteNonQuery();
                        }
                        stt++;
                    }

                    tr.Commit();
                    return KetQuaXuLy.Ok("Đã kê toa thuốc " + maToa + ". Tổng tiền thuốc: " + tongTien.ToString("N0") + " đ.");
                }
                catch (Exception ex)
                {
                    try { tr.Rollback(); } catch { }
                    return KetQuaXuLy.Fail(ex.Message);
                }
            }
        }
    }
}