﻿using System;
using System.Data;
using QuanLyHoSoBenhAn.Data;

namespace QuanLyHoSoBenhAn.Services
{
    public class KhamBenhService
    {
        public DataTable LayPhieuChoKham()
        {
            return Db.Query(@"SELECT p.MaPK, p.MaHoSo, h.HoTen, k.TenKhoa, b.HoTen AS TenBacSi, p.NgayGioKham, p.LoaiKham, p.TrieuChung, p.ThanNhiet, p.HuyetAp, p.KetLuan
                              FROM PhieuKhamBenh p 
                              JOIN HoSoBenhAn h ON p.MaHoSo = h.MaHoSo 
                              JOIN KhoaDieuTri k ON p.MaK = k.MaK 
                              JOIN BacSi b ON p.MaBS = b.MaBS 
                              ORDER BY p.NgayGioKham DESC");
        }

        public DataTable LayLichSuKham(string maHoSo)
        {
            return Db.Query(@"SELECT p.MaPK, p.NgayGioKham, k.TenKhoa, b.HoTen AS BacSiKham, p.TrieuChung, p.KetLuan, t.TongTien AS TienThuoc
                              FROM PhieuKhamBenh p 
                              JOIN KhoaDieuTri k ON p.MaK = k.MaK 
                              JOIN BacSi b ON p.MaBS = b.MaBS 
                              LEFT JOIN ToaThuoc t ON p.MaPK = t.MaPK 
                              WHERE p.MaHoSo = @h 
                              ORDER BY p.NgayGioKham DESC", Db.P("@h", maHoSo));
        }

        public KetQuaXuLy CapNhatKetLuan(string maPK, string trieuChung, decimal thanNhiet, string huyetAp, string ketLuan)
        {
            if (string.IsNullOrWhiteSpace(maPK)) return KetQuaXuLy.Fail("Chưa chọn phiếu khám bệnh.");
            if (string.IsNullOrWhiteSpace(ketLuan)) return KetQuaXuLy.Fail("Vui lòng nhập kết luận chẩn đoán bệnh.");

            try
            {
                Db.Execute(@"UPDATE PhieuKhamBenh 
                             SET TrieuChung = @tc, ThanNhiet = @tn, HuyetAp = @ha, KetLuan = @kl 
                             WHERE MaPK = @pk",
                    Db.P("@tc", trieuChung), Db.P("@tn", thanNhiet), Db.P("@ha", huyetAp), Db.P("@kl", ketLuan), Db.P("@pk", maPK));
                return KetQuaXuLy.Ok("Đã lưu chẩn đoán cho phiếu khám " + maPK + ".");
            }
            catch (Exception ex) { return KetQuaXuLy.Fail(ex.Message); }
        }
    }
}