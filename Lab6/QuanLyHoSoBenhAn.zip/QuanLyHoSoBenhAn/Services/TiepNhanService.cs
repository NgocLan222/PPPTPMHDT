﻿using System;
using System.Data;
using System.Data.SqlClient;
using QuanLyHoSoBenhAn.Data;

namespace QuanLyHoSoBenhAn.Services
{
    public class TiepNhanService
    {
        public DataTable LayDanhSachHoSo()
        {
            return Db.Query(@"SELECT h.MaHoSo, h.MaBN, h.HoTen, h.DienThoai, h.NgaySinh, h.GioiTinh, h.HanSuDung, h.TrangThai 
                              FROM HoSoBenhAn h ORDER BY h.MaHoSo DESC");
        }

        public DataTable TraCuuHoSo(string tuKhoa)
        {
            return Db.Query(@"SELECT h.MaHoSo, h.MaBN, h.HoTen, h.DiaChi, h.NgaySinh, h.GioiTinh, h.DienThoai, h.Anh3x4, h.LePhiHangNam, h.HanSuDung, h.TrangThai 
                              FROM HoSoBenhAn h 
                              WHERE h.MaHoSo LIKE @k OR h.DienThoai LIKE @k OR h.HoTen LIKE @k",
                Db.P("@k", "%" + tuKhoa + "%"));
        }

        public KetQuaXuLy DangKyMoi(string maBN, string hoTen, string diaChi, DateTime ngaySinh, string gioiTinh, string dienThoai, string anh3x4, string maHoSo, decimal lePhi)
        {
            if (string.IsNullOrWhiteSpace(maBN) || string.IsNullOrWhiteSpace(hoTen) || string.IsNullOrWhiteSpace(maHoSo) || string.IsNullOrWhiteSpace(dienThoai))
                return KetQuaXuLy.Fail("Thông tin đăng ký chưa đầy đủ.");
            if (lePhi <= 0)
                return KetQuaXuLy.Fail("Bệnh nhân lần đầu khám phải đóng lệ phí quản lý hằng năm.");

            using (var cn = Db.OpenConnection())
            using (var tr = cn.BeginTransaction())
            {
                try
                {
                    using (var cmd = new SqlCommand(@"INSERT INTO BenhNhan(MaBN, HoTen, DiaChi, NgaySinh, GioiTinh, DienThoai, Anh3x4) 
                                                      VALUES(@bn, @ht, @dc, @ns, @gt, @dt, @anh)", cn, tr))
                    {
                        cmd.Parameters.Add(Db.P("@bn", maBN));
                        cmd.Parameters.Add(Db.P("@ht", hoTen));
                        cmd.Parameters.Add(Db.P("@dc", diaChi));
                        cmd.Parameters.Add(Db.P("@ns", ngaySinh.Date));
                        cmd.Parameters.Add(Db.P("@gt", gioiTinh));
                        cmd.Parameters.Add(Db.P("@dt", dienThoai));
                        cmd.Parameters.Add(Db.P("@anh", anh3x4));
                        cmd.ExecuteNonQuery();
                    }

                    DateTime hanDung = DateTime.Today.AddYears(1);
                    using (var cmd = new SqlCommand(@"INSERT INTO HoSoBenhAn(MaHoSo, MaBN, HoTen, DiaChi, NgaySinh, GioiTinh, DienThoai, Anh3x4, LePhiHangNam, HanSuDung, TrangThai) 
                                                      VALUES(@hs, @bn, @ht, @dc, @ns, @gt, @dt, @anh, @lp, @hd, @tt)", cn, tr))
                    {
                        cmd.Parameters.Add(Db.P("@hs", maHoSo));
                        cmd.Parameters.Add(Db.P("@bn", maBN));
                        cmd.Parameters.Add(Db.P("@ht", hoTen));
                        cmd.Parameters.Add(Db.P("@dc", diaChi));
                        cmd.Parameters.Add(Db.P("@ns", ngaySinh.Date));
                        cmd.Parameters.Add(Db.P("@gt", gioiTinh));
                        cmd.Parameters.Add(Db.P("@dt", dienThoai));
                        cmd.Parameters.Add(Db.P("@anh", anh3x4));
                        cmd.Parameters.Add(Db.P("@lp", lePhi));
                        cmd.Parameters.Add(Db.P("@hd", hanDung));
                        cmd.Parameters.Add(Db.P("@tt", QuyDinh.ConHieuLuc));
                        cmd.ExecuteNonQuery();
                    }

                    tr.Commit();
                    return KetQuaXuLy.Ok("Đã cấp hồ sơ bệnh án " + maHoSo + ". Hạn sử dụng đến " + hanDung.ToString("dd/MM/yyyy") + ".");
                }
                catch (Exception ex)
                {
                    try { tr.Rollback(); } catch { }
                    return KetQuaXuLy.Fail(ex.Message);
                }
            }
        }

        public KetQuaXuLy DatLichKhamDinhKy(string maLK, string maHoSo, DateTime ngayGioHen, string ghiChu)
        {
            if (string.IsNullOrWhiteSpace(maLK) || string.IsNullOrWhiteSpace(maHoSo))
                return KetQuaXuLy.Fail("Chưa nhập đủ thông tin cuộc hẹn.");
            if (ngayGioHen <= DateTime.Now)
                return KetQuaXuLy.Fail("Ngày giờ hẹn phải sau thời điểm hiện tại.");

            try
            {
                var dt = Db.Query("SELECT HanSuDung, TrangThai FROM HoSoBenhAn WHERE MaHoSo = @h", Db.P("@h", maHoSo));
                if (dt.Rows.Count == 0) return KetQuaXuLy.Fail("Không tìm thấy hồ sơ bệnh án.");
                if (Convert.ToDateTime(dt.Rows[0]["HanSuDung"]).Date < DateTime.Today)
                    return KetQuaXuLy.Fail("Hồ sơ bệnh án đã hết hạn lệ phí thường niên. Vui lòng gia hạn để đặt lịch hẹn.");

                Db.Execute(@"INSERT INTO LichKhamDinhKy(MaLK, MaHoSo, NgayGioHen, GhiChu, TrangThai) 
                             VALUES(@lk, @hs, @ngay, @gc, @tt)",
                    Db.P("@lk", maLK), Db.P("@hs", maHoSo), Db.P("@ngay", ngayGioHen), Db.P("@gc", ghiChu), Db.P("@tt", "Chờ khám"));

                return KetQuaXuLy.Ok("Đã đặt lịch hẹn khám định kỳ ngày " + ngayGioHen.ToString("dd/MM/yyyy HH:mm") + ".");
            }
            catch (Exception ex) { return KetQuaXuLy.Fail(ex.Message); }
        }

        public KetQuaXuLy LapPhieuKham(string maPK, string maHoSo, string maBS, string maK, string loaiKham, string trieuChung, decimal thanNhiet, string huyetAp)
        {
            if (string.IsNullOrWhiteSpace(maPK) || string.IsNullOrWhiteSpace(maHoSo) || string.IsNullOrWhiteSpace(maBS) || string.IsNullOrWhiteSpace(maK))
                return KetQuaXuLy.Fail("Chưa chọn đủ thông tin hồ sơ, khoa hoặc bác sĩ.");
            if (thanNhiet < 34 || thanNhiet > 43)
                return KetQuaXuLy.Fail("Thân nhiệt phải nằm trong khoảng từ 34.0°C đến 43.0°C.");

            try
            {
                var dt = Db.Query("SELECT HanSuDung, TrangThai FROM HoSoBenhAn WHERE MaHoSo = @h", Db.P("@h", maHoSo));
                if (dt.Rows.Count == 0) return KetQuaXuLy.Fail("Không tìm thấy hồ sơ bệnh án.");
                if (loaiKham == QuyDinh.KhamDinhKy && Convert.ToDateTime(dt.Rows[0]["HanSuDung"]).Date < DateTime.Today)
                    return KetQuaXuLy.Fail("Hồ sơ đã hết hạn lệ phí năm, không thể lập phiếu khám định kỳ miễn phí.");

                Db.Execute(@"INSERT INTO PhieuKhamBenh(MaPK, MaHoSo, MaBS, MaK, NgayGioKham, TrieuChung, ThanNhiet, HuyetAp, LoaiKham) 
                             VALUES(@pk, @hs, @bs, @k, SYSDATETIME(), @tc, @tn, @ha, @lk)",
                    Db.P("@pk", maPK), Db.P("@hs", maHoSo), Db.P("@bs", maBS), Db.P("@k", maK),
                    Db.P("@tc", trieuChung), Db.P("@tn", thanNhiet), Db.P("@ha", huyetAp), Db.P("@lk", loaiKham));

                return KetQuaXuLy.Ok("Đã lập phiếu khám bệnh " + maPK + " thành công.");
            }
            catch (Exception ex) { return KetQuaXuLy.Fail(ex.Message); }
        }
    }
}