﻿using System;
using System.Data;
using QuanLyHoSoBenhAn.Data;

namespace QuanLyHoSoBenhAn.Services
{
    public class XetNghiemService
    {
        public DataTable LayXetNghiemTheoPhieuKham(string maPK)
        {
            return Db.Query(@"SELECT pxn.MaPXN, lxn.TenLXN, lxn.DonGia, pxn.NgayGioChiDinh, pxn.KetQua, pxn.NgayGioCoKetQua, pxn.TrangThai 
                              FROM PhieuXetNghiem pxn 
                              JOIN LoaiXetNghiem lxn ON pxn.MaLXN = lxn.MaLXN 
                              WHERE pxn.MaPK = @pk ORDER BY pxn.NgayGioChiDinh", Db.P("@pk", maPK));
        }

        public DataTable LayDanhSachChoXetNghiem()
        {
            return Db.Query(@"SELECT pxn.MaPXN, pxn.MaPK, h.HoTen, lxn.TenLXN, pxn.NgayGioChiDinh, pxn.TrangThai 
                              FROM PhieuXetNghiem pxn 
                              JOIN PhieuKhamBenh p ON pxn.MaPK = p.MaPK 
                              JOIN HoSoBenhAn h ON p.MaHoSo = h.MaHoSo 
                              JOIN LoaiXetNghiem lxn ON pxn.MaLXN = lxn.MaLXN 
                              WHERE pxn.TrangThai = @tt ORDER BY pxn.NgayGioChiDinh", Db.P("@tt", QuyDinh.ChoXetNghiem));
        }

        public KetQuaXuLy ChiDinhXetNghiem(string maPXN, string maPK, string maLXN)
        {
            if (string.IsNullOrWhiteSpace(maPXN) || string.IsNullOrWhiteSpace(maPK) || string.IsNullOrWhiteSpace(maLXN))
                return KetQuaXuLy.Fail("Chưa chọn đủ thông tin chỉ định xét nghiệm.");

            try
            {
                Db.Execute(@"INSERT INTO PhieuXetNghiem(MaPXN, MaPK, MaLXN, NgayGioChiDinh, TrangThai) 
                             VALUES(@pxn, @pk, @lxn, SYSDATETIME(), @tt)",
                    Db.P("@pxn", maPXN), Db.P("@pk", maPK), Db.P("@lxn", maLXN), Db.P("@tt", QuyDinh.ChoXetNghiem));
                return KetQuaXuLy.Ok("Đã tạo phiếu chỉ định xét nghiệm " + maPXN + ".");
            }
            catch (Exception ex) { return KetQuaXuLy.Fail(ex.Message); }
        }

        public KetQuaXuLy CapNhatKetQua(string maPXN, string ketQua)
        {
            if (string.IsNullOrWhiteSpace(maPXN)) return KetQuaXuLy.Fail("Chưa chọn phiếu xét nghiệm.");
            if (string.IsNullOrWhiteSpace(ketQua)) return KetQuaXuLy.Fail("Kết quả xét nghiệm không được để trống.");

            try
            {
                Db.Execute(@"UPDATE PhieuXetNghiem 
                             SET KetQua = @kq, NgayGioCoKetQua = SYSDATETIME(), TrangThai = @tt 
                             WHERE MaPXN = @pxn",
                    Db.P("@kq", ketQua), Db.P("@tt", QuyDinh.DaCoKetQua), Db.P("@pxn", maPXN));
                return KetQuaXuLy.Ok("Đã cập nhật kết quả xét nghiệm " + maPXN + ".");
            }
            catch (Exception ex) { return KetQuaXuLy.Fail(ex.Message); }
        }
    }
}