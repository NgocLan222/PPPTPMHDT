﻿using System;
using System.Data;
using QuanLyHoSoBenhAn.Data;

namespace QuanLyHoSoBenhAn.Services
{
    public class VienPhiService
    {
        public DataTable LayDanhSachChoThanhToan()
        {
            return Db.Query(@"SELECT p.MaPK, p.MaHoSo, h.HoTen, p.LoaiKham, p.NgayGioKham,
                                     ISNULL(t.TongTien, 0) AS TienThuoc,
                                     ISNULL((SELECT SUM(lxn.DonGia) FROM PhieuXetNghiem pxn JOIN LoaiXetNghiem lxn ON pxn.MaLXN = lxn.MaLXN WHERE pxn.MaPK = p.MaPK), 0) AS TienXetNghiem,
                                     CASE WHEN p.LoaiKham = N'Khám định kỳ' THEN 0 ELSE 150000 END AS TienKham
                              FROM PhieuKhamBenh p 
                              JOIN HoSoBenhAn h ON p.MaHoSo = h.MaHoSo 
                              LEFT JOIN ToaThuoc t ON p.MaPK = t.MaPK 
                              WHERE NOT EXISTS(SELECT 1 FROM HoaDonVienPhi hd WHERE hd.MaPK = p.MaPK)
                              ORDER BY p.NgayGioKham DESC");
        }

        public KetQuaXuLy ThanhToan(string maHD, string maPK, decimal tienKham, decimal tienXN, decimal tienThuoc)
        {
            if (string.IsNullOrWhiteSpace(maHD) || string.IsNullOrWhiteSpace(maPK))
                return KetQuaXuLy.Fail("Chưa có mã hóa đơn hoặc mã phiếu khám.");

            decimal tongTien = tienKham + tienXN + tienThuoc;
            try
            {
                Db.Execute(@"INSERT INTO HoaDonVienPhi(MaHD, MaPK, NgayThanhToan, TienKham, TienXetNghiem, TienThuoc, TongTien, TrangThai) 
                             VALUES(@hd, @pk, SYSDATETIME(), @tk, @txn, @tt, @tong, @st)",
                    Db.P("@hd", maHD), Db.P("@pk", maPK), Db.P("@tk", tienKham), Db.P("@txn", tienXN),
                    Db.P("@tt", tienThuoc), Db.P("@tong", tongTien), Db.P("@st", QuyDinh.DaThanhToan));

                return KetQuaXuLy.Ok("Đã thanh toán viện phí " + maHD + ". Tổng thu: " + tongTien.ToString("N0") + " đ.");
            }
            catch (Exception ex) { return KetQuaXuLy.Fail(ex.Message); }
        }
    }
}