﻿using System;
using System.Data;
using QuanLyHoSoBenhAn.Data;

namespace QuanLyHoSoBenhAn.Services
{
    public class DanhMucService
    {
        public DataTable LayKhoa()
        {
            return Db.Query("SELECT MaK, TenKhoa FROM KhoaDieuTri ORDER BY TenKhoa");
        }

        public DataTable LayBacSi()
        {
            return Db.Query(@"SELECT b.MaBS, b.HoTen, k.TenKhoa, b.DienThoai, b.TrangThai 
                              FROM BacSi b JOIN KhoaDieuTri k ON b.MaK = k.MaK ORDER BY b.HoTen");
        }

        public DataTable LayBacSiTheoKhoa(string maK)
        {
            return Db.Query("SELECT MaBS, MaBS + ' - ' + HoTen AS HienThi FROM BacSi WHERE MaK = @k AND TrangThai = 1 ORDER BY HoTen", Db.P("@k", maK));
        }

        public DataTable LayLoaiXetNghiem()
        {
            return Db.Query("SELECT MaLXN, TenLXN, DonGia FROM LoaiXetNghiem ORDER BY TenLXN");
        }

        public DataTable LayThuoc()
        {
            return Db.Query("SELECT MaThuoc, TenThuoc, DVT, DonGia, CongDung, ChongChiDinh FROM Thuoc ORDER BY TenThuoc");
        }

        public KetQuaXuLy ThemKhoa(string ma, string ten)
        {
            if (string.IsNullOrWhiteSpace(ma) || string.IsNullOrWhiteSpace(ten))
                return KetQuaXuLy.Fail("Mã và tên khoa không được để trống.");
            return Chay("INSERT INTO KhoaDieuTri(MaK, TenKhoa) VALUES(@m, @t)", "Đã thêm khoa điều trị.",
                Db.P("@m", ma), Db.P("@t", ten));
        }

        public KetQuaXuLy ThemBacSi(string ma, string ten, string maK, string dienThoai)
        {
            if (string.IsNullOrWhiteSpace(ma) || string.IsNullOrWhiteSpace(ten) || string.IsNullOrWhiteSpace(maK))
                return KetQuaXuLy.Fail("Thông tin bác sĩ chưa đầy đủ.");
            return Chay("INSERT INTO BacSi(MaBS, HoTen, MaK, DienThoai, TrangThai) VALUES(@m, @t, @k, @dt, 1)", "Đã thêm bác sĩ.",
                Db.P("@m", ma), Db.P("@t", ten), Db.P("@k", maK), Db.P("@dt", dienThoai));
        }

        public KetQuaXuLy ThemLoaiXN(string ma, string ten, decimal donGia)
        {
            if (string.IsNullOrWhiteSpace(ma) || string.IsNullOrWhiteSpace(ten) || donGia < 0)
                return KetQuaXuLy.Fail("Thông tin xét nghiệm không hợp lệ.");
            return Chay("INSERT INTO LoaiXetNghiem(MaLXN, TenLXN, DonGia) VALUES(@m, @t, @g)", "Đã thêm loại xét nghiệm.",
                Db.P("@m", ma), Db.P("@t", ten), Db.P("@g", donGia));
        }

        public KetQuaXuLy ThemThuoc(string ma, string ten, string dvt, decimal donGia, string congDung, string chongChiDinh)
        {
            if (string.IsNullOrWhiteSpace(ma) || string.IsNullOrWhiteSpace(ten) || donGia < 0)
                return KetQuaXuLy.Fail("Thông tin thuốc không hợp lệ.");
            return Chay("INSERT INTO Thuoc(MaThuoc, TenThuoc, DVT, DonGia, CongDung, ChongChiDinh) VALUES(@m, @t, @d, @g, @cd, @ccd)", "Đã thêm thuốc mới.",
                Db.P("@m", ma), Db.P("@t", ten), Db.P("@d", dvt), Db.P("@g", donGia), Db.P("@cd", congDung), Db.P("@ccd", chongChiDinh));
        }

        private static KetQuaXuLy Chay(string sql, string thongBao, params System.Data.SqlClient.SqlParameter[] ps)
        {
            try { Db.Execute(sql, ps); return KetQuaXuLy.Ok(thongBao); }
            catch (Exception ex) { return KetQuaXuLy.Fail(ex.Message); }
        }
    }
}