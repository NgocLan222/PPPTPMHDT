﻿using System;
using System.Data;
using QuanLyHoSoBenhAn.Data;

namespace QuanLyHoSoBenhAn.Services
{
    public class TheoDoiService
    {
        public DataTable LayDanhSachDaXuatVien()
        {
            return Db.Query(@"SELECT p.MaPK, h.MaHoSo, h.HoTen, h.DienThoai, hd.NgayThanhToan, p.KetLuan 
                              FROM PhieuKhamBenh p 
                              JOIN HoSoBenhAn h ON p.MaHoSo = h.MaHoSo 
                              JOIN HoaDonVienPhi hd ON p.MaPK = hd.MaPK 
                              WHERE hd.TrangThai = @st AND NOT EXISTS(SELECT 1 FROM TheoDoiSauKham td WHERE td.MaPK = p.MaPK)
                              ORDER BY hd.NgayThanhToan DESC", Db.P("@st", QuyDinh.DaThanhToan));
        }

        public DataTable LayLichSuTheoDoi()
        {
            return Db.Query(@"SELECT td.MaTD, td.MaPK, h.HoTen, td.NgayTheoDoi, td.DienBienBenh, td.PhanUngPhu, td.HieuQuaDieuTri 
                              FROM TheoDoiSauKham td 
                              JOIN HoSoBenhAn h ON td.MaHoSo = h.MaHoSo 
                              ORDER BY td.NgayTheoDoi DESC");
        }

        public KetQuaXuLy GhiNhan(string maTD, string maPK, string maHoSo, DateTime ngayTheoDoi, string dienBien, string phanUngPhu, string hieuQua)
        {
            if (string.IsNullOrWhiteSpace(maTD) || string.IsNullOrWhiteSpace(maPK) || string.IsNullOrWhiteSpace(maHoSo))
                return KetQuaXuLy.Fail("Chưa chọn phiếu khám bệnh để ghi nhận theo dõi.");

            try
            {
                object o = Db.Scalar("SELECT COUNT(*) FROM HoaDonVienPhi WHERE MaPK = @pk AND TrangThai = @st",
                    Db.P("@pk", maPK), Db.P("@st", QuyDinh.DaThanhToan));
                if (Convert.ToInt32(o) == 0)
                    return KetQuaXuLy.Fail("Chỉ được ghi nhận theo dõi sau khi bệnh nhân đã thanh toán viện phí xuất viện.");

                Db.Execute(@"INSERT INTO TheoDoiSauKham(MaTD, MaPK, MaHoSo, NgayTheoDoi, DienBienBenh, PhanUngPhu, HieuQuaDieuTri) 
                             VALUES(@td, @pk, @hs, @ngay, @db, @pu, @hq)",
                    Db.P("@td", maTD), Db.P("@pk", maPK), Db.P("@hs", maHoSo), Db.P("@ngay", ngayTheoDoi.Date),
                    Db.P("@db", dienBien), Db.P("@pu", phanUngPhu), Db.P("@hq", hieuQua));

                return KetQuaXuLy.Ok("Đã ghi nhận thông tin theo dõi sau khám cho phiếu " + maPK + ".");
            }
            catch (Exception ex) { return KetQuaXuLy.Fail(ex.Message); }
        }
    }
}