﻿namespace QuanLyCongTyDuLich.Forms
{
    partial class FrmDangKyDoan
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.grpDoan = new System.Windows.Forms.GroupBox();
            this.txtDaiDien = new System.Windows.Forms.TextBox();
            this.lblDaiDien = new System.Windows.Forms.Label();
            this.txtDT = new System.Windows.Forms.TextBox();
            this.lblDT = new System.Windows.Forms.Label();
            this.txtDiaChi = new System.Windows.Forms.TextBox();
            this.lblDiaChi = new System.Windows.Forms.Label();
            this.txtTenCQ = new System.Windows.Forms.TextBox();
            this.lblTenCQ = new System.Windows.Forms.Label();
            this.txtMaDoan = new System.Windows.Forms.TextBox();
            this.lblMaDoan = new System.Windows.Forms.Label();
            this.grpDangKy = new System.Windows.Forms.GroupBox();
            this.lblTong = new System.Windows.Forms.Label();
            this.lblTongTieuDe = new System.Windows.Forms.Label();
            this.lblKetThuc = new System.Windows.Forms.Label();
            this.lblKetThucTieuDe = new System.Windows.Forms.Label();
            this.chkBH = new System.Windows.Forms.CheckBox();
            this.numCoc = new System.Windows.Forms.NumericUpDown();
            this.lblCoc = new System.Windows.Forms.Label();
            this.txtDon = new System.Windows.Forms.TextBox();
            this.lblDon = new System.Windows.Forms.Label();
            this.numNguoi = new System.Windows.Forms.NumericUpDown();
            this.lblNguoi = new System.Windows.Forms.Label();
            this.dtDi = new System.Windows.Forms.DateTimePicker();
            this.lblNgayDi = new System.Windows.Forms.Label();
            this.cboTour = new System.Windows.Forms.ComboBox();
            this.lblTour = new System.Windows.Forms.Label();
            this.txtSo = new System.Windows.Forms.TextBox();
            this.lblSo = new System.Windows.Forms.Label();
            this.lblThanhVien = new System.Windows.Forms.Label();
            this.dgvThanhVien = new System.Windows.Forms.DataGridView();
            this.btnDangKy = new System.Windows.Forms.Button();
            this.btnHuy = new System.Windows.Forms.Button();
            this.lblDanhSach = new System.Windows.Forms.Label();
            this.dgv = new System.Windows.Forms.DataGridView();
            this.btnDong = new System.Windows.Forms.Button();
            this.grpDoan.SuspendLayout();
            this.grpDangKy.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numCoc)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numNguoi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvThanhVien)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).BeginInit();
            this.SuspendLayout();
            // 
            // grpDoan
            // 
            this.grpDoan.Controls.Add(this.txtDaiDien);
            this.grpDoan.Controls.Add(this.lblDaiDien);
            this.grpDoan.Controls.Add(this.txtDT);
            this.grpDoan.Controls.Add(this.lblDT);
            this.grpDoan.Controls.Add(this.txtDiaChi);
            this.grpDoan.Controls.Add(this.lblDiaChi);
            this.grpDoan.Controls.Add(this.txtTenCQ);
            this.grpDoan.Controls.Add(this.lblTenCQ);
            this.grpDoan.Controls.Add(this.txtMaDoan);
            this.grpDoan.Controls.Add(this.lblMaDoan);
            this.grpDoan.Location = new System.Drawing.Point(20, 15);
            this.grpDoan.Name = "grpDoan";
            this.grpDoan.Size = new System.Drawing.Size(460, 205);
            this.grpDoan.TabIndex = 0;
            this.grpDoan.TabStop = false;
            this.grpDoan.Text = "Thông tin đoàn khách";
            // 
            // txtDaiDien
            // 
            this.txtDaiDien.Location = new System.Drawing.Point(140, 162);
            this.txtDaiDien.Name = "txtDaiDien";
            this.txtDaiDien.Size = new System.Drawing.Size(305, 22);
            this.txtDaiDien.TabIndex = 9;
            // 
            // lblDaiDien
            // 
            this.lblDaiDien.AutoSize = true;
            this.lblDaiDien.Location = new System.Drawing.Point(15, 165);
            this.lblDaiDien.Name = "lblDaiDien";
            this.lblDaiDien.Size = new System.Drawing.Size(99, 17);
            this.lblDaiDien.TabIndex = 8;
            this.lblDaiDien.Text = "Người đại diện:";
            // 
            // txtDT
            // 
            this.txtDT.Location = new System.Drawing.Point(140, 127);
            this.txtDT.Name = "txtDT";
            this.txtDT.Size = new System.Drawing.Size(160, 22);
            this.txtDT.TabIndex = 7;
            // 
            // lblDT
            // 
            this.lblDT.AutoSize = true;
            this.lblDT.Location = new System.Drawing.Point(15, 130);
            this.lblDT.Name = "lblDT";
            this.lblDT.Size = new System.Drawing.Size(76, 17);
            this.lblDT.TabIndex = 6;
            this.lblDT.Text = "Điện thoại:";
            // 
            // txtDiaChi
            // 
            this.txtDiaChi.Location = new System.Drawing.Point(140, 92);
            this.txtDiaChi.Name = "txtDiaChi";
            this.txtDiaChi.Size = new System.Drawing.Size(305, 22);
            this.txtDiaChi.TabIndex = 5;
            // 
            // lblDiaChi
            // 
            this.lblDiaChi.AutoSize = true;
            this.lblDiaChi.Location = new System.Drawing.Point(15, 95);
            this.lblDiaChi.Name = "lblDiaChi";
            this.lblDiaChi.Size = new System.Drawing.Size(55, 17);
            this.lblDiaChi.TabIndex = 4;
            this.lblDiaChi.Text = "Địa chỉ:";
            // 
            // txtTenCQ
            // 
            this.txtTenCQ.Location = new System.Drawing.Point(140, 57);
            this.txtTenCQ.Name = "txtTenCQ";
            this.txtTenCQ.Size = new System.Drawing.Size(305, 22);
            this.txtTenCQ.TabIndex = 3;
            // 
            // lblTenCQ
            // 
            this.lblTenCQ.AutoSize = true;
            this.lblTenCQ.Location = new System.Drawing.Point(15, 60);
            this.lblTenCQ.Name = "lblTenCQ";
            this.lblTenCQ.Size = new System.Drawing.Size(126, 17);
            this.lblTenCQ.TabIndex = 2;
            this.lblTenCQ.Text = "Cơ quan / gia đình:";
            // 
            // txtMaDoan
            // 
            this.txtMaDoan.Location = new System.Drawing.Point(140, 22);
            this.txtMaDoan.Name = "txtMaDoan";
            this.txtMaDoan.Size = new System.Drawing.Size(160, 22);
            this.txtMaDoan.TabIndex = 1;
            // 
            // lblMaDoan
            // 
            this.lblMaDoan.AutoSize = true;
            this.lblMaDoan.Location = new System.Drawing.Point(15, 25);
            this.lblMaDoan.Name = "lblMaDoan";
            this.lblMaDoan.Size = new System.Drawing.Size(67, 17);
            this.lblMaDoan.TabIndex = 0;
            this.lblMaDoan.Text = "Mã đoàn:";
            // 
            // grpDangKy
            // 
            this.grpDangKy.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.grpDangKy.Controls.Add(this.lblTong);
            this.grpDangKy.Controls.Add(this.lblTongTieuDe);
            this.grpDangKy.Controls.Add(this.lblKetThuc);
            this.grpDangKy.Controls.Add(this.lblKetThucTieuDe);
            this.grpDangKy.Controls.Add(this.chkBH);
            this.grpDangKy.Controls.Add(this.numCoc);
            this.grpDangKy.Controls.Add(this.lblCoc);
            this.grpDangKy.Controls.Add(this.txtDon);
            this.grpDangKy.Controls.Add(this.lblDon);
            this.grpDangKy.Controls.Add(this.numNguoi);
            this.grpDangKy.Controls.Add(this.lblNguoi);
            this.grpDangKy.Controls.Add(this.dtDi);
            this.grpDangKy.Controls.Add(this.lblNgayDi);
            this.grpDangKy.Controls.Add(this.cboTour);
            this.grpDangKy.Controls.Add(this.lblTour);
            this.grpDangKy.Controls.Add(this.txtSo);
            this.grpDangKy.Controls.Add(this.lblSo);
            this.grpDangKy.Location = new System.Drawing.Point(495, 15);
            this.grpDangKy.Name = "grpDangKy";
            this.grpDangKy.Size = new System.Drawing.Size(525, 205);
            this.grpDangKy.TabIndex = 1;
            this.grpDangKy.TabStop = false;
            this.grpDangKy.Text = "Đăng ký tour";
            // 
            // lblTong
            // 
            this.lblTong.AutoSize = true;
            this.lblTong.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.lblTong.ForeColor = System.Drawing.Color.DarkRed;
            this.lblTong.Location = new System.Drawing.Point(365, 170);
            this.lblTong.Name = "lblTong";
            this.lblTong.Size = new System.Drawing.Size(39, 23);
            this.lblTong.TabIndex = 16;
            this.lblTong.Text = "0 đ";
            // 
            // lblTongTieuDe
            // 
            this.lblTongTieuDe.AutoSize = true;
            this.lblTongTieuDe.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.lblTongTieuDe.Location = new System.Drawing.Point(245, 171);
            this.lblTongTieuDe.Name = "lblTongTieuDe";
            this.lblTongTieuDe.Size = new System.Drawing.Size(117, 21);
            this.lblTongTieuDe.TabIndex = 15;
            this.lblTongTieuDe.Text = "Tổng dự kiến:";
            // 
            // lblKetThuc
            // 
            this.lblKetThuc.AutoSize = true;
            this.lblKetThuc.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.lblKetThuc.Location = new System.Drawing.Point(115, 171);
            this.lblKetThuc.Name = "lblKetThuc";
            this.lblKetThuc.Size = new System.Drawing.Size(16, 21);
            this.lblKetThuc.TabIndex = 14;
            this.lblKetThuc.Text = "-";
            // 
            // lblKetThucTieuDe
            // 
            this.lblKetThucTieuDe.AutoSize = true;
            this.lblKetThucTieuDe.Location = new System.Drawing.Point(15, 173);
            this.lblKetThucTieuDe.Name = "lblKetThucTieuDe";
            this.lblKetThucTieuDe.Size = new System.Drawing.Size(91, 17);
            this.lblKetThucTieuDe.TabIndex = 13;
            this.lblKetThucTieuDe.Text = "Kết thúc DK:";
            // 
            // chkBH
            // 
            this.chkBH.AutoSize = true;
            this.chkBH.Location = new System.Drawing.Point(320, 137);
            this.chkBH.Name = "chkBH";
            this.chkBH.Size = new System.Drawing.Size(118, 21);
            this.chkBH.TabIndex = 12;
            this.chkBH.Text = "Mua bảo hiểm";
            this.chkBH.UseVisualStyleBackColor = true;
            this.chkBH.CheckedChanged += new System.EventHandler(this.chkBH_CheckedChanged);
            // 
            // numCoc
            // 
            this.numCoc.Location = new System.Drawing.Point(100, 136);
            this.numCoc.Maximum = new decimal(new int[] { 1000000000, 0, 0, 0 });
            this.numCoc.Name = "numCoc";
            this.numCoc.Size = new System.Drawing.Size(170, 22);
            this.numCoc.TabIndex = 11;
            this.numCoc.ThousandsSeparator = true;
            // 
            // lblCoc
            // 
            this.lblCoc.AutoSize = true;
            this.lblCoc.Location = new System.Drawing.Point(15, 138);
            this.lblCoc.Name = "lblCoc";
            this.lblCoc.Size = new System.Drawing.Size(66, 17);
            this.lblCoc.TabIndex = 10;
            this.lblCoc.Text = "Tiền cọc:";
            // 
            // txtDon
            // 
            this.txtDon.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtDon.Location = new System.Drawing.Point(100, 99);
            this.txtDon.Name = "txtDon";
            this.txtDon.Size = new System.Drawing.Size(405, 22);
            this.txtDon.TabIndex = 9;
            // 
            // lblDon
            // 
            this.lblDon.AutoSize = true;
            this.lblDon.Location = new System.Drawing.Point(15, 102);
            this.lblDon.Name = "lblDon";
            this.lblDon.Size = new System.Drawing.Size(73, 17);
            this.lblDon.TabIndex = 8;
            this.lblDon.Text = "Điểm đón:";
            // 
            // numNguoi
            // 
            this.numNguoi.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.numNguoi.Location = new System.Drawing.Point(375, 61);
            this.numNguoi.Maximum = new decimal(new int[] { 1000, 0, 0, 0 });
            this.numNguoi.Minimum = new decimal(new int[] { 13, 0, 0, 0 });
            this.numNguoi.Name = "numNguoi";
            this.numNguoi.Size = new System.Drawing.Size(80, 22);
            this.numNguoi.TabIndex = 7;
            this.numNguoi.Value = new decimal(new int[] { 13, 0, 0, 0 });
            // 
            // lblNguoi
            // 
            this.lblNguoi.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblNguoi.AutoSize = true;
            this.lblNguoi.Location = new System.Drawing.Point(295, 63);
            this.lblNguoi.Name = "lblNguoi";
            this.lblNguoi.Size = new System.Drawing.Size(68, 17);
            this.lblNguoi.TabIndex = 6;
            this.lblNguoi.Text = "Số người:";
            // 
            // dtDi
            // 
            this.dtDi.CustomFormat = "dd/MM/yyyy";
            this.dtDi.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtDi.Location = new System.Drawing.Point(100, 60);
            this.dtDi.Name = "dtDi";
            this.dtDi.Size = new System.Drawing.Size(140, 22);
            this.dtDi.TabIndex = 5;
            // 
            // lblNgayDi
            // 
            this.lblNgayDi.AutoSize = true;
            this.lblNgayDi.Location = new System.Drawing.Point(15, 63);
            this.lblNgayDi.Name = "lblNgayDi";
            this.lblNgayDi.Size = new System.Drawing.Size(60, 17);
            this.lblNgayDi.TabIndex = 4;
            this.lblNgayDi.Text = "Ngày đi:";
            // 
            // cboTour
            // 
            this.cboTour.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cboTour.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboTour.FormattingEnabled = true;
            this.cboTour.Location = new System.Drawing.Point(290, 22);
            this.cboTour.Name = "cboTour";
            this.cboTour.Size = new System.Drawing.Size(215, 24);
            this.cboTour.TabIndex = 3;
            // 
            // lblTour
            // 
            this.lblTour.AutoSize = true;
            this.lblTour.Location = new System.Drawing.Point(245, 25);
            this.lblTour.Name = "lblTour";
            this.lblTour.Size = new System.Drawing.Size(42, 17);
            this.lblTour.TabIndex = 2;
            this.lblTour.Text = "Tour:";
            // 
            // txtSo
            // 
            this.txtSo.Location = new System.Drawing.Point(100, 22);
            this.txtSo.Name = "txtSo";
            this.txtSo.Size = new System.Drawing.Size(130, 22);
            this.txtSo.TabIndex = 1;
            // 
            // lblSo
            // 
            this.lblSo.AutoSize = true;
            this.lblSo.Location = new System.Drawing.Point(15, 25);
            this.lblSo.Name = "lblSo";
            this.lblSo.Size = new System.Drawing.Size(67, 17);
            this.lblSo.TabIndex = 0;
            this.lblSo.Text = "Số phiếu:";
            // 
            // lblThanhVien
            // 
            this.lblThanhVien.AutoSize = true;
            this.lblThanhVien.Location = new System.Drawing.Point(20, 230);
            this.lblThanhVien.Name = "lblThanhVien";
            this.lblThanhVien.Size = new System.Drawing.Size(437, 17);
            this.lblThanhVien.TabIndex = 2;
            this.lblThanhVien.Text = "Danh sách người cùng đi (bắt buộc đủ số người khi mua bảo hiểm):";
            // 
            // dgvThanhVien
            // 
            this.dgvThanhVien.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvThanhVien.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvThanhVien.BackgroundColor = System.Drawing.Color.White;
            this.dgvThanhVien.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvThanhVien.Location = new System.Drawing.Point(20, 252);
            this.dgvThanhVien.Name = "dgvThanhVien";
            this.dgvThanhVien.RowHeadersWidth = 51;
            this.dgvThanhVien.RowTemplate.Height = 24;
            this.dgvThanhVien.Size = new System.Drawing.Size(1000, 115);
            this.dgvThanhVien.TabIndex = 3;
            // 
            // btnDangKy
            // 
            this.btnDangKy.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDangKy.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnDangKy.Location = new System.Drawing.Point(670, 375);
            this.btnDangKy.Name = "btnDangKy";
            this.btnDangKy.Size = new System.Drawing.Size(165, 40);
            this.btnDangKy.TabIndex = 4;
            this.btnDangKy.Text = "Lập phiếu đăng ký";
            this.btnDangKy.UseVisualStyleBackColor = true;
            this.btnDangKy.Click += new System.EventHandler(this.btnDangKy_Click);
            // 
            // btnHuy
            // 
            this.btnHuy.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnHuy.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnHuy.Location = new System.Drawing.Point(835, 375);
            this.btnHuy.Name = "btnHuy";
            this.btnHuy.Size = new System.Drawing.Size(185, 40);
            this.btnHuy.TabIndex = 5;
            this.btnHuy.Text = "Hủy phiếu (mất cọc)";
            this.btnHuy.UseVisualStyleBackColor = true;
            this.btnHuy.Click += new System.EventHandler(this.btnHuy_Click);
            // 
            // lblDanhSach
            // 
            this.lblDanhSach.AutoSize = true;
            this.lblDanhSach.Location = new System.Drawing.Point(20, 410);
            this.lblDanhSach.Name = "lblDanhSach";
            this.lblDanhSach.Size = new System.Drawing.Size(165, 17);
            this.lblDanhSach.TabIndex = 6;
            this.lblDanhSach.Text = "Các phiếu đăng ký đoàn:";
            // 
            // dgv
            // 
            this.dgv.AllowUserToAddRows = false;
            this.dgv.AllowUserToDeleteRows = false;
            this.dgv.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgv.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv.BackgroundColor = System.Drawing.Color.White;
            this.dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv.Location = new System.Drawing.Point(20, 432);
            this.dgv.Name = "dgv";
            this.dgv.ReadOnly = true;
            this.dgv.RowHeadersWidth = 51;
            this.dgv.RowTemplate.Height = 24;
            this.dgv.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv.Size = new System.Drawing.Size(1000, 200);
            this.dgv.TabIndex = 7;
            // 
            // btnDong
            // 
            this.btnDong.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDong.Location = new System.Drawing.Point(905, 642);
            this.btnDong.Name = "btnDong";
            this.btnDong.Size = new System.Drawing.Size(115, 35);
            this.btnDong.TabIndex = 8;
            this.btnDong.Text = "Đóng";
            this.btnDong.UseVisualStyleBackColor = true;
            this.btnDong.Click += new System.EventHandler(this.btnDong_Click);
            // 
            // FrmDangKyDoan
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1040, 690);
            this.Controls.Add(this.btnDong);
            this.Controls.Add(this.dgv);
            this.Controls.Add(this.lblDanhSach);
            this.Controls.Add(this.btnHuy);
            this.Controls.Add(this.btnDangKy);
            this.Controls.Add(this.dgvThanhVien);
            this.Controls.Add(this.lblThanhVien);
            this.Controls.Add(this.grpDangKy);
            this.Controls.Add(this.grpDoan);
            this.Name = "FrmDangKyDoan";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Phiếu đăng ký theo đoàn";
            this.Load += new System.EventHandler(this.FrmDangKyDoan_Load);
            this.grpDoan.ResumeLayout(false);
            this.grpDoan.PerformLayout();
            this.grpDangKy.ResumeLayout(false);
            this.grpDangKy.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numCoc)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numNguoi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvThanhVien)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.GroupBox grpDoan;
        private System.Windows.Forms.Label lblMaDoan;
        private System.Windows.Forms.TextBox txtMaDoan;
        private System.Windows.Forms.Label lblTenCQ;
        private System.Windows.Forms.TextBox txtTenCQ;
        private System.Windows.Forms.Label lblDiaChi;
        private System.Windows.Forms.TextBox txtDiaChi;
        private System.Windows.Forms.Label lblDT;
        private System.Windows.Forms.TextBox txtDT;
        private System.Windows.Forms.Label lblDaiDien;
        private System.Windows.Forms.TextBox txtDaiDien;
        private System.Windows.Forms.GroupBox grpDangKy;
        private System.Windows.Forms.Label lblSo;
        private System.Windows.Forms.TextBox txtSo;
        private System.Windows.Forms.Label lblTour;
        private System.Windows.Forms.ComboBox cboTour;
        private System.Windows.Forms.Label lblNgayDi;
        private System.Windows.Forms.DateTimePicker dtDi;
        private System.Windows.Forms.Label lblNguoi;
        private System.Windows.Forms.NumericUpDown numNguoi;
        private System.Windows.Forms.Label lblDon;
        private System.Windows.Forms.TextBox txtDon;
        private System.Windows.Forms.Label lblCoc;
        private System.Windows.Forms.NumericUpDown numCoc;
        private System.Windows.Forms.CheckBox chkBH;
        private System.Windows.Forms.Label lblKetThucTieuDe;
        private System.Windows.Forms.Label lblKetThuc;
        private System.Windows.Forms.Label lblTongTieuDe;
        private System.Windows.Forms.Label lblTong;
        private System.Windows.Forms.Label lblThanhVien;
        private System.Windows.Forms.DataGridView dgvThanhVien;
        private System.Windows.Forms.Button btnDangKy;
        private System.Windows.Forms.Button btnHuy;
        private System.Windows.Forms.Label lblDanhSach;
        private System.Windows.Forms.DataGridView dgv;
        private System.Windows.Forms.Button btnDong;
    }
}