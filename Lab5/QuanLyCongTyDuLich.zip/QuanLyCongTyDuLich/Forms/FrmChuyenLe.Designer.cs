﻿namespace QuanLyCongTyDuLich.Forms
{
    partial class FrmChuyenLe
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblMa = new System.Windows.Forms.Label();
            this.txtMa = new System.Windows.Forms.TextBox();
            this.lblTour = new System.Windows.Forms.Label();
            this.cboTour = new System.Windows.Forms.ComboBox();
            this.lblNgayDi = new System.Windows.Forms.Label();
            this.dtDi = new System.Windows.Forms.DateTimePicker();
            this.lblNgayVeTieuDe = new System.Windows.Forms.Label();
            this.lblNgayVe = new System.Windows.Forms.Label();
            this.lblDon = new System.Windows.Forms.Label();
            this.txtDon = new System.Windows.Forms.TextBox();
            this.btnThem = new System.Windows.Forms.Button();
            this.btnDongDK = new System.Windows.Forms.Button();
            this.dgv = new System.Windows.Forms.DataGridView();
            this.btnDong = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).BeginInit();
            this.SuspendLayout();
            // 
            // lblMa
            // 
            this.lblMa.AutoSize = true;
            this.lblMa.Location = new System.Drawing.Point(25, 25);
            this.lblMa.Name = "lblMa";
            this.lblMa.Size = new System.Drawing.Size(80, 17);
            this.lblMa.TabIndex = 0;
            this.lblMa.Text = "Mã chuyến:";
            // 
            // txtMa
            // 
            this.txtMa.Location = new System.Drawing.Point(120, 22);
            this.txtMa.Name = "txtMa";
            this.txtMa.Size = new System.Drawing.Size(150, 22);
            this.txtMa.TabIndex = 1;
            // 
            // lblTour
            // 
            this.lblTour.AutoSize = true;
            this.lblTour.Location = new System.Drawing.Point(300, 25);
            this.lblTour.Name = "lblTour";
            this.lblTour.Size = new System.Drawing.Size(42, 17);
            this.lblTour.TabIndex = 2;
            this.lblTour.Text = "Tour:";
            // 
            // cboTour
            // 
            this.cboTour.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cboTour.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboTour.FormattingEnabled = true;
            this.cboTour.Location = new System.Drawing.Point(360, 22);
            this.cboTour.Name = "cboTour";
            this.cboTour.Size = new System.Drawing.Size(580, 24);
            this.cboTour.TabIndex = 3;
            // 
            // lblNgayDi
            // 
            this.lblNgayDi.AutoSize = true;
            this.lblNgayDi.Location = new System.Drawing.Point(25, 65);
            this.lblNgayDi.Name = "lblNgayDi";
            this.lblNgayDi.Size = new System.Drawing.Size(60, 17);
            this.lblNgayDi.TabIndex = 4;
            this.lblNgayDi.Text = "Ngày đi:";
            // 
            // dtDi
            // 
            this.dtDi.CustomFormat = "dd/MM/yyyy";
            this.dtDi.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtDi.Location = new System.Drawing.Point(120, 62);
            this.dtDi.Name = "dtDi";
            this.dtDi.Size = new System.Drawing.Size(150, 22);
            this.dtDi.TabIndex = 5;
            // 
            // lblNgayVeTieuDe
            // 
            this.lblNgayVeTieuDe.AutoSize = true;
            this.lblNgayVeTieuDe.Location = new System.Drawing.Point(300, 65);
            this.lblNgayVeTieuDe.Name = "lblNgayVeTieuDe";
            this.lblNgayVeTieuDe.Size = new System.Drawing.Size(65, 17);
            this.lblNgayVeTieuDe.TabIndex = 6;
            this.lblNgayVeTieuDe.Text = "Ngày về:";
            // 
            // lblNgayVe
            // 
            this.lblNgayVe.AutoSize = true;
            this.lblNgayVe.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.lblNgayVe.ForeColor = System.Drawing.Color.DarkBlue;
            this.lblNgayVe.Location = new System.Drawing.Point(380, 62);
            this.lblNgayVe.Name = "lblNgayVe";
            this.lblNgayVe.Size = new System.Drawing.Size(17, 23);
            this.lblNgayVe.TabIndex = 7;
            this.lblNgayVe.Text = "-";
            // 
            // lblDon
            // 
            this.lblDon.AutoSize = true;
            this.lblDon.Location = new System.Drawing.Point(25, 105);
            this.lblDon.Name = "lblDon";
            this.lblDon.Size = new System.Drawing.Size(93, 17);
            this.lblDon.TabIndex = 8;
            this.lblDon.Text = "Địa điểm đón:";
            // 
            // txtDon
            // 
            this.txtDon.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtDon.Location = new System.Drawing.Point(120, 102);
            this.txtDon.Name = "txtDon";
            this.txtDon.Size = new System.Drawing.Size(560, 22);
            this.txtDon.TabIndex = 9;
            // 
            // btnThem
            // 
            this.btnThem.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnThem.Location = new System.Drawing.Point(700, 96);
            this.btnThem.Name = "btnThem";
            this.btnThem.Size = new System.Drawing.Size(115, 35);
            this.btnThem.TabIndex = 10;
            this.btnThem.Text = "Tạo chuyến";
            this.btnThem.UseVisualStyleBackColor = true;
            this.btnThem.Click += new System.EventHandler(this.btnThem_Click);
            // 
            // btnDongDK
            // 
            this.btnDongDK.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDongDK.Location = new System.Drawing.Point(825, 96);
            this.btnDongDK.Name = "btnDongDK";
            this.btnDongDK.Size = new System.Drawing.Size(115, 35);
            this.btnDongDK.TabIndex = 11;
            this.btnDongDK.Text = "Đóng đăng ký";
            this.btnDongDK.UseVisualStyleBackColor = true;
            this.btnDongDK.Click += new System.EventHandler(this.btnDongDK_Click);
            // 
            // dgv
            // 
            this.dgv.AllowUserToAddRows = false;
            this.dgv.AllowUserToDeleteRows = false;
            this.dgv.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgv.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv.BackgroundColor = System.Drawing.Color.White;
            this.dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv.Location = new System.Drawing.Point(25, 145);
            this.dgv.Name = "dgv";
            this.dgv.ReadOnly = true;
            this.dgv.RowHeadersWidth = 51;
            this.dgv.RowTemplate.Height = 24;
            this.dgv.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv.Size = new System.Drawing.Size(915, 375);
            this.dgv.TabIndex = 12;
            // 
            // btnDong
            // 
            this.btnDong.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDong.Location = new System.Drawing.Point(830, 535);
            this.btnDong.Name = "btnDong";
            this.btnDong.Size = new System.Drawing.Size(110, 35);
            this.btnDong.TabIndex = 13;
            this.btnDong.Text = "Đóng";
            this.btnDong.UseVisualStyleBackColor = true;
            this.btnDong.Click += new System.EventHandler(this.btnDong_Click);
            // 
            // FrmChuyenLe
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(965, 585);
            this.Controls.Add(this.btnDong);
            this.Controls.Add(this.dgv);
            this.Controls.Add(this.btnDongDK);
            this.Controls.Add(this.btnThem);
            this.Controls.Add(this.txtDon);
            this.Controls.Add(this.lblDon);
            this.Controls.Add(this.lblNgayVe);
            this.Controls.Add(this.lblNgayVeTieuDe);
            this.Controls.Add(this.dtDi);
            this.Controls.Add(this.lblNgayDi);
            this.Controls.Add(this.cboTour);
            this.Controls.Add(this.lblTour);
            this.Controls.Add(this.txtMa);
            this.Controls.Add(this.lblMa);
            this.Name = "FrmChuyenLe";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Lịch chuyến khách lẻ";
            this.Load += new System.EventHandler(this.FrmChuyenLe_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Label lblMa;
        private System.Windows.Forms.TextBox txtMa;
        private System.Windows.Forms.Label lblTour;
        private System.Windows.Forms.ComboBox cboTour;
        private System.Windows.Forms.Label lblNgayDi;
        private System.Windows.Forms.DateTimePicker dtDi;
        private System.Windows.Forms.Label lblNgayVeTieuDe;
        private System.Windows.Forms.Label lblNgayVe;
        private System.Windows.Forms.Label lblDon;
        private System.Windows.Forms.TextBox txtDon;
        private System.Windows.Forms.Button btnThem;
        private System.Windows.Forms.Button btnDongDK;
        private System.Windows.Forms.DataGridView dgv;
        private System.Windows.Forms.Button btnDong;
    }
}