﻿namespace QuanLyCongTyDuLich.Forms
{
    partial class FrmDanhMuc
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.tabDanhMuc = new System.Windows.Forms.TabControl();
            this.tabPT = new System.Windows.Forms.TabPage();
            this.btnThemPT = new System.Windows.Forms.Button();
            this.txtPTGhiChu = new System.Windows.Forms.TextBox();
            this.lblPTGhiChu = new System.Windows.Forms.Label();
            this.txtPTTen = new System.Windows.Forms.TextBox();
            this.lblPTTen = new System.Windows.Forms.Label();
            this.txtPTMa = new System.Windows.Forms.TextBox();
            this.lblPTMa = new System.Windows.Forms.Label();
            this.dgvPT = new System.Windows.Forms.DataGridView();
            this.tabDB = new System.Windows.Forms.TabPage();
            this.btnThemDB = new System.Windows.Forms.Button();
            this.txtDBDT = new System.Windows.Forms.TextBox();
            this.lblDBDT = new System.Windows.Forms.Label();
            this.txtDBDiaChi = new System.Windows.Forms.TextBox();
            this.lblDBDiaChi = new System.Windows.Forms.Label();
            this.txtDBTen = new System.Windows.Forms.TextBox();
            this.lblDBTen = new System.Windows.Forms.Label();
            this.txtDBMa = new System.Windows.Forms.TextBox();
            this.lblDBMa = new System.Windows.Forms.Label();
            this.dgvDB = new System.Windows.Forms.DataGridView();
            this.tabHDV = new System.Windows.Forms.TabPage();
            this.numLuong = new System.Windows.Forms.NumericUpDown();
            this.btnThemHDV = new System.Windows.Forms.Button();
            this.lblLuong = new System.Windows.Forms.Label();
            this.txtHDVDT = new System.Windows.Forms.TextBox();
            this.lblHDVDT = new System.Windows.Forms.Label();
            this.txtHDVTen = new System.Windows.Forms.TextBox();
            this.lblHDVTen = new System.Windows.Forms.Label();
            this.txtHDVMa = new System.Windows.Forms.TextBox();
            this.lblHDVMa = new System.Windows.Forms.Label();
            this.dgvHDV = new System.Windows.Forms.DataGridView();
            this.tabDTQ = new System.Windows.Forms.TabPage();
            this.btnThemDTQ = new System.Windows.Forms.Button();
            this.txtDTQYNghia = new System.Windows.Forms.TextBox();
            this.lblDTQYNghia = new System.Windows.Forms.Label();
            this.txtDTQNoiDung = new System.Windows.Forms.TextBox();
            this.lblDTQNoiDung = new System.Windows.Forms.Label();
            this.txtDTQDiaDiem = new System.Windows.Forms.TextBox();
            this.lblDTQDiaDiem = new System.Windows.Forms.Label();
            this.txtDTQTen = new System.Windows.Forms.TextBox();
            this.lblDTQTen = new System.Windows.Forms.Label();
            this.txtDTQMa = new System.Windows.Forms.TextBox();
            this.lblDTQMa = new System.Windows.Forms.Label();
            this.dgvDTQ = new System.Windows.Forms.DataGridView();
            this.btnDong = new System.Windows.Forms.Button();
            this.tabDanhMuc.SuspendLayout();
            this.tabPT.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPT)).BeginInit();
            this.tabDB.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDB)).BeginInit();
            this.tabHDV.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numLuong)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHDV)).BeginInit();
            this.tabDTQ.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDTQ)).BeginInit();
            this.SuspendLayout();
            // 
            // tabDanhMuc
            // 
            this.tabDanhMuc.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabDanhMuc.Controls.Add(this.tabPT);
            this.tabDanhMuc.Controls.Add(this.tabDB);
            this.tabDanhMuc.Controls.Add(this.tabHDV);
            this.tabDanhMuc.Controls.Add(this.tabDTQ);
            this.tabDanhMuc.Location = new System.Drawing.Point(20, 20);
            this.tabDanhMuc.Name = "tabDanhMuc";
            this.tabDanhMuc.SelectedIndex = 0;
            this.tabDanhMuc.Size = new System.Drawing.Size(925, 520);
            this.tabDanhMuc.TabIndex = 0;
            // 
            // tabPT
            // 
            this.tabPT.Controls.Add(this.btnThemPT);
            this.tabPT.Controls.Add(this.txtPTGhiChu);
            this.tabPT.Controls.Add(this.lblPTGhiChu);
            this.tabPT.Controls.Add(this.txtPTTen);
            this.tabPT.Controls.Add(this.lblPTTen);
            this.tabPT.Controls.Add(this.txtPTMa);
            this.tabPT.Controls.Add(this.lblPTMa);
            this.tabPT.Controls.Add(this.dgvPT);
            this.tabPT.Location = new System.Drawing.Point(4, 25);
            this.tabPT.Name = "tabPT";
            this.tabPT.Padding = new System.Windows.Forms.Padding(3);
            this.tabPT.Size = new System.Drawing.Size(917, 491);
            this.tabPT.TabIndex = 0;
            this.tabPT.Text = "Phương tiện";
            this.tabPT.UseVisualStyleBackColor = true;
            // 
            // btnThemPT
            // 
            this.btnThemPT.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnThemPT.Location = new System.Drawing.Point(780, 425);
            this.btnThemPT.Name = "btnThemPT";
            this.btnThemPT.Size = new System.Drawing.Size(120, 35);
            this.btnThemPT.TabIndex = 7;
            this.btnThemPT.Text = "Thêm";
            this.btnThemPT.UseVisualStyleBackColor = true;
            this.btnThemPT.Click += new System.EventHandler(this.btnThemPT_Click);
            // 
            // txtPTGhiChu
            // 
            this.txtPTGhiChu.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtPTGhiChu.Location = new System.Drawing.Point(90, 431);
            this.txtPTGhiChu.Name = "txtPTGhiChu";
            this.txtPTGhiChu.Size = new System.Drawing.Size(660, 22);
            this.txtPTGhiChu.TabIndex = 6;
            // 
            // lblPTGhiChu
            // 
            this.lblPTGhiChu.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblPTGhiChu.AutoSize = true;
            this.lblPTGhiChu.Location = new System.Drawing.Point(15, 434);
            this.lblPTGhiChu.Name = "lblPTGhiChu";
            this.lblPTGhiChu.Size = new System.Drawing.Size(61, 17);
            this.lblPTGhiChu.TabIndex = 5;
            this.lblPTGhiChu.Text = "Ghi chú:";
            // 
            // txtPTTen
            // 
            this.txtPTTen.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtPTTen.Location = new System.Drawing.Point(400, 385);
            this.txtPTTen.Name = "txtPTTen";
            this.txtPTTen.Size = new System.Drawing.Size(350, 22);
            this.txtPTTen.TabIndex = 4;
            // 
            // lblPTTen
            // 
            this.lblPTTen.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblPTTen.AutoSize = true;
            this.lblPTTen.Location = new System.Drawing.Point(325, 388);
            this.lblPTTen.Name = "lblPTTen";
            this.lblPTTen.Size = new System.Drawing.Size(60, 17);
            this.lblPTTen.TabIndex = 3;
            this.lblPTTen.Text = "Tên PT:";
            // 
            // txtPTMa
            // 
            this.txtPTMa.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.txtPTMa.Location = new System.Drawing.Point(90, 385);
            this.txtPTMa.Name = "txtPTMa";
            this.txtPTMa.Size = new System.Drawing.Size(200, 22);
            this.txtPTMa.TabIndex = 2;
            // 
            // lblPTMa
            // 
            this.lblPTMa.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblPTMa.AutoSize = true;
            this.lblPTMa.Location = new System.Drawing.Point(15, 388);
            this.lblPTMa.Name = "lblPTMa";
            this.lblPTMa.Size = new System.Drawing.Size(54, 17);
            this.lblPTMa.TabIndex = 1;
            this.lblPTMa.Text = "Mã PT:";
            // 
            // dgvPT
            // 
            this.dgvPT.AllowUserToAddRows = false;
            this.dgvPT.AllowUserToDeleteRows = false;
            this.dgvPT.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvPT.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvPT.BackgroundColor = System.Drawing.Color.White;
            this.dgvPT.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPT.Location = new System.Drawing.Point(15, 15);
            this.dgvPT.Name = "dgvPT";
            this.dgvPT.ReadOnly = true;
            this.dgvPT.RowHeadersWidth = 51;
            this.dgvPT.RowTemplate.Height = 24;
            this.dgvPT.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvPT.Size = new System.Drawing.Size(885, 345);
            this.dgvPT.TabIndex = 0;
            // 
            // tabDB
            // 
            this.tabDB.Controls.Add(this.btnThemDB);
            this.tabDB.Controls.Add(this.txtDBDT);
            this.tabDB.Controls.Add(this.lblDBDT);
            this.tabDB.Controls.Add(this.txtDBDiaChi);
            this.tabDB.Controls.Add(this.lblDBDiaChi);
            this.tabDB.Controls.Add(this.txtDBTen);
            this.tabDB.Controls.Add(this.lblDBTen);
            this.tabDB.Controls.Add(this.txtDBMa);
            this.tabDB.Controls.Add(this.lblDBMa);
            this.tabDB.Controls.Add(this.dgvDB);
            this.tabDB.Location = new System.Drawing.Point(4, 25);
            this.tabDB.Name = "tabDB";
            this.tabDB.Padding = new System.Windows.Forms.Padding(3);
            this.tabDB.Size = new System.Drawing.Size(917, 491);
            this.tabDB.TabIndex = 1;
            this.tabDB.Text = "Điểm bán vé";
            this.tabDB.UseVisualStyleBackColor = true;
            // 
            // btnThemDB
            // 
            this.btnThemDB.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnThemDB.Location = new System.Drawing.Point(780, 425);
            this.btnThemDB.Name = "btnThemDB";
            this.btnThemDB.Size = new System.Drawing.Size(120, 35);
            this.btnThemDB.TabIndex = 9;
            this.btnThemDB.Text = "Thêm";
            this.btnThemDB.UseVisualStyleBackColor = true;
            this.btnThemDB.Click += new System.EventHandler(this.btnThemDB_Click);
            // 
            // txtDBDT
            // 
            this.txtDBDT.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.txtDBDT.Location = new System.Drawing.Point(580, 431);
            this.txtDBDT.Name = "txtDBDT";
            this.txtDBDT.Size = new System.Drawing.Size(170, 22);
            this.txtDBDT.TabIndex = 8;
            // 
            // lblDBDT
            // 
            this.lblDBDT.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.lblDBDT.AutoSize = true;
            this.lblDBDT.Location = new System.Drawing.Point(495, 434);
            this.lblDBDT.Name = "lblDBDT";
            this.lblDBDT.Size = new System.Drawing.Size(76, 17);
            this.lblDBDT.TabIndex = 7;
            this.lblDBDT.Text = "Điện thoại:";
            // 
            // txtDBDiaChi
            // 
            this.txtDBDiaChi.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtDBDiaChi.Location = new System.Drawing.Point(120, 431);
            this.txtDBDiaChi.Name = "txtDBDiaChi";
            this.txtDBDiaChi.Size = new System.Drawing.Size(350, 22);
            this.txtDBDiaChi.TabIndex = 6;
            // 
            // lblDBDiaChi
            // 
            this.lblDBDiaChi.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblDBDiaChi.AutoSize = true;
            this.lblDBDiaChi.Location = new System.Drawing.Point(15, 434);
            this.lblDBDiaChi.Name = "lblDBDiaChi";
            this.lblDBDiaChi.Size = new System.Drawing.Size(55, 17);
            this.lblDBDiaChi.TabIndex = 5;
            this.lblDBDiaChi.Text = "Địa chỉ:";
            // 
            // txtDBTen
            // 
            this.txtDBTen.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtDBTen.Location = new System.Drawing.Point(420, 385);
            this.txtDBTen.Name = "txtDBTen";
            this.txtDBTen.Size = new System.Drawing.Size(330, 22);
            this.txtDBTen.TabIndex = 4;
            // 
            // lblDBTen
            // 
            this.lblDBTen.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblDBTen.AutoSize = true;
            this.lblDBTen.Location = new System.Drawing.Point(315, 388);
            this.lblDBTen.Name = "lblDBTen";
            this.lblDBTen.Size = new System.Drawing.Size(99, 17);
            this.lblDBTen.TabIndex = 3;
            this.lblDBTen.Text = "Tên điểm bán:";
            // 
            // txtDBMa
            // 
            this.txtDBMa.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.txtDBMa.Location = new System.Drawing.Point(120, 385);
            this.txtDBMa.Name = "txtDBMa";
            this.txtDBMa.Size = new System.Drawing.Size(170, 22);
            this.txtDBMa.TabIndex = 2;
            // 
            // lblDBMa
            // 
            this.lblDBMa.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblDBMa.AutoSize = true;
            this.lblDBMa.Location = new System.Drawing.Point(15, 388);
            this.lblDBMa.Name = "lblDBMa";
            this.lblDBMa.Size = new System.Drawing.Size(93, 17);
            this.lblDBMa.TabIndex = 1;
            this.lblDBMa.Text = "Mã điểm bán:";
            // 
            // dgvDB
            // 
            this.dgvDB.AllowUserToAddRows = false;
            this.dgvDB.AllowUserToDeleteRows = false;
            this.dgvDB.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvDB.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvDB.BackgroundColor = System.Drawing.Color.White;
            this.dgvDB.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDB.Location = new System.Drawing.Point(15, 15);
            this.dgvDB.Name = "dgvDB";
            this.dgvDB.ReadOnly = true;
            this.dgvDB.RowHeadersWidth = 51;
            this.dgvDB.RowTemplate.Height = 24;
            this.dgvDB.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvDB.Size = new System.Drawing.Size(885, 345);
            this.dgvDB.TabIndex = 0;
            // 
            // tabHDV
            // 
            this.tabHDV.Controls.Add(this.numLuong);
            this.tabHDV.Controls.Add(this.btnThemHDV);
            this.tabHDV.Controls.Add(this.lblLuong);
            this.tabHDV.Controls.Add(this.txtHDVDT);
            this.tabHDV.Controls.Add(this.lblHDVDT);
            this.tabHDV.Controls.Add(this.txtHDVTen);
            this.tabHDV.Controls.Add(this.lblHDVTen);
            this.tabHDV.Controls.Add(this.txtHDVMa);
            this.tabHDV.Controls.Add(this.lblHDVMa);
            this.tabHDV.Controls.Add(this.dgvHDV);
            this.tabHDV.Location = new System.Drawing.Point(4, 25);
            this.tabHDV.Name = "tabHDV";
            this.tabHDV.Padding = new System.Windows.Forms.Padding(3);
            this.tabHDV.Size = new System.Drawing.Size(917, 491);
            this.tabHDV.TabIndex = 2;
            this.tabHDV.Text = "Hướng dẫn viên";
            this.tabHDV.UseVisualStyleBackColor = true;
            // 
            // numLuong
            // 
            this.numLuong.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.numLuong.Location = new System.Drawing.Point(540, 431);
            this.numLuong.Maximum = new decimal(new int[] { 1000000000, 0, 0, 0 });
            this.numLuong.Name = "numLuong";
            this.numLuong.Size = new System.Drawing.Size(210, 22);
            this.numLuong.TabIndex = 8;
            this.numLuong.ThousandsSeparator = true;
            // 
            // btnThemHDV
            // 
            this.btnThemHDV.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnThemHDV.Location = new System.Drawing.Point(780, 425);
            this.btnThemHDV.Name = "btnThemHDV";
            this.btnThemHDV.Size = new System.Drawing.Size(120, 35);
            this.btnThemHDV.TabIndex = 9;
            this.btnThemHDV.Text = "Thêm";
            this.btnThemHDV.UseVisualStyleBackColor = true;
            this.btnThemHDV.Click += new System.EventHandler(this.btnThemHDV_Click);
            // 
            // lblLuong
            // 
            this.lblLuong.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.lblLuong.AutoSize = true;
            this.lblLuong.Location = new System.Drawing.Point(430, 434);
            this.lblLuong.Name = "lblLuong";
            this.lblLuong.Size = new System.Drawing.Size(103, 17);
            this.lblLuong.TabIndex = 7;
            this.lblLuong.Text = "Lương căn bản:";
            // 
            // txtHDVDT
            // 
            this.txtHDVDT.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtHDVDT.Location = new System.Drawing.Point(120, 431);
            this.txtHDVDT.Name = "txtHDVDT";
            this.txtHDVDT.Size = new System.Drawing.Size(280, 22);
            this.txtHDVDT.TabIndex = 6;
            // 
            // lblHDVDT
            // 
            this.lblHDVDT.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblHDVDT.AutoSize = true;
            this.lblHDVDT.Location = new System.Drawing.Point(15, 434);
            this.lblHDVDT.Name = "lblHDVDT";
            this.lblHDVDT.Size = new System.Drawing.Size(76, 17);
            this.lblHDVDT.TabIndex = 5;
            this.lblHDVDT.Text = "Điện thoại:";
            // 
            // txtHDVTen
            // 
            this.txtHDVTen.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtHDVTen.Location = new System.Drawing.Point(400, 385);
            this.txtHDVTen.Name = "txtHDVTen";
            this.txtHDVTen.Size = new System.Drawing.Size(350, 22);
            this.txtHDVTen.TabIndex = 4;
            // 
            // lblHDVTen
            // 
            this.lblHDVTen.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblHDVTen.AutoSize = true;
            this.lblHDVTen.Location = new System.Drawing.Point(325, 388);
            this.lblHDVTen.Name = "lblHDVTen";
            this.lblHDVTen.Size = new System.Drawing.Size(54, 17);
            this.lblHDVTen.TabIndex = 3;
            this.lblHDVTen.Text = "Họ tên:";
            // 
            // txtHDVMa
            // 
            this.txtHDVMa.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.txtHDVMa.Location = new System.Drawing.Point(120, 385);
            this.txtHDVMa.Name = "txtHDVMa";
            this.txtHDVMa.Size = new System.Drawing.Size(180, 22);
            this.txtHDVMa.TabIndex = 2;
            // 
            // lblHDVMa
            // 
            this.lblHDVMa.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblHDVMa.AutoSize = true;
            this.lblHDVMa.Location = new System.Drawing.Point(15, 388);
            this.lblHDVMa.Name = "lblHDVMa";
            this.lblHDVMa.Size = new System.Drawing.Size(66, 17);
            this.lblHDVMa.TabIndex = 1;
            this.lblHDVMa.Text = "Mã HDV:";
            // 
            // dgvHDV
            // 
            this.dgvHDV.AllowUserToAddRows = false;
            this.dgvHDV.AllowUserToDeleteRows = false;
            this.dgvHDV.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvHDV.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvHDV.BackgroundColor = System.Drawing.Color.White;
            this.dgvHDV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvHDV.Location = new System.Drawing.Point(15, 15);
            this.dgvHDV.Name = "dgvHDV";
            this.dgvHDV.ReadOnly = true;
            this.dgvHDV.RowHeadersWidth = 51;
            this.dgvHDV.RowTemplate.Height = 24;
            this.dgvHDV.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvHDV.Size = new System.Drawing.Size(885, 345);
            this.dgvHDV.TabIndex = 0;
            // 
            // tabDTQ
            // 
            this.tabDTQ.Controls.Add(this.btnThemDTQ);
            this.tabDTQ.Controls.Add(this.txtDTQYNghia);
            this.tabDTQ.Controls.Add(this.lblDTQYNghia);
            this.tabDTQ.Controls.Add(this.txtDTQNoiDung);
            this.tabDTQ.Controls.Add(this.lblDTQNoiDung);
            this.tabDTQ.Controls.Add(this.txtDTQDiaDiem);
            this.tabDTQ.Controls.Add(this.lblDTQDiaDiem);
            this.tabDTQ.Controls.Add(this.txtDTQTen);
            this.tabDTQ.Controls.Add(this.lblDTQTen);
            this.tabDTQ.Controls.Add(this.txtDTQMa);
            this.tabDTQ.Controls.Add(this.lblDTQMa);
            this.tabDTQ.Controls.Add(this.dgvDTQ);
            this.tabDTQ.Location = new System.Drawing.Point(4, 25);
            this.tabDTQ.Name = "tabDTQ";
            this.tabDTQ.Padding = new System.Windows.Forms.Padding(3);
            this.tabDTQ.Size = new System.Drawing.Size(917, 491);
            this.tabDTQ.TabIndex = 3;
            this.tabDTQ.Text = "Điểm tham quan";
            this.tabDTQ.UseVisualStyleBackColor = true;
            // 
            // btnThemDTQ
            // 
            this.btnThemDTQ.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnThemDTQ.Location = new System.Drawing.Point(780, 425);
            this.btnThemDTQ.Name = "btnThemDTQ";
            this.btnThemDTQ.Size = new System.Drawing.Size(120, 35);
            this.btnThemDTQ.TabIndex = 11;
            this.btnThemDTQ.Text = "Thêm";
            this.btnThemDTQ.UseVisualStyleBackColor = true;
            this.btnThemDTQ.Click += new System.EventHandler(this.btnThemDTQ_Click);
            // 
            // txtDTQYNghia
            // 
            this.txtDTQYNghia.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.txtDTQYNghia.Location = new System.Drawing.Point(480, 431);
            this.txtDTQYNghia.Name = "txtDTQYNghia";
            this.txtDTQYNghia.Size = new System.Drawing.Size(270, 22);
            this.txtDTQYNghia.TabIndex = 10;
            // 
            // lblDTQYNghia
            // 
            this.lblDTQYNghia.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.lblDTQYNghia.AutoSize = true;
            this.lblDTQYNghia.Location = new System.Drawing.Point(415, 434);
            this.lblDTQYNghia.Name = "lblDTQYNghia";
            this.lblDTQYNghia.Size = new System.Drawing.Size(59, 17);
            this.lblDTQYNghia.TabIndex = 9;
            this.lblDTQYNghia.Text = "Ý nghĩa:";
            // 
            // txtDTQNoiDung
            // 
            this.txtDTQNoiDung.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtDTQNoiDung.Location = new System.Drawing.Point(110, 431);
            this.txtDTQNoiDung.Name = "txtDTQNoiDung";
            this.txtDTQNoiDung.Size = new System.Drawing.Size(280, 22);
            this.txtDTQNoiDung.TabIndex = 8;
            // 
            // lblDTQNoiDung
            // 
            this.lblDTQNoiDung.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblDTQNoiDung.AutoSize = true;
            this.lblDTQNoiDung.Location = new System.Drawing.Point(15, 434);
            this.lblDTQNoiDung.Name = "lblDTQNoiDung";
            this.lblDTQNoiDung.Size = new System.Drawing.Size(69, 17);
            this.lblDTQNoiDung.TabIndex = 7;
            this.lblDTQNoiDung.Text = "Nội dung:";
            // 
            // txtDTQDiaDiem
            // 
            this.txtDTQDiaDiem.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.txtDTQDiaDiem.Location = new System.Drawing.Point(580, 385);
            this.txtDTQDiaDiem.Name = "txtDTQDiaDiem";
            this.txtDTQDiaDiem.Size = new System.Drawing.Size(170, 22);
            this.txtDTQDiaDiem.TabIndex = 6;
            // 
            // lblDTQDiaDiem
            // 
            this.lblDTQDiaDiem.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.lblDTQDiaDiem.AutoSize = true;
            this.lblDTQDiaDiem.Location = new System.Drawing.Point(505, 388);
            this.lblDTQDiaDiem.Name = "lblDTQDiaDiem";
            this.lblDTQDiaDiem.Size = new System.Drawing.Size(67, 17);
            this.lblDTQDiaDiem.TabIndex = 5;
            this.lblDTQDiaDiem.Text = "Địa điểm:";
            // 
            // txtDTQTen
            // 
            this.txtDTQTen.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtDTQTen.Location = new System.Drawing.Point(340, 385);
            this.txtDTQTen.Name = "txtDTQTen";
            this.txtDTQTen.Size = new System.Drawing.Size(145, 22);
            this.txtDTQTen.TabIndex = 4;
            // 
            // lblDTQTen
            // 
            this.lblDTQTen.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblDTQTen.AutoSize = true;
            this.lblDTQTen.Location = new System.Drawing.Point(265, 388);
            this.lblDTQTen.Name = "lblDTQTen";
            this.lblDTQTen.Size = new System.Drawing.Size(66, 17);
            this.lblDTQTen.TabIndex = 3;
            this.lblDTQTen.Text = "Tên TQ:";
            // 
            // txtDTQMa
            // 
            this.txtDTQMa.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.txtDTQMa.Location = new System.Drawing.Point(110, 385);
            this.txtDTQMa.Name = "txtDTQMa";
            this.txtDTQMa.Size = new System.Drawing.Size(130, 22);
            this.txtDTQMa.TabIndex = 2;
            // 
            // lblDTQMa
            // 
            this.lblDTQMa.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblDTQMa.AutoSize = true;
            this.lblDTQMa.Location = new System.Drawing.Point(15, 388);
            this.lblDTQMa.Name = "lblDTQMa";
            this.lblDTQMa.Size = new System.Drawing.Size(87, 17);
            this.lblDTQMa.TabIndex = 1;
            this.lblDTQMa.Text = "Mã điểm TQ:";
            // 
            // dgvDTQ
            // 
            this.dgvDTQ.AllowUserToAddRows = false;
            this.dgvDTQ.AllowUserToDeleteRows = false;
            this.dgvDTQ.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvDTQ.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvDTQ.BackgroundColor = System.Drawing.Color.White;
            this.dgvDTQ.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDTQ.Location = new System.Drawing.Point(15, 15);
            this.dgvDTQ.Name = "dgvDTQ";
            this.dgvDTQ.ReadOnly = true;
            this.dgvDTQ.RowHeadersWidth = 51;
            this.dgvDTQ.RowTemplate.Height = 24;
            this.dgvDTQ.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvDTQ.Size = new System.Drawing.Size(885, 345);
            this.dgvDTQ.TabIndex = 0;
            // 
            // btnDong
            // 
            this.btnDong.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDong.Location = new System.Drawing.Point(830, 550);
            this.btnDong.Name = "btnDong";
            this.btnDong.Size = new System.Drawing.Size(110, 35);
            this.btnDong.TabIndex = 1;
            this.btnDong.Text = "Đóng";
            this.btnDong.UseVisualStyleBackColor = true;
            this.btnDong.Click += new System.EventHandler(this.btnDong_Click);
            // 
            // FrmDanhMuc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(965, 600);
            this.Controls.Add(this.btnDong);
            this.Controls.Add(this.tabDanhMuc);
            this.Name = "FrmDanhMuc";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Danh mục";
            this.Load += new System.EventHandler(this.FrmDanhMuc_Load);
            this.tabDanhMuc.ResumeLayout(false);
            this.tabPT.ResumeLayout(false);
            this.tabPT.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPT)).EndInit();
            this.tabDB.ResumeLayout(false);
            this.tabDB.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDB)).EndInit();
            this.tabHDV.ResumeLayout(false);
            this.tabHDV.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numLuong)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHDV)).EndInit();
            this.tabDTQ.ResumeLayout(false);
            this.tabDTQ.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDTQ)).EndInit();
            this.ResumeLayout(false);
        }

        private System.Windows.Forms.TabControl tabDanhMuc;
        private System.Windows.Forms.TabPage tabPT;
        private System.Windows.Forms.TabPage tabDB;
        private System.Windows.Forms.TabPage tabHDV;
        private System.Windows.Forms.TabPage tabDTQ;
        private System.Windows.Forms.DataGridView dgvPT;
        private System.Windows.Forms.Label lblPTMa;
        private System.Windows.Forms.TextBox txtPTMa;
        private System.Windows.Forms.Label lblPTTen;
        private System.Windows.Forms.TextBox txtPTTen;
        private System.Windows.Forms.Label lblPTGhiChu;
        private System.Windows.Forms.TextBox txtPTGhiChu;
        private System.Windows.Forms.Button btnThemPT;
        private System.Windows.Forms.DataGridView dgvDB;
        private System.Windows.Forms.Label lblDBMa;
        private System.Windows.Forms.TextBox txtDBMa;
        private System.Windows.Forms.Label lblDBTen;
        private System.Windows.Forms.TextBox txtDBTen;
        private System.Windows.Forms.Label lblDBDiaChi;
        private System.Windows.Forms.TextBox txtDBDiaChi;
        private System.Windows.Forms.Label lblDBDT;
        private System.Windows.Forms.TextBox txtDBDT;
        private System.Windows.Forms.Button btnThemDB;
        private System.Windows.Forms.DataGridView dgvHDV;
        private System.Windows.Forms.Label lblHDVMa;
        private System.Windows.Forms.TextBox txtHDVMa;
        private System.Windows.Forms.Label lblHDVTen;
        private System.Windows.Forms.TextBox txtHDVTen;
        private System.Windows.Forms.Label lblHDVDT;
        private System.Windows.Forms.TextBox txtHDVDT;
        private System.Windows.Forms.Label lblLuong;
        private System.Windows.Forms.NumericUpDown numLuong;
        private System.Windows.Forms.Button btnThemHDV;
        private System.Windows.Forms.DataGridView dgvDTQ;
        private System.Windows.Forms.Label lblDTQMa;
        private System.Windows.Forms.TextBox txtDTQMa;
        private System.Windows.Forms.Label lblDTQTen;
        private System.Windows.Forms.TextBox txtDTQTen;
        private System.Windows.Forms.Label lblDTQDiaDiem;
        private System.Windows.Forms.TextBox txtDTQDiaDiem;
        private System.Windows.Forms.Label lblDTQNoiDung;
        private System.Windows.Forms.TextBox txtDTQNoiDung;
        private System.Windows.Forms.Label lblDTQYNghia;
        private System.Windows.Forms.TextBox txtDTQYNghia;
        private System.Windows.Forms.Button btnThemDTQ;
        private System.Windows.Forms.Button btnDong;
    }
}