﻿namespace QuanLyCongTyDuLich.Forms
{
    partial class FrmTour
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblChonTour = new System.Windows.Forms.Label();
            this.cboTour = new System.Windows.Forms.ComboBox();
            this.tabTour = new System.Windows.Forms.TabControl();
            this.tabTour1 = new System.Windows.Forms.TabPage();
            this.btnThemTour = new System.Windows.Forms.Button();
            this.txtMoTa = new System.Windows.Forms.TextBox();
            this.lblMoTa = new System.Windows.Forms.Label();
            this.numGia = new System.Windows.Forms.NumericUpDown();
            this.lblGia = new System.Windows.Forms.Label();
            this.numDem = new System.Windows.Forms.NumericUpDown();
            this.lblDem = new System.Windows.Forms.Label();
            this.numNgay = new System.Windows.Forms.NumericUpDown();
            this.lblNgay = new System.Windows.Forms.Label();
            this.txtTen = new System.Windows.Forms.TextBox();
            this.lblTen = new System.Windows.Forms.Label();
            this.txtMa = new System.Windows.Forms.TextBox();
            this.lblMa = new System.Windows.Forms.Label();
            this.dgvTour = new System.Windows.Forms.DataGridView();
            this.tabDiemDung = new System.Windows.Forms.TabPage();
            this.btnThemDD = new System.Windows.Forms.Button();
            this.txtGhiChuDD = new System.Windows.Forms.TextBox();
            this.lblGhiChuDD = new System.Windows.Forms.Label();
            this.numSao = new System.Windows.Forms.NumericUpDown();
            this.lblSao = new System.Windows.Forms.Label();
            this.chkKS = new System.Windows.Forms.CheckBox();
            this.chkAn = new System.Windows.Forms.CheckBox();
            this.chkDoiPT = new System.Windows.Forms.CheckBox();
            this.txtDiemDung = new System.Windows.Forms.TextBox();
            this.lblDiemDung = new System.Windows.Forms.Label();
            this.numThuTu = new System.Windows.Forms.NumericUpDown();
            this.lblThuTu = new System.Windows.Forms.Label();
            this.dgvDiemDung = new System.Windows.Forms.DataGridView();
            this.tabChang = new System.Windows.Forms.TabPage();
            this.lblGhiChuNho = new System.Windows.Forms.Label();
            this.btnThemChang = new System.Windows.Forms.Button();
            this.txtGhiChuPT = new System.Windows.Forms.TextBox();
            this.lblGhiChuPT = new System.Windows.Forms.Label();
            this.cboPT = new System.Windows.Forms.ComboBox();
            this.lblPT = new System.Windows.Forms.Label();
            this.numChang = new System.Windows.Forms.NumericUpDown();
            this.lblChang = new System.Windows.Forms.Label();
            this.dgvChang = new System.Windows.Forms.DataGridView();
            this.tabTQ = new System.Windows.Forms.TabPage();
            this.btnThemTQ = new System.Windows.Forms.Button();
            this.numThuTuTQ = new System.Windows.Forms.NumericUpDown();
            this.lblThuTuTQ = new System.Windows.Forms.Label();
            this.cboDTQ = new System.Windows.Forms.ComboBox();
            this.lblDTQ = new System.Windows.Forms.Label();
            this.dgvTQ = new System.Windows.Forms.DataGridView();
            this.btnDong = new System.Windows.Forms.Button();
            this.tabTour.SuspendLayout();
            this.tabTour1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numGia)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numDem)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numNgay)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTour)).BeginInit();
            this.tabDiemDung.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numSao)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numThuTu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDiemDung)).BeginInit();
            this.tabChang.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numChang)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvChang)).BeginInit();
            this.tabTQ.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numThuTuTQ)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTQ)).BeginInit();
            this.SuspendLayout();
            // 
            // lblChonTour
            // 
            this.lblChonTour.AutoSize = true;
            this.lblChonTour.Location = new System.Drawing.Point(20, 20);
            this.lblChonTour.Name = "lblChonTour";
            this.lblChonTour.Size = new System.Drawing.Size(250, 17);
            this.lblChonTour.TabIndex = 0;
            this.lblChonTour.Text = "Tour đang chọn (cho các tab hành trình):";
            // 
            // cboTour
            // 
            this.cboTour.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboTour.FormattingEnabled = true;
            this.cboTour.Location = new System.Drawing.Point(280, 17);
            this.cboTour.Name = "cboTour";
            this.cboTour.Size = new System.Drawing.Size(400, 24);
            this.cboTour.TabIndex = 1;
            this.cboTour.SelectedIndexChanged += new System.EventHandler(this.cboTour_SelectedIndexChanged);
            // 
            // tabTour
            // 
            this.tabTour.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabTour.Controls.Add(this.tabTour1);
            this.tabTour.Controls.Add(this.tabDiemDung);
            this.tabTour.Controls.Add(this.tabChang);
            this.tabTour.Controls.Add(this.tabTQ);
            this.tabTour.Location = new System.Drawing.Point(20, 55);
            this.tabTour.Name = "tabTour";
            this.tabTour.SelectedIndex = 0;
            this.tabTour.Size = new System.Drawing.Size(945, 520);
            this.tabTour.TabIndex = 2;
            // 
            // tabTour1
            // 
            this.tabTour1.Controls.Add(this.btnThemTour);
            this.tabTour1.Controls.Add(this.txtMoTa);
            this.tabTour1.Controls.Add(this.lblMoTa);
            this.tabTour1.Controls.Add(this.numGia);
            this.tabTour1.Controls.Add(this.lblGia);
            this.tabTour1.Controls.Add(this.numDem);
            this.tabTour1.Controls.Add(this.lblDem);
            this.tabTour1.Controls.Add(this.numNgay);
            this.tabTour1.Controls.Add(this.lblNgay);
            this.tabTour1.Controls.Add(this.txtTen);
            this.tabTour1.Controls.Add(this.lblTen);
            this.tabTour1.Controls.Add(this.txtMa);
            this.tabTour1.Controls.Add(this.lblMa);
            this.tabTour1.Controls.Add(this.dgvTour);
            this.tabTour1.Location = new System.Drawing.Point(4, 25);
            this.tabTour1.Name = "tabTour1";
            this.tabTour1.Padding = new System.Windows.Forms.Padding(3);
            this.tabTour1.Size = new System.Drawing.Size(937, 491);
            this.tabTour1.TabIndex = 0;
            this.tabTour1.Text = "Tour";
            this.tabTour1.UseVisualStyleBackColor = true;
            // 
            // btnThemTour
            // 
            this.btnThemTour.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnThemTour.Location = new System.Drawing.Point(795, 430);
            this.btnThemTour.Name = "btnThemTour";
            this.btnThemTour.Size = new System.Drawing.Size(125, 45);
            this.btnThemTour.TabIndex = 13;
            this.btnThemTour.Text = "Thêm tour";
            this.btnThemTour.UseVisualStyleBackColor = true;
            this.btnThemTour.Click += new System.EventHandler(this.btnThemTour_Click);
            // 
            // txtMoTa
            // 
            this.txtMoTa.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtMoTa.Location = new System.Drawing.Point(110, 442);
            this.txtMoTa.Name = "txtMoTa";
            this.txtMoTa.Size = new System.Drawing.Size(665, 22);
            this.txtMoTa.TabIndex = 12;
            // 
            // lblMoTa
            // 
            this.lblMoTa.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblMoTa.AutoSize = true;
            this.lblMoTa.Location = new System.Drawing.Point(15, 445);
            this.lblMoTa.Name = "lblMoTa";
            this.lblMoTa.Size = new System.Drawing.Size(47, 17);
            this.lblMoTa.TabIndex = 11;
            this.lblMoTa.Text = "Mô tả:";
            // 
            // numGia
            // 
            this.numGia.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.numGia.Location = new System.Drawing.Point(620, 401);
            this.numGia.Maximum = new decimal(new int[] { 1000000000, 0, 0, 0 });
            this.numGia.Name = "numGia";
            this.numGia.Size = new System.Drawing.Size(155, 22);
            this.numGia.TabIndex = 10;
            this.numGia.ThousandsSeparator = true;
            // 
            // lblGia
            // 
            this.lblGia.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblGia.AutoSize = true;
            this.lblGia.Location = new System.Drawing.Point(505, 403);
            this.lblGia.Name = "lblGia";
            this.lblGia.Size = new System.Drawing.Size(110, 17);
            this.lblGia.TabIndex = 9;
            this.lblGia.Text = "Đơn giá / khách:";
            // 
            // numDem
            // 
            this.numDem.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.numDem.Location = new System.Drawing.Point(395, 401);
            this.numDem.Name = "numDem";
            this.numDem.Size = new System.Drawing.Size(80, 22);
            this.numDem.TabIndex = 8;
            // 
            // lblDem
            // 
            this.lblDem.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblDem.AutoSize = true;
            this.lblDem.Location = new System.Drawing.Point(330, 403);
            this.lblDem.Name = "lblDem";
            this.lblDem.Size = new System.Drawing.Size(60, 17);
            this.lblDem.TabIndex = 7;
            this.lblDem.Text = "Số đêm:";
            // 
            // numNgay
            // 
            this.numNgay.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.numNgay.Location = new System.Drawing.Point(220, 401);
            this.numNgay.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
            this.numNgay.Name = "numNgay";
            this.numNgay.Size = new System.Drawing.Size(80, 22);
            this.numNgay.TabIndex = 6;
            this.numNgay.Value = new decimal(new int[] { 1, 0, 0, 0 });
            // 
            // lblNgay
            // 
            this.lblNgay.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblNgay.AutoSize = true;
            this.lblNgay.Location = new System.Drawing.Point(150, 403);
            this.lblNgay.Name = "lblNgay";
            this.lblNgay.Size = new System.Drawing.Size(65, 17);
            this.lblNgay.TabIndex = 5;
            this.lblNgay.Text = "Số ngày:";
            // 
            // txtTen
            // 
            this.txtTen.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtTen.Location = new System.Drawing.Point(380, 358);
            this.txtTen.Name = "txtTen";
            this.txtTen.Size = new System.Drawing.Size(395, 22);
            this.txtTen.TabIndex = 4;
            // 
            // lblTen
            // 
            this.lblTen.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblTen.AutoSize = true;
            this.lblTen.Location = new System.Drawing.Point(310, 361);
            this.lblTen.Name = "lblTen";
            this.lblTen.Size = new System.Drawing.Size(65, 17);
            this.lblTen.TabIndex = 3;
            this.lblTen.Text = "Tên tour:";
            // 
            // txtMa
            // 
            this.txtMa.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.txtMa.Location = new System.Drawing.Point(110, 358);
            this.txtMa.Name = "txtMa";
            this.txtMa.Size = new System.Drawing.Size(170, 22);
            this.txtMa.TabIndex = 2;
            // 
            // lblMa
            // 
            this.lblMa.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblMa.AutoSize = true;
            this.lblMa.Location = new System.Drawing.Point(15, 361);
            this.lblMa.Name = "lblMa";
            this.lblMa.Size = new System.Drawing.Size(59, 17);
            this.lblMa.TabIndex = 1;
            this.lblMa.Text = "Mã tour:";
            // 
            // dgvTour
            // 
            this.dgvTour.AllowUserToAddRows = false;
            this.dgvTour.AllowUserToDeleteRows = false;
            this.dgvTour.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvTour.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvTour.BackgroundColor = System.Drawing.Color.White;
            this.dgvTour.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTour.Location = new System.Drawing.Point(15, 15);
            this.dgvTour.Name = "dgvTour";
            this.dgvTour.ReadOnly = true;
            this.dgvTour.RowHeadersWidth = 51;
            this.dgvTour.RowTemplate.Height = 24;
            this.dgvTour.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvTour.Size = new System.Drawing.Size(905, 325);
            this.dgvTour.TabIndex = 0;
            // 
            // tabDiemDung
            // 
            this.tabDiemDung.Controls.Add(this.btnThemDD);
            this.tabDiemDung.Controls.Add(this.txtGhiChuDD);
            this.tabDiemDung.Controls.Add(this.lblGhiChuDD);
            this.tabDiemDung.Controls.Add(this.numSao);
            this.tabDiemDung.Controls.Add(this.lblSao);
            this.tabDiemDung.Controls.Add(this.chkKS);
            this.tabDiemDung.Controls.Add(this.chkAn);
            this.tabDiemDung.Controls.Add(this.chkDoiPT);
            this.tabDiemDung.Controls.Add(this.txtDiemDung);
            this.tabDiemDung.Controls.Add(this.lblDiemDung);
            this.tabDiemDung.Controls.Add(this.numThuTu);
            this.tabDiemDung.Controls.Add(this.lblThuTu);
            this.tabDiemDung.Controls.Add(this.dgvDiemDung);
            this.tabDiemDung.Location = new System.Drawing.Point(4, 25);
            this.tabDiemDung.Name = "tabDiemDung";
            this.tabDiemDung.Padding = new System.Windows.Forms.Padding(3);
            this.tabDiemDung.Size = new System.Drawing.Size(937, 491);
            this.tabDiemDung.TabIndex = 1;
            this.tabDiemDung.Text = "Điểm dừng";
            this.tabDiemDung.UseVisualStyleBackColor = true;
            // 
            // btnThemDD
            // 
            this.btnThemDD.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnThemDD.Location = new System.Drawing.Point(795, 430);
            this.btnThemDD.Name = "btnThemDD";
            this.btnThemDD.Size = new System.Drawing.Size(125, 45);
            this.btnThemDD.TabIndex = 12;
            this.btnThemDD.Text = "Thêm điểm dừng";
            this.btnThemDD.UseVisualStyleBackColor = true;
            this.btnThemDD.Click += new System.EventHandler(this.btnThemDD_Click);
            // 
            // txtGhiChuDD
            // 
            this.txtGhiChuDD.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtGhiChuDD.Location = new System.Drawing.Point(100, 442);
            this.txtGhiChuDD.Name = "txtGhiChuDD";
            this.txtGhiChuDD.Size = new System.Drawing.Size(675, 22);
            this.txtGhiChuDD.TabIndex = 11;
            // 
            // lblGhiChuDD
            // 
            this.lblGhiChuDD.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblGhiChuDD.AutoSize = true;
            this.lblGhiChuDD.Location = new System.Drawing.Point(15, 445);
            this.lblGhiChuDD.Name = "lblGhiChuDD";
            this.lblGhiChuDD.Size = new System.Drawing.Size(61, 17);
            this.lblGhiChuDD.TabIndex = 10;
            this.lblGhiChuDD.Text = "Ghi chú:";
            // 
            // numSao
            // 
            this.numSao.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.numSao.Enabled = false;
            this.numSao.Location = new System.Drawing.Point(580, 401);
            this.numSao.Maximum = new decimal(new int[] { 5, 0, 0, 0 });
            this.numSao.Minimum = new decimal(new int[] { 2, 0, 0, 0 });
            this.numSao.Name = "numSao";
            this.numSao.Size = new System.Drawing.Size(65, 22);
            this.numSao.TabIndex = 9;
            this.numSao.Value = new decimal(new int[] { 3, 0, 0, 0 });
            // 
            // lblSao
            // 
            this.lblSao.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblSao.AutoSize = true;
            this.lblSao.Location = new System.Drawing.Point(505, 403);
            this.lblSao.Name = "lblSao";
            this.lblSao.Size = new System.Drawing.Size(73, 17);
            this.lblSao.TabIndex = 8;
            this.lblSao.Text = "Hạng sao:";
            // 
            // chkKS
            // 
            this.chkKS.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.chkKS.AutoSize = true;
            this.chkKS.Location = new System.Drawing.Point(365, 402);
            this.chkKS.Name = "chkKS";
            this.chkKS.Size = new System.Drawing.Size(113, 21);
            this.chkKS.TabIndex = 7;
            this.chkKS.Text = "Có khách sạn";
            this.chkKS.UseVisualStyleBackColor = true;
            this.chkKS.CheckedChanged += new System.EventHandler(this.chkKS_CheckedChanged);
            // 
            // chkAn
            // 
            this.chkAn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.chkAn.AutoSize = true;
            this.chkAn.Location = new System.Drawing.Point(235, 402);
            this.chkAn.Name = "chkAn";
            this.chkAn.Size = new System.Drawing.Size(95, 21);
            this.chkAn.TabIndex = 6;
            this.chkAn.Text = "Có nơi ăn";
            this.chkAn.UseVisualStyleBackColor = true;
            // 
            // chkDoiPT
            // 
            this.chkDoiPT.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.chkDoiPT.AutoSize = true;
            this.chkDoiPT.Location = new System.Drawing.Point(100, 402);
            this.chkDoiPT.Name = "chkDoiPT";
            this.chkDoiPT.Size = new System.Drawing.Size(130, 21);
            this.chkDoiPT.TabIndex = 5;
            this.chkDoiPT.Text = "Đổi phương tiện";
            this.chkDoiPT.UseVisualStyleBackColor = true;
            // 
            // txtDiemDung
            // 
            this.txtDiemDung.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtDiemDung.Location = new System.Drawing.Point(365, 358);
            this.txtDiemDung.Name = "txtDiemDung";
            this.txtDiemDung.Size = new System.Drawing.Size(410, 22);
            this.txtDiemDung.TabIndex = 4;
            // 
            // lblDiemDung
            // 
            this.lblDiemDung.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblDiemDung.AutoSize = true;
            this.lblDiemDung.Location = new System.Drawing.Point(250, 361);
            this.lblDiemDung.Name = "lblDiemDung";
            this.lblDiemDung.Size = new System.Drawing.Size(107, 17);
            this.lblDiemDung.TabIndex = 3;
            this.lblDiemDung.Text = "Tên điểm dừng:";
            // 
            // numThuTu
            // 
            this.numThuTu.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.numThuTu.Location = new System.Drawing.Point(100, 358);
            this.numThuTu.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
            this.numThuTu.Name = "numThuTu";
            this.numThuTu.Size = new System.Drawing.Size(120, 22);
            this.numThuTu.TabIndex = 2;
            this.numThuTu.Value = new decimal(new int[] { 1, 0, 0, 0 });
            // 
            // lblThuTu
            // 
            this.lblThuTu.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblThuTu.AutoSize = true;
            this.lblThuTu.Location = new System.Drawing.Point(15, 361);
            this.lblThuTu.Name = "lblThuTu";
            this.lblThuTu.Size = new System.Drawing.Size(53, 17);
            this.lblThuTu.TabIndex = 1;
            this.lblThuTu.Text = "Thứ tự:";
            // 
            // dgvDiemDung
            // 
            this.dgvDiemDung.AllowUserToAddRows = false;
            this.dgvDiemDung.AllowUserToDeleteRows = false;
            this.dgvDiemDung.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvDiemDung.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvDiemDung.BackgroundColor = System.Drawing.Color.White;
            this.dgvDiemDung.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDiemDung.Location = new System.Drawing.Point(15, 15);
            this.dgvDiemDung.Name = "dgvDiemDung";
            this.dgvDiemDung.ReadOnly = true;
            this.dgvDiemDung.RowHeadersWidth = 51;
            this.dgvDiemDung.RowTemplate.Height = 24;
            this.dgvDiemDung.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvDiemDung.Size = new System.Drawing.Size(905, 325);
            this.dgvDiemDung.TabIndex = 0;
            // 
            // tabChang
            // 
            this.tabChang.Controls.Add(this.lblGhiChuNho);
            this.tabChang.Controls.Add(this.btnThemChang);
            this.tabChang.Controls.Add(this.txtGhiChuPT);
            this.tabChang.Controls.Add(this.lblGhiChuPT);
            this.tabChang.Controls.Add(this.cboPT);
            this.tabChang.Controls.Add(this.lblPT);
            this.tabChang.Controls.Add(this.numChang);
            this.tabChang.Controls.Add(this.lblChang);
            this.tabChang.Controls.Add(this.dgvChang);
            this.tabChang.Location = new System.Drawing.Point(4, 25);
            this.tabChang.Name = "tabChang";
            this.tabChang.Padding = new System.Windows.Forms.Padding(3);
            this.tabChang.Size = new System.Drawing.Size(937, 491);
            this.tabChang.TabIndex = 2;
            this.tabChang.Text = "Phương tiện theo chặng";
            this.tabChang.UseVisualStyleBackColor = true;
            // 
            // lblGhiChuNho
            // 
            this.lblGhiChuNho.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblGhiChuNho.AutoSize = true;
            this.lblGhiChuNho.ForeColor = System.Drawing.Color.Gray;
            this.lblGhiChuNho.Location = new System.Drawing.Point(15, 445);
            this.lblGhiChuNho.Name = "lblGhiChuNho";
            this.lblGhiChuNho.Size = new System.Drawing.Size(433, 17);
            this.lblGhiChuNho.TabIndex = 8;
            this.lblGhiChuNho.Text = "Chặng k là đoạn đi tới điểm dừng thứ k; một chặng có thể dùng nhiều phương tiện.";
            // 
            // btnThemChang
            // 
            this.btnThemChang.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnThemChang.Location = new System.Drawing.Point(795, 385);
            this.btnThemChang.Name = "btnThemChang";
            this.btnThemChang.Size = new System.Drawing.Size(125, 45);
            this.btnThemChang.TabIndex = 7;
            this.btnThemChang.Text = "Gắn phương tiện";
            this.btnThemChang.UseVisualStyleBackColor = true;
            this.btnThemChang.Click += new System.EventHandler(this.btnThemChang_Click);
            // 
            // txtGhiChuPT
            // 
            this.txtGhiChuPT.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtGhiChuPT.Location = new System.Drawing.Point(110, 401);
            this.txtGhiChuPT.Name = "txtGhiChuPT";
            this.txtGhiChuPT.Size = new System.Drawing.Size(665, 22);
            this.txtGhiChuPT.TabIndex = 6;
            // 
            // lblGhiChuPT
            // 
            this.lblGhiChuPT.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblGhiChuPT.AutoSize = true;
            this.lblGhiChuPT.Location = new System.Drawing.Point(15, 404);
            this.lblGhiChuPT.Name = "lblGhiChuPT";
            this.lblGhiChuPT.Size = new System.Drawing.Size(61, 17);
            this.lblGhiChuPT.TabIndex = 5;
            this.lblGhiChuPT.Text = "Ghi chú:";
            // 
            // cboPT
            // 
            this.cboPT.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cboPT.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboPT.FormattingEnabled = true;
            this.cboPT.Location = new System.Drawing.Point(360, 358);
            this.cboPT.Name = "cboPT";
            this.cboPT.Size = new System.Drawing.Size(415, 24);
            this.cboPT.TabIndex = 4;
            // 
            // lblPT
            // 
            this.lblPT.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblPT.AutoSize = true;
            this.lblPT.Location = new System.Drawing.Point(260, 361);
            this.lblPT.Name = "lblPT";
            this.lblPT.Size = new System.Drawing.Size(91, 17);
            this.lblPT.TabIndex = 3;
            this.lblPT.Text = "Phương tiện:";
            // 
            // numChang
            // 
            this.numChang.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.numChang.Location = new System.Drawing.Point(110, 358);
            this.numChang.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
            this.numChang.Name = "numChang";
            this.numChang.Size = new System.Drawing.Size(120, 22);
            this.numChang.TabIndex = 2;
            this.numChang.Value = new decimal(new int[] { 1, 0, 0, 0 });
            // 
            // lblChang
            // 
            this.lblChang.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblChang.AutoSize = true;
            this.lblChang.Location = new System.Drawing.Point(15, 361);
            this.lblChang.Name = "lblChang";
            this.lblChang.Size = new System.Drawing.Size(73, 17);
            this.lblChang.TabIndex = 1;
            this.lblChang.Text = "Chặng thứ:";
            // 
            // dgvChang
            // 
            this.dgvChang.AllowUserToAddRows = false;
            this.dgvChang.AllowUserToDeleteRows = false;
            this.dgvChang.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvChang.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvChang.BackgroundColor = System.Drawing.Color.White;
            this.dgvChang.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvChang.Location = new System.Drawing.Point(15, 15);
            this.dgvChang.Name = "dgvChang";
            this.dgvChang.ReadOnly = true;
            this.dgvChang.RowHeadersWidth = 51;
            this.dgvChang.RowTemplate.Height = 24;
            this.dgvChang.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvChang.Size = new System.Drawing.Size(905, 325);
            this.dgvChang.TabIndex = 0;
            // 
            // tabTQ
            // 
            this.tabTQ.Controls.Add(this.btnThemTQ);
            this.tabTQ.Controls.Add(this.numThuTuTQ);
            this.tabTQ.Controls.Add(this.lblThuTuTQ);
            this.tabTQ.Controls.Add(this.cboDTQ);
            this.tabTQ.Controls.Add(this.lblDTQ);
            this.tabTQ.Controls.Add(this.dgvTQ);
            this.tabTQ.Location = new System.Drawing.Point(4, 25);
            this.tabTQ.Name = "tabTQ";
            this.tabTQ.Padding = new System.Windows.Forms.Padding(3);
            this.tabTQ.Size = new System.Drawing.Size(937, 491);
            this.tabTQ.TabIndex = 3;
            this.tabTQ.Text = "Điểm tham quan";
            this.tabTQ.UseVisualStyleBackColor = true;
            // 
            // btnThemTQ
            // 
            this.btnThemTQ.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnThemTQ.Location = new System.Drawing.Point(795, 385);
            this.btnThemTQ.Name = "btnThemTQ";
            this.btnThemTQ.Size = new System.Drawing.Size(125, 45);
            this.btnThemTQ.TabIndex = 5;
            this.btnThemTQ.Text = "Gắn điểm TQ";
            this.btnThemTQ.UseVisualStyleBackColor = true;
            this.btnThemTQ.Click += new System.EventHandler(this.btnThemTQ_Click);
            // 
            // numThuTuTQ
            // 
            this.numThuTuTQ.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.numThuTuTQ.Location = new System.Drawing.Point(650, 396);
            this.numThuTuTQ.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
            this.numThuTuTQ.Name = "numThuTuTQ";
            this.numThuTuTQ.Size = new System.Drawing.Size(120, 22);
            this.numThuTuTQ.TabIndex = 4;
            this.numThuTuTQ.Value = new decimal(new int[] { 1, 0, 0, 0 });
            // 
            // lblThuTuTQ
            // 
            this.lblThuTuTQ.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.lblThuTuTQ.AutoSize = true;
            this.lblThuTuTQ.Location = new System.Drawing.Point(580, 399);
            this.lblThuTuTQ.Name = "lblThuTuTQ";
            this.lblThuTuTQ.Size = new System.Drawing.Size(53, 17);
            this.lblThuTuTQ.TabIndex = 3;
            this.lblThuTuTQ.Text = "Thứ tự:";
            // 
            // cboDTQ
            // 
            this.cboDTQ.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cboDTQ.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboDTQ.FormattingEnabled = true;
            this.cboDTQ.Location = new System.Drawing.Point(145, 396);
            this.cboDTQ.Name = "cboDTQ";
            this.cboDTQ.Size = new System.Drawing.Size(410, 24);
            this.cboDTQ.TabIndex = 2;
            // 
            // lblDTQ
            // 
            this.lblDTQ.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblDTQ.AutoSize = true;
            this.lblDTQ.Location = new System.Drawing.Point(15, 399);
            this.lblDTQ.Name = "lblDTQ";
            this.lblDTQ.Size = new System.Drawing.Size(113, 17);
            this.lblDTQ.TabIndex = 1;
            this.lblDTQ.Text = "Điểm tham quan:";
            // 
            // dgvTQ
            // 
            this.dgvTQ.AllowUserToAddRows = false;
            this.dgvTQ.AllowUserToDeleteRows = false;
            this.dgvTQ.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvTQ.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvTQ.BackgroundColor = System.Drawing.Color.White;
            this.dgvTQ.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTQ.Location = new System.Drawing.Point(15, 15);
            this.dgvTQ.Name = "dgvTQ";
            this.dgvTQ.ReadOnly = true;
            this.dgvTQ.RowHeadersWidth = 51;
            this.dgvTQ.RowTemplate.Height = 24;
            this.dgvTQ.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvTQ.Size = new System.Drawing.Size(905, 325);
            this.dgvTQ.TabIndex = 0;
            // 
            // btnDong
            // 
            this.btnDong.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDong.Location = new System.Drawing.Point(850, 585);
            this.btnDong.Name = "btnDong";
            this.btnDong.Size = new System.Drawing.Size(115, 35);
            this.btnDong.TabIndex = 3;
            this.btnDong.Text = "Đóng";
            this.btnDong.UseVisualStyleBackColor = true;
            this.btnDong.Click += new System.EventHandler(this.btnDong_Click);
            // 
            // FrmTour
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(985, 630);
            this.Controls.Add(this.btnDong);
            this.Controls.Add(this.tabTour);
            this.Controls.Add(this.cboTour);
            this.Controls.Add(this.lblChonTour);
            this.Name = "FrmTour";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Tour - hành trình";
            this.Load += new System.EventHandler(this.FrmTour_Load);
            this.tabTour.ResumeLayout(false);
            this.tabTour1.ResumeLayout(false);
            this.tabTour1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numGia)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numDem)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numNgay)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTour)).EndInit();
            this.tabDiemDung.ResumeLayout(false);
            this.tabDiemDung.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numSao)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numThuTu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDiemDung)).EndInit();
            this.tabChang.ResumeLayout(false);
            this.tabChang.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numChang)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvChang)).EndInit();
            this.tabTQ.ResumeLayout(false);
            this.tabTQ.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numThuTuTQ)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTQ)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Label lblChonTour;
        private System.Windows.Forms.ComboBox cboTour;
        private System.Windows.Forms.TabControl tabTour;
        private System.Windows.Forms.TabPage tabTour1;
        private System.Windows.Forms.TabPage tabDiemDung;
        private System.Windows.Forms.TabPage tabChang;
        private System.Windows.Forms.TabPage tabTQ;
        private System.Windows.Forms.DataGridView dgvTour;
        private System.Windows.Forms.Label lblMa;
        private System.Windows.Forms.TextBox txtMa;
        private System.Windows.Forms.Label lblTen;
        private System.Windows.Forms.TextBox txtTen;
        private System.Windows.Forms.Label lblNgay;
        private System.Windows.Forms.NumericUpDown numNgay;
        private System.Windows.Forms.Label lblDem;
        private System.Windows.Forms.NumericUpDown numDem;
        private System.Windows.Forms.Label lblGia;
        private System.Windows.Forms.NumericUpDown numGia;
        private System.Windows.Forms.Label lblMoTa;
        private System.Windows.Forms.TextBox txtMoTa;
        private System.Windows.Forms.Button btnThemTour;
        private System.Windows.Forms.DataGridView dgvDiemDung;
        private System.Windows.Forms.Label lblThuTu;
        private System.Windows.Forms.NumericUpDown numThuTu;
        private System.Windows.Forms.Label lblDiemDung;
        private System.Windows.Forms.TextBox txtDiemDung;
        private System.Windows.Forms.CheckBox chkDoiPT;
        private System.Windows.Forms.CheckBox chkAn;
        private System.Windows.Forms.CheckBox chkKS;
        private System.Windows.Forms.Label lblSao;
        private System.Windows.Forms.NumericUpDown numSao;
        private System.Windows.Forms.Label lblGhiChuDD;
        private System.Windows.Forms.TextBox txtGhiChuDD;
        private System.Windows.Forms.Button btnThemDD;
        private System.Windows.Forms.DataGridView dgvChang;
        private System.Windows.Forms.Label lblChang;
        private System.Windows.Forms.NumericUpDown numChang;
        private System.Windows.Forms.Label lblPT;
        private System.Windows.Forms.ComboBox cboPT;
        private System.Windows.Forms.Label lblGhiChuPT;
        private System.Windows.Forms.TextBox txtGhiChuPT;
        private System.Windows.Forms.Button btnThemChang;
        private System.Windows.Forms.Label lblGhiChuNho;
        private System.Windows.Forms.DataGridView dgvTQ;
        private System.Windows.Forms.Label lblDTQ;
        private System.Windows.Forms.ComboBox cboDTQ;
        private System.Windows.Forms.Label lblThuTuTQ;
        private System.Windows.Forms.NumericUpDown numThuTuTQ;
        private System.Windows.Forms.Button btnThemTQ;
        private System.Windows.Forms.Button btnDong;
    }
}