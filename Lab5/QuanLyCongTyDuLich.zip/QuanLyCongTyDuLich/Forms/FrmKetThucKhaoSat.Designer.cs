﻿namespace QuanLyCongTyDuLich.Forms
{
    partial class FrmKetThucKhaoSat
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.tabKT = new System.Windows.Forms.TabControl();
            this.tabThanhToan = new System.Windows.Forms.TabPage();
            this.btnThanhToan = new System.Windows.Forms.Button();
            this.txtGhiChu = new System.Windows.Forms.TextBox();
            this.lblGhiChu = new System.Windows.Forms.Label();
            this.numTien = new System.Windows.Forms.NumericUpDown();
            this.lblTien = new System.Windows.Forms.Label();
            this.dtTT = new System.Windows.Forms.DateTimePicker();
            this.lblNgayTT = new System.Windows.Forms.Label();
            this.txtSoDK = new System.Windows.Forms.TextBox();
            this.lblSoDK = new System.Windows.Forms.Label();
            this.txtSoTT = new System.Windows.Forms.TextBox();
            this.lblSoTT = new System.Windows.Forms.Label();
            this.dgvDoan = new System.Windows.Forms.DataGridView();
            this.tabKhaoSat = new System.Windows.Forms.TabPage();
            this.btnGhiPH = new System.Windows.Forms.Button();
            this.txtGopY = new System.Windows.Forms.TextBox();
            this.lblGopY = new System.Windows.Forms.Label();
            this.numDiem = new System.Windows.Forms.NumericUpDown();
            this.lblDiem = new System.Windows.Forms.Label();
            this.dtPH = new System.Windows.Forms.DateTimePicker();
            this.lblNgayPH = new System.Windows.Forms.Label();
            this.txtKSChon = new System.Windows.Forms.TextBox();
            this.lblKSChon = new System.Windows.Forms.Label();
            this.dgvKS = new System.Windows.Forms.DataGridView();
            this.btnGui = new System.Windows.Forms.Button();
            this.dtGui = new System.Windows.Forms.DateTimePicker();
            this.lblNgayGui = new System.Windows.Forms.Label();
            this.txtMaKS = new System.Windows.Forms.TextBox();
            this.lblMaKS = new System.Windows.Forms.Label();
            this.cboDangKy = new System.Windows.Forms.ComboBox();
            this.lblDangKy = new System.Windows.Forms.Label();
            this.cboLoaiKS = new System.Windows.Forms.ComboBox();
            this.lblLoaiKS = new System.Windows.Forms.Label();
            this.btnDong = new System.Windows.Forms.Button();
            this.tabKT.SuspendLayout();
            this.tabThanhToan.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numTien)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDoan)).BeginInit();
            this.tabKhaoSat.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numDiem)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvKS)).BeginInit();
            this.SuspendLayout();
            // 
            // tabKT
            // 
            this.tabKT.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabKT.Controls.Add(this.tabThanhToan);
            this.tabKT.Controls.Add(this.tabKhaoSat);
            this.tabKT.Location = new System.Drawing.Point(20, 15);
            this.tabKT.Name = "tabKT";
            this.tabKT.SelectedIndex = 0;
            this.tabKT.Size = new System.Drawing.Size(950, 530);
            this.tabKT.TabIndex = 0;
            // 
            // tabThanhToan
            // 
            this.tabThanhToan.Controls.Add(this.btnThanhToan);
            this.tabThanhToan.Controls.Add(this.txtGhiChu);
            this.tabThanhToan.Controls.Add(this.lblGhiChu);
            this.tabThanhToan.Controls.Add(this.numTien);
            this.tabThanhToan.Controls.Add(this.lblTien);
            this.tabThanhToan.Controls.Add(this.dtTT);
            this.tabThanhToan.Controls.Add(this.lblNgayTT);
            this.tabThanhToan.Controls.Add(this.txtSoDK);
            this.tabThanhToan.Controls.Add(this.lblSoDK);
            this.tabThanhToan.Controls.Add(this.txtSoTT);
            this.tabThanhToan.Controls.Add(this.lblSoTT);
            this.tabThanhToan.Controls.Add(this.dgvDoan);
            this.tabThanhToan.Location = new System.Drawing.Point(4, 25);
            this.tabThanhToan.Name = "tabThanhToan";
            this.tabThanhToan.Padding = new System.Windows.Forms.Padding(3);
            this.tabThanhToan.Size = new System.Drawing.Size(942, 501);
            this.tabThanhToan.TabIndex = 0;
            this.tabThanhToan.Text = "Thanh toán sau tour (đoàn)";
            this.tabThanhToan.UseVisualStyleBackColor = true;
            // 
            // btnThanhToan
            // 
            this.btnThanhToan.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnThanhToan.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnThanhToan.Location = new System.Drawing.Point(770, 428);
            this.btnThanhToan.Name = "btnThanhToan";
            this.btnThanhToan.Size = new System.Drawing.Size(155, 42);
            this.btnThanhToan.TabIndex = 11;
            this.btnThanhToan.Text = "Ghi nhận thanh toán";
            this.btnThanhToan.UseVisualStyleBackColor = true;
            this.btnThanhToan.Click += new System.EventHandler(this.btnThanhToan_Click);
            // 
            // txtGhiChu
            // 
            this.txtGhiChu.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtGhiChu.Location = new System.Drawing.Point(390, 439);
            this.txtGhiChu.Name = "txtGhiChu";
            this.txtGhiChu.Size = new System.Drawing.Size(360, 22);
            this.txtGhiChu.TabIndex = 10;
            // 
            // lblGhiChu
            // 
            this.lblGhiChu.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblGhiChu.AutoSize = true;
            this.lblGhiChu.Location = new System.Drawing.Point(325, 442);
            this.lblGhiChu.Name = "lblGhiChu";
            this.lblGhiChu.Size = new System.Drawing.Size(61, 17);
            this.lblGhiChu.TabIndex = 9;
            this.lblGhiChu.Text = "Ghi chú:";
            // 
            // numTien
            // 
            this.numTien.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.numTien.Location = new System.Drawing.Point(125, 439);
            this.numTien.Maximum = new decimal(new int[] { 1000000000, 0, 0, 0 });
            this.numTien.Name = "numTien";
            this.numTien.Size = new System.Drawing.Size(180, 22);
            this.numTien.TabIndex = 8;
            this.numTien.ThousandsSeparator = true;
            // 
            // lblTien
            // 
            this.lblTien.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblTien.AutoSize = true;
            this.lblTien.Location = new System.Drawing.Point(15, 442);
            this.lblTien.Name = "lblTien";
            this.lblTien.Size = new System.Drawing.Size(56, 17);
            this.lblTien.TabIndex = 7;
            this.lblTien.Text = "Số tiền:";
            // 
            // dtTT
            // 
            this.dtTT.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.dtTT.CustomFormat = "dd/MM/yyyy";
            this.dtTT.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtTT.Location = new System.Drawing.Point(680, 396);
            this.dtTT.Name = "dtTT";
            this.dtTT.Size = new System.Drawing.Size(140, 22);
            this.dtTT.TabIndex = 6;
            // 
            // lblNgayTT
            // 
            this.lblNgayTT.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.lblNgayTT.AutoSize = true;
            this.lblNgayTT.Location = new System.Drawing.Point(555, 399);
            this.lblNgayTT.Name = "lblNgayTT";
            this.lblNgayTT.Size = new System.Drawing.Size(117, 17);
            this.lblNgayTT.TabIndex = 5;
            this.lblNgayTT.Text = "Ngày thanh toán:";
            // 
            // txtSoDK
            // 
            this.txtSoDK.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.txtSoDK.Location = new System.Drawing.Point(390, 396);
            this.txtSoDK.Name = "txtSoDK";
            this.txtSoDK.ReadOnly = true;
            this.txtSoDK.Size = new System.Drawing.Size(145, 22);
            this.txtSoDK.TabIndex = 4;
            // 
            // lblSoDK
            // 
            this.lblSoDK.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblSoDK.AutoSize = true;
            this.lblSoDK.Location = new System.Drawing.Point(300, 399);
            this.lblSoDK.Name = "lblSoDK";
            this.lblSoDK.Size = new System.Drawing.Size(83, 17);
            this.lblSoDK.TabIndex = 3;
            this.lblSoDK.Text = "Phiếu đoàn:";
            // 
            // txtSoTT
            // 
            this.txtSoTT.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.txtSoTT.Location = new System.Drawing.Point(125, 396);
            this.txtSoTT.Name = "txtSoTT";
            this.txtSoTT.Size = new System.Drawing.Size(150, 22);
            this.txtSoTT.TabIndex = 2;
            // 
            // lblSoTT
            // 
            this.lblSoTT.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblSoTT.AutoSize = true;
            this.lblSoTT.Location = new System.Drawing.Point(15, 399);
            this.lblSoTT.Name = "lblSoTT";
            this.lblSoTT.Size = new System.Drawing.Size(100, 17);
            this.lblSoTT.TabIndex = 1;
            this.lblSoTT.Text = "Số thanh toán:";
            // 
            // dgvDoan
            // 
            this.dgvDoan.AllowUserToAddRows = false;
            this.dgvDoan.AllowUserToDeleteRows = false;
            this.dgvDoan.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvDoan.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvDoan.BackgroundColor = System.Drawing.Color.White;
            this.dgvDoan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDoan.Location = new System.Drawing.Point(15, 15);
            this.dgvDoan.Name = "dgvDoan";
            this.dgvDoan.ReadOnly = true;
            this.dgvDoan.RowHeadersWidth = 51;
            this.dgvDoan.RowTemplate.Height = 24;
            this.dgvDoan.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvDoan.Size = new System.Drawing.Size(910, 360);
            this.dgvDoan.TabIndex = 0;
            this.dgvDoan.SelectionChanged += new System.EventHandler(this.dgvDoan_SelectionChanged);
            // 
            // tabKhaoSat
            // 
            this.tabKhaoSat.Controls.Add(this.btnGhiPH);
            this.tabKhaoSat.Controls.Add(this.txtGopY);
            this.tabKhaoSat.Controls.Add(this.lblGopY);
            this.tabKhaoSat.Controls.Add(this.numDiem);
            this.tabKhaoSat.Controls.Add(this.lblDiem);
            this.tabKhaoSat.Controls.Add(this.dtPH);
            this.tabKhaoSat.Controls.Add(this.lblNgayPH);
            this.tabKhaoSat.Controls.Add(this.txtKSChon);
            this.tabKhaoSat.Controls.Add(this.lblKSChon);
            this.tabKhaoSat.Controls.Add(this.dgvKS);
            this.tabKhaoSat.Controls.Add(this.btnGui);
            this.tabKhaoSat.Controls.Add(this.dtGui);
            this.tabKhaoSat.Controls.Add(this.lblNgayGui);
            this.tabKhaoSat.Controls.Add(this.txtMaKS);
            this.tabKhaoSat.Controls.Add(this.lblMaKS);
            this.tabKhaoSat.Controls.Add(this.cboDangKy);
            this.tabKhaoSat.Controls.Add(this.lblDangKy);
            this.tabKhaoSat.Controls.Add(this.cboLoaiKS);
            this.tabKhaoSat.Controls.Add(this.lblLoaiKS);
            this.tabKhaoSat.Location = new System.Drawing.Point(4, 25);
            this.tabKhaoSat.Name = "tabKhaoSat";
            this.tabKhaoSat.Padding = new System.Windows.Forms.Padding(3);
            this.tabKhaoSat.Size = new System.Drawing.Size(942, 501);
            this.tabKhaoSat.TabIndex = 1;
            this.tabKhaoSat.Text = "Khảo sát khách hàng";
            this.tabKhaoSat.UseVisualStyleBackColor = true;
            // 
            // btnGhiPH
            // 
            this.btnGhiPH.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnGhiPH.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnGhiPH.Location = new System.Drawing.Point(785, 442);
            this.btnGhiPH.Name = "btnGhiPH";
            this.btnGhiPH.Size = new System.Drawing.Size(140, 36);
            this.btnGhiPH.TabIndex = 18;
            this.btnGhiPH.Text = "Ghi nhận góp ý";
            this.btnGhiPH.UseVisualStyleBackColor = true;
            this.btnGhiPH.Click += new System.EventHandler(this.btnGhiPH_Click);
            // 
            // txtGopY
            // 
            this.txtGopY.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtGopY.Location = new System.Drawing.Point(100, 448);
            this.txtGopY.Name = "txtGopY";
            this.txtGopY.Size = new System.Drawing.Size(665, 22);
            this.txtGopY.TabIndex = 17;
            // 
            // lblGopY
            // 
            this.lblGopY.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblGopY.AutoSize = true;
            this.lblGopY.Location = new System.Drawing.Point(15, 451);
            this.lblGopY.Name = "lblGopY";
            this.lblGopY.Size = new System.Drawing.Size(50, 17);
            this.lblGopY.TabIndex = 16;
            this.lblGopY.Text = "Góp ý:";
            // 
            // numDiem
            // 
            this.numDiem.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.numDiem.Location = new System.Drawing.Point(630, 408);
            this.numDiem.Maximum = new decimal(new int[] { 5, 0, 0, 0 });
            this.numDiem.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
            this.numDiem.Name = "numDiem";
            this.numDiem.Size = new System.Drawing.Size(60, 22);
            this.numDiem.TabIndex = 15;
            this.numDiem.Value = new decimal(new int[] { 5, 0, 0, 0 });
            // 
            // lblDiem
            // 
            this.lblDiem.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.lblDiem.AutoSize = true;
            this.lblDiem.Location = new System.Drawing.Point(545, 410);
            this.lblDiem.Name = "lblDiem";
            this.lblDiem.Size = new System.Drawing.Size(76, 17);
            this.lblDiem.TabIndex = 14;
            this.lblDiem.Text = "Điểm (1-5):";
            // 
            // dtPH
            // 
            this.dtPH.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.dtPH.CustomFormat = "dd/MM/yyyy";
            this.dtPH.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtPH.Location = new System.Drawing.Point(365, 407);
            this.dtPH.Name = "dtPH";
            this.dtPH.Size = new System.Drawing.Size(140, 22);
            this.dtPH.TabIndex = 13;
            // 
            // lblNgayPH
            // 
            this.lblNgayPH.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblNgayPH.AutoSize = true;
            this.lblNgayPH.Location = new System.Drawing.Point(255, 410);
            this.lblNgayPH.Name = "lblNgayPH";
            this.lblNgayPH.Size = new System.Drawing.Size(104, 17);
            this.lblNgayPH.TabIndex = 12;
            this.lblNgayPH.Text = "Ngày phản hồi:";
            // 
            // txtKSChon
            // 
            this.txtKSChon.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.txtKSChon.Location = new System.Drawing.Point(100, 407);
            this.txtKSChon.Name = "txtKSChon";
            this.txtKSChon.ReadOnly = true;
            this.txtKSChon.Size = new System.Drawing.Size(130, 22);
            this.txtKSChon.TabIndex = 11;
            // 
            // lblKSChon
            // 
            this.lblKSChon.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblKSChon.AutoSize = true;
            this.lblKSChon.Location = new System.Drawing.Point(15, 410);
            this.lblKSChon.Name = "lblKSChon";
            this.lblKSChon.Size = new System.Drawing.Size(82, 17);
            this.lblKSChon.TabIndex = 10;
            this.lblKSChon.Text = "Phiếu chọn:";
            // 
            // dgvKS
            // 
            this.dgvKS.AllowUserToAddRows = false;
            this.dgvKS.AllowUserToDeleteRows = false;
            this.dgvKS.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvKS.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvKS.BackgroundColor = System.Drawing.Color.White;
            this.dgvKS.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvKS.Location = new System.Drawing.Point(15, 95);
            this.dgvKS.Name = "dgvKS";
            this.dgvKS.ReadOnly = true;
            this.dgvKS.RowHeadersWidth = 51;
            this.dgvKS.RowTemplate.Height = 24;
            this.dgvKS.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvKS.Size = new System.Drawing.Size(910, 295);
            this.dgvKS.TabIndex = 9;
            this.dgvKS.SelectionChanged += new System.EventHandler(this.dgvKS_SelectionChanged);
            // 
            // btnGui
            // 
            this.btnGui.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnGui.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnGui.Location = new System.Drawing.Point(775, 47);
            this.btnGui.Name = "btnGui";
            this.btnGui.Size = new System.Drawing.Size(150, 36);
            this.btnGui.TabIndex = 8;
            this.btnGui.Text = "Gửi phiếu khảo sát";
            this.btnGui.UseVisualStyleBackColor = true;
            this.btnGui.Click += new System.EventHandler(this.btnGui_Click);
            // 
            // dtGui
            // 
            this.dtGui.CustomFormat = "dd/MM/yyyy";
            this.dtGui.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtGui.Location = new System.Drawing.Point(100, 54);
            this.dtGui.Name = "dtGui";
            this.dtGui.Size = new System.Drawing.Size(140, 22);
            this.dtGui.TabIndex = 7;
            // 
            // lblNgayGui
            // 
            this.lblNgayGui.AutoSize = true;
            this.lblNgayGui.Location = new System.Drawing.Point(15, 57);
            this.lblNgayGui.Name = "lblNgayGui";
            this.lblNgayGui.Size = new System.Drawing.Size(68, 17);
            this.lblNgayGui.TabIndex = 6;
            this.lblNgayGui.Text = "Ngày gửi:";
            // 
            // txtMaKS
            // 
            this.txtMaKS.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtMaKS.Location = new System.Drawing.Point(775, 17);
            this.txtMaKS.Name = "txtMaKS";
            this.txtMaKS.Size = new System.Drawing.Size(150, 22);
            this.txtMaKS.TabIndex = 5;
            // 
            // lblMaKS
            // 
            this.lblMaKS.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblMaKS.AutoSize = true;
            this.lblMaKS.Location = new System.Drawing.Point(715, 20);
            this.lblMaKS.Name = "lblMaKS";
            this.lblMaKS.Size = new System.Drawing.Size(54, 17);
            this.lblMaKS.TabIndex = 4;
            this.lblMaKS.Text = "Mã KS:";
            // 
            // cboDangKy
            // 
            this.cboDangKy.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cboDangKy.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboDangKy.FormattingEnabled = true;
            this.cboDangKy.Location = new System.Drawing.Point(365, 17);
            this.cboDangKy.Name = "cboDangKy";
            this.cboDangKy.Size = new System.Drawing.Size(330, 24);
            this.cboDangKy.TabIndex = 3;
            // 
            // lblDangKy
            // 
            this.lblDangKy.AutoSize = true;
            this.lblDangKy.Location = new System.Drawing.Point(220, 20);
            this.lblDangKy.Name = "lblDangKy";
            this.lblDangKy.Size = new System.Drawing.Size(139, 17);
            this.lblDangKy.TabIndex = 2;
            this.lblDangKy.Text = "Đăng ký đã kết thúc:";
            // 
            // cboLoaiKS
            // 
            this.cboLoaiKS.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboLoaiKS.FormattingEnabled = true;
            this.cboLoaiKS.Location = new System.Drawing.Point(100, 17);
            this.cboLoaiKS.Name = "cboLoaiKS";
            this.cboLoaiKS.Size = new System.Drawing.Size(100, 24);
            this.cboLoaiKS.TabIndex = 1;
            this.cboLoaiKS.SelectedIndexChanged += new System.EventHandler(this.cboLoaiKS_SelectedIndexChanged);
            // 
            // lblLoaiKS
            // 
            this.lblLoaiKS.AutoSize = true;
            this.lblLoaiKS.Location = new System.Drawing.Point(15, 20);
            this.lblLoaiKS.Name = "lblLoaiKS";
            this.lblLoaiKS.Size = new System.Drawing.Size(82, 17);
            this.lblLoaiKS.TabIndex = 0;
            this.lblLoaiKS.Text = "Loại khách:";
            // 
            // btnDong
            // 
            this.btnDong.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDong.Location = new System.Drawing.Point(855, 555);
            this.btnDong.Name = "btnDong";
            this.btnDong.Size = new System.Drawing.Size(110, 35);
            this.btnDong.TabIndex = 1;
            this.btnDong.Text = "Đóng";
            this.btnDong.UseVisualStyleBackColor = true;
            this.btnDong.Click += new System.EventHandler(this.btnDong_Click);
            // 
            // FrmKetThucKhaoSat
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(985, 605);
            this.Controls.Add(this.btnDong);
            this.Controls.Add(this.tabKT);
            this.Name = "FrmKetThucKhaoSat";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Kết thúc tour - thanh toán đoàn - khảo sát";
            this.Load += new System.EventHandler(this.FrmKetThucKhaoSat_Load);
            this.tabKT.ResumeLayout(false);
            this.tabThanhToan.ResumeLayout(false);
            this.tabThanhToan.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numTien)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDoan)).EndInit();
            this.tabKhaoSat.ResumeLayout(false);
            this.tabKhaoSat.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numDiem)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvKS)).EndInit();
            this.ResumeLayout(false);
        }

        private System.Windows.Forms.TabControl tabKT;
        private System.Windows.Forms.TabPage tabThanhToan;
        private System.Windows.Forms.TabPage tabKhaoSat;
        private System.Windows.Forms.DataGridView dgvDoan;
        private System.Windows.Forms.Label lblSoTT;
        private System.Windows.Forms.TextBox txtSoTT;
        private System.Windows.Forms.Label lblSoDK;
        private System.Windows.Forms.TextBox txtSoDK;
        private System.Windows.Forms.Label lblNgayTT;
        private System.Windows.Forms.DateTimePicker dtTT;
        private System.Windows.Forms.Label lblTien;
        private System.Windows.Forms.NumericUpDown numTien;
        private System.Windows.Forms.Label lblGhiChu;
        private System.Windows.Forms.TextBox txtGhiChu;
        private System.Windows.Forms.Button btnThanhToan;
        private System.Windows.Forms.Label lblLoaiKS;
        private System.Windows.Forms.ComboBox cboLoaiKS;
        private System.Windows.Forms.Label lblDangKy;
        private System.Windows.Forms.ComboBox cboDangKy;
        private System.Windows.Forms.Label lblMaKS;
        private System.Windows.Forms.TextBox txtMaKS;
        private System.Windows.Forms.Label lblNgayGui;
        private System.Windows.Forms.DateTimePicker dtGui;
        private System.Windows.Forms.Button btnGui;
        private System.Windows.Forms.DataGridView dgvKS;
        private System.Windows.Forms.Label lblKSChon;
        private System.Windows.Forms.TextBox txtKSChon;
        private System.Windows.Forms.Label lblNgayPH;
        private System.Windows.Forms.DateTimePicker dtPH;
        private System.Windows.Forms.Label lblDiem;
        private System.Windows.Forms.NumericUpDown numDiem;
        private System.Windows.Forms.Label lblGopY;
        private System.Windows.Forms.TextBox txtGopY;
        private System.Windows.Forms.Button btnGhiPH;
        private System.Windows.Forms.Button btnDong;
    }
}