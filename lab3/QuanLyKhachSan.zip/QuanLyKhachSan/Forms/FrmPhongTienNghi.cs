﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using QuanLyKhachSan.Data;
using QuanLyKhachSan.Services;

namespace QuanLyKhachSan.Forms
{
    public partial class FrmPhongTienNghi : Form
    {
        private enum CheDoXem
        {
            Phong,
            TienNghi,
            LapDat
        }

        private CheDoXem _cheDoHienTai = CheDoXem.Phong;
        private readonly PhongTienNghiService _ptnService = new PhongTienNghiService();

        public FrmPhongTienNghi()
        {
            InitializeComponent();
        }

        private void FrmPhongTienNghi_Load(object sender, EventArgs e)
        {
            LamMoiPhieuLapDat();
            ChonCheDo(CheDoXem.Phong);
        }

        // Tự động sinh mã phiếu chuẩn: LD001, LD002...
        private void LamMoiPhieuLapDat()
        {
            int soLuong = Convert.ToInt32(Db.Scalar("SELECT COUNT(*) FROM PhieuLapDat"));
            txtMaPhieuLD.Text = string.Format("LD{0:D3}", soLuong + 1);
            txtTinhTrangLD.Text = "Tốt";
        }

        private void ChonCheDo(CheDoXem cheDo)
        {
            _cheDoHienTai = cheDo;
            CapNhatNutNav();
            NapDuLieu();

            txt1.Clear();
            txt2.Clear();
            txt3.Clear();
            txt4.Clear();
        }

        private void CapNhatNutNav()
        {
            Color mauBinhThuong = Color.Black;
            Color mauDangChon = Color.FromArgb(26, 59, 93);
            Font fontBinhThuong = new Font("Segoe UI", 9.5F, FontStyle.Regular);
            Font fontDangChon = new Font("Segoe UI", 9.5F, FontStyle.Bold);

            Button[] dsNut = { btnNavPhong, btnNavTienNghi, btnNavLapDat };
            foreach (var btn in dsNut)
            {
                btn.ForeColor = mauBinhThuong;
                btn.Font = fontBinhThuong;
            }

            switch (_cheDoHienTai)
            {
                case CheDoXem.Phong:
                    btnNavPhong.ForeColor = mauDangChon;
                    btnNavPhong.Font = fontDangChon;
                    lbl1.Text = "Số phòng:";
                    lbl2.Text = "Khu vực:";
                    lbl3.Text = "Số người tối đa:";
                    lbl4.Text = "Đơn giá/ngày:";
                    colPhong.HeaderText = "Phòng";
                    colKhu.HeaderText = "Khu";
                    colSucChua.HeaderText = "Sức chứa";
                    colDonGia.HeaderText = "Đơn giá";
                    colTrangThai.HeaderText = "Trạng thái";
                    break;

                case CheDoXem.TienNghi:
                    btnNavTienNghi.ForeColor = mauDangChon;
                    btnNavTienNghi.Font = fontDangChon;
                    lbl1.Text = "Mã tiện nghi:";
                    lbl2.Text = "Loại tiện nghi:";
                    lbl3.Text = "Số thứ tự:";
                    lbl4.Text = "Trạng thái:";
                    colPhong.HeaderText = "Mã TN";
                    colKhu.HeaderText = "Loại tiện nghi";
                    colSucChua.HeaderText = "Số TT";
                    colDonGia.HeaderText = "Trạng thái";
                    colTrangThai.HeaderText = "Ghi chú";
                    break;

                case CheDoXem.LapDat:
                    btnNavLapDat.ForeColor = mauDangChon;
                    btnNavLapDat.Font = fontDangChon;
                    lbl1.Text = "Mã phiếu:";
                    lbl2.Text = "Số phòng:";
                    lbl3.Text = "Mã tiện nghi:";
                    lbl4.Text = "Tình trạng:";
                    colPhong.HeaderText = "Mã phiếu";
                    colKhu.HeaderText = "Phòng";
                    colSucChua.HeaderText = "Thiết bị";
                    colDonGia.HeaderText = "Ngày lắp";
                    colTrangThai.HeaderText = "Tình trạng";
                    break;
            }
        }

        private void NapDuLieu()
        {
            DataTable dtHienThi = new DataTable();
            dtHienThi.Columns.Add("Phong", typeof(string));
            dtHienThi.Columns.Add("Khu", typeof(string));
            dtHienThi.Columns.Add("SucChua", typeof(string));
            dtHienThi.Columns.Add("DonGia", typeof(string));
            dtHienThi.Columns.Add("TrangThai", typeof(string));

            switch (_cheDoHienTai)
            {
                case CheDoXem.Phong:
                    DataTable dtP = _ptnService.LayDanhSachPhong();
                    foreach (DataRow r in dtP.Rows)
                    {
                        decimal.TryParse(r["DonGiaNgay"]?.ToString(), out decimal gia);
                        dtHienThi.Rows.Add(r["SoPhong"], r["TenKhuVuc"], r["SoNguoiToiDa"], gia > 0 ? gia.ToString("N0") : "0", r["TrangThaiPhong"]);
                    }
                    break;

                case CheDoXem.TienNghi:
                    DataTable dtTN = _ptnService.LayDanhSachTienNghi();
                    foreach (DataRow r in dtTN.Rows)
                    {
                        dtHienThi.Rows.Add(r["MaTienNghi"], r["TenLoaiTienNghi"], r["SoThuTu"], r["TrangThai"], "");
                    }
                    break;

                case CheDoXem.LapDat:
                    DataTable dtLD = _ptnService.LayDanhSachPhieuLapDat();
                    foreach (DataRow r in dtLD.Rows)
                    {
                        DateTime.TryParse(r["NgayLap"]?.ToString(), out DateTime ngay);
                        dtHienThi.Rows.Add(r["MaPhieuLapDat"], r["SoPhong"], r["MaTienNghi"] + " (" + r["TenLoaiTienNghi"] + ")", ngay.ToString("dd/MM/yyyy"), r["TinhTrang"]);
                    }
                    break;
            }

            dgvDanhSach.DataSource = dtHienThi;
        }

        private void btnNavPhong_Click(object sender, EventArgs e) => ChonCheDo(CheDoXem.Phong);
        private void btnNavTienNghi_Click(object sender, EventArgs e) => ChonCheDo(CheDoXem.TienNghi);
        private void btnNavLapDat_Click(object sender, EventArgs e) => ChonCheDo(CheDoXem.LapDat);

        // Click vào dòng trên bảng để tự điền thông tin tương ứng
        private void dgvDanhSach_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                var row = dgvDanhSach.Rows[e.RowIndex];
                txt1.Text = row.Cells["colPhong"].Value?.ToString();
                txt2.Text = row.Cells["colKhu"].Value?.ToString();
                txt3.Text = row.Cells["colSucChua"].Value?.ToString();
                txt4.Text = row.Cells["colDonGia"].Value?.ToString();

                if (_cheDoHienTai == CheDoXem.Phong)
                {
                    // Chọn phòng -> điền vào ô Phòng của phiếu lắp đặt
                    txtPhongLD.Text = txt1.Text;

                    // Nếu ô Tiện nghi chưa có, tự động lấy tiện nghi đầu tiên chưa lắp hôm nay
                    if (string.IsNullOrWhiteSpace(txtMaTNLD.Text))
                    {
                        object tnChuaLap = Db.Scalar(@"SELECT TOP 1 MaTienNghi FROM TienNghi 
                                                      WHERE MaTienNghi NOT IN (SELECT MaTienNghi FROM PhieuLapDat WHERE CAST(NgayLap AS DATE) = CAST(GETDATE() AS DATE))");
                        if (tnChuaLap != null)
                            txtMaTNLD.Text = tnChuaLap.ToString();
                    }
                }
                else if (_cheDoHienTai == CheDoXem.TienNghi)
                {
                    // Chọn tiện nghi -> điền vào ô Tiện nghi của phiếu lắp đặt
                    txtMaTNLD.Text = txt1.Text;
                }
                else if (_cheDoHienTai == CheDoXem.LapDat)
                {
                    txtMaPhieuLD.Text = row.Cells["colPhong"].Value?.ToString();
                    txtPhongLD.Text = row.Cells["colKhu"].Value?.ToString();
                    txtTinhTrangLD.Text = row.Cells["colTrangThai"].Value?.ToString();
                }
            }
        }

        // Thực hiện lập phiếu lắp đặt theo đúng quy tắc BR04
        private void btnLapPhieu_Click(object sender, EventArgs e)
        {
            string maPhieu = txtMaPhieuLD.Text.Trim();
            string soPhong = txtPhongLD.Text.Trim();
            string maTN = txtMaTNLD.Text.Trim();
            string tinhTrang = txtTinhTrangLD.Text.Trim();

            if (string.IsNullOrWhiteSpace(maPhieu) || string.IsNullOrWhiteSpace(soPhong) || string.IsNullOrWhiteSpace(maTN))
            {
                MessageBox.Show("Vui lòng nhấp chọn Phòng và Tiện nghi trước khi lập phiếu.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var (ok, msg) = _ptnService.LapPhieuLapDat(maPhieu, soPhong, maTN, DateTime.Today, tinhTrang);
            MessageBox.Show(msg, ok ? "Thông báo" : "Cảnh báo quy tắc BR04", MessageBoxButtons.OK, ok ? MessageBoxIcon.Information : MessageBoxIcon.Warning);

            if (ok)
            {
                LamMoiPhieuLapDat();
                if (_cheDoHienTai == CheDoXem.LapDat)
                    NapDuLieu();
            }
        }
    }
}