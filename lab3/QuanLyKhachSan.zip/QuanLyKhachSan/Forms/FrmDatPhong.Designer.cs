﻿namespace QuanLyKhachSan.Forms
{
    partial class FrmDatPhong
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.btnNavKhachHang = new System.Windows.Forms.Button();
            this.btnNavDatPhong = new System.Windows.Forms.Button();
            this.btnNavNhanPhong = new System.Windows.Forms.Button();
            this.lblSoPhieu = new System.Windows.Forms.Label();
            this.txtSoPhieu = new System.Windows.Forms.TextBox();
            this.lblKhach = new System.Windows.Forms.Label();
            this.txtKhach = new System.Windows.Forms.TextBox();
            this.lblKenhDat = new System.Windows.Forms.Label();
            this.txtKenhDat = new System.Windows.Forms.TextBox();
            this.lblTienCoc = new System.Windows.Forms.Label();
            this.txtTienCoc = new System.Windows.Forms.TextBox();
            this.dgvPhongTrong = new System.Windows.Forms.DataGridView();
            this.colPhong = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colKhu = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSucChua = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDonGia = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgvPhongChon = new System.Windows.Forms.DataGridView();
            this.colPhongChon = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSoNguoi = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDonGiaNgay = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnLapPhieuDat = new System.Windows.Forms.Button();
            this.lblPhieuDat = new System.Windows.Forms.Label();
            this.dgvPhieuDat = new System.Windows.Forms.DataGridView();
            this.colSoPhieu = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTenKhach = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colNgayNhan = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colNgayTra = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colCoc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colKenh = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTrangThai = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPhongTrong)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPhongChon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPhieuDat)).BeginInit();
            this.SuspendLayout();
            // 
            // btnNavKhachHang
            // 
            this.btnNavKhachHang.AutoSize = true;
            this.btnNavKhachHang.BackColor = System.Drawing.Color.Transparent;
            this.btnNavKhachHang.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNavKhachHang.FlatAppearance.BorderSize = 0;
            this.btnNavKhachHang.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNavKhachHang.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnNavKhachHang.ForeColor = System.Drawing.Color.Black;
            this.btnNavKhachHang.Location = new System.Drawing.Point(20, 15);
            this.btnNavKhachHang.Name = "btnNavKhachHang";
            this.btnNavKhachHang.Size = new System.Drawing.Size(105, 31);
            this.btnNavKhachHang.TabIndex = 0;
            this.btnNavKhachHang.Text = "[Khách hàng]";
            this.btnNavKhachHang.UseVisualStyleBackColor = false;
            this.btnNavKhachHang.Click += new System.EventHandler(this.btnNavKhachHang_Click);
            // 
            // btnNavDatPhong
            // 
            this.btnNavDatPhong.AutoSize = true;
            this.btnNavDatPhong.BackColor = System.Drawing.Color.Transparent;
            this.btnNavDatPhong.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNavDatPhong.FlatAppearance.BorderSize = 0;
            this.btnNavDatPhong.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNavDatPhong.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.btnNavDatPhong.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(59)))), ((int)(((byte)(93)))));
            this.btnNavDatPhong.Location = new System.Drawing.Point(125, 15);
            this.btnNavDatPhong.Name = "btnNavDatPhong";
            this.btnNavDatPhong.Size = new System.Drawing.Size(100, 31);
            this.btnNavDatPhong.TabIndex = 1;
            this.btnNavDatPhong.Text = "[Đặt phòng]";
            this.btnNavDatPhong.UseVisualStyleBackColor = false;
            this.btnNavDatPhong.Click += new System.EventHandler(this.btnNavDatPhong_Click);
            // 
            // btnNavNhanPhong
            // 
            this.btnNavNhanPhong.AutoSize = true;
            this.btnNavNhanPhong.BackColor = System.Drawing.Color.Transparent;
            this.btnNavNhanPhong.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNavNhanPhong.FlatAppearance.BorderSize = 0;
            this.btnNavNhanPhong.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNavNhanPhong.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnNavNhanPhong.ForeColor = System.Drawing.Color.Black;
            this.btnNavNhanPhong.Location = new System.Drawing.Point(225, 15);
            this.btnNavNhanPhong.Name = "btnNavNhanPhong";
            this.btnNavNhanPhong.Size = new System.Drawing.Size(185, 31);
            this.btnNavNhanPhong.TabIndex = 2;
            this.btnNavNhanPhong.Text = "[Nhận phòng / Người lưu trú]";
            this.btnNavNhanPhong.UseVisualStyleBackColor = false;
            this.btnNavNhanPhong.Click += new System.EventHandler(this.btnNavNhanPhong_Click);
            // 
            // lblSoPhieu
            // 
            this.lblSoPhieu.AutoSize = true;
            this.lblSoPhieu.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblSoPhieu.Location = new System.Drawing.Point(24, 60);
            this.lblSoPhieu.Name = "lblSoPhieu";
            this.lblSoPhieu.Size = new System.Drawing.Size(103, 21);
            this.lblSoPhieu.TabIndex = 3;
            this.lblSoPhieu.Text = "Số phiếu đặt:";
            // 
            // txtSoPhieu
            // 
            this.txtSoPhieu.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtSoPhieu.Location = new System.Drawing.Point(135, 57);
            this.txtSoPhieu.Name = "txtSoPhieu";
            this.txtSoPhieu.Size = new System.Drawing.Size(120, 29);
            this.txtSoPhieu.TabIndex = 4;
            this.txtSoPhieu.Text = "DP001";
            // 
            // lblKhach
            // 
            this.lblKhach.AutoSize = true;
            this.lblKhach.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblKhach.Location = new System.Drawing.Point(275, 60);
            this.lblKhach.Name = "lblKhach";
            this.lblKhach.Size = new System.Drawing.Size(56, 21);
            this.lblKhach.TabIndex = 5;
            this.lblKhach.Text = "Khách:";
            // 
            // txtKhach
            // 
            this.txtKhach.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtKhach.Location = new System.Drawing.Point(335, 57);
            this.txtKhach.Name = "txtKhach";
            this.txtKhach.Size = new System.Drawing.Size(185, 29);
            this.txtKhach.TabIndex = 6;
            this.txtKhach.Text = "Nguyễn Văn A";
            // 
            // lblKenhDat
            // 
            this.lblKenhDat.AutoSize = true;
            this.lblKenhDat.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblKenhDat.Location = new System.Drawing.Point(535, 60);
            this.lblKenhDat.Name = "lblKenhDat";
            this.lblKenhDat.Size = new System.Drawing.Size(73, 21);
            this.lblKenhDat.TabIndex = 7;
            this.lblKenhDat.Text = "Kênh đặt:";
            // 
            // txtKenhDat
            // 
            this.txtKenhDat.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtKenhDat.Location = new System.Drawing.Point(615, 57);
            this.txtKenhDat.Name = "txtKenhDat";
            this.txtKenhDat.Size = new System.Drawing.Size(120, 29);
            this.txtKenhDat.TabIndex = 8;
            this.txtKenhDat.Text = "Website";
            // 
            // lblTienCoc
            // 
            this.lblTienCoc.AutoSize = true;
            this.lblTienCoc.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblTienCoc.Location = new System.Drawing.Point(750, 60);
            this.lblTienCoc.Name = "lblTienCoc";
            this.lblTienCoc.Size = new System.Drawing.Size(70, 21);
            this.lblTienCoc.TabIndex = 9;
            this.lblTienCoc.Text = "Tiền cọc:";
            // 
            // txtTienCoc
            // 
            this.txtTienCoc.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtTienCoc.Location = new System.Drawing.Point(825, 57);
            this.txtTienCoc.Name = "txtTienCoc";
            this.txtTienCoc.Size = new System.Drawing.Size(95, 29);
            this.txtTienCoc.TabIndex = 10;
            this.txtTienCoc.Text = "500000";
            // 
            // dgvPhongTrong
            // 
            this.dgvPhongTrong.AllowUserToAddRows = false;
            this.dgvPhongTrong.AllowUserToDeleteRows = false;
            this.dgvPhongTrong.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvPhongTrong.BackgroundColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(235)))), ((int)(((byte)(245)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvPhongTrong.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvPhongTrong.ColumnHeadersHeight = 30;
            this.dgvPhongTrong.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colPhong,
            this.colKhu,
            this.colSucChua,
            this.colDonGia});
            this.dgvPhongTrong.EnableHeadersVisualStyles = false;
            this.dgvPhongTrong.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dgvPhongTrong.Location = new System.Drawing.Point(24, 100);
            this.dgvPhongTrong.MultiSelect = false;
            this.dgvPhongTrong.Name = "dgvPhongTrong";
            this.dgvPhongTrong.ReadOnly = true;
            this.dgvPhongTrong.RowHeadersWidth = 35;
            this.dgvPhongTrong.RowTemplate.Height = 28;
            this.dgvPhongTrong.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvPhongTrong.Size = new System.Drawing.Size(430, 195);
            this.dgvPhongTrong.TabIndex = 11;
            this.dgvPhongTrong.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvPhongTrong_CellDoubleClick);
            // 
            // colPhong
            // 
            this.colPhong.DataPropertyName = "Phong";
            this.colPhong.FillWeight = 85F;
            this.colPhong.HeaderText = "Phòng";
            this.colPhong.MinimumWidth = 6;
            this.colPhong.Name = "colPhong";
            this.colPhong.ReadOnly = true;
            // 
            // colKhu
            // 
            this.colKhu.DataPropertyName = "Khu";
            this.colKhu.FillWeight = 115F;
            this.colKhu.HeaderText = "Khu";
            this.colKhu.MinimumWidth = 6;
            this.colKhu.Name = "colKhu";
            this.colKhu.ReadOnly = true;
            // 
            // colSucChua
            // 
            this.colSucChua.DataPropertyName = "SucChua";
            this.colSucChua.FillWeight = 90F;
            this.colSucChua.HeaderText = "Sức chứa";
            this.colSucChua.MinimumWidth = 6;
            this.colSucChua.Name = "colSucChua";
            this.colSucChua.ReadOnly = true;
            // 
            // colDonGia
            // 
            this.colDonGia.DataPropertyName = "DonGia";
            this.colDonGia.FillWeight = 110F;
            this.colDonGia.HeaderText = "Đơn giá";
            this.colDonGia.MinimumWidth = 6;
            this.colDonGia.Name = "colDonGia";
            this.colDonGia.ReadOnly = true;
            // 
            // dgvPhongChon
            // 
            this.dgvPhongChon.AllowUserToAddRows = false;
            this.dgvPhongChon.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvPhongChon.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvPhongChon.BackgroundColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(235)))), ((int)(((byte)(245)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvPhongChon.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dgvPhongChon.ColumnHeadersHeight = 30;
            this.dgvPhongChon.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colPhongChon,
            this.colSoNguoi,
            this.colDonGiaNgay});
            this.dgvPhongChon.EnableHeadersVisualStyles = false;
            this.dgvPhongChon.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dgvPhongChon.Location = new System.Drawing.Point(480, 100);
            this.dgvPhongChon.MultiSelect = false;
            this.dgvPhongChon.Name = "dgvPhongChon";
            this.dgvPhongChon.RowHeadersWidth = 35;
            this.dgvPhongChon.RowTemplate.Height = 28;
            this.dgvPhongChon.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvPhongChon.Size = new System.Drawing.Size(440, 195);
            this.dgvPhongChon.TabIndex = 12;
            // 
            // colPhongChon
            // 
            this.colPhongChon.DataPropertyName = "PhongChon";
            this.colPhongChon.FillWeight = 110F;
            this.colPhongChon.HeaderText = "Phòng chọn";
            this.colPhongChon.MinimumWidth = 6;
            this.colPhongChon.Name = "colPhongChon";
            this.colPhongChon.ReadOnly = true;
            // 
            // colSoNguoi
            // 
            this.colSoNguoi.DataPropertyName = "SoNguoi";
            this.colSoNguoi.FillWeight = 90F;
            this.colSoNguoi.HeaderText = "Số người";
            this.colSoNguoi.MinimumWidth = 6;
            this.colSoNguoi.Name = "colSoNguoi";
            // 
            // colDonGiaNgay
            // 
            this.colDonGiaNgay.DataPropertyName = "DonGiaNgay";
            this.colDonGiaNgay.FillWeight = 120F;
            this.colDonGiaNgay.HeaderText = "Đơn giá/ngày";
            this.colDonGiaNgay.MinimumWidth = 6;
            this.colDonGiaNgay.Name = "colDonGiaNgay";
            this.colDonGiaNgay.ReadOnly = true;
            // 
            // btnLapPhieuDat
            // 
            this.btnLapPhieuDat.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnLapPhieuDat.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnLapPhieuDat.Location = new System.Drawing.Point(740, 305);
            this.btnLapPhieuDat.Name = "btnLapPhieuDat";
            this.btnLapPhieuDat.Size = new System.Drawing.Size(180, 36);
            this.btnLapPhieuDat.TabIndex = 13;
            this.btnLapPhieuDat.Text = "Lập phiếu đặt";
            this.btnLapPhieuDat.UseVisualStyleBackColor = true;
            this.btnLapPhieuDat.Click += new System.EventHandler(this.btnLapPhieuDat_Click);
            // 
            // lblPhieuDat
            // 
            this.lblPhieuDat.AutoSize = true;
            this.lblPhieuDat.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblPhieuDat.Location = new System.Drawing.Point(24, 320);
            this.lblPhieuDat.Name = "lblPhieuDat";
            this.lblPhieuDat.Size = new System.Drawing.Size(126, 21);
            this.lblPhieuDat.TabIndex = 14;
            this.lblPhieuDat.Text = "Phiếu đặt phòng:";
            // 
            // dgvPhieuDat
            // 
            this.dgvPhieuDat.AllowUserToAddRows = false;
            this.dgvPhieuDat.AllowUserToDeleteRows = false;
            this.dgvPhieuDat.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvPhieuDat.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvPhieuDat.BackgroundColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(235)))), ((int)(((byte)(245)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvPhieuDat.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgvPhieuDat.ColumnHeadersHeight = 30;
            this.dgvPhieuDat.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colSoPhieu,
            this.colTenKhach,
            this.colNgayNhan,
            this.colNgayTra,
            this.colCoc,
            this.colKenh,
            this.colTrangThai});
            this.dgvPhieuDat.EnableHeadersVisualStyles = false;
            this.dgvPhieuDat.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dgvPhieuDat.Location = new System.Drawing.Point(24, 348);
            this.dgvPhieuDat.MultiSelect = false;
            this.dgvPhieuDat.Name = "dgvPhieuDat";
            this.dgvPhieuDat.ReadOnly = true;
            this.dgvPhieuDat.RowHeadersWidth = 35;
            this.dgvPhieuDat.RowTemplate.Height = 28;
            this.dgvPhieuDat.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvPhieuDat.Size = new System.Drawing.Size(896, 175);
            this.dgvPhieuDat.TabIndex = 15;
            this.dgvPhieuDat.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvPhieuDat_CellClick);
            // 
            // colSoPhieu
            // 
            this.colSoPhieu.DataPropertyName = "SoPhieu";
            this.colSoPhieu.FillWeight = 85F;
            this.colSoPhieu.HeaderText = "Số phiếu";
            this.colSoPhieu.MinimumWidth = 6;
            this.colSoPhieu.Name = "colSoPhieu";
            this.colSoPhieu.ReadOnly = true;
            // 
            // colTenKhach
            // 
            this.colTenKhach.DataPropertyName = "Khach";
            this.colTenKhach.FillWeight = 120F;
            this.colTenKhach.HeaderText = "Khách";
            this.colTenKhach.MinimumWidth = 6;
            this.colTenKhach.Name = "colTenKhach";
            this.colTenKhach.ReadOnly = true;
            // 
            // colNgayNhan
            // 
            this.colNgayNhan.DataPropertyName = "NgayNhan";
            this.colNgayNhan.FillWeight = 95F;
            this.colNgayNhan.HeaderText = "Ngày nhận";
            this.colNgayNhan.MinimumWidth = 6;
            this.colNgayNhan.Name = "colNgayNhan";
            this.colNgayNhan.ReadOnly = true;
            // 
            // colNgayTra
            // 
            this.colNgayTra.DataPropertyName = "NgayTraDuKien";
            this.colNgayTra.FillWeight = 110F;
            this.colNgayTra.HeaderText = "Ngày trả dự kiến";
            this.colNgayTra.MinimumWidth = 6;
            this.colNgayTra.Name = "colNgayTra";
            this.colNgayTra.ReadOnly = true;
            // 
            // colCoc
            // 
            this.colCoc.DataPropertyName = "Coc";
            this.colCoc.FillWeight = 80F;
            this.colCoc.HeaderText = "Cọc";
            this.colCoc.MinimumWidth = 6;
            this.colCoc.Name = "colCoc";
            this.colCoc.ReadOnly = true;
            // 
            // colKenh
            // 
            this.colKenh.DataPropertyName = "Kenh";
            this.colKenh.FillWeight = 85F;
            this.colKenh.HeaderText = "Kênh";
            this.colKenh.MinimumWidth = 6;
            this.colKenh.Name = "colKenh";
            this.colKenh.ReadOnly = true;
            // 
            // colTrangThai
            // 
            this.colTrangThai.DataPropertyName = "TrangThai";
            this.colTrangThai.FillWeight = 95F;
            this.colTrangThai.HeaderText = "Trạng thái";
            this.colTrangThai.MinimumWidth = 6;
            this.colTrangThai.Name = "colTrangThai";
            this.colTrangThai.ReadOnly = true;
            // 
            // FrmDatPhong
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(247)))), ((int)(((byte)(250)))));
            this.ClientSize = new System.Drawing.Size(945, 540);
            this.Controls.Add(this.dgvPhieuDat);
            this.Controls.Add(this.lblPhieuDat);
            this.Controls.Add(this.btnLapPhieuDat);
            this.Controls.Add(this.dgvPhongChon);
            this.Controls.Add(this.dgvPhongTrong);
            this.Controls.Add(this.txtTienCoc);
            this.Controls.Add(this.lblTienCoc);
            this.Controls.Add(this.txtKenhDat);
            this.Controls.Add(this.lblKenhDat);
            this.Controls.Add(this.txtKhach);
            this.Controls.Add(this.lblKhach);
            this.Controls.Add(this.txtSoPhieu);
            this.Controls.Add(this.lblSoPhieu);
            this.Controls.Add(this.btnNavNhanPhong);
            this.Controls.Add(this.btnNavDatPhong);
            this.Controls.Add(this.btnNavKhachHang);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "FrmDatPhong";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Khách hàng - Đặt phòng - Nhận phòng";
            this.Load += new System.EventHandler(this.FrmDatPhong_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvPhongTrong)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPhongChon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPhieuDat)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Button btnNavKhachHang;
        private System.Windows.Forms.Button btnNavDatPhong;
        private System.Windows.Forms.Button btnNavNhanPhong;
        private System.Windows.Forms.Label lblSoPhieu;
        private System.Windows.Forms.TextBox txtSoPhieu;
        private System.Windows.Forms.Label lblKhach;
        private System.Windows.Forms.TextBox txtKhach;
        private System.Windows.Forms.Label lblKenhDat;
        private System.Windows.Forms.TextBox txtKenhDat;
        private System.Windows.Forms.Label lblTienCoc;
        private System.Windows.Forms.TextBox txtTienCoc;
        private System.Windows.Forms.DataGridView dgvPhongTrong;
        private System.Windows.Forms.DataGridViewTextBoxColumn colPhong;
        private System.Windows.Forms.DataGridViewTextBoxColumn colKhu;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSucChua;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDonGia;
        private System.Windows.Forms.DataGridView dgvPhongChon;
        private System.Windows.Forms.DataGridViewTextBoxColumn colPhongChon;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSoNguoi;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDonGiaNgay;
        private System.Windows.Forms.Button btnLapPhieuDat;
        private System.Windows.Forms.Label lblPhieuDat;
        private System.Windows.Forms.DataGridView dgvPhieuDat;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSoPhieu;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTenKhach;
        private System.Windows.Forms.DataGridViewTextBoxColumn colNgayNhan;
        private System.Windows.Forms.DataGridViewTextBoxColumn colNgayTra;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCoc;
        private System.Windows.Forms.DataGridViewTextBoxColumn colKenh;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTrangThai;
    }
}