﻿using System;
using System.Data;
using System.Windows.Forms;
using QuanLyKhachSan.Services;

namespace QuanLyKhachSan.Forms
{
    public partial class FrmTraPhong : Form
    {
        private readonly TraPhongService _tpService = new TraPhongService();
        private string _maTienNghiDangChon = "";

        public FrmTraPhong()
        {
            InitializeComponent();
        }

        private void FrmTraPhong_Load(object sender, EventArgs e)
        {
            // Thiết lập giá trị mẫu đúng chuẩn theo hình minh họa của thầy
            txtPhieuDangO.Text = "DP001";
            txtSoPhieuDenBu.Text = "DB001";
            txtMucDo.Text = "Hư hỏng nhẹ";
            txtSoTienDenBu.Text = "500000";
            txtSoHoaDon.Text = "HD001";
            txtSoNgayTinhTien.Text = "2";
            txtHinhThuc.Text = "Thẻ";
            txtSoTienThanhToan.Text = "1200000";

            NapTatCaDuLieu();
        }

        private void txtPhieuDangO_TextChanged(object sender, EventArgs e)
        {
            NapTatCaDuLieu();
        }

        private void NapTatCaDuLieu()
        {
            string maPhieu = txtPhieuDangO.Text.Trim();

            // 1. Nạp bảng phòng
            DataTable dtP = _tpService.LayThongTinPhong(maPhieu);
            DataTable dtHienThiP = new DataTable();
            dtHienThiP.Columns.Add("Phong", typeof(string));
            dtHienThiP.Columns.Add("DonGia", typeof(string));

            foreach (DataRow r in dtP.Rows)
            {
                decimal.TryParse(r["DonGia"]?.ToString(), out decimal gia);
                dtHienThiP.Rows.Add(r["Phong"], gia > 0 ? gia.ToString("N0") : "");
            }
            dgvPhong.DataSource = dtHienThiP;

            // 2. Nạp bảng tiện nghi kiểm tra
            DataTable dtTN = _tpService.LayTienNghiTrongPhong(maPhieu);
            dgvTienNghi.DataSource = dtTN;

            // 3. Nạp bảng đền bù
            DataTable dtDB = _tpService.LayDanhSachDenBu(maPhieu);
            DataTable dtHienThiDB = new DataTable();
            dtHienThiDB.Columns.Add("TienNghiDenBu", typeof(string));
            dtHienThiDB.Columns.Add("MucDo", typeof(string));
            dtHienThiDB.Columns.Add("SoTien", typeof(string));

            foreach (DataRow r in dtDB.Rows)
            {
                decimal.TryParse(r["SoTien"]?.ToString(), out decimal tien);
                dtHienThiDB.Rows.Add(r["TienNghiDenBu"], r["MucDo"], tien > 0 ? tien.ToString("N0") : "");
            }
            dgvDenBu.DataSource = dtHienThiDB;

            // 4. Nạp bảng hóa đơn
            NapDanhSachHoaDon();
        }

        private void NapDanhSachHoaDon()
        {
            string maPhieu = txtPhieuDangO.Text.Trim();
            DataTable dtHD = _tpService.LayDanhSachHoaDon(maPhieu);
            DataTable dtHienThiHD = new DataTable();
            dtHienThiHD.Columns.Add("HoaDon", typeof(string));
            dtHienThiHD.Columns.Add("PhieuDat", typeof(string));
            dtHienThiHD.Columns.Add("TienPhong", typeof(string));
            dtHienThiHD.Columns.Add("TienDichVu", typeof(string));
            dtHienThiHD.Columns.Add("TongTien", typeof(string));
            dtHienThiHD.Columns.Add("TrangThai", typeof(string));

            foreach (DataRow r in dtHD.Rows)
            {
                decimal.TryParse(r["TienPhong"]?.ToString(), out decimal tienP);
                decimal.TryParse(r["TienDichVu"]?.ToString(), out decimal tienDV);
                decimal.TryParse(r["TongTien"]?.ToString(), out decimal tong);

                dtHienThiHD.Rows.Add(
                    r["MaHoaDon"],
                    r["MaPhieuDat"],
                    tienP > 0 ? tienP.ToString("N0") : "0",
                    tienDV > 0 ? tienDV.ToString("N0") : "0",
                    tong > 0 ? tong.ToString("N0") : "0",
                    r["TrangThai"]
                );
            }
            dgvHoaDon.DataSource = dtHienThiHD;
        }

        private void dgvTienNghi_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                var row = dgvTienNghi.Rows[e.RowIndex];
                _maTienNghiDangChon = row.Cells["colTN_TienNghi"].Value?.ToString();
            }
        }

        private void dgvHoaDon_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                var row = dgvHoaDon.Rows[e.RowIndex];
                txtSoHoaDon.Text = row.Cells["colHD_HoaDon"].Value?.ToString();
                txtSoTienThanhToan.Text = row.Cells["colHD_TongTien"].Value?.ToString()?.Replace(",", "");
            }
        }

        // Lập phiếu đền bù (BR08)
        private void btnLapPhieuDenBu_Click(object sender, EventArgs e)
        {
            string maDB = txtSoPhieuDenBu.Text.Trim();
            string maPhieu = txtPhieuDangO.Text.Trim();
            string mucDo = txtMucDo.Text.Trim();
            decimal.TryParse(txtSoTienDenBu.Text.Replace(",", "").Trim(), out decimal soTien);

            var (ok, msg) = _tpService.LapPhieuDenBu(maDB, maPhieu, _maTienNghiDangChon, mucDo, soTien);
            MessageBox.Show(msg, ok ? "Thông báo" : "Lỗi đền bù", MessageBoxButtons.OK, ok ? MessageBoxIcon.Information : MessageBoxIcon.Warning);

            if (ok)
            {
                NapTatCaDuLieu();
                txtSoPhieuDenBu.Text = "DB" + DateTime.Now.ToString("mmss");
            }
        }

        // Lập hóa đơn tính tiền (BR09)
        private void btnLapHoaDon_Click(object sender, EventArgs e)
        {
            string maHD = txtSoHoaDon.Text.Trim();
            string maPhieu = txtPhieuDangO.Text.Trim();
            int.TryParse(txtSoNgayTinhTien.Text.Trim(), out int soNgay);

            var (ok, msg) = _tpService.LapHoaDon(maHD, maPhieu, soNgay > 0 ? soNgay : 1);
            MessageBox.Show(msg, ok ? "Thông báo" : "Lỗi lập hóa đơn", MessageBoxButtons.OK, ok ? MessageBoxIcon.Information : MessageBoxIcon.Warning);

            if (ok)
            {
                NapDanhSachHoaDon();
            }
        }

        // Ghi nhận thanh toán (BR10)
        private void btnThanhToan_Click(object sender, EventArgs e)
        {
            string maHD = txtSoHoaDon.Text.Trim();
            string hinhThuc = txtHinhThuc.Text.Trim();
            decimal.TryParse(txtSoTienThanhToan.Text.Replace(",", "").Trim(), out decimal soTien);

            var (ok, msg) = _tpService.ThanhToan(maHD, hinhThuc, soTien);
            MessageBox.Show(msg, ok ? "Thông báo" : "Lỗi thanh toán", MessageBoxButtons.OK, ok ? MessageBoxIcon.Information : MessageBoxIcon.Warning);

            if (ok)
            {
                NapDanhSachHoaDon();
            }
        }

        // Hoàn tất trả phòng
        private void btnHoanTatTraPhong_Click(object sender, EventArgs e)
        {
            string maPhieu = txtPhieuDangO.Text.Trim();
            var (ok, msg) = _tpService.HoanTatTraPhong(maPhieu);
            MessageBox.Show(msg, ok ? "Thông báo" : "Lỗi trả phòng", MessageBoxButtons.OK, ok ? MessageBoxIcon.Information : MessageBoxIcon.Warning);

            if (ok)
            {
                NapTatCaDuLieu();
            }
        }
    }
}