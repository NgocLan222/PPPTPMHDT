﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using QuanLyKhachSan.Data;
using QuanLyKhachSan.Services;

namespace QuanLyKhachSan.Forms
{
    public partial class FrmDatPhong : Form
    {
        private enum CheDoXem
        {
            KhachHang,
            DatPhong,
            NhanPhong
        }

        private CheDoXem _cheDoHienTai = CheDoXem.DatPhong;
        private readonly DatPhongService _datPhongService = new DatPhongService();
        private DataTable _dtPhongChon = new DataTable();

        public FrmDatPhong()
        {
            InitializeComponent();
        }

        private void FrmDatPhong_Load(object sender, EventArgs e)
        {
            KhoiTaoBangPhongChon();
            ChonCheDo(CheDoXem.DatPhong);
        }

        private void KhoiTaoBangPhongChon()
        {
            _dtPhongChon = new DataTable();
            _dtPhongChon.Columns.Add("PhongChon", typeof(string));
            _dtPhongChon.Columns.Add("SoNguoi", typeof(int));
            _dtPhongChon.Columns.Add("DonGiaNgay", typeof(string));
            dgvPhongChon.DataSource = _dtPhongChon;
        }

        private void ChonCheDo(CheDoXem cheDo)
        {
            _cheDoHienTai = cheDo;
            CapNhatNutNav();
            NapDuLieu();
        }

        private void CapNhatNutNav()
        {
            Color mauBinhThuong = Color.Black;
            Color mauDangChon = Color.FromArgb(26, 59, 93);
            Font fontBinhThuong = new Font("Segoe UI", 9.5F, FontStyle.Regular);
            Font fontDangChon = new Font("Segoe UI", 9.5F, FontStyle.Bold);

            btnNavKhachHang.ForeColor = mauBinhThuong;
            btnNavKhachHang.Font = fontBinhThuong;
            btnNavDatPhong.ForeColor = mauBinhThuong;
            btnNavDatPhong.Font = fontBinhThuong;
            btnNavNhanPhong.ForeColor = mauBinhThuong;
            btnNavNhanPhong.Font = fontBinhThuong;

            switch (_cheDoHienTai)
            {
                case CheDoXem.KhachHang:
                    btnNavKhachHang.ForeColor = mauDangChon;
                    btnNavKhachHang.Font = fontDangChon;
                    btnLapPhieuDat.Text = "Lưu khách hàng";
                    break;
                case CheDoXem.DatPhong:
                    btnNavDatPhong.ForeColor = mauDangChon;
                    btnNavDatPhong.Font = fontDangChon;
                    btnLapPhieuDat.Text = "Lập phiếu đặt";
                    break;
                case CheDoXem.NhanPhong:
                    btnNavNhanPhong.ForeColor = mauDangChon;
                    btnNavNhanPhong.Font = fontDangChon;
                    btnLapPhieuDat.Text = "Nhận phòng";
                    break;
            }
        }

        private void NapDuLieu()
        {
            // Nạp danh sách phòng trống bên trái
            DataTable dtPhong = _datPhongService.LayDanhSachPhongKhaDung();
            DataTable dtHienThiPhong = new DataTable();
            dtHienThiPhong.Columns.Add("Phong", typeof(string));
            dtHienThiPhong.Columns.Add("Khu", typeof(string));
            dtHienThiPhong.Columns.Add("SucChua", typeof(string));
            dtHienThiPhong.Columns.Add("DonGia", typeof(string));

            foreach (DataRow r in dtPhong.Rows)
            {
                decimal.TryParse(r["DonGia"]?.ToString(), out decimal gia);
                dtHienThiPhong.Rows.Add(r["Phong"], r["Khu"], r["SucChua"], gia > 0 ? gia.ToString("N0") : "");
            }
            dgvPhongTrong.DataSource = dtHienThiPhong;

            // Nạp danh sách phiếu đặt phòng bên dưới
            DataTable dtPhieu = _datPhongService.LayDanhSachPhieuDat();
            DataTable dtHienThiPhieu = new DataTable();
            dtHienThiPhieu.Columns.Add("SoPhieu", typeof(string));
            dtHienThiPhieu.Columns.Add("Khach", typeof(string));
            dtHienThiPhieu.Columns.Add("NgayNhan", typeof(string));
            dtHienThiPhieu.Columns.Add("NgayTraDuKien", typeof(string));
            dtHienThiPhieu.Columns.Add("Coc", typeof(string));
            dtHienThiPhieu.Columns.Add("Kenh", typeof(string));
            dtHienThiPhieu.Columns.Add("TrangThai", typeof(string));

            foreach (DataRow r in dtPhieu.Rows)
            {
                DateTime.TryParse(r["NgayNhan"]?.ToString(), out DateTime nhan);
                DateTime.TryParse(r["NgayTraDuKien"]?.ToString(), out DateTime tra);
                decimal.TryParse(r["Coc"]?.ToString(), out decimal coc);

                dtHienThiPhieu.Rows.Add(r["SoPhieu"], r["Khach"], nhan.ToString("dd/MM/yyyy"), tra.ToString("dd/MM/yyyy"),
                    coc > 0 ? coc.ToString("N0") : "0", r["Kenh"], r["TrangThai"]);
            }
            dgvPhieuDat.DataSource = dtHienThiPhieu;
        }

        private void btnNavKhachHang_Click(object sender, EventArgs e) => ChonCheDo(CheDoXem.KhachHang);
        private void btnNavDatPhong_Click(object sender, EventArgs e) => ChonCheDo(CheDoXem.DatPhong);
        private void btnNavNhanPhong_Click(object sender, EventArgs e) => ChonCheDo(CheDoXem.NhanPhong);

        // Nhấp đúp vào phòng ở bảng bên trái để đưa sang bảng chọn bên phải
        private void dgvPhongTrong_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                var row = dgvPhongTrong.Rows[e.RowIndex];
                string phong = row.Cells["colPhong"].Value?.ToString();
                string gia = row.Cells["colDonGia"].Value?.ToString();

                // Kiểm tra xem phòng đã được chọn chưa
                foreach (DataRow r in _dtPhongChon.Rows)
                {
                    if (r["PhongChon"]?.ToString() == phong)
                    {
                        MessageBox.Show("Phòng này đã được chọn trong danh sách đặt.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }
                }

                _dtPhongChon.Rows.Add(phong, 2, gia);
            }
        }

        // Nhấp vào phiếu ở bảng dưới để xem thông tin
        private void dgvPhieuDat_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                var row = dgvPhieuDat.Rows[e.RowIndex];
                txtSoPhieu.Text = row.Cells["colSoPhieu"].Value?.ToString();
                txtKhach.Text = row.Cells["colTenKhach"].Value?.ToString();
                txtKenhDat.Text = row.Cells["colKenh"].Value?.ToString();
                txtTienCoc.Text = row.Cells["colCoc"].Value?.ToString()?.Replace(",", "");
            }
        }

        // Xử lý nút Lập phiếu đặt / Nhận phòng
        private void btnLapPhieuDat_Click(object sender, EventArgs e)
        {
            if (_cheDoHienTai == CheDoXem.NhanPhong)
            {
                string soPhieu = txtSoPhieu.Text.Trim();
                if (string.IsNullOrWhiteSpace(soPhieu))
                {
                    MessageBox.Show("Vui lòng chọn phiếu đặt cần nhận phòng.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                var (ok, msg) = _datPhongService.NhanPhong(soPhieu);
                MessageBox.Show(msg, ok ? "Thông báo" : "Lỗi", MessageBoxButtons.OK, ok ? MessageBoxIcon.Information : MessageBoxIcon.Warning);
                if (ok) NapDuLieu();
                return;
            }

            // Nghiệp vụ Lập phiếu đặt phòng
            string maPhieu = txtSoPhieu.Text.Trim();
            string tenKhach = txtKhach.Text.Trim();
            string kenhDat = txtKenhDat.Text.Trim();
            decimal.TryParse(txtTienCoc.Text.Replace(",", "").Trim(), out decimal tienCoc);

            if (_dtPhongChon.Rows.Count == 0)
            {
                MessageBox.Show("Vui lòng nhấp đúp chọn ít nhất một phòng từ bảng danh sách bên trái.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            List<(string SoPhong, int SoNguoi, decimal DonGia)> dsPhong = new List<(string, int, decimal)>();
            foreach (DataRow r in _dtPhongChon.Rows)
            {
                string p = r["PhongChon"].ToString();
                int.TryParse(r["SoNguoi"]?.ToString(), out int soNguoi);
                decimal.TryParse(r["DonGiaNgay"]?.ToString()?.Replace(",", ""), out decimal gia);
                dsPhong.Add((p, soNguoi > 0 ? soNguoi : 1, gia));
            }

            DateTime ngayNhan = DateTime.Today;
            DateTime ngayTra = DateTime.Today.AddDays(1);

            var (thanhCong, thongBao) = _datPhongService.LapPhieuDat(maPhieu, tenKhach, kenhDat, tienCoc, ngayNhan, ngayTra, dsPhong);
            MessageBox.Show(thongBao, thanhCong ? "Thông báo" : "Lỗi nghiệp vụ đặt phòng", MessageBoxButtons.OK, thanhCong ? MessageBoxIcon.Information : MessageBoxIcon.Warning);

            if (thanhCong)
            {
                _dtPhongChon.Clear();
                NapDuLieu();
                txtSoPhieu.Text = "DP" + DateTime.Now.ToString("mmss");
            }
        }
    }
}