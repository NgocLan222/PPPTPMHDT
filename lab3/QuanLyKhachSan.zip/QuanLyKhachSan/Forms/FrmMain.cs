﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace QuanLyKhachSan.Forms
{
    public partial class FrmMain : Form
    {
        public FrmMain()
        {
            InitializeComponent();
        }

        private void FrmMain_Load(object sender, EventArgs e)
        {
            // Tự động gắn Icon sắc nét chuẩn theo hình chụp của thầy
            btnDanhMuc.Image = TaoIconDanhMuc();
            btnPhong.Image = TaoIconPhong();
            btnDatPhong.Image = TaoIconDatPhong();
            btnDichVu.Image = TaoIconDichVu();
            btnTraPhong.Image = TaoIconTraPhong();
            btnThongKe.Image = TaoIconThongKe();
            btnThoat.Image = TaoIconThoat();
        }

        #region Các sự kiện mở Form
        private void btnDanhMuc_Click(object sender, EventArgs e)
        {
            new FrmDanhMuc().ShowDialog();
        }

        private void btnPhong_Click(object sender, EventArgs e)
        {
            new FrmPhongTienNghi().ShowDialog();
        }

        private void btnDatPhong_Click(object sender, EventArgs e)
        {
            new FrmDatPhong().ShowDialog();
        }

        private void btnDichVu_Click(object sender, EventArgs e)
        {
            new FrmDichVu().ShowDialog();
        }

        private void btnTraPhong_Click(object sender, EventArgs e)
        {
            new FrmTraPhong().ShowDialog();
        }

        private void btnThongKe_Click(object sender, EventArgs e)
        {
            new FrmThongKe().ShowDialog();
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Bạn có thực sự muốn thoát khỏi hệ thống?", "Xác nhận",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }
        #endregion

        #region Vẽ Icon Đồ Họa Theo Mẫu Của Thầy
        // 1. Icon Kẹp hồ sơ (Danh mục)
        private Image TaoIconDanhMuc()
        {
            var bmp = new Bitmap(38, 38);
            using (var g = Graphics.FromImage(bmp))
            {
                g.SmoothingMode = SmoothingMode.AntiAlias;
                // Bìa kẹp xanh
                using (var brush = new SolidBrush(Color.FromArgb(52, 120, 190)))
                    g.FillRectangle(brush, 6, 8, 26, 28);
                // Giấy trắng
                g.FillRectangle(Brushes.White, 9, 12, 20, 22);
                // Kẹp kim loại xanh đậm trên đầu
                using (var brush = new SolidBrush(Color.FromArgb(30, 80, 140)))
                    g.FillRectangle(brush, 13, 5, 12, 6);
                // Các dòng danh mục
                using (var pen = new Pen(Color.FromArgb(52, 120, 190), 2))
                {
                    g.DrawLine(pen, 14, 17, 25, 17);
                    g.DrawLine(pen, 14, 22, 25, 22);
                    g.DrawLine(pen, 14, 27, 23, 27);
                }
                // Dấu chấm đầu dòng
                using (var dotBrush = new SolidBrush(Color.FromArgb(230, 126, 34)))
                {
                    g.FillEllipse(dotBrush, 11, 16, 2, 2);
                    g.FillEllipse(dotBrush, 11, 21, 2, 2);
                    g.FillEllipse(dotBrush, 11, 26, 2, 2);
                }
            }
            return bmp;
        }

        // 2. Icon Giường ngủ (Phòng - Tiện nghi)
        private Image TaoIconPhong()
        {
            var bmp = new Bitmap(42, 38);
            using (var g = Graphics.FromImage(bmp))
            {
                g.SmoothingMode = SmoothingMode.AntiAlias;
                // Thành giường gỗ nâu
                using (var wood = new SolidBrush(Color.FromArgb(150, 75, 20)))
                {
                    g.FillRectangle(wood, 3, 10, 5, 24); // Thành đầu giường
                    g.FillRectangle(wood, 35, 18, 4, 16); // Thành chân giường
                    g.FillRectangle(wood, 3, 26, 36, 4);  // Khung đỡ
                }
                // Nệm và chăn màu xanh dương
                using (var bed = new SolidBrush(Color.FromArgb(0, 130, 220)))
                    g.FillRectangle(bed, 14, 18, 22, 10);
                // Gối nằm
                using (var pillow = new SolidBrush(Color.FromArgb(220, 240, 255)))
                    g.FillRectangle(pillow, 9, 16, 6, 8);
            }
            return bmp;
        }

        // 3. Icon Chìa khóa vàng (Đặt / Nhận phòng)
        private Image TaoIconDatPhong()
        {
            var bmp = new Bitmap(38, 38);
            using (var g = Graphics.FromImage(bmp))
            {
                g.SmoothingMode = SmoothingMode.AntiAlias;
                using (var pen = new Pen(Color.FromArgb(235, 160, 20), 4))
                {
                    // Tay cầm chìa khóa
                    g.DrawEllipse(pen, 18, 6, 14, 14);
                    // Thân chìa
                    g.DrawLine(pen, 20, 18, 7, 31);
                    // Răng chìa
                    g.DrawLine(pen, 7, 31, 11, 33);
                    g.DrawLine(pen, 11, 27, 14, 29);
                }
                // Lỗ tròn giữa tay cầm
                g.FillEllipse(Brushes.White, 23, 11, 4, 4);
            }
            return bmp;
        }

        // 4. Icon Bánh răng (Sử dụng dịch vụ)
        private Image TaoIconDichVu()
        {
            var bmp = new Bitmap(38, 38);
            using (var g = Graphics.FromImage(bmp))
            {
                g.SmoothingMode = SmoothingMode.AntiAlias;
                using (var brush = new SolidBrush(Color.FromArgb(100, 115, 135)))
                {
                    // Thân ngoài bánh răng
                    g.FillEllipse(brush, 7, 7, 24, 24);
                    // 4 cạnh chữ thập
                    g.FillRectangle(brush, 16, 3, 6, 32);
                    g.FillRectangle(brush, 3, 16, 32, 6);
                }
                // Trục rỗng ở tâm
                g.FillEllipse(Brushes.White, 14, 14, 10, 10);
            }
            return bmp;
        }

        // 5. Icon Bàn tay đỡ tiền (Trả phòng - Thanh toán)
        private Image TaoIconTraPhong()
        {
            var bmp = new Bitmap(42, 38);
            using (var g = Graphics.FromImage(bmp))
            {
                g.SmoothingMode = SmoothingMode.AntiAlias;
                // Tờ tiền xanh lá
                using (var money = new SolidBrush(Color.FromArgb(39, 174, 96)))
                    g.FillRectangle(money, 8, 8, 26, 15);
                // Dấu $
                using (var font = new Font("Segoe UI", 9F, FontStyle.Bold))
                    g.DrawString("$", font, Brushes.White, 16, 8);
                // Bàn tay vàng đỡ phía dưới
                using (var hand = new SolidBrush(Color.FromArgb(245, 180, 50)))
                {
                    g.FillRectangle(hand, 3, 24, 16, 6);
                    g.FillRectangle(hand, 16, 26, 18, 5);
                }
            }
            return bmp;
        }

        // 6. Icon Biểu đồ cột (Thống kê)
        private Image TaoIconThongKe()
        {
            var bmp = new Bitmap(38, 38);
            using (var g = Graphics.FromImage(bmp))
            {
                g.SmoothingMode = SmoothingMode.AntiAlias;
                // Cột xanh dương thấp
                using (var b1 = new SolidBrush(Color.FromArgb(41, 128, 185)))
                    g.FillRectangle(b1, 6, 24, 6, 10);
                // Cột cam vừa
                using (var b2 = new SolidBrush(Color.FromArgb(243, 156, 18)))
                    g.FillRectangle(b2, 16, 16, 6, 18);
                // Cột xanh lá cao
                using (var b3 = new SolidBrush(Color.FromArgb(39, 174, 96)))
                    g.FillRectangle(b3, 26, 7, 6, 27);
            }
            return bmp;
        }

        // 7. Icon Cửa & Mũi tên (Thoát)
        private Image TaoIconThoat()
        {
            var bmp = new Bitmap(38, 38);
            using (var g = Graphics.FromImage(bmp))
            {
                g.SmoothingMode = SmoothingMode.AntiAlias;
                // Cửa gỗ nâu
                using (var door = new SolidBrush(Color.FromArgb(160, 90, 45)))
                    g.FillRectangle(door, 6, 6, 16, 26);
                // Tay nắm cửa
                g.FillEllipse(Brushes.Gold, 18, 18, 3, 3);
                // Mũi tên xanh lá chỉ ra ngoài
                using (var arrow = new SolidBrush(Color.FromArgb(46, 204, 113)))
                {
                    Point[] pts = {
                        new Point(18, 15),
                        new Point(26, 15),
                        new Point(26, 11),
                        new Point(34, 19),
                        new Point(26, 27),
                        new Point(26, 23),
                        new Point(18, 23)
                    };
                    g.FillPolygon(arrow, pts);
                }
            }
            return bmp;
        }
        #endregion
    }
}