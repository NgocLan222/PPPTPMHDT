﻿using System;
using System.Data;
using System.Windows.Forms;
using QuanLyKhachSan.Services;

namespace QuanLyKhachSan.Forms
{
    public partial class FrmThongKe : Form
    {
        private readonly ThongKeService _tkService = new ThongKeService();

        public FrmThongKe()
        {
            InitializeComponent();
        }

        private void FrmThongKe_Load(object sender, EventArgs e)
        {
            // Mặc định lấy từ đầu tháng hiện tại đến ngày hiện tại
            DateTime homNay = DateTime.Today;
            dtpTuNgay.Value = new DateTime(homNay.Year, homNay.Month, 1);
            dtpDenNgay.Value = homNay;

            ThucHienThongKe();
        }

        private void btnThongKe_Click(object sender, EventArgs e)
        {
            ThucHienThongKe();
        }

        private void ThucHienThongKe()
        {
            DateTime tuNgay = dtpTuNgay.Value;
            DateTime denNgay = dtpDenNgay.Value;

            if (tuNgay.Date > denNgay.Date)
            {
                MessageBox.Show("Từ ngày không được lớn hơn Đến ngày.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Lấy trực tiếp dữ liệu từ Database SQL
            var (phieuDat, dangO, hoaDon, doanhThuHD, tongDenBu) = _tkService.LayTongHopSoLieu(tuNgay, denNgay);

            // Hiển thị số liệu thật (nếu chưa có giao dịch nào thì hiển thị 0)
            lblPhieuDat.Text = $"Phiếu đặt: {phieuDat}";
            lblDangO.Text = $"Đang ở: {dangO}";
            lblHoaDon.Text = $"Hóa đơn: {hoaDon}";
            lblDoanhThuHD.Text = $"Doanh thu HĐ: {doanhThuHD:N0} đ";
            lblTongDenBu.Text = $"Tổng đền bù: {tongDenBu:N0} đ";

            // Nạp bảng chi tiết dịch vụ sử dụng
            DataTable dtDV = _tkService.LayThongKeDichVu(tuNgay, denNgay);
            DataTable dtHienThi = new DataTable();
            dtHienThi.Columns.Add("MaDV", typeof(string));
            dtHienThi.Columns.Add("TenDichVu", typeof(string));
            dtHienThi.Columns.Add("TongSoLuong", typeof(string));
            dtHienThi.Columns.Add("TongTien", typeof(string));

            foreach (DataRow r in dtDV.Rows)
            {
                decimal.TryParse(r["TongTien"]?.ToString(), out decimal tien);
                dtHienThi.Rows.Add(
                    r["MaDV"],
                    r["TenDichVu"],
                    r["TongSoLuong"],
                    tien > 0 ? tien.ToString("N0") : "0"
                );
            }

            dgvDichVu.DataSource = dtHienThi;
        }
    }
}