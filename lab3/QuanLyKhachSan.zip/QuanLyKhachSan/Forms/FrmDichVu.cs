﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Windows.Forms;
using QuanLyKhachSan.Data;
using QuanLyKhachSan.Services;

namespace QuanLyKhachSan.Forms
{
    public partial class FrmDichVu : Form
    {
        private readonly DichVuService _dvService = new DichVuService();

        public FrmDichVu()
        {
            InitializeComponent();
        }

        private void FrmDichVu_Load(object sender, EventArgs e)
        {
            // Thiết lập giá trị thực tế theo ngày hiện tại
            txtNgaySuDung.Text = DateTime.Today.ToString("dd/MM/yyyy");
            txtSoLuong.Text = "1";
            txtDichVu.Clear();

            // Tự động tìm phiếu đang ở gần nhất trong CSDL để hỗ trợ lễ tân
            object phieuDangO = Db.Scalar("SELECT TOP 1 MaPhieuDat FROM PhieuDatPhong WHERE TrangThai = N'Đang ở' ORDER BY NgayDat DESC");
            if (phieuDangO != null)
            {
                txtPhieuLuuTru.Text = phieuDangO.ToString();
                txtPhong.Text = _dvService.LayPhongTheoPhieuDat(phieuDangO.ToString());
            }
            else
            {
                txtPhieuLuuTru.Clear();
                txtPhong.Clear();
            }

            NapDanhSachSuDung();
        }

        private void NapDanhSachSuDung()
        {
            DataTable dt = _dvService.LayDanhSachSuDungDichVu();
            DataTable dtHienThi = new DataTable();
            dtHienThi.Columns.Add("SoPhieu", typeof(string));
            dtHienThi.Columns.Add("Phong", typeof(string));
            dtHienThi.Columns.Add("Ngay", typeof(string));
            dtHienThi.Columns.Add("DichVu", typeof(string));
            dtHienThi.Columns.Add("SoLuong", typeof(string));
            dtHienThi.Columns.Add("DonGia", typeof(string));
            dtHienThi.Columns.Add("ThanhTien", typeof(string));

            foreach (DataRow r in dt.Rows)
            {
                DateTime.TryParse(r["Ngay"]?.ToString(), out DateTime ngay);
                decimal.TryParse(r["DonGia"]?.ToString(), out decimal donGia);
                decimal.TryParse(r["ThanhTien"]?.ToString(), out decimal thanhTien);

                dtHienThi.Rows.Add(
                    r["SoPhieu"],
                    r["Phong"],
                    ngay.ToString("dd/MM/yyyy"),
                    r["DichVu"],
                    r["SoLuong"],
                    donGia > 0 ? donGia.ToString("N0") : "0",
                    thanhTien > 0 ? thanhTien.ToString("N0") : "0"
                );
            }

            dgvDichVu.DataSource = dtHienThi;
        }

        // Tự động tìm phòng tương ứng khi gõ mã phiếu lưu trú
        private void txtPhieuLuuTru_TextChanged(object sender, EventArgs e)
        {
            string p = _dvService.LayPhongTheoPhieuDat(txtPhieuLuuTru.Text.Trim());
            if (!string.IsNullOrEmpty(p))
            {
                txtPhong.Text = p;
            }
        }

        // Nhấp chuột vào dòng trên bảng để lấy lại thông tin
        private void dgvDichVu_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                var row = dgvDichVu.Rows[e.RowIndex];
                txtPhieuLuuTru.Text = row.Cells["colSoPhieu"].Value?.ToString();
                txtPhong.Text = row.Cells["colPhong"].Value?.ToString();
                txtNgaySuDung.Text = row.Cells["colNgay"].Value?.ToString();
                txtDichVu.Text = row.Cells["colDichVu"].Value?.ToString();
                txtSoLuong.Text = row.Cells["colSoLuong"].Value?.ToString();
            }
        }

        // Thực hiện ghi nhận và tự động cộng dồn nếu cùng ngày (BR07)
        private void btnGhiNhan_Click(object sender, EventArgs e)
        {
            string maPhieu = txtPhieuLuuTru.Text.Trim();
            string phong = txtPhong.Text.Trim();
            string tenDV = txtDichVu.Text.Trim();

            if (string.IsNullOrWhiteSpace(maPhieu))
            {
                MessageBox.Show("Vui lòng nhập hoặc chọn Phiếu lưu trú.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (string.IsNullOrWhiteSpace(tenDV))
            {
                MessageBox.Show("Vui lòng nhập tên dịch vụ đã sử dụng.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!int.TryParse(txtSoLuong.Text.Trim(), out int soLuong) || soLuong <= 0)
            {
                MessageBox.Show("Số lượng sử dụng phải là số nguyên dương lớn hơn 0.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DateTime ngayDung;
            string[] formats = { "dd/MM/yyyy", "d/M/yyyy", "yyyy-MM-dd" };
            if (!DateTime.TryParseExact(txtNgaySuDung.Text.Trim(), formats, CultureInfo.InvariantCulture, DateTimeStyles.None, out ngayDung))
            {
                ngayDung = DateTime.Today;
            }

            var (ok, msg) = _dvService.GhiNhanDichVu(maPhieu, phong, tenDV, soLuong, ngayDung);
            MessageBox.Show(msg, ok ? "Thông báo" : "Lỗi ghi nhận", MessageBoxButtons.OK, ok ? MessageBoxIcon.Information : MessageBoxIcon.Warning);

            if (ok)
            {
                NapDanhSachSuDung();
                txtDichVu.Clear();
                txtSoLuong.Text = "1";
            }
        }
    }
}