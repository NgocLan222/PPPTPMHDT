﻿using System;
using System.Data;
using System.Globalization;
using System.Windows.Forms;
using QuanLyKhachSan.Services;

namespace QuanLyKhachSan.Forms
{
    public partial class FrmDichVu : Form
    {
        private readonly DichVuService _dvService = new DichVuService();

        public FrmDichVu()
        {
            InitializeComponent();
        }

        private void FrmDichVu_Load(object sender, EventArgs e)
        {
            // Điền dữ liệu mẫu ban đầu đúng như hình của thầy
            txtPhieuLuuTru.Text = "DP001";
            txtPhong.Text = "A101";
            txtDichVu.Text = "Ăn sáng";
            txtNgaySuDung.Text = "12/09/2026";
            txtSoLuong.Text = "2";

            NapDanhSachSuDung();
        }

        private void NapDanhSachSuDung()
        {
            DataTable dt = _dvService.LayDanhSachSuDungDichVu();
            DataTable dtHienThi = new DataTable();
            dtHienThi.Columns.Add("SoPhieu", typeof(string));
            dtHienThi.Columns.Add("Phong", typeof(string));
            dtHienThi.Columns.Add("Ngay", typeof(string));
            dtHienThi.Columns.Add("DichVu", typeof(string));
            dtHienThi.Columns.Add("SoLuong", typeof(string));
            dtHienThi.Columns.Add("DonGia", typeof(string));
            dtHienThi.Columns.Add("ThanhTien", typeof(string));

            foreach (DataRow r in dt.Rows)
            {
                DateTime.TryParse(r["Ngay"]?.ToString(), out DateTime ngay);
                decimal.TryParse(r["DonGia"]?.ToString(), out decimal donGia);
                decimal.TryParse(r["ThanhTien"]?.ToString(), out decimal thanhTien);

                dtHienThi.Rows.Add(
                    r["SoPhieu"],
                    r["Phong"],
                    ngay.ToString("dd/MM/yyyy"),
                    r["DichVu"],
                    r["SoLuong"],
                    donGia > 0 ? donGia.ToString("N0") : "0",
                    thanhTien > 0 ? thanhTien.ToString("N0") : "0"
                );
            }

            dgvDichVu.DataSource = dtHienThi;
        }

        // Tự động tìm số phòng khi người dùng nhập/sửa số phiếu lưu trú
        private void txtPhieuLuuTru_TextChanged(object sender, EventArgs e)
        {
            string p = _dvService.LayPhongTheoPhieuDat(txtPhieuLuuTru.Text.Trim());
            if (!string.IsNullOrEmpty(p))
            {
                txtPhong.Text = p;
            }
        }

        private void dgvDichVu_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                var row = dgvDichVu.Rows[e.RowIndex];
                txtPhieuLuuTru.Text = row.Cells["colSoPhieu"].Value?.ToString();
                txtPhong.Text = row.Cells["colPhong"].Value?.ToString();
                txtNgaySuDung.Text = row.Cells["colNgay"].Value?.ToString();
                txtDichVu.Text = row.Cells["colDichVu"].Value?.ToString();
                txtSoLuong.Text = row.Cells["colSoLuong"].Value?.ToString();
            }
        }

        // Thực hiện ghi nhận và kiểm tra quy tắc cộng dồn BR07
        private void btnGhiNhan_Click(object sender, EventArgs e)
        {
            string maPhieu = txtPhieuLuuTru.Text.Trim();
            string phong = txtPhong.Text.Trim();
            string tenDV = txtDichVu.Text.Trim();

            if (!int.TryParse(txtSoLuong.Text.Trim(), out int soLuong) || soLuong <= 0)
            {
                MessageBox.Show("Số lượng sử dụng phải là số nguyên dương lớn hơn 0.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DateTime ngayDung;
            string[] formats = { "dd/MM/yyyy", "d/M/yyyy", "yyyy-MM-dd" };
            if (!DateTime.TryParseExact(txtNgaySuDung.Text.Trim(), formats, CultureInfo.InvariantCulture, DateTimeStyles.None, out ngayDung))
            {
                ngayDung = DateTime.Today;
            }

            var (ok, msg) = _dvService.GhiNhanDichVu(maPhieu, phong, tenDV, soLuong, ngayDung);
            MessageBox.Show(msg, ok ? "Thông báo" : "Lỗi ghi nhận", MessageBoxButtons.OK, ok ? MessageBoxIcon.Information : MessageBoxIcon.Warning);

            if (ok)
            {
                NapDanhSachSuDung();
            }
        }
    }
}