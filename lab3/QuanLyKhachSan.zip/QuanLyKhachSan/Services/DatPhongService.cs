﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using QuanLyKhachSan.Data;

namespace QuanLyKhachSan.Services
{
    public class DatPhongService
    {
        public DatPhongService()
        {
            // Tự động bổ sung cột KenhDat vào bảng PhieuDatPhong nếu chưa có
            try
            {
                Db.Execute(@"IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('PhieuDatPhong') AND name = 'KenhDat')
                             ALTER TABLE PhieuDatPhong ADD KenhDat NVARCHAR(50) DEFAULT N'Website';");
            }
            catch { }
        }

        // 1. Lấy danh sách phòng khả dụng cho bảng bên trái
        public DataTable LayDanhSachPhongKhaDung()
        {
            string sql = @"SELECT p.SoPhong AS Phong, kv.TenKhuVuc AS Khu, p.SoNguoiToiDa AS SucChua, p.DonGiaNgay AS DonGia 
                           FROM Phong p 
                           JOIN KhuVuc kv ON p.MaKhuVuc = kv.MaKhuVuc 
                           WHERE p.TrangThaiPhong <> N'Đang ở'
                           ORDER BY p.SoPhong";
            return Db.Query(sql);
        }

        // 2. Lấy danh sách phiếu đặt phòng cho bảng bên dưới
        public DataTable LayDanhSachPhieuDat()
        {
            string sql = @"SELECT pd.MaPhieuDat AS SoPhieu, kh.HoTen AS Khach, 
                                  pd.NgayNhan, pd.NgayTraDuKien, pd.TienCoc AS Coc, 
                                  ISNULL(pd.KenhDat, N'Trực tiếp') AS Kenh, pd.TrangThai
                           FROM PhieuDatPhong pd 
                           JOIN KhachHang kh ON pd.MaKhach = kh.MaKhach 
                           ORDER BY pd.NgayDat DESC";
            return Db.Query(sql);
        }

        // 3. Nghiệp vụ Lập phiếu đặt phòng (BR02, BR05)
        public (bool Ok, string Msg) LapPhieuDat(string maPhieu, string tenKhach, string kenhDat, decimal tienCoc,
                                                DateTime ngayNhan, DateTime ngayTra,
                                                List<(string SoPhong, int SoNguoi, decimal DonGia)> dsPhongChon)
        {
            if (string.IsNullOrWhiteSpace(maPhieu) || string.IsNullOrWhiteSpace(tenKhach))
                return (false, "Vui lòng nhập đầy đủ Số phiếu đặt và Tên khách hàng.");

            if (dsPhongChon == null || dsPhongChon.Count == 0)
                return (false, "Vui lòng chọn ít nhất một phòng từ bảng bên trái.");

            // Kiểm tra mã phiếu đã tồn tại chưa
            int daCoPhieu = Convert.ToInt32(Db.Scalar("SELECT COUNT(*) FROM PhieuDatPhong WHERE MaPhieuDat = @ma", new SqlParameter("@ma", maPhieu.Trim())));
            if (daCoPhieu > 0)
                return (false, "Mã phiếu đặt phòng này đã tồn tại.");

            // Kiểm tra khách hàng, nếu chưa có thì tự động tạo khách mới
            object khObj = Db.Scalar("SELECT TOP 1 MaKhach FROM KhachHang WHERE HoTen = @ten", new SqlParameter("@ten", tenKhach.Trim()));
            string maKhach = khObj != null ? khObj.ToString() : null;
            if (string.IsNullOrEmpty(maKhach))
            {
                maKhach = "KH" + DateTime.Now.ToString("yyMMddHHmmss");
                Db.Execute("INSERT INTO KhachHang (MaKhach, HoTen, SoDienThoai) VALUES (@ma, @ten, '')",
                    new SqlParameter("@ma", maKhach), new SqlParameter("@ten", tenKhach.Trim()));
            }

            // Ghi nhận đặt phòng
            foreach (var item in dsPhongChon)
            {
                // BR02: Kiểm tra sức chứa tối đa
                int sucChua = Convert.ToInt32(Db.Scalar("SELECT SoNguoiToiDa FROM Phong WHERE SoPhong = @p", new SqlParameter("@p", item.SoPhong)));
                if (item.SoNguoi > sucChua)
                    return (false, $"Phòng {item.SoPhong} chỉ chứa tối đa {sucChua} người (Bạn đang chọn {item.SoNguoi} người - Vi phạm BR02).");

                // BR05: Kiểm tra trùng lịch đặt
                string sqlCheckLich = @"SELECT COUNT(*) FROM PhieuDatPhong 
                                       WHERE SoPhong = @p 
                                         AND TrangThai IN (N'Đã đặt', N'Đang ở')
                                         AND NOT (NgayTraDuKien <= @nhan OR NgayNhan >= @tra)";
                int trung = Convert.ToInt32(Db.Scalar(sqlCheckLich,
                    new SqlParameter("@p", item.SoPhong),
                    new SqlParameter("@nhan", ngayNhan),
                    new SqlParameter("@tra", ngayTra)));

                if (trung > 0)
                    return (false, $"Phòng {item.SoPhong} đã có khách đặt hoặc đang ở trong khoảng thời gian này.");

                // Thêm vào PhieuDatPhong
                string sqlInsert = @"INSERT INTO PhieuDatPhong (MaPhieuDat, SoPhong, MaKhach, NgayDat, NgayNhan, NgayTraDuKien, TienCoc, KenhDat, TrangThai)
                                     VALUES (@ma, @p, @kh, GETDATE(), @nhan, @tra, @coc, @kenh, N'Đã đặt')";
                Db.Execute(sqlInsert,
                    new SqlParameter("@ma", maPhieu.Trim()),
                    new SqlParameter("@p", item.SoPhong),
                    new SqlParameter("@kh", maKhach),
                    new SqlParameter("@nhan", ngayNhan),
                    new SqlParameter("@tra", ngayTra),
                    new SqlParameter("@coc", tienCoc),
                    new SqlParameter("@kenh", string.IsNullOrWhiteSpace(kenhDat) ? "Website" : kenhDat.Trim()));

                // Cập nhật trạng thái phòng
                Db.Execute("UPDATE Phong SET TrangThaiPhong = N'Đã đặt' WHERE SoPhong = @p", new SqlParameter("@p", item.SoPhong));
            }

            return (true, "Lập phiếu đặt phòng thành công.");
        }

        // 4. Nhận phòng
        public (bool Ok, string Msg) NhanPhong(string maPhieu)
        {
            string sqlPhong = "SELECT SoPhong FROM PhieuDatPhong WHERE MaPhieuDat = @ma";
            object pObj = Db.Scalar(sqlPhong, new SqlParameter("@ma", maPhieu));
            if (pObj == null)
                return (false, "Không tìm thấy phiếu đặt phòng.");

            Db.Execute("UPDATE PhieuDatPhong SET TrangThai = N'Đang ở' WHERE MaPhieuDat = @ma", new SqlParameter("@ma", maPhieu));
            Db.Execute("UPDATE Phong SET TrangThaiPhong = N'Đang ở' WHERE SoPhong = @p", new SqlParameter("@p", pObj.ToString()));
            return (true, "Xác nhận nhận phòng thành công.");
        }
    }
}