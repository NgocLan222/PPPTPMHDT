﻿using System;
using System.Data;
using System.Data.SqlClient;
using QuanLyKhachSan.Data;

namespace QuanLyKhachSan.Services
{
    public class TraPhongService
    {
        // 1. Lấy thông tin phòng của phiếu đặt đang ở
        public DataTable LayThongTinPhong(string maPhieu)
        {
            string sql = @"SELECT pd.SoPhong AS Phong, p.DonGiaNgay AS DonGia
                           FROM PhieuDatPhong pd
                           JOIN Phong p ON pd.SoPhong = p.SoPhong
                           WHERE pd.MaPhieuDat = @ma";
            return Db.Query(sql, new SqlParameter("@ma", maPhieu.Trim()));
        }

        // 2. Lấy danh sách tiện nghi lắp đặt trong phòng để kiểm tra
        public DataTable LayTienNghiTrongPhong(string maPhieu)
        {
            string sql = @"SELECT tn.MaTienNghi AS TienNghi, ltn.TenLoaiTienNghi AS Loai, pld.TinhTrang
                           FROM PhieuDatPhong pd
                           JOIN PhieuLapDat pld ON pd.SoPhong = pld.SoPhong
                           JOIN TienNghi tn ON pld.MaTienNghi = tn.MaTienNghi
                           JOIN LoaiTienNghi ltn ON tn.MaLoaiTienNghi = ltn.MaLoaiTienNghi
                           WHERE pd.MaPhieuDat = @ma";
            return Db.Query(sql, new SqlParameter("@ma", maPhieu.Trim()));
        }

        // 3. Lấy danh sách tiện nghi đền bù của phiếu
        public DataTable LayDanhSachDenBu(string maPhieu)
        {
            string sql = @"SELECT db.MaTienNghi AS TienNghiDenBu, db.MucDoHuHong AS MucDo, db.GiaDenBu AS SoTien
                           FROM PhieuDenBu db
                           WHERE db.MaPhieuDat = @ma";
            return Db.Query(sql, new SqlParameter("@ma", maPhieu.Trim()));
        }

        // 4. Lập phiếu đền bù hư hỏng (BR08)
        public (bool Ok, string Msg) LapPhieuDenBu(string maDB, string maPhieu, string maTN, string mucDo, decimal soTien)
        {
            if (string.IsNullOrWhiteSpace(maDB) || string.IsNullOrWhiteSpace(maPhieu))
                return (false, "Vui lòng nhập đầy đủ Số phiếu đền bù và Phiếu đang ở.");

            int daCo = Convert.ToInt32(Db.Scalar("SELECT COUNT(*) FROM PhieuDenBu WHERE MaPhieuDenBu = @ma", new SqlParameter("@ma", maDB.Trim())));
            if (daCo > 0)
                return (false, "Mã phiếu đền bù này đã tồn tại.");

            // Nếu maTN để trống, lấy tiện nghi đầu tiên của phòng
            if (string.IsNullOrWhiteSpace(maTN))
            {
                object tnObj = Db.Scalar(@"SELECT TOP 1 pld.MaTienNghi 
                                           FROM PhieuLapDat pld 
                                           JOIN PhieuDatPhong pd ON pld.SoPhong = pd.SoPhong 
                                           WHERE pd.MaPhieuDat = @ma", new SqlParameter("@ma", maPhieu.Trim()));
                maTN = tnObj != null ? tnObj.ToString() : "TN001";
            }

            string sql = @"INSERT INTO PhieuDenBu (MaPhieuDenBu, MaPhieuDat, MaTienNghi, MucDoHuHong, GiaDenBu, LyDo, NgayLap)
                           VALUES (@ma, @phieu, @tn, @mucdo, @tien, N'Hư hỏng khi trả phòng', GETDATE())";
            Db.Execute(sql,
                new SqlParameter("@ma", maDB.Trim()),
                new SqlParameter("@phieu", maPhieu.Trim()),
                new SqlParameter("@tn", maTN),
                new SqlParameter("@mucdo", string.IsNullOrWhiteSpace(mucDo) ? "Hư hỏng nhẹ" : mucDo.Trim()),
                new SqlParameter("@tien", soTien));

            return (true, "Lập phiếu đền bù thành công.");
        }

        // 5. Lấy danh sách hóa đơn hiển thị lên DataGridView
        public DataTable LayDanhSachHoaDon(string maPhieu)
        {
            string sql = @"SELECT hd.MaHoaDon, 
                                  hd.MaPhieuDat, 
                                  (SELECT ISNULL(p.DonGiaNgay, 0) * 2 FROM PhieuDatPhong pd2 JOIN Phong p ON pd2.SoPhong = p.SoPhong WHERE pd2.MaPhieuDat = hd.MaPhieuDat) AS TienPhong,
                                  ISNULL((SELECT SUM(ThanhTien) FROM ChiTietSuDungDichVu WHERE MaPhieuDat = hd.MaPhieuDat), 0) AS TienDichVu,
                                  hd.TongTien, 
                                  hd.TrangThai
                           FROM HoaDon hd
                           WHERE hd.MaPhieuDat = @ma OR @ma = ''
                           ORDER BY hd.NgayLap DESC";
            return Db.Query(sql, new SqlParameter("@ma", maPhieu.Trim()));
        }

        // 6. Lập hóa đơn tính tiền phòng + dịch vụ + đền bù - cọc (BR09)
        public (bool Ok, string Msg) LapHoaDon(string maHD, string maPhieu, int soNgayO)
        {
            if (string.IsNullOrWhiteSpace(maHD) || string.IsNullOrWhiteSpace(maPhieu))
                return (false, "Vui lòng nhập Số hóa đơn và chọn Phiếu đang ở.");

            int daCo = Convert.ToInt32(Db.Scalar("SELECT COUNT(*) FROM HoaDon WHERE MaHoaDon = @ma", new SqlParameter("@ma", maHD.Trim())));
            if (daCo > 0)
                return (false, "Mã hóa đơn này đã tồn tại.");

            // Tính tiền phòng
            decimal donGiaPhong = Convert.ToDecimal(Db.Scalar(
                "SELECT ISNULL(p.DonGiaNgay, 500000) FROM PhieuDatPhong pd JOIN Phong p ON pd.SoPhong = p.SoPhong WHERE pd.MaPhieuDat = @ma",
                new SqlParameter("@ma", maPhieu.Trim())));
            decimal tienPhong = (soNgayO > 0 ? soNgayO : 1) * donGiaPhong;

            // Tiền dịch vụ
            decimal tienDV = Convert.ToDecimal(Db.Scalar(
                "SELECT ISNULL(SUM(ThanhTien), 0) FROM ChiTietSuDungDichVu WHERE MaPhieuDat = @ma",
                new SqlParameter("@ma", maPhieu.Trim())));

            // Tiền đền bù
            decimal tienDB = Convert.ToDecimal(Db.Scalar(
                "SELECT ISNULL(SUM(GiaDenBu), 0) FROM PhieuDenBu WHERE MaPhieuDat = @ma",
                new SqlParameter("@ma", maPhieu.Trim())));

            // Tiền cọc đã nộp
            decimal tienCoc = Convert.ToDecimal(Db.Scalar(
                "SELECT ISNULL(TienCoc, 0) FROM PhieuDatPhong WHERE MaPhieuDat = @ma",
                new SqlParameter("@ma", maPhieu.Trim())));

            decimal tongTien = (tienPhong + tienDV + tienDB) - tienCoc;
            if (tongTien < 0) tongTien = 0;

            string sqlInsert = @"INSERT INTO HoaDon (MaHoaDon, MaPhieuDat, NgayLap, TongTien, TrangThai)
                                 VALUES (@ma, @phieu, GETDATE(), @tong, N'Chưa thanh toán')";
            Db.Execute(sqlInsert,
                new SqlParameter("@ma", maHD.Trim()),
                new SqlParameter("@phieu", maPhieu.Trim()),
                new SqlParameter("@tong", tongTien));

            return (true, $"Lập hóa đơn thành công! Tổng tiền cần thanh toán: {tongTien:N0} đ (Đã trừ cọc).");
        }

        // 7. Ghi nhận giao dịch thanh toán đa phương thức (BR10)
        public (bool Ok, string Msg) ThanhToan(string maHD, string hinhThuc, decimal soTien)
        {
            if (string.IsNullOrWhiteSpace(maHD))
                return (false, "Vui lòng chọn hoặc nhập Mã hóa đơn cần thanh toán.");
            if (soTien <= 0)
                return (false, "Số tiền thanh toán phải lớn hơn 0.");

            int daCoHD = Convert.ToInt32(Db.Scalar("SELECT COUNT(*) FROM HoaDon WHERE MaHoaDon = @ma", new SqlParameter("@ma", maHD.Trim())));
            if (daCoHD == 0)
                return (false, "Mã hóa đơn không tồn tại.");

            // Lưu giao dịch thanh toán
            string sqlTT = @"INSERT INTO ThanhToan (MaHoaDon, NgayThanhToan, PhuongThuc, SoTien)
                             VALUES (@ma, GETDATE(), @pt, @tien)";
            Db.Execute(sqlTT,
                new SqlParameter("@ma", maHD.Trim()),
                new SqlParameter("@pt", string.IsNullOrWhiteSpace(hinhThuc) ? "Thẻ" : hinhThuc.Trim()),
                new SqlParameter("@tien", soTien));

            // Cập nhật trạng thái Hóa đơn
            Db.Execute("UPDATE HoaDon SET TrangThai = N'Đã thanh toán' WHERE MaHoaDon = @ma", new SqlParameter("@ma", maHD.Trim()));

            return (true, "Ghi nhận thanh toán thành công.");
        }

        // 8. Hoàn tất trả phòng và giải phóng trạng thái phòng
        public (bool Ok, string Msg) HoanTatTraPhong(string maPhieu)
        {
            if (string.IsNullOrWhiteSpace(maPhieu))
                return (false, "Vui lòng nhập Phiếu đang ở để hoàn tất thủ tục trả phòng.");

            object pObj = Db.Scalar("SELECT SoPhong FROM PhieuDatPhong WHERE MaPhieuDat = @ma", new SqlParameter("@ma", maPhieu.Trim()));
            if (pObj == null)
                return (false, "Không tìm thấy phiếu đặt phòng.");

            string soPhong = pObj.ToString();

            // Đóng phiếu đặt
            Db.Execute("UPDATE PhieuDatPhong SET TrangThai = N'Đã trả phòng' WHERE MaPhieuDat = @ma", new SqlParameter("@ma", maPhieu.Trim()));
            // Giải phóng phòng về Trống
            Db.Execute("UPDATE Phong SET TrangThaiPhong = N'Trống' WHERE SoPhong = @p", new SqlParameter("@p", soPhong));

            return (true, $"Đã hoàn tất trả phòng! Phòng {soPhong} hiện đã sẵn sàng đón lượt khách mới.");
        }
    }
}