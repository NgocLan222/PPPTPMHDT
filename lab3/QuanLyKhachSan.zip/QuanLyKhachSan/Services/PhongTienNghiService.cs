﻿using System;
using System.Data;
using System.Data.SqlClient;
using QuanLyKhachSan.Data;

namespace QuanLyKhachSan.Services
{
    public class PhongTienNghiService
    {
        #region 1. Nghiệp vụ Quản lý Phòng (BR01, BR02)
        public DataTable LayDanhSachPhong()
        {
            string sql = @"SELECT p.SoPhong, p.MaKhuVuc, kv.TenKhuVuc, p.SoNguoiToiDa, p.DonGiaNgay, p.TrangThaiPhong 
                           FROM Phong p 
                           JOIN KhuVuc kv ON p.MaKhuVuc = kv.MaKhuVuc 
                           ORDER BY p.SoPhong";
            return Db.Query(sql);
        }

        public (bool Ok, string Msg) LuuPhong(string soPhong, string maKV, int soNguoi, decimal donGia, bool isThem)
        {
            if (string.IsNullOrWhiteSpace(soPhong) || string.IsNullOrWhiteSpace(maKV))
                return (false, "Vui lòng nhập đầy đủ Số phòng và chọn Khu vực.");
            if (soNguoi <= 0)
                return (false, "Số người ở tối đa phải lớn hơn 0 (Quy định BR02).");
            if (donGia < 0)
                return (false, "Đơn giá thuê theo ngày không được là số âm.");

            if (isThem)
            {
                int daCo = Convert.ToInt32(Db.Scalar("SELECT COUNT(*) FROM Phong WHERE SoPhong = @p", new SqlParameter("@p", soPhong.Trim())));
                if (daCo > 0)
                    return (false, "Số phòng này đã tồn tại trong khách sạn.");

                string sqlInsert = @"INSERT INTO Phong (SoPhong, MaKhuVuc, SoNguoiToiDa, DonGiaNgay, TrangThaiPhong) 
                                     VALUES (@p, @kv, @nguoi, @gia, N'Trống')";
                Db.Execute(sqlInsert,
                    new SqlParameter("@p", soPhong.Trim()),
                    new SqlParameter("@kv", maKV),
                    new SqlParameter("@nguoi", soNguoi),
                    new SqlParameter("@gia", donGia));
            }
            else
            {
                string sqlUpdate = @"UPDATE Phong 
                                     SET MaKhuVuc = @kv, SoNguoiToiDa = @nguoi, DonGiaNgay = @gia 
                                     WHERE SoPhong = @p";
                Db.Execute(sqlUpdate,
                    new SqlParameter("@kv", maKV),
                    new SqlParameter("@nguoi", soNguoi),
                    new SqlParameter("@gia", donGia),
                    new SqlParameter("@p", soPhong.Trim()));
            }
            return (true, "Lưu thông tin phòng thành công.");
        }

        public (bool Ok, string Msg) XoaPhong(string soPhong)
        {
            int coPhieuDat = Convert.ToInt32(Db.Scalar("SELECT COUNT(*) FROM PhieuDatPhong WHERE SoPhong = @p", new SqlParameter("@p", soPhong)));
            if (coPhieuDat > 0)
                return (false, "Không thể xóa phòng đã phát sinh lịch sử đặt phòng.");

            int coLapDat = Convert.ToInt32(Db.Scalar("SELECT COUNT(*) FROM PhieuLapDat WHERE SoPhong = @p", new SqlParameter("@p", soPhong)));
            if (coLapDat > 0)
                return (false, "Không thể xóa phòng đang có lịch sử lắp đặt thiết bị.");

            Db.Execute("DELETE FROM Phong WHERE SoPhong = @p", new SqlParameter("@p", soPhong));
            return (true, "Xóa phòng thành công.");
        }
        #endregion

        #region 2. Nghiệp vụ Quản lý Tiện Nghi (BR03)
        public DataTable LayDanhSachTienNghi()
        {
            string sql = @"SELECT tn.MaTienNghi, tn.MaLoaiTienNghi, ltn.TenLoaiTienNghi, tn.SoThuTu, tn.TrangThai 
                           FROM TienNghi tn 
                           JOIN LoaiTienNghi ltn ON tn.MaLoaiTienNghi = ltn.MaLoaiTienNghi 
                           ORDER BY tn.MaLoaiTienNghi, tn.SoThuTu";
            return Db.Query(sql);
        }

        public (bool Ok, string Msg) LuuTienNghi(string maTN, string maLoai, int stt, string trangThai, bool isThem)
        {
            if (string.IsNullOrWhiteSpace(maTN) || string.IsNullOrWhiteSpace(maLoai))
                return (false, "Vui lòng nhập Mã tiện nghi và chọn Loại tiện nghi.");
            if (stt <= 0)
                return (false, "Số thứ tự thiết bị phải lớn hơn 0.");

            if (isThem)
            {
                int daCoMa = Convert.ToInt32(Db.Scalar("SELECT COUNT(*) FROM TienNghi WHERE MaTienNghi = @ma", new SqlParameter("@ma", maTN.Trim())));
                if (daCoMa > 0)
                    return (false, "Mã tiện nghi này đã tồn tại.");

                // BR03: Kiểm tra STT phân biệt trong cùng loại tiện nghi
                int daCoSTT = Convert.ToInt32(Db.Scalar("SELECT COUNT(*) FROM TienNghi WHERE MaLoaiTienNghi = @loai AND SoThuTu = @stt",
                    new SqlParameter("@loai", maLoai), new SqlParameter("@stt", stt)));
                if (daCoSTT > 0)
                    return (false, $"Trong loại tiện nghi này đã có thiết bị mang số thứ tự {stt} (Vi phạm BR03).");

                string sqlInsert = @"INSERT INTO TienNghi (MaTienNghi, MaLoaiTienNghi, SoThuTu, TrangThai) 
                                     VALUES (@ma, @loai, @stt, @tt)";
                Db.Execute(sqlInsert,
                    new SqlParameter("@ma", maTN.Trim()),
                    new SqlParameter("@loai", maLoai),
                    new SqlParameter("@stt", stt),
                    new SqlParameter("@tt", trangThai ?? "Tốt"));
            }
            else
            {
                int daCoSTT = Convert.ToInt32(Db.Scalar("SELECT COUNT(*) FROM TienNghi WHERE MaLoaiTienNghi = @loai AND SoThuTu = @stt AND MaTienNghi <> @ma",
                    new SqlParameter("@loai", maLoai), new SqlParameter("@stt", stt), new SqlParameter("@ma", maTN.Trim())));
                if (daCoSTT > 0)
                    return (false, $"Số thứ tự {stt} đã bị trùng với một thiết bị khác cùng loại.");

                string sqlUpdate = @"UPDATE TienNghi 
                                     SET MaLoaiTienNghi = @loai, SoThuTu = @stt, TrangThai = @tt 
                                     WHERE MaTienNghi = @ma";
                Db.Execute(sqlUpdate,
                    new SqlParameter("@loai", maLoai),
                    new SqlParameter("@stt", stt),
                    new SqlParameter("@tt", trangThai ?? "Tốt"),
                    new SqlParameter("@ma", maTN.Trim()));
            }
            return (true, "Lưu thông tin tiện nghi thành công.");
        }

        public (bool Ok, string Msg) XoaTienNghi(string maTN)
        {
            int coLapDat = Convert.ToInt32(Db.Scalar("SELECT COUNT(*) FROM PhieuLapDat WHERE MaTienNghi = @ma", new SqlParameter("@ma", maTN)));
            if (coLapDat > 0)
                return (false, "Không thể xóa tiện nghi đã có lịch sử lắp đặt vào phòng.");

            int coDenBu = Convert.ToInt32(Db.Scalar("SELECT COUNT(*) FROM PhieuDenBu WHERE MaTienNghi = @ma", new SqlParameter("@ma", maTN)));
            if (coDenBu > 0)
                return (false, "Không thể xóa tiện nghi đã phát sinh phiếu đền bù thiệt hại.");

            Db.Execute("DELETE FROM TienNghi WHERE MaTienNghi = @ma", new SqlParameter("@ma", maTN));
            return (true, "Xóa tiện nghi thành công.");
        }
        #endregion

        #region 3. Nghiệp vụ Lập Phiếu Lắp Đặt / Luân Chuyển (BR04)
        public DataTable LayDanhSachPhieuLapDat()
        {
            string sql = @"SELECT pld.MaPhieuLapDat, pld.SoPhong, pld.MaTienNghi, ltn.TenLoaiTienNghi, tn.SoThuTu, pld.NgayLap, pld.TinhTrang 
                           FROM PhieuLapDat pld 
                           JOIN TienNghi tn ON pld.MaTienNghi = tn.MaTienNghi 
                           JOIN LoaiTienNghi ltn ON tn.MaLoaiTienNghi = ltn.MaLoaiTienNghi 
                           ORDER BY pld.NgayLap DESC, pld.MaPhieuLapDat DESC";
            return Db.Query(sql);
        }

        // BR04: Trong một ngày một thiết bị chỉ được trang bị cho một phòng duy nhất
        public (bool Ok, string Msg) LapPhieuLapDat(string maPhieu, string soPhong, string maTN, DateTime ngayLap, string tinhTrang)
        {
            if (string.IsNullOrWhiteSpace(maPhieu) || string.IsNullOrWhiteSpace(soPhong) || string.IsNullOrWhiteSpace(maTN))
                return (false, "Vui lòng nhập đầy đủ Mã phiếu, chọn Phòng và Thiết bị.");

            int daCoPhieu = Convert.ToInt32(Db.Scalar("SELECT COUNT(*) FROM PhieuLapDat WHERE MaPhieuLapDat = @ma", new SqlParameter("@ma", maPhieu.Trim())));
            if (daCoPhieu > 0)
                return (false, "Mã phiếu lắp đặt này đã tồn tại.");

            // Kiểm tra quy tắc BR04
            string sqlCheckBR04 = @"SELECT COUNT(*) FROM PhieuLapDat 
                                   WHERE MaTienNghi = @tn AND CAST(NgayLap AS DATE) = CAST(@ngay AS DATE)";
            int daLapTrongNgay = Convert.ToInt32(Db.Scalar(sqlCheckBR04,
                new SqlParameter("@tn", maTN),
                new SqlParameter("@ngay", ngayLap.Date)));

            if (daLapTrongNgay > 0)
                return (false, "Quy tắc BR04: Thiết bị này đã được lắp đặt cho một phòng trong ngày hôm nay. Không thể lắp thêm phòng khác!");

            string sqlInsert = @"INSERT INTO PhieuLapDat (MaPhieuLapDat, SoPhong, MaTienNghi, NgayLap, TinhTrang) 
                                 VALUES (@ma, @phong, @tn, @ngay, @tt)";
            Db.Execute(sqlInsert,
                new SqlParameter("@ma", maPhieu.Trim()),
                new SqlParameter("@phong", soPhong),
                new SqlParameter("@tn", maTN),
                new SqlParameter("@ngay", ngayLap.Date),
                new SqlParameter("@tt", string.IsNullOrWhiteSpace(tinhTrang) ? "Hoạt động tốt" : tinhTrang.Trim()));

            return (true, "Lập phiếu lắp đặt thiết bị thành công.");
        }
        #endregion
    }
}