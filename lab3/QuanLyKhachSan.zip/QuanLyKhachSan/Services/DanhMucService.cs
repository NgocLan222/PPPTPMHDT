﻿using System;
using System.Data;
using System.Data.SqlClient;
using QuanLyKhachSan.Data;

namespace QuanLyKhachSan.Services
{
    public class DanhMucService
    {
        #region 1. Khu Vực (BR01)
        public DataTable LayDanhSachKhuVuc()
        {
            return Db.Query("SELECT MaKhuVuc, TenKhuVuc FROM KhuVuc ORDER BY MaKhuVuc");
        }

        public (bool Ok, string Msg) LuuKhuVuc(string maKV, string tenKV, bool isThem)
        {
            if (string.IsNullOrWhiteSpace(maKV) || string.IsNullOrWhiteSpace(tenKV))
                return (false, "Vui lòng nhập đầy đủ Mã khu vực và Tên khu vực.");

            if (isThem)
            {
                int daCo = Convert.ToInt32(Db.Scalar("SELECT COUNT(*) FROM KhuVuc WHERE MaKhuVuc = @ma", new SqlParameter("@ma", maKV.Trim())));
                if (daCo > 0)
                    return (false, "Mã khu vực này đã tồn tại trong hệ thống.");

                Db.Execute("INSERT INTO KhuVuc (MaKhuVuc, TenKhuVuc) VALUES (@ma, @ten)",
                    new SqlParameter("@ma", maKV.Trim()), new SqlParameter("@ten", tenKV.Trim()));
            }
            else
            {
                Db.Execute("UPDATE KhuVuc SET TenKhuVuc = @ten WHERE MaKhuVuc = @ma",
                    new SqlParameter("@ten", tenKV.Trim()), new SqlParameter("@ma", maKV.Trim()));
            }
            return (true, "Lưu thông tin khu vực thành công.");
        }

        public (bool Ok, string Msg) XoaKhuVuc(string maKV)
        {
            int coPhong = Convert.ToInt32(Db.Scalar("SELECT COUNT(*) FROM Phong WHERE MaKhuVuc = @ma", new SqlParameter("@ma", maKV)));
            if (coPhong > 0)
                return (false, "Không thể xóa khu vực đã có phòng trực thuộc (Ràng buộc khóa ngoại).");

            Db.Execute("DELETE FROM KhuVuc WHERE MaKhuVuc = @ma", new SqlParameter("@ma", maKV));
            return (true, "Xóa khu vực thành công.");
        }
        #endregion

        #region 2. Loại Tiện Nghi (BR03)
        public DataTable LayDanhSachLoaiTienNghi()
        {
            return Db.Query("SELECT MaLoaiTienNghi, TenLoaiTienNghi FROM LoaiTienNghi ORDER BY MaLoaiTienNghi");
        }

        public (bool Ok, string Msg) LuuLoaiTienNghi(string maLoai, string tenLoai, bool isThem)
        {
            if (string.IsNullOrWhiteSpace(maLoai) || string.IsNullOrWhiteSpace(tenLoai))
                return (false, "Vui lòng nhập đầy đủ Mã loại và Tên loại tiện nghi.");

            if (isThem)
            {
                int daCo = Convert.ToInt32(Db.Scalar("SELECT COUNT(*) FROM LoaiTienNghi WHERE MaLoaiTienNghi = @ma", new SqlParameter("@ma", maLoai.Trim())));
                if (daCo > 0)
                    return (false, "Mã loại tiện nghi đã tồn tại.");

                Db.Execute("INSERT INTO LoaiTienNghi (MaLoaiTienNghi, TenLoaiTienNghi) VALUES (@ma, @ten)",
                    new SqlParameter("@ma", maLoai.Trim()), new SqlParameter("@ten", tenLoai.Trim()));
            }
            else
            {
                Db.Execute("UPDATE LoaiTienNghi SET TenLoaiTienNghi = @ten WHERE MaLoaiTienNghi = @ma",
                    new SqlParameter("@ten", tenLoai.Trim()), new SqlParameter("@ma", maLoai.Trim()));
            }
            return (true, "Lưu loại tiện nghi thành công.");
        }

        public (bool Ok, string Msg) XoaLoaiTienNghi(string maLoai)
        {
            int coTienNghi = Convert.ToInt32(Db.Scalar("SELECT COUNT(*) FROM TienNghi WHERE MaLoaiTienNghi = @ma", new SqlParameter("@ma", maLoai)));
            if (coTienNghi > 0)
                return (false, "Không thể xóa loại tiện nghi đã phát sinh các thiết bị cụ thể.");

            Db.Execute("DELETE FROM LoaiTienNghi WHERE MaLoaiTienNghi = @ma", new SqlParameter("@ma", maLoai));
            return (true, "Xóa loại tiện nghi thành công.");
        }
        #endregion

        #region 3. Dịch Vụ
        public DataTable LayDanhSachDichVu()
        {
            return Db.Query("SELECT MaDichVu, TenDichVu, DonGia FROM DichVu ORDER BY MaDichVu");
        }

        public (bool Ok, string Msg) LuuDichVu(string maDV, string tenDV, decimal donGia, bool isThem)
        {
            if (string.IsNullOrWhiteSpace(maDV) || string.IsNullOrWhiteSpace(tenDV))
                return (false, "Vui lòng nhập đầy đủ Mã và Tên dịch vụ.");
            if (donGia < 0)
                return (false, "Đơn giá dịch vụ không được là số âm.");

            if (isThem)
            {
                int daCo = Convert.ToInt32(Db.Scalar("SELECT COUNT(*) FROM DichVu WHERE MaDichVu = @ma", new SqlParameter("@ma", maDV.Trim())));
                if (daCo > 0)
                    return (false, "Mã dịch vụ đã tồn tại.");

                Db.Execute("INSERT INTO DichVu (MaDichVu, TenDichVu, DonGia) VALUES (@ma, @ten, @gia)",
                    new SqlParameter("@ma", maDV.Trim()), new SqlParameter("@ten", tenDV.Trim()), new SqlParameter("@gia", donGia));
            }
            else
            {
                Db.Execute("UPDATE DichVu SET TenDichVu = @ten, DonGia = @gia WHERE MaDichVu = @ma",
                    new SqlParameter("@ten", tenDV.Trim()), new SqlParameter("@gia", donGia), new SqlParameter("@ma", maDV.Trim()));
            }
            return (true, "Lưu thông tin dịch vụ thành công.");
        }

        public (bool Ok, string Msg) XoaDichVu(string maDV)
        {
            int daSuDung = Convert.ToInt32(Db.Scalar("SELECT COUNT(*) FROM ChiTietSuDungDichVu WHERE MaDichVu = @ma", new SqlParameter("@ma", maDV)));
            if (daSuDung > 0)
                return (false, "Không thể xóa dịch vụ này vì đã có khách hàng sử dụng.");

            Db.Execute("DELETE FROM DichVu WHERE MaDichVu = @ma", new SqlParameter("@ma", maDV));
            return (true, "Xóa dịch vụ thành công.");
        }
        #endregion

        #region 4. Quy Định Đền Bù (BR08)
        public DataTable LayDanhSachQuyDinhDenBu()
        {
            return Db.Query(@"SELECT qd.MaQuyDinh, qd.MaLoaiTienNghi, ltn.TenLoaiTienNghi, qd.MucDoHuHong, qd.GiaDenBu
                             FROM QuyDinhDenBu qd
                             JOIN LoaiTienNghi ltn ON qd.MaLoaiTienNghi = ltn.MaLoaiTienNghi
                             ORDER BY qd.MaQuyDinh");
        }

        public (bool Ok, string Msg) LuuQuyDinhDenBu(string maQD, string maLoaiTN, string mucDo, decimal giaDenBu, bool isThem)
        {
            if (string.IsNullOrWhiteSpace(maQD) || string.IsNullOrWhiteSpace(maLoaiTN) || string.IsNullOrWhiteSpace(mucDo))
                return (false, "Vui lòng nhập đầy đủ thông tin quy định đền bù.");
            if (giaDenBu < 0)
                return (false, "Giá đền bù không được là số âm.");

            if (isThem)
            {
                int daCo = Convert.ToInt32(Db.Scalar("SELECT COUNT(*) FROM QuyDinhDenBu WHERE MaQuyDinh = @ma", new SqlParameter("@ma", maQD.Trim())));
                if (daCo > 0)
                    return (false, "Mã quy định đền bù đã tồn tại.");

                Db.Execute("INSERT INTO QuyDinhDenBu (MaQuyDinh, MaLoaiTienNghi, MucDoHuHong, GiaDenBu) VALUES (@ma, @loai, @mucDo, @gia)",
                    new SqlParameter("@ma", maQD.Trim()), new SqlParameter("@loai", maLoaiTN), new SqlParameter("@mucDo", mucDo.Trim()), new SqlParameter("@gia", giaDenBu));
            }
            else
            {
                Db.Execute("UPDATE QuyDinhDenBu SET MaLoaiTienNghi = @loai, MucDoHuHong = @mucDo, GiaDenBu = @gia WHERE MaQuyDinh = @ma",
                    new SqlParameter("@loai", maLoaiTN), new SqlParameter("@mucDo", mucDo.Trim()), new SqlParameter("@gia", giaDenBu), new SqlParameter("@ma", maQD.Trim()));
            }
            return (true, "Lưu quy định đền bù thành công.");
        }

        public (bool Ok, string Msg) XoaQuyDinhDenBu(string maQD)
        {
            Db.Execute("DELETE FROM QuyDinhDenBu WHERE MaQuyDinh = @ma", new SqlParameter("@ma", maQD));
            return (true, "Xóa quy định đền bù thành công.");
        }
        #endregion

        #region 5. Nhân Viên
        public DataTable LayDanhSachNhanVien()
        {
            return Db.Query("SELECT MaNV, HoTen, ChucVu, SoDienThoai FROM NhanVien ORDER BY MaNV");
        }

        public (bool Ok, string Msg) LuuNhanVien(string maNV, string hoTen, string chucVu, string sdt, bool isThem)
        {
            if (string.IsNullOrWhiteSpace(maNV) || string.IsNullOrWhiteSpace(hoTen))
                return (false, "Vui lòng nhập đầy đủ Mã và Họ tên nhân viên.");

            if (isThem)
            {
                int daCo = Convert.ToInt32(Db.Scalar("SELECT COUNT(*) FROM NhanVien WHERE MaNV = @ma", new SqlParameter("@ma", maNV.Trim())));
                if (daCo > 0)
                    return (false, "Mã nhân viên đã tồn tại.");

                Db.Execute("INSERT INTO NhanVien (MaNV, HoTen, ChucVu, SoDienThoai) VALUES (@ma, @ten, @cv, @sdt)",
                    new SqlParameter("@ma", maNV.Trim()), new SqlParameter("@ten", hoTen.Trim()), new SqlParameter("@cv", chucVu ?? ""), new SqlParameter("@sdt", sdt ?? ""));
            }
            else
            {
                Db.Execute("UPDATE NhanVien SET HoTen = @ten, ChucVu = @cv, SoDienThoai = @sdt WHERE MaNV = @ma",
                    new SqlParameter("@ten", hoTen.Trim()), new SqlParameter("@cv", chucVu ?? ""), new SqlParameter("@sdt", sdt ?? ""), new SqlParameter("@ma", maNV.Trim()));
            }
            return (true, "Lưu nhân viên thành công.");
        }

        public (bool Ok, string Msg) XoaNhanVien(string maNV)
        {
            int coPhieu = Convert.ToInt32(Db.Scalar("SELECT COUNT(*) FROM PhieuDatPhong WHERE MaNV = @ma", new SqlParameter("@ma", maNV)));
            if (coPhieu > 0)
                return (false, "Không thể xóa nhân viên này vì đã tham gia lập phiếu đặt phòng.");

            Db.Execute("DELETE FROM NhanVien WHERE MaNV = @ma", new SqlParameter("@ma", maNV));
            return (true, "Xóa nhân viên thành công.");
        }
        #endregion
    }
}