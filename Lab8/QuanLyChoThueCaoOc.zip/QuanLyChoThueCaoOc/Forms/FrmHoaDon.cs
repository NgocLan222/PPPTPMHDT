﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using QuanLyChoThueCaoOc.Data;

namespace QuanLyChoThueCaoOc.Forms
{
    public partial class FrmHoaDon : Form
    {
        public FrmHoaDon()
        {
            InitializeComponent();
            cboLoaiHD.SelectedIndexChanged += cboLoaiHD_SelectedIndexChanged;
            cboHopDong.SelectedIndexChanged += cboHopDong_SelectedIndexChanged;
            cboPhong.SelectedIndexChanged += cboPhong_SelectedIndexChanged;
            cboDichVu.SelectedIndexChanged += cboDichVu_SelectedIndexChanged;
            numChiSoDau.ValueChanged += TinhTienDichVu;
            numChiSoCuoi.ValueChanged += TinhTienDichVu;
            cboLocTrangThai.SelectedIndexChanged += cboLocTrangThai_SelectedIndexChanged;
        }

        private void FrmHoaDon_Load(object sender, EventArgs e)
        {
            cboLoaiHD.SelectedIndex = 0; // Mặc định: Tiền phòng
            cboLocTrangThai.SelectedIndex = 0; // Mặc định: Tất cả
            TaiDanhSachHopDong();
            TaiDanhSachHoaDon();
            TaoMaTuDong();
            dtpHanThanhToan.Value = DateTime.Now.AddDays(10);
        }

        private void TaoMaTuDong()
        {
            txtMaHoaDon.Text = "INV" + DateTime.Now.ToString("yyMMddHHmm").Substring(2, 6);
        }

        private void TaiDanhSachHopDong()
        {
            string sql = "SELECT MaHD, MaHD + ' - ' + MaKH AS HienThi FROM HopDongThue WHERE TrangThai = N'Hiệu lực'";
            DataTable dt = Db.LayBang(sql);
            FormHelper.Nap(cboHopDong, dt, "HienThi", "MaHD");
            TaiDanhSachPhongTheoHD();
        }

        private void TaiDanhSachPhongTheoHD()
        {
            string maHD = FormHelper.Gia(cboHopDong);
            if (string.IsNullOrEmpty(maHD)) return;

            string sql = @"SELECT p.MaPhong, p.MaPhong + ' - ' + p.TenPhong AS HienThi 
                           FROM ChiTietThuePhong ct 
                           JOIN Phong p ON ct.MaPhong = p.MaPhong 
                           WHERE ct.MaHD = @MaHD";
            SqlParameter[] p = { new SqlParameter("@MaHD", maHD) };
            DataTable dt = Db.LayBang(sql, p);
            FormHelper.Nap(cboPhong, dt, "HienThi", "MaPhong");

            CapNhatDonGiaTheoPhong();
        }

        private void CapNhatDonGiaTheoPhong()
        {
            if (cboLoaiHD.SelectedIndex == 0) // Tiền phòng
            {
                string maPhong = FormHelper.Gia(cboPhong);
                if (string.IsNullOrEmpty(maPhong)) return;

                string sql = "SELECT DonGiaThue FROM Phong WHERE MaPhong = @MaPhong";
                SqlParameter[] p = { new SqlParameter("@MaPhong", maPhong) };
                object kq = Db.LayGiaTri(sql, p);
                if (kq != null && kq != DBNull.Value)
                {
                    decimal gia = Convert.ToDecimal(kq);
                    txtThanhTien.Text = gia.ToString("N0");
                }
            }
        }

        private void cboLoaiHD_SelectedIndexChanged(object sender, EventArgs e)
        {
            bool isDichVu = (cboLoaiHD.SelectedIndex == 1);
            cboDichVu.Enabled = isDichVu;
            numChiSoDau.Enabled = isDichVu;
            numChiSoCuoi.Enabled = isDichVu;

            if (isDichVu)
            {
                if (cboDichVu.SelectedIndex < 0) cboDichVu.SelectedIndex = 0;
                TinhTienDichVu(sender, e);
            }
            else
            {
                CapNhatDonGiaTheoPhong();
            }
        }

        private void cboHopDong_SelectedIndexChanged(object sender, EventArgs e)
        {
            TaiDanhSachPhongTheoHD();
        }

        private void cboPhong_SelectedIndexChanged(object sender, EventArgs e)
        {
            CapNhatDonGiaTheoPhong();
        }

        private void cboDichVu_SelectedIndexChanged(object sender, EventArgs e)
        {
            TinhTienDichVu(sender, e);
        }

        private void TinhTienDichVu(object sender, EventArgs e)
        {
            if (cboLoaiHD.SelectedIndex != 1) return;

            decimal chiSo = numChiSoCuoi.Value - numChiSoDau.Value;
            if (chiSo < 0) chiSo = 0;

            string tenDV = cboDichVu.SelectedItem?.ToString() ?? "";
            decimal donGia = 0;

            if (tenDV.Contains("Điện")) donGia = 3500;
            else if (tenDV.Contains("Nước")) donGia = 18000;
            else if (tenDV.Contains("Internet"))
            {
                donGia = 350000;
                txtThanhTien.Text = donGia.ToString("N0");
                return;
            }
            else donGia = 200000; // Phí vệ sinh

            decimal tong = chiSo * donGia;
            txtThanhTien.Text = tong.ToString("N0");
        }

        private void TaiDanhSachHoaDon()
        {
            string sql = @"SELECT MaHoaDon, MaHD, MaPhong, LoaiHoaDon, TenDichVu, 
                                  KyThang, KyNam, NgayLap, HanThanhToan, SoTien, NgayThanhToan, TrangThai 
                           FROM HoaDon ";

            if (cboLocTrangThai.SelectedIndex == 1)
                sql += "WHERE TrangThai = N'Chưa thanh toán' ";
            else if (cboLocTrangThai.SelectedIndex == 2)
                sql += "WHERE TrangThai = N'Đã thanh toán' ";

            sql += "ORDER BY NgayLap DESC";
            dgvHoaDon.DataSource = Db.LayBang(sql);
        }

        private void cboLocTrangThai_SelectedIndexChanged(object sender, EventArgs e)
        {
            TaiDanhSachHoaDon();
        }

        private void btnLapHoaDon_Click(object sender, EventArgs e)
        {
            string maHD = txtMaHoaDon.Text.Trim();
            string soHD = FormHelper.Gia(cboHopDong);
            string maPhong = FormHelper.Gia(cboPhong);
            string loaiHD = cboLoaiHD.SelectedItem.ToString();
            string tenDV = (loaiHD == "Tiền dịch vụ") ? cboDichVu.SelectedItem.ToString() : null;
            int thang = (int)numKyThang.Value;
            int nam = (int)numKyNam.Value;

            if (string.IsNullOrEmpty(maHD) || string.IsNullOrEmpty(soHD) || string.IsNullOrEmpty(maPhong))
            {
                FormHelper.ThongBao("Vui lòng chọn đầy đủ Hợp đồng và Phòng thuê!", false);
                return;
            }

            // Kiểm tra ràng buộc kinh doanh Câu 4: Tiền thuê phòng chỉ thu từ tháng 7 trở đi
            if (loaiHD == "Tiền phòng" && thang < 7)
            {
                DialogResult dr = MessageBox.Show(
                    $"Theo quy định, tiền thuê phòng của 6 tháng đầu đã được thu trước khi ký hợp đồng.\nBạn có chắc chắn muốn lập hóa đơn tiền phòng cho Kỳ tháng {thang}/{nam}?",
                    "Cảnh báo nghiệp vụ", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (dr == DialogResult.No) return;
            }

            decimal soTien = 0;
            decimal.TryParse(txtThanhTien.Text.Replace(",", "").Replace(".", ""), out soTien);

            if (soTien <= 0)
            {
                FormHelper.ThongBao("Số tiền thanh toán phải lớn hơn 0!", false);
                return;
            }

            decimal chiSoDau = (loaiHD == "Tiền dịch vụ") ? numChiSoDau.Value : 0;
            decimal chiSoCuoi = (loaiHD == "Tiền dịch vụ") ? numChiSoCuoi.Value : 0;
            decimal tieuThu = chiSoCuoi - chiSoDau;
            if (tieuThu < 0) tieuThu = 0;

            string sqlInsert = @"INSERT INTO HoaDon (MaHoaDon, LoaiHoaDon, TenDichVu, KyThang, KyNam, NgayLap, HanThanhToan, ChiSoDau, ChiSoCuoi, SoLuongTieuThu, SoTien, TrangThai, MaHD, MaPhong)
                                 VALUES (@MaHoaDon, @LoaiHoaDon, @TenDichVu, @KyThang, @KyNam, GETDATE(), @HanThanhToan, @ChiSoDau, @ChiSoCuoi, @SoLuongTieuThu, @SoTien, N'Chưa thanh toán', @MaHD, @MaPhong)";
            SqlParameter[] p = {
                new SqlParameter("@MaHoaDon", maHD),
                new SqlParameter("@LoaiHoaDon", loaiHD),
                new SqlParameter("@TenDichVu", (object)tenDV ?? DBNull.Value),
                new SqlParameter("@KyThang", thang),
                new SqlParameter("@KyNam", nam),
                new SqlParameter("@HanThanhToan", dtpHanThanhToan.Value.Date),
                new SqlParameter("@ChiSoDau", chiSoDau),
                new SqlParameter("@ChiSoCuoi", chiSoCuoi),
                new SqlParameter("@SoLuongTieuThu", tieuThu),
                new SqlParameter("@SoTien", soTien),
                new SqlParameter("@MaHD", soHD),
                new SqlParameter("@MaPhong", maPhong)
            };

            if (Db.ThucThi(sqlInsert, p) > 0)
            {
                FormHelper.ThongBao($"Lập hóa đơn {maHD} thành công! Số tiền: {soTien:N0} VNĐ", true);
                TaiDanhSachHoaDon();
                TaoMaTuDong();
            }
            else
            {
                FormHelper.ThongBao("Lập hóa đơn thất bại, vui lòng kiểm tra lại!", false);
            }
        }

        private void btnThanhToan_Click(object sender, EventArgs e)
        {
            if (dgvHoaDon.CurrentRow == null)
            {
                FormHelper.ThongBao("Vui lòng chọn một hóa đơn trong bảng để xác nhận nộp tiền!", false);
                return;
            }

            string maHoaDon = FormHelper.O(dgvHoaDon, "MaHoaDon");
            string trangThai = FormHelper.O(dgvHoaDon, "TrangThai");

            if (trangThai == "Đã thanh toán")
            {
                FormHelper.ThongBao("Hóa đơn này đã được thanh toán trước đó!", false);
                return;
            }

            DialogResult dr = MessageBox.Show($"Xác nhận khách hàng đã nộp đủ tiền cho hóa đơn: {maHoaDon}?",
                                              "Xác nhận thanh toán", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dr == DialogResult.Yes)
            {
                string sqlUpdate = @"UPDATE HoaDon 
                                     SET TrangThai = N'Đã thanh toán', NgayThanhToan = GETDATE() 
                                     WHERE MaHoaDon = @MaHoaDon";
                SqlParameter[] p = { new SqlParameter("@MaHoaDon", maHoaDon) };

                if (Db.ThucThi(sqlUpdate, p) > 0)
                {
                    FormHelper.ThongBao($"Đã gạch nợ thành công cho hóa đơn {maHoaDon}!", true);
                    TaiDanhSachHoaDon();
                }
            }
        }

        private void btnLamMoi_Click(object sender, EventArgs e)
        {
            TaoMaTuDong();
            numChiSoDau.Value = 0;
            numChiSoCuoi.Value = 0;
            TaiDanhSachHoaDon();
        }

        private void btnDong_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}