﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using QuanLyChoThueCaoOc.Data;

namespace QuanLyChoThueCaoOc.Forms
{
    public partial class FrmPhong_KhachHang : Form
    {
        public FrmPhong_KhachHang()
        {
            InitializeComponent();
        }

        private void FrmPhong_KhachHang_Load(object sender, EventArgs e)
        {
            cboTrangThai.SelectedIndex = 0; // Mặc định: Trống
            TaiDanhSachPhong();
            TaiDanhSachKhachHang();
            TaoMaPhongMoi();
            TaoMaKHMoi();
        }

        private void TaoMaPhongMoi()
        {
            txtMaPhong.Text = "P" + numSoTang.Value.ToString("00") + "01";
        }

        private void TaoMaKHMoi()
        {
            txtMaKH.Text = "KH" + DateTime.Now.ToString("yyMMddHHmm").Substring(2, 6);
        }

        // ================= PHẦN 1: QUẢN LÝ PHÒNG =================
        private void TaiDanhSachPhong()
        {
            string sql = @"SELECT MaPhong, TenPhong, SoTang, DoCao, DienTich, HuongPhong, DonGiaThue, TrangThai 
                           FROM Phong ORDER BY SoTang ASC, MaPhong ASC";
            dgvPhong.DataSource = Db.LayBang(sql);
        }

        private void dgvPhong_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvPhong.CurrentRow == null) return;

            txtMaPhong.Text = FormHelper.O(dgvPhong, "MaPhong");
            txtTenPhong.Text = FormHelper.O(dgvPhong, "TenPhong");

            decimal soTang = 1, doCao = 3.3m, dienTich = 50, donGia = 10000000;
            decimal.TryParse(FormHelper.O(dgvPhong, "SoTang"), out soTang);
            decimal.TryParse(FormHelper.O(dgvPhong, "DoCao"), out doCao);
            decimal.TryParse(FormHelper.O(dgvPhong, "DienTich"), out dienTich);
            decimal.TryParse(FormHelper.O(dgvPhong, "DonGiaThue"), out donGia);

            numSoTang.Value = soTang;
            numDoCao.Value = doCao;
            numDienTich.Value = dienTich;
            numDonGia.Value = donGia;

            txtHuong.Text = FormHelper.O(dgvPhong, "HuongPhong");
            cboTrangThai.SelectedItem = FormHelper.O(dgvPhong, "TrangThai");
        }

        private void btnThemPhong_Click(object sender, EventArgs e)
        {
            string maPhong = txtMaPhong.Text.Trim();
            string tenPhong = txtTenPhong.Text.Trim();
            string huong = txtHuong.Text.Trim();
            string trangThai = cboTrangThai.SelectedItem?.ToString() ?? "Trống";

            if (string.IsNullOrEmpty(maPhong) || string.IsNullOrEmpty(tenPhong))
            {
                FormHelper.ThongBao("Vui lòng nhập đầy đủ Mã phòng và Tên phòng!", false);
                return;
            }

            string sqlCheck = "SELECT COUNT(*) FROM Phong WHERE MaPhong = @MaPhong";
            SqlParameter[] pCheck = { new SqlParameter("@MaPhong", maPhong) };
            if (Convert.ToInt32(Db.LayGiaTri(sqlCheck, pCheck)) > 0)
            {
                FormHelper.ThongBao("Mã phòng này đã tồn tại!", false);
                return;
            }

            string sqlInsert = @"INSERT INTO Phong (MaPhong, TenPhong, SoTang, DoCao, DienTich, HuongPhong, DonGiaThue, TrangThai)
                                 VALUES (@MaPhong, @TenPhong, @SoTang, @DoCao, @DienTich, @HuongPhong, @DonGiaThue, @TrangThai)";
            SqlParameter[] p = {
                new SqlParameter("@MaPhong", maPhong),
                new SqlParameter("@TenPhong", tenPhong),
                new SqlParameter("@SoTang", (int)numSoTang.Value),
                new SqlParameter("@DoCao", numDoCao.Value),
                new SqlParameter("@DienTich", numDienTich.Value),
                new SqlParameter("@HuongPhong", huong),
                new SqlParameter("@DonGiaThue", numDonGia.Value),
                new SqlParameter("@TrangThai", trangThai)
            };

            if (Db.ThucThi(sqlInsert, p) > 0)
            {
                FormHelper.ThongBao($"Thêm phòng {maPhong} thành công!", true);
                TaiDanhSachPhong();
            }
        }

        private void btnSuaPhong_Click(object sender, EventArgs e)
        {
            string maPhong = txtMaPhong.Text.Trim();
            if (string.IsNullOrEmpty(maPhong))
            {
                FormHelper.ThongBao("Vui lòng chọn phòng cần cập nhật!", false);
                return;
            }

            string sqlUpdate = @"UPDATE Phong 
                                 SET TenPhong = @TenPhong, SoTang = @SoTang, DoCao = @DoCao, 
                                     DienTich = @DienTich, HuongPhong = @HuongPhong, 
                                     DonGiaThue = @DonGiaThue, TrangThai = @TrangThai 
                                 WHERE MaPhong = @MaPhong";
            SqlParameter[] p = {
                new SqlParameter("@MaPhong", maPhong),
                new SqlParameter("@TenPhong", txtTenPhong.Text.Trim()),
                new SqlParameter("@SoTang", (int)numSoTang.Value),
                new SqlParameter("@DoCao", numDoCao.Value),
                new SqlParameter("@DienTich", numDienTich.Value),
                new SqlParameter("@HuongPhong", txtHuong.Text.Trim()),
                new SqlParameter("@DonGiaThue", numDonGia.Value),
                new SqlParameter("@TrangThai", cboTrangThai.SelectedItem?.ToString() ?? "Trống")
            };

            if (Db.ThucThi(sqlUpdate, p) > 0)
            {
                FormHelper.ThongBao($"Cập nhật thông tin phòng {maPhong} thành công!", true);
                TaiDanhSachPhong();
            }
        }

        private void btnXoaPhong_Click(object sender, EventArgs e)
        {
            string maPhong = txtMaPhong.Text.Trim();
            if (string.IsNullOrEmpty(maPhong))
            {
                FormHelper.ThongBao("Vui lòng chọn phòng cần xóa!", false);
                return;
            }

            // Kiểm tra ràng buộc khóa ngoại
            string sqlCheckHD = "SELECT COUNT(*) FROM ChiTietThuePhong WHERE MaPhong = @MaPhong";
            SqlParameter[] pCheck = { new SqlParameter("@MaPhong", maPhong) };
            if (Convert.ToInt32(Db.LayGiaTri(sqlCheckHD, pCheck)) > 0)
            {
                FormHelper.ThongBao("Không thể xóa phòng này vì đã có dữ liệu Hợp đồng thuê!", false);
                return;
            }

            if (MessageBox.Show($"Bạn chắc chắn muốn xóa phòng {maPhong}?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                string sqlDelete = "DELETE FROM Phong WHERE MaPhong = @MaPhong";
                SqlParameter[] p = { new SqlParameter("@MaPhong", maPhong) };
                if (Db.ThucThi(sqlDelete, p) > 0)
                {
                    FormHelper.ThongBao($"Đã xóa phòng {maPhong}!", true);
                    TaiDanhSachPhong();
                    btnLamMoiPhong_Click(sender, e);
                }
            }
        }

        private void btnLamMoiPhong_Click(object sender, EventArgs e)
        {
            TaoMaPhongMoi();
            txtTenPhong.Clear();
            txtHuong.Text = "Đông Nam";
            numDonGia.Value = 25000000;
            cboTrangThai.SelectedIndex = 0;
            TaiDanhSachPhong();
        }

        // ================= PHẦN 2: QUẢN LÝ KHÁCH HÀNG =================
        private void TaiDanhSachKhachHang()
        {
            string sql = @"SELECT MaKH, TenCongTy, NguoiDaiDien, MaSoThue, DienThoai, Email, DiaChi 
                           FROM KhachHang ORDER BY MaKH DESC";
            dgvKhachHang.DataSource = Db.LayBang(sql);
        }

        private void dgvKhachHang_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvKhachHang.CurrentRow == null) return;

            txtMaKH.Text = FormHelper.O(dgvKhachHang, "MaKH");
            txtTenCongTy.Text = FormHelper.O(dgvKhachHang, "TenCongTy");
            txtNguoiDaiDien.Text = FormHelper.O(dgvKhachHang, "NguoiDaiDien");
            txtMST.Text = FormHelper.O(dgvKhachHang, "MaSoThue");
            txtDienThoai.Text = FormHelper.O(dgvKhachHang, "DienThoai");
            txtEmail.Text = FormHelper.O(dgvKhachHang, "Email");
            txtDiaChi.Text = FormHelper.O(dgvKhachHang, "DiaChi");
        }

        private void btnThemKH_Click(object sender, EventArgs e)
        {
            string maKH = txtMaKH.Text.Trim();
            string tenCongTy = txtTenCongTy.Text.Trim();
            string nguoiDD = txtNguoiDaiDien.Text.Trim();
            string mst = txtMST.Text.Trim();
            string dt = txtDienThoai.Text.Trim();
            string email = txtEmail.Text.Trim();
            string diaChi = txtDiaChi.Text.Trim();

            if (string.IsNullOrEmpty(maKH) || string.IsNullOrEmpty(tenCongTy) || string.IsNullOrEmpty(mst))
            {
                FormHelper.ThongBao("Vui lòng nhập đầy đủ Mã KH, Tên công ty và Mã số thuế!", false);
                return;
            }

            string sqlCheck = "SELECT COUNT(*) FROM KhachHang WHERE MaKH = @MaKH OR MaSoThue = @MST";
            SqlParameter[] pCheck = {
                new SqlParameter("@MaKH", maKH),
                new SqlParameter("@MST", mst)
            };
            if (Convert.ToInt32(Db.LayGiaTri(sqlCheck, pCheck)) > 0)
            {
                FormHelper.ThongBao("Mã khách hàng hoặc Mã số thuế này đã tồn tại!", false);
                return;
            }

            string sqlInsert = @"INSERT INTO KhachHang (MaKH, TenCongTy, NguoiDaiDien, MaSoThue, DienThoai, Email, DiaChi)
                                 VALUES (@MaKH, @TenCongTy, @NguoiDaiDien, @MaSoThue, @DienThoai, @Email, @DiaChi)";
            SqlParameter[] p = {
                new SqlParameter("@MaKH", maKH),
                new SqlParameter("@TenCongTy", tenCongTy),
                new SqlParameter("@NguoiDaiDien", nguoiDD),
                new SqlParameter("@MaSoThue", mst),
                new SqlParameter("@DienThoai", dt),
                new SqlParameter("@Email", string.IsNullOrEmpty(email) ? (object)DBNull.Value : email),
                new SqlParameter("@DiaChi", diaChi)
            };

            if (Db.ThucThi(sqlInsert, p) > 0)
            {
                FormHelper.ThongBao($"Thêm khách hàng {tenCongTy} thành công!", true);
                TaiDanhSachKhachHang();
            }
        }

        private void btnSuaKH_Click(object sender, EventArgs e)
        {
            string maKH = txtMaKH.Text.Trim();
            if (string.IsNullOrEmpty(maKH))
            {
                FormHelper.ThongBao("Vui lòng chọn khách hàng cần cập nhật!", false);
                return;
            }

            string sqlUpdate = @"UPDATE KhachHang 
                                 SET TenCongTy = @TenCongTy, NguoiDaiDien = @NguoiDaiDien, 
                                     MaSoThue = @MaSoThue, DienThoai = @DienThoai, 
                                     Email = @Email, DiaChi = @DiaChi 
                                 WHERE MaKH = @MaKH";
            SqlParameter[] p = {
                new SqlParameter("@MaKH", maKH),
                new SqlParameter("@TenCongTy", txtTenCongTy.Text.Trim()),
                new SqlParameter("@NguoiDaiDien", txtNguoiDaiDien.Text.Trim()),
                new SqlParameter("@MaSoThue", txtMST.Text.Trim()),
                new SqlParameter("@DienThoai", txtDienThoai.Text.Trim()),
                new SqlParameter("@Email", txtEmail.Text.Trim()),
                new SqlParameter("@DiaChi", txtDiaChi.Text.Trim())
            };

            if (Db.ThucThi(sqlUpdate, p) > 0)
            {
                FormHelper.ThongBao($"Cập nhật doanh nghiệp {txtTenCongTy.Text.Trim()} thành công!", true);
                TaiDanhSachKhachHang();
            }
        }

        private void btnXoaKH_Click(object sender, EventArgs e)
        {
            string maKH = txtMaKH.Text.Trim();
            if (string.IsNullOrEmpty(maKH))
            {
                FormHelper.ThongBao("Vui lòng chọn khách hàng cần xóa!", false);
                return;
            }

            string sqlCheckHD = "SELECT COUNT(*) FROM HopDongThue WHERE MaKH = @MaKH";
            SqlParameter[] pCheck = { new SqlParameter("@MaKH", maKH) };
            if (Convert.ToInt32(Db.LayGiaTri(sqlCheckHD, pCheck)) > 0)
            {
                FormHelper.ThongBao("Không thể xóa khách hàng này vì đã có Hợp đồng thuê!", false);
                return;
            }

            if (MessageBox.Show($"Bạn chắc chắn muốn xóa khách hàng {maKH}?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                string sqlDelete = "DELETE FROM KhachHang WHERE MaKH = @MaKH";
                SqlParameter[] p = { new SqlParameter("@MaKH", maKH) };
                if (Db.ThucThi(sqlDelete, p) > 0)
                {
                    FormHelper.ThongBao($"Đã xóa khách hàng {maKH}!", true);
                    TaiDanhSachKhachHang();
                    btnLamMoiKH_Click(sender, e);
                }
            }
        }

        private void btnLamMoiKH_Click(object sender, EventArgs e)
        {
            TaoMaKHMoi();
            txtTenCongTy.Clear();
            txtNguoiDaiDien.Clear();
            txtMST.Clear();
            txtDienThoai.Clear();
            txtEmail.Clear();
            txtDiaChi.Clear();
            TaiDanhSachKhachHang();
        }

        private void btnDong_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}