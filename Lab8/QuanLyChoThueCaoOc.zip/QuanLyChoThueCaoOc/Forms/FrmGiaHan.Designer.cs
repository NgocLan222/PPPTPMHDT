﻿namespace QuanLyChoThueCaoOc.Forms
{
    partial class FrmGiaHan
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code
        private void InitializeComponent()
        {
            this.lblTieuDe = new System.Windows.Forms.Label();
            this.gbThongTin = new System.Windows.Forms.GroupBox();
            this.txtLyDo = new System.Windows.Forms.TextBox();
            this.lblLyDo = new System.Windows.Forms.Label();
            this.dtpNgayKetThucMoi = new System.Windows.Forms.DateTimePicker();
            this.lblNgayMoi = new System.Windows.Forms.Label();
            this.numThoiGianGiaHan = new System.Windows.Forms.NumericUpDown();
            this.lblThoiGian = new System.Windows.Forms.Label();
            this.dtpNgayLap = new System.Windows.Forms.DateTimePicker();
            this.lblNgayLap = new System.Windows.Forms.Label();
            this.cboPhong = new System.Windows.Forms.ComboBox();
            this.lblPhong = new System.Windows.Forms.Label();
            this.cboHopDong = new System.Windows.Forms.ComboBox();
            this.lblHopDong = new System.Windows.Forms.Label();
            this.txtMaPGH = new System.Windows.Forms.TextBox();
            this.lblMaPGH = new System.Windows.Forms.Label();
            this.btnKiemTra = new System.Windows.Forms.Button();
            this.btnXacNhan = new System.Windows.Forms.Button();
            this.btnLamMoi = new System.Windows.Forms.Button();
            this.btnDong = new System.Windows.Forms.Button();
            this.gbDanhSach = new System.Windows.Forms.GroupBox();
            this.dgvGiaHan = new System.Windows.Forms.DataGridView();
            this.gbThongTin.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numThoiGianGiaHan)).BeginInit();
            this.gbDanhSach.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvGiaHan)).BeginInit();
            this.SuspendLayout();
            // 
            // lblTieuDe
            // 
            this.lblTieuDe.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblTieuDe.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold);
            this.lblTieuDe.ForeColor = System.Drawing.Color.DarkBlue;
            this.lblTieuDe.Location = new System.Drawing.Point(0, 0);
            this.lblTieuDe.Name = "lblTieuDe";
            this.lblTieuDe.Size = new System.Drawing.Size(934, 60);
            this.lblTieuDe.TabIndex = 0;
            this.lblTieuDe.Text = "LẬP VÀ DUYỆT PHIẾU GIA HẠN THUÊ VĂN PHÒNG";
            this.lblTieuDe.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // gbThongTin
            // 
            this.gbThongTin.Controls.Add(this.txtLyDo);
            this.gbThongTin.Controls.Add(this.lblLyDo);
            this.gbThongTin.Controls.Add(this.dtpNgayKetThucMoi);
            this.gbThongTin.Controls.Add(this.lblNgayMoi);
            this.gbThongTin.Controls.Add(this.numThoiGianGiaHan);
            this.gbThongTin.Controls.Add(this.lblThoiGian);
            this.gbThongTin.Controls.Add(this.dtpNgayLap);
            this.gbThongTin.Controls.Add(this.lblNgayLap);
            this.gbThongTin.Controls.Add(this.cboPhong);
            this.gbThongTin.Controls.Add(this.lblPhong);
            this.gbThongTin.Controls.Add(this.cboHopDong);
            this.gbThongTin.Controls.Add(this.lblHopDong);
            this.gbThongTin.Controls.Add(this.txtMaPGH);
            this.gbThongTin.Controls.Add(this.lblMaPGH);
            this.gbThongTin.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.gbThongTin.Location = new System.Drawing.Point(20, 65);
            this.gbThongTin.Name = "gbThongTin";
            this.gbThongTin.Size = new System.Drawing.Size(894, 185);
            this.gbThongTin.TabIndex = 1;
            this.gbThongTin.TabStop = false;
            this.gbThongTin.Text = "Thông tin đề nghị gia hạn";
            // 
            // txtLyDo
            // 
            this.txtLyDo.Location = new System.Drawing.Point(595, 110);
            this.txtLyDo.Multiline = true;
            this.txtLyDo.Name = "txtLyDo";
            this.txtLyDo.Size = new System.Drawing.Size(275, 60);
            this.txtLyDo.TabIndex = 13;
            // 
            // lblLyDo
            // 
            this.lblLyDo.AutoSize = true;
            this.lblLyDo.Location = new System.Drawing.Point(465, 113);
            this.lblLyDo.Name = "lblLyDo";
            this.lblLyDo.Size = new System.Drawing.Size(51, 21);
            this.lblLyDo.TabIndex = 12;
            this.lblLyDo.Text = "Lý do:";
            // 
            // dtpNgayKetThucMoi
            // 
            this.dtpNgayKetThucMoi.CustomFormat = "dd/MM/yyyy";
            this.dtpNgayKetThucMoi.Enabled = false;
            this.dtpNgayKetThucMoi.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpNgayKetThucMoi.Location = new System.Drawing.Point(595, 70);
            this.dtpNgayKetThucMoi.Name = "dtpNgayKetThucMoi";
            this.dtpNgayKetThucMoi.Size = new System.Drawing.Size(275, 29);
            this.dtpNgayKetThucMoi.TabIndex = 11;
            // 
            // lblNgayMoi
            // 
            this.lblNgayMoi.AutoSize = true;
            this.lblNgayMoi.Location = new System.Drawing.Point(465, 73);
            this.lblNgayMoi.Name = "lblNgayMoi";
            this.lblNgayMoi.Size = new System.Drawing.Size(113, 21);
            this.lblNgayMoi.TabIndex = 10;
            this.lblNgayMoi.Text = "Hạn ngày mới:";
            // 
            // numThoiGianGiaHan
            // 
            this.numThoiGianGiaHan.Location = new System.Drawing.Point(595, 30);
            this.numThoiGianGiaHan.Maximum = new decimal(new int[] { 36, 0, 0, 0 });
            this.numThoiGianGiaHan.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
            this.numThoiGianGiaHan.Name = "numThoiGianGiaHan";
            this.numThoiGianGiaHan.Size = new System.Drawing.Size(275, 29);
            this.numThoiGianGiaHan.TabIndex = 9;
            this.numThoiGianGiaHan.Value = new decimal(new int[] { 3, 0, 0, 0 });
            // 
            // lblThoiGian
            // 
            this.lblThoiGian.AutoSize = true;
            this.lblThoiGian.Location = new System.Drawing.Point(465, 33);
            this.lblThoiGian.Name = "lblThoiGian";
            this.lblThoiGian.Size = new System.Drawing.Size(126, 21);
            this.lblThoiGian.TabIndex = 8;
            this.lblThoiGian.Text = "Số tháng gia hạn:";
            // 
            // dtpNgayLap
            // 
            this.dtpNgayLap.CustomFormat = "dd/MM/yyyy";
            this.dtpNgayLap.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpNgayLap.Location = new System.Drawing.Point(145, 145);
            this.dtpNgayLap.Name = "dtpNgayLap";
            this.dtpNgayLap.Size = new System.Drawing.Size(285, 29);
            this.dtpNgayLap.TabIndex = 7;
            // 
            // lblNgayLap
            // 
            this.lblNgayLap.AutoSize = true;
            this.lblNgayLap.Location = new System.Drawing.Point(20, 150);
            this.lblNgayLap.Name = "lblNgayLap";
            this.lblNgayLap.Size = new System.Drawing.Size(75, 21);
            this.lblNgayLap.TabIndex = 6;
            this.lblNgayLap.Text = "Ngày lập:";
            // 
            // cboPhong
            // 
            this.cboPhong.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboPhong.FormattingEnabled = true;
            this.cboPhong.Location = new System.Drawing.Point(145, 107);
            this.cboPhong.Name = "cboPhong";
            this.cboPhong.Size = new System.Drawing.Size(285, 29);
            this.cboPhong.TabIndex = 5;
            // 
            // lblPhong
            // 
            this.lblPhong.AutoSize = true;
            this.lblPhong.Location = new System.Drawing.Point(20, 110);
            this.lblPhong.Name = "lblPhong";
            this.lblPhong.Size = new System.Drawing.Size(98, 21);
            this.lblPhong.TabIndex = 4;
            this.lblPhong.Text = "Phòng thuê:";
            // 
            // cboHopDong
            // 
            this.cboHopDong.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboHopDong.FormattingEnabled = true;
            this.cboHopDong.Location = new System.Drawing.Point(145, 68);
            this.cboHopDong.Name = "cboHopDong";
            this.cboHopDong.Size = new System.Drawing.Size(285, 29);
            this.cboHopDong.TabIndex = 3;
            // 
            // lblHopDong
            // 
            this.lblHopDong.AutoSize = true;
            this.lblHopDong.Location = new System.Drawing.Point(20, 71);
            this.lblHopDong.Name = "lblHopDong";
            this.lblHopDong.Size = new System.Drawing.Size(107, 21);
            this.lblHopDong.TabIndex = 2;
            this.lblHopDong.Text = "Hợp đồng gốc:";
            // 
            // txtMaPGH
            // 
            this.txtMaPGH.Location = new System.Drawing.Point(145, 30);
            this.txtMaPGH.Name = "txtMaPGH";
            this.txtMaPGH.Size = new System.Drawing.Size(285, 29);
            this.txtMaPGH.TabIndex = 1;
            // 
            // lblMaPGH
            // 
            this.lblMaPGH.AutoSize = true;
            this.lblMaPGH.Location = new System.Drawing.Point(20, 33);
            this.lblMaPGH.Name = "lblMaPGH";
            this.lblMaPGH.Size = new System.Drawing.Size(102, 21);
            this.lblMaPGH.TabIndex = 0;
            this.lblMaPGH.Text = "Mã phiếu GH:";
            // 
            // btnKiemTra
            // 
            this.btnKiemTra.BackColor = System.Drawing.Color.LightSkyBlue;
            this.btnKiemTra.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnKiemTra.Location = new System.Drawing.Point(165, 260);
            this.btnKiemTra.Name = "btnKiemTra";
            this.btnKiemTra.Size = new System.Drawing.Size(175, 42);
            this.btnKiemTra.TabIndex = 2;
            this.btnKiemTra.Text = "Kiểm tra điều kiện";
            this.btnKiemTra.UseVisualStyleBackColor = false;
            this.btnKiemTra.Click += new System.EventHandler(this.btnKiemTra_Click);
            // 
            // btnXacNhan
            // 
            this.btnXacNhan.BackColor = System.Drawing.Color.LightGreen;
            this.btnXacNhan.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnXacNhan.Location = new System.Drawing.Point(365, 260);
            this.btnXacNhan.Name = "btnXacNhan";
            this.btnXacNhan.Size = new System.Drawing.Size(175, 42);
            this.btnXacNhan.TabIndex = 3;
            this.btnXacNhan.Text = "Xác nhận gia hạn";
            this.btnXacNhan.UseVisualStyleBackColor = false;
            this.btnXacNhan.Click += new System.EventHandler(this.btnXacNhan_Click);
            // 
            // btnLamMoi
            // 
            this.btnLamMoi.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnLamMoi.Location = new System.Drawing.Point(565, 260);
            this.btnLamMoi.Name = "btnLamMoi";
            this.btnLamMoi.Size = new System.Drawing.Size(120, 42);
            this.btnLamMoi.TabIndex = 4;
            this.btnLamMoi.Text = "Làm mới";
            this.btnLamMoi.UseVisualStyleBackColor = true;
            this.btnLamMoi.Click += new System.EventHandler(this.btnLamMoi_Click);
            // 
            // btnDong
            // 
            this.btnDong.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnDong.Location = new System.Drawing.Point(705, 260);
            this.btnDong.Name = "btnDong";
            this.btnDong.Size = new System.Drawing.Size(120, 42);
            this.btnDong.TabIndex = 5;
            this.btnDong.Text = "Đóng";
            this.btnDong.UseVisualStyleBackColor = true;
            this.btnDong.Click += new System.EventHandler(this.btnDong_Click);
            // 
            // gbDanhSach
            // 
            this.gbDanhSach.Controls.Add(this.dgvGiaHan);
            this.gbDanhSach.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.gbDanhSach.Location = new System.Drawing.Point(20, 315);
            this.gbDanhSach.Name = "gbDanhSach";
            this.gbDanhSach.Size = new System.Drawing.Size(894, 255);
            this.gbDanhSach.TabIndex = 6;
            this.gbDanhSach.TabStop = false;
            this.gbDanhSach.Text = "Danh sách các phiếu gia hạn đã lập";
            // 
            // dgvGiaHan
            // 
            this.dgvGiaHan.AllowUserToAddRows = false;
            this.dgvGiaHan.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvGiaHan.BackgroundColor = System.Drawing.Color.White;
            this.dgvGiaHan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvGiaHan.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvGiaHan.Location = new System.Drawing.Point(3, 25);
            this.dgvGiaHan.Name = "dgvGiaHan";
            this.dgvGiaHan.ReadOnly = true;
            this.dgvGiaHan.RowHeadersWidth = 51;
            this.dgvGiaHan.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvGiaHan.Size = new System.Drawing.Size(888, 227);
            this.dgvGiaHan.TabIndex = 0;
            // 
            // FrmGiaHan
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(248)))), ((int)(((byte)(250)))));
            this.ClientSize = new System.Drawing.Size(934, 585);
            this.Controls.Add(this.gbDanhSach);
            this.Controls.Add(this.btnDong);
            this.Controls.Add(this.btnLamMoi);
            this.Controls.Add(this.btnXacNhan);
            this.Controls.Add(this.btnKiemTra);
            this.Controls.Add(this.gbThongTin);
            this.Controls.Add(this.lblTieuDe);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "FrmGiaHan";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quản lý Gia hạn Hợp đồng Thuê Văn phòng";
            this.Load += new System.EventHandler(this.FrmGiaHan_Load);
            this.gbThongTin.ResumeLayout(false);
            this.gbThongTin.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numThoiGianGiaHan)).EndInit();
            this.gbDanhSach.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvGiaHan)).EndInit();
            this.ResumeLayout(false);
        }
        #endregion

        private System.Windows.Forms.Label lblTieuDe;
        private System.Windows.Forms.GroupBox gbThongTin;
        private System.Windows.Forms.Label lblMaPGH;
        private System.Windows.Forms.TextBox txtMaPGH;
        private System.Windows.Forms.Label lblHopDong;
        private System.Windows.Forms.ComboBox cboHopDong;
        private System.Windows.Forms.Label lblPhong;
        private System.Windows.Forms.ComboBox cboPhong;
        private System.Windows.Forms.Label lblNgayLap;
        private System.Windows.Forms.DateTimePicker dtpNgayLap;
        private System.Windows.Forms.Label lblThoiGian;
        private System.Windows.Forms.NumericUpDown numThoiGianGiaHan;
        private System.Windows.Forms.Label lblNgayMoi;
        private System.Windows.Forms.DateTimePicker dtpNgayKetThucMoi;
        private System.Windows.Forms.Label lblLyDo;
        private System.Windows.Forms.TextBox txtLyDo;
        private System.Windows.Forms.Button btnKiemTra;
        private System.Windows.Forms.Button btnXacNhan;
        private System.Windows.Forms.Button btnLamMoi;
        private System.Windows.Forms.Button btnDong;
        private System.Windows.Forms.GroupBox gbDanhSach;
        private System.Windows.Forms.DataGridView dgvGiaHan;
    }
}