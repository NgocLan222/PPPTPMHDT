﻿using System;
using System.Windows.Forms;

namespace QuanLyChoThueCaoOc.Forms
{
    public partial class FrmMain : Form
    {
        public FrmMain()
        {
            InitializeComponent();
        }

        private void btnGiaHan_Click(object sender, EventArgs e)
        {
            
            new FrmGiaHan().ShowDialog();
        }

        private void btnPhongKH_Click(object sender, EventArgs e)
        {
            new FrmPhong_KhachHang().ShowDialog();
        }

        private void btnHopDong_Click(object sender, EventArgs e)
        {
            new FrmHopDongThue().ShowDialog();
        }

        private void btnHoaDon_Click(object sender, EventArgs e)
        {
            new FrmHoaDon().ShowDialog();
        }

        private void btnNhanVien_Click(object sender, EventArgs e)
        {
            new FrmNhanVien_TheXe().ShowDialog();
        }

        private void btnKiemTra_Click(object sender, EventArgs e)
        {
            new FrmKiemTra_XuPhat().ShowDialog();
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Bạn có muốn thoát chương trình?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }
    }
}