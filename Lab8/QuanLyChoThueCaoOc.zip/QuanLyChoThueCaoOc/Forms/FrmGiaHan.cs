﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using QuanLyChoThueCaoOc.Data;

namespace QuanLyChoThueCaoOc.Forms
{
    public partial class FrmGiaHan : Form
    {
        public FrmGiaHan()
        {
            InitializeComponent();
            cboHopDong.SelectedIndexChanged += cboHopDong_SelectedIndexChanged;
            numThoiGianGiaHan.ValueChanged += numThoiGianGiaHan_ValueChanged;
        }

        private void FrmGiaHan_Load(object sender, EventArgs e)
        {
            TaiDanhSachHopDong();
            TaiDanhSachPhieuGiaHan();
            TaoMaTuDong();
        }

        private void TaoMaTuDong()
        {
            txtMaPGH.Text = "PGH" + DateTime.Now.ToString("yyMMddHHmm").Substring(2, 6);
        }

        private void TaiDanhSachHopDong()
        {
            string sql = "SELECT MaHD, MaHD + ' - ' + MaKH AS HienThi FROM HopDongThue WHERE TrangThai = N'Hiệu lực'";
            DataTable dt = Db.LayBang(sql);
            FormHelper.Nap(cboHopDong, dt, "HienThi", "MaHD");
            TaiDanhSachPhongTheoHD();
        }

        private void TaiDanhSachPhongTheoHD()
        {
            string maHD = FormHelper.Gia(cboHopDong);
            if (string.IsNullOrEmpty(maHD)) return;

            string sql = @"SELECT p.MaPhong, p.MaPhong + ' - ' + p.TenPhong AS HienThi 
                           FROM ChiTietThuePhong ct 
                           JOIN Phong p ON ct.MaPhong = p.MaPhong 
                           WHERE ct.MaHD = @MaHD";
            SqlParameter[] p = { new SqlParameter("@MaHD", maHD) };
            DataTable dt = Db.LayBang(sql, p);
            FormHelper.Nap(cboPhong, dt, "HienThi", "MaPhong");

            TinhNgayKetThucMoi();
        }

        private void TaiDanhSachPhieuGiaHan()
        {
            string sql = @"SELECT pgh.MaPGH, pgh.MaHD, pgh.MaPhong, pgh.NgayLap, 
                                  pgh.ThoiGianGiaHan, pgh.NgayKetThucMoi, pgh.TrangThaiDuyet, pgh.LyDo 
                           FROM PhieuGiaHan pgh 
                           ORDER BY pgh.NgayLap DESC";
            dgvGiaHan.DataSource = Db.LayBang(sql);
        }

        private void cboHopDong_SelectedIndexChanged(object sender, EventArgs e)
        {
            TaiDanhSachPhongTheoHD();
        }

        private void numThoiGianGiaHan_ValueChanged(object sender, EventArgs e)
        {
            TinhNgayKetThucMoi();
        }

        private void TinhNgayKetThucMoi()
        {
            string maHD = FormHelper.Gia(cboHopDong);
            if (string.IsNullOrEmpty(maHD)) return;

            string sql = "SELECT NgayKetThuc FROM HopDongThue WHERE MaHD = @MaHD";
            SqlParameter[] p = { new SqlParameter("@MaHD", maHD) };
            object kq = Db.LayGiaTri(sql, p);

            if (kq != null && kq != DBNull.Value)
            {
                DateTime ngayHienTai = Convert.ToDateTime(kq);
                int thangCongThem = (int)numThoiGianGiaHan.Value;
                dtpNgayKetThucMoi.Value = ngayHienTai.AddMonths(thangCongThem);
            }
        }

        // Logic kiểm tra điều kiện (Bám sát Sequence Diagram Câu 6)
        private bool KiemTraDieuKienGiaHan(out string lyDoLoi)
        {
            lyDoLoi = "";
            string maHD = FormHelper.Gia(cboHopDong);
            string maPhong = FormHelper.Gia(cboPhong);
            int thoiGianGiaHan = (int)numThoiGianGiaHan.Value;

            if (string.IsNullOrEmpty(maHD) || string.IsNullOrEmpty(maPhong))
            {
                lyDoLoi = "Vui lòng chọn Hợp đồng và Phòng cần gia hạn!";
                return false;
            }

            // 1. Kiểm tra thời hạn: ThoiGianGiaHan <= 1/2 ThoiHanThue gốc
            string sqlHD = "SELECT ThoiHanThue FROM HopDongThue WHERE MaHD = @MaHD";
            SqlParameter[] pHD = { new SqlParameter("@MaHD", maHD) };
            object kqHD = Db.LayGiaTri(sqlHD, pHD);
            if (kqHD == null)
            {
                lyDoLoi = "Không tìm thấy thông tin hợp đồng gốc!";
                return false;
            }

            int thoiHanGoc = Convert.ToInt32(kqHD);
            double thoiGianChoPhep = thoiHanGoc / 2.0;

            if (thoiGianGiaHan > thoiGianChoPhep)
            {
                lyDoLoi = $"Số tháng gia hạn ({thoiGianGiaHan} tháng) đã vượt quá 1/2 thời hạn thuê gốc ({thoiHanGoc} tháng / 2 = {thoiGianChoPhep} tháng)!";
                return false;
            }

            // 2. Kiểm tra nợ phí: Không còn hóa đơn tiền phòng hoặc tiền dịch vụ chưa thanh toán
            string sqlNo = @"SELECT COUNT(*) FROM HoaDon 
                             WHERE MaHD = @MaHD AND MaPhong = @MaPhong 
                             AND TrangThai = N'Chưa thanh toán'";
            SqlParameter[] pNo = {
                new SqlParameter("@MaHD", maHD),
                new SqlParameter("@MaPhong", maPhong)
            };
            int soHoaDonNo = Convert.ToInt32(Db.LayGiaTri(sqlNo, pNo));

            if (soHoaDonNo > 0)
            {
                lyDoLoi = $"Phòng {maPhong} thuộc Hợp đồng {maHD} hiện còn {soHoaDonNo} hóa đơn chưa thanh toán. Phải thanh toán hết nợ phí mới được gia hạn!";
                return false;
            }

            return true;
        }

        private void btnKiemTra_Click(object sender, EventArgs e)
        {
            string loi;
            if (KiemTraDieuKienGiaHan(out loi))
            {
                FormHelper.ThongBao("Đủ điều kiện gia hạn hợp đồng! (Thời gian hợp lệ và không nợ phí).", true);
            }
            else
            {
                FormHelper.ThongBao(loi, false);
            }
        }

        private void btnXacNhan_Click(object sender, EventArgs e)
        {
            string maPGH = txtMaPGH.Text.Trim();
            if (string.IsNullOrEmpty(maPGH))
            {
                FormHelper.ThongBao("Vui lòng nhập Mã phiếu gia hạn!", false);
                return;
            }

            // Kiểm tra trùng mã
            string sqlCheck = "SELECT COUNT(*) FROM PhieuGiaHan WHERE MaPGH = @MaPGH";
            SqlParameter[] pCheck = { new SqlParameter("@MaPGH", maPGH) };
            if (Convert.ToInt32(Db.LayGiaTri(sqlCheck, pCheck)) > 0)
            {
                FormHelper.ThongBao("Mã phiếu gia hạn đã tồn tại, vui lòng đổi mã khác!", false);
                return;
            }

            string loi;
            if (!KiemTraDieuKienGiaHan(out loi))
            {
                FormHelper.ThongBao("Từ chối gia hạn: " + loi, false);
                return;
            }

            // Thỏa mãn điều kiện -> Thêm phiếu gia hạn
            string sqlInsert = @"INSERT INTO PhieuGiaHan (MaPGH, NgayLap, ThoiGianGiaHan, NgayKetThucMoi, TrangThaiDuyet, LyDo, MaHD, MaPhong)
                                 VALUES (@MaPGH, @NgayLap, @ThoiGian, @NgayMoi, N'Đã duyệt', @LyDo, @MaHD, @MaPhong)";
            SqlParameter[] pInsert = {
                new SqlParameter("@MaPGH", maPGH),
                new SqlParameter("@NgayLap", dtpNgayLap.Value.Date),
                new SqlParameter("@ThoiGian", (int)numThoiGianGiaHan.Value),
                new SqlParameter("@NgayMoi", dtpNgayKetThucMoi.Value.Date),
                new SqlParameter("@LyDo", txtLyDo.Text.Trim()),
                new SqlParameter("@MaHD", FormHelper.Gia(cboHopDong)),
                new SqlParameter("@MaPhong", FormHelper.Gia(cboPhong))
            };

            if (Db.ThucThi(sqlInsert, pInsert) > 0)
            {
                FormHelper.ThongBao("Lập và phê duyệt Phiếu gia hạn thành công!", true);
                TaiDanhSachPhieuGiaHan();
                TaoMaTuDong();
            }
            else
            {
                FormHelper.ThongBao("Không thể lưu phiếu gia hạn, vui lòng kiểm tra lại!", false);
            }
        }

        private void btnLamMoi_Click(object sender, EventArgs e)
        {
            TaoMaTuDong();
            txtLyDo.Clear();
            numThoiGianGiaHan.Value = 3;
            TaiDanhSachPhieuGiaHan();
        }

        private void btnDong_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}