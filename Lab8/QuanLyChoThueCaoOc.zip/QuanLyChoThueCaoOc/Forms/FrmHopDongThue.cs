﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using QuanLyChoThueCaoOc.Data;

namespace QuanLyChoThueCaoOc.Forms
{
    public partial class FrmHopDongThue : Form
    {
        // Bảng tạm chứa các văn phòng được chọn cho hợp đồng này
        private DataTable dtPhongChon = new DataTable();

        public FrmHopDongThue()
        {
            InitializeComponent();
            KhoiTaoBangTam();
            dtpNgayBatDau.ValueChanged += dtpNgayBatDau_ValueChanged;
            numThoiHanThue.ValueChanged += numThoiHanThue_ValueChanged;
        }

        private void KhoiTaoBangTam()
        {
            dtPhongChon.Columns.Add("MaPhong", typeof(string));
            dtPhongChon.Columns.Add("TenPhong", typeof(string));
            dtPhongChon.Columns.Add("DonGiaThue", typeof(decimal));
            dtPhongChon.Columns.Add("GhiChu", typeof(string));
            dgvPhongChon.DataSource = dtPhongChon;
        }

        private void FrmHopDongThue_Load(object sender, EventArgs e)
        {
            TaiDanhSachKhachHang();
            TaiDanhSachPhongTrong();
            TaiDanhSachHopDong();
            TaoMaTuDong();
            CapNhatNgayKetThuc();
        }

        private void TaoMaTuDong()
        {
            txtMaHD.Text = "HD" + DateTime.Now.ToString("yyMMddHHmm").Substring(2, 6);
        }

        private void TaiDanhSachKhachHang()
        {
            string sql = "SELECT MaKH, MaKH + ' - ' + TenCongTy AS HienThi FROM KhachHang";
            DataTable dt = Db.LayBang(sql);
            FormHelper.Nap(cboKhachHang, dt, "HienThi", "MaKH");
        }

        private void TaiDanhSachPhongTrong()
        {
            string sql = "SELECT MaPhong, MaPhong + ' (' + TenPhong + ' - ' + CAST(DonGiaThue AS VARCHAR) + ' đ)' AS HienThi, DonGiaThue, TenPhong FROM Phong WHERE TrangThai = N'Trống'";
            DataTable dt = Db.LayBang(sql);
            FormHelper.Nap(cboPhongTrong, dt, "HienThi", "MaPhong");
        }

        private void TaiDanhSachHopDong()
        {
            string sql = @"SELECT hd.MaHD, kh.TenCongTy, hd.NgayKy, hd.NgayBatDau, hd.NgayKetThuc, 
                                  hd.ThoiHanThue, hd.TienCoc, hd.TongTien6ThangDau, hd.TrangThai 
                           FROM HopDongThue hd 
                           JOIN KhachHang kh ON hd.MaKH = kh.MaKH 
                           ORDER BY hd.NgayKy DESC";
            dgvHopDong.DataSource = Db.LayBang(sql);
        }

        private void dtpNgayBatDau_ValueChanged(object sender, EventArgs e)
        {
            CapNhatNgayKetThuc();
        }

        private void numThoiHanThue_ValueChanged(object sender, EventArgs e)
        {
            CapNhatNgayKetThuc();
        }

        private void CapNhatNgayKetThuc()
        {
            int thang = (int)numThoiHanThue.Value;
            dtpNgayKetThuc.Value = dtpNgayBatDau.Value.AddMonths(thang);
        }

        private void TinhTongTien()
        {
            decimal tong1Thang = 0;
            foreach (DataRow r in dtPhongChon.Rows)
            {
                tong1Thang += Convert.ToDecimal(r["DonGiaThue"]);
            }
            decimal tong6Thang = tong1Thang * 6;

            txtTien1Thang.Text = tong1Thang.ToString("N0") + " VNĐ";
            txtTong6Thang.Text = tong6Thang.ToString("N0") + " VNĐ";

            if (numTienCoc.Value == 0)
            {
                numTienCoc.Value = tong1Thang; // Gợi ý cọc 1 tháng tiền thuê
            }
        }

        private void btnThemPhong_Click(object sender, EventArgs e)
        {
            string maPhong = FormHelper.Gia(cboPhongTrong);
            if (string.IsNullOrEmpty(maPhong))
            {
                FormHelper.ThongBao("Không có phòng trống nào được chọn!", false);
                return;
            }

            // Kiểm tra phòng đã được thêm vào danh sách hợp đồng này chưa
            foreach (DataRow r in dtPhongChon.Rows)
            {
                if (r["MaPhong"].ToString() == maPhong)
                {
                    FormHelper.ThongBao("Phòng này đã được thêm vào hợp đồng rồi!", false);
                    return;
                }
            }

            // Lấy thông tin giá phòng từ database
            string sql = "SELECT TenPhong, DonGiaThue FROM Phong WHERE MaPhong = @MaPhong";
            SqlParameter[] p = { new SqlParameter("@MaPhong", maPhong) };
            DataTable dt = Db.LayBang(sql, p);

            if (dt.Rows.Count > 0)
            {
                string tenPhong = dt.Rows[0]["TenPhong"].ToString();
                decimal donGia = Convert.ToDecimal(dt.Rows[0]["DonGiaThue"]);
                string ghiChu = txtGhiChuPhong.Text.Trim();

                dtPhongChon.Rows.Add(maPhong, tenPhong, donGia, ghiChu);
                TinhTongTien();
                txtGhiChuPhong.Clear();
            }
        }

        private void btnXoaPhong_Click(object sender, EventArgs e)
        {
            if (dgvPhongChon.CurrentRow != null)
            {
                int index = dgvPhongChon.CurrentRow.Index;
                dtPhongChon.Rows.RemoveAt(index);
                TinhTongTien();
            }
            else
            {
                FormHelper.ThongBao("Vui lòng chọn phòng trong bảng để xóa!", false);
            }
        }

        private void btnLuuHopDong_Click(object sender, EventArgs e)
        {
            string maHD = txtMaHD.Text.Trim();
            string maKH = FormHelper.Gia(cboKhachHang);

            if (string.IsNullOrEmpty(maHD) || string.IsNullOrEmpty(maKH))
            {
                FormHelper.ThongBao("Vui lòng nhập Mã HĐ và chọn Khách hàng!", false);
                return;
            }

            if (dtPhongChon.Rows.Count == 0)
            {
                FormHelper.ThongBao("Hợp đồng bắt buộc phải chọn ít nhất 1 văn phòng thuê!", false);
                return;
            }

            if (numThoiHanThue.Value < 6)
            {
                FormHelper.ThongBao("Theo quy định, thời hạn thuê tối thiểu phải từ 6 tháng trở lên!", false);
                return;
            }

            // Kiểm tra trùng mã hợp đồng
            string sqlCheck = "SELECT COUNT(*) FROM HopDongThue WHERE MaHD = @MaHD";
            SqlParameter[] pCheck = { new SqlParameter("@MaHD", maHD) };
            if (Convert.ToInt32(Db.LayGiaTri(sqlCheck, pCheck)) > 0)
            {
                FormHelper.ThongBao("Mã Hợp đồng đã tồn tại, vui lòng đổi mã khác!", false);
                return;
            }

            decimal tong1Thang = 0;
            foreach (DataRow r in dtPhongChon.Rows)
            {
                tong1Thang += Convert.ToDecimal(r["DonGiaThue"]);
            }
            decimal tong6ThangDau = tong1Thang * 6;
            decimal tienCoc = numTienCoc.Value;

            // Thực hiện lưu hợp đồng, danh sách chi tiết phòng và cập nhật trạng thái phòng trong 1 Transaction
            using (SqlConnection conn = Db.GetConnection())
            {
                conn.Open();
                SqlTransaction trans = conn.BeginTransaction();
                try
                {
                    // 1. Thêm vào bảng HopDongThue
                    string sqlHD = @"INSERT INTO HopDongThue (MaHD, NgayKy, NgayBatDau, NgayKetThuc, ThoiHanThue, TienCoc, TongTien6ThangDau, TrangThai, MaKH)
                                     VALUES (@MaHD, @NgayKy, @NgayBatDau, @NgayKetThuc, @ThoiHanThue, @TienCoc, @TongTien6ThangDau, N'Hiệu lực', @MaKH)";
                    using (SqlCommand cmdHD = new SqlCommand(sqlHD, conn, trans))
                    {
                        cmdHD.Parameters.AddWithValue("@MaHD", maHD);
                        cmdHD.Parameters.AddWithValue("@NgayKy", dtpNgayKy.Value.Date);
                        cmdHD.Parameters.AddWithValue("@NgayBatDau", dtpNgayBatDau.Value.Date);
                        cmdHD.Parameters.AddWithValue("@NgayKetThuc", dtpNgayKetThuc.Value.Date);
                        cmdHD.Parameters.AddWithValue("@ThoiHanThue", (int)numThoiHanThue.Value);
                        cmdHD.Parameters.AddWithValue("@TienCoc", tienCoc);
                        cmdHD.Parameters.AddWithValue("@TongTien6ThangDau", tong6ThangDau);
                        cmdHD.Parameters.AddWithValue("@MaKH", maKH);
                        cmdHD.ExecuteNonQuery();
                    }

                    // 2. Thêm từng phòng vào ChiTietThuePhong & cập nhật trạng thái phòng thành 'Đang thuê'
                    int stt = 1;
                    foreach (DataRow r in dtPhongChon.Rows)
                    {
                        string maPhong = r["MaPhong"].ToString();
                        decimal donGia = Convert.ToDecimal(r["DonGiaThue"]);
                        string ghiChu = r["GhiChu"].ToString();
                        string maCTTP = "CT" + DateTime.Now.ToString("yyMM") + stt.ToString("D3");

                        // Lưu chi tiết thuê phòng
                        string sqlCT = @"INSERT INTO ChiTietThuePhong (MaCTTP, MaHD, MaPhong, DonGiaThue, TienThueThang, GhiChu)
                                         VALUES (@MaCTTP, @MaHD, @MaPhong, @DonGiaThue, @TienThueThang, @GhiChu)";
                        using (SqlCommand cmdCT = new SqlCommand(sqlCT, conn, trans))
                        {
                            cmdCT.Parameters.AddWithValue("@MaCTTP", maCTTP);
                            cmdCT.Parameters.AddWithValue("@MaHD", maHD);
                            cmdCT.Parameters.AddWithValue("@MaPhong", maPhong);
                            cmdCT.Parameters.AddWithValue("@DonGiaThue", donGia);
                            cmdCT.Parameters.AddWithValue("@TienThueThang", donGia);
                            cmdCT.Parameters.AddWithValue("@GhiChu", string.IsNullOrEmpty(ghiChu) ? (object)DBNull.Value : ghiChu);
                            cmdCT.ExecuteNonQuery();
                        }

                        // Cập nhật trạng thái phòng
                        string sqlPhong = "UPDATE Phong SET TrangThai = N'Đang thuê' WHERE MaPhong = @MaPhong";
                        using (SqlCommand cmdPhong = new SqlCommand(sqlPhong, conn, trans))
                        {
                            cmdPhong.Parameters.AddWithValue("@MaPhong", maPhong);
                            cmdPhong.ExecuteNonQuery();
                        }

                        stt++;
                    }

                    trans.Commit();
                    FormHelper.ThongBao($"Ký hợp đồng {maHD} thành công! Đã thu trước 6 tháng đầu ({tong6ThangDau:N0} đ) và tiền cọc ({tienCoc:N0} đ).", true);

                    // Làm mới dữ liệu
                    dtPhongChon.Clear();
                    TaiDanhSachPhongTrong();
                    TaiDanhSachHopDong();
                    TaoMaTuDong();
                    TinhTongTien();
                }
                catch (Exception ex)
                {
                    trans.Rollback();
                    FormHelper.ThongBao("Lỗi khi lưu hợp đồng: " + ex.Message, false);
                }
            }
        }

        private void btnLamMoi_Click(object sender, EventArgs e)
        {
            TaoMaTuDong();
            dtPhongChon.Clear();
            TaiDanhSachPhongTrong();
            TaiDanhSachHopDong();
            TinhTongTien();
        }

        private void btnDong_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}