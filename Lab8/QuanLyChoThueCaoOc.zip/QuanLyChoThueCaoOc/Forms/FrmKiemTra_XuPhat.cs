﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using QuanLyChoThueCaoOc.Data;

namespace QuanLyChoThueCaoOc.Forms
{
    public partial class FrmKiemTra_XuPhat : Form
    {
        public FrmKiemTra_XuPhat()
        {
            InitializeComponent();
            cboLoaiBB.SelectedIndexChanged += cboLoaiBB_SelectedIndexChanged;
        }

        private void FrmKiemTra_XuPhat_Load(object sender, EventArgs e)
        {
            cboLoaiBB.SelectedIndex = 0; // Mặc định: Kiểm tra định kỳ 1 năm
            cboTrangThai.SelectedIndex = 0; // Mặc định: Chờ xử lý
            TaiDanhSachPhong();
            TaiDanhSachBienBan();
            TaoMaTuDong();
        }

        private void TaoMaTuDong()
        {
            txtMaBB.Text = "BB" + DateTime.Now.ToString("yyMMddHHmm").Substring(2, 6);
        }

        private void TaiDanhSachPhong()
        {
            string sql = "SELECT MaPhong, MaPhong + ' - ' + TenPhong + ' (' + TrangThai + ')' AS HienThi FROM Phong";
            DataTable dt = Db.LayBang(sql);
            FormHelper.Nap(cboPhong, dt, "HienThi", "MaPhong");
        }

        private void TaiDanhSachBienBan()
        {
            string sql = @"SELECT bb.MaBB, bb.MaPhong, p.TenPhong, bb.LoaiBienBan, bb.NgayLap, 
                                  bb.MoTaKetQua, bb.SoTienPhat, bb.BienPhapKhacPhuc, bb.TrangThai 
                           FROM KiemTra_XuPhat bb 
                           JOIN Phong p ON bb.MaPhong = p.MaPhong 
                           ORDER BY bb.NgayLap DESC";
            dgvBienBan.DataSource = Db.LayBang(sql);
        }

        private void cboLoaiBB_SelectedIndexChanged(object sender, EventArgs e)
        {
            bool isXuPhat = (cboLoaiBB.SelectedIndex == 1);
            numTienPhat.Enabled = isXuPhat;
            txtBienPhap.Enabled = isXuPhat;

            if (isXuPhat)
            {
                if (numTienPhat.Value == 0) numTienPhat.Value = 5000000; // Gợi ý phạt 5 triệu vi phạm kết cấu
                txtBienPhap.Text = "Yêu cầu tháo dỡ, hoàn trả nguyên trạng kết cấu ban đầu trong vòng 7 ngày.";
            }
            else
            {
                numTienPhat.Value = 0;
                txtBienPhap.Text = "Lập kế hoạch bảo trì, tu sửa định kỳ theo tiêu chuẩn tòa nhà.";
            }
        }

        private void dgvBienBan_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvBienBan.CurrentRow == null) return;

            txtMaBB.Text = FormHelper.O(dgvBienBan, "MaBB");
            cboPhong.SelectedValue = FormHelper.O(dgvBienBan, "MaPhong");
            cboLoaiBB.SelectedItem = FormHelper.O(dgvBienBan, "LoaiBienBan");
            txtMoTa.Text = FormHelper.O(dgvBienBan, "MoTaKetQua");
            txtBienPhap.Text = FormHelper.O(dgvBienBan, "BienPhapKhacPhuc");
            cboTrangThai.SelectedItem = FormHelper.O(dgvBienBan, "TrangThai");

            decimal tienPhat = 0;
            decimal.TryParse(FormHelper.O(dgvBienBan, "SoTienPhat"), out tienPhat);
            numTienPhat.Value = tienPhat;
        }

        private void btnLapBB_Click(object sender, EventArgs e)
        {
            string maBB = txtMaBB.Text.Trim();
            string maPhong = FormHelper.Gia(cboPhong);
            string loaiBB = cboLoaiBB.SelectedItem?.ToString() ?? "Kiểm tra định kỳ 1 năm";
            string moTa = txtMoTa.Text.Trim();
            string bienPhap = txtBienPhap.Text.Trim();
            string trangThai = cboTrangThai.SelectedItem?.ToString() ?? "Chờ xử lý";
            decimal soTienPhat = (loaiBB == "Phạt thay đổi kết cấu") ? numTienPhat.Value : 0;

            if (string.IsNullOrEmpty(maBB) || string.IsNullOrEmpty(maPhong) || string.IsNullOrEmpty(moTa))
            {
                FormHelper.ThongBao("Vui lòng nhập đầy đủ Mã biên bản, Phòng kiểm tra và Mô tả kết quả!", false);
                return;
            }

            // Kiểm tra trùng mã biên bản
            string sqlCheck = "SELECT COUNT(*) FROM KiemTra_XuPhat WHERE MaBB = @MaBB";
            SqlParameter[] pCheck = { new SqlParameter("@MaBB", maBB) };
            if (Convert.ToInt32(Db.LayGiaTri(sqlCheck, pCheck)) > 0)
            {
                FormHelper.ThongBao("Mã biên bản đã tồn tại, vui lòng đổi mã khác!", false);
                return;
            }

            string sqlInsert = @"INSERT INTO KiemTra_XuPhat (MaBB, NgayLap, LoaiBienBan, MoTaKetQua, SoTienPhat, BienPhapKhacPhuc, TrangThai, MaPhong)
                                 VALUES (@MaBB, @NgayLap, @LoaiBienBan, @MoTaKetQua, @SoTienPhat, @BienPhapKhacPhuc, @TrangThai, @MaPhong)";
            SqlParameter[] p = {
                new SqlParameter("@MaBB", maBB),
                new SqlParameter("@NgayLap", dtpNgayLap.Value.Date),
                new SqlParameter("@LoaiBienBan", loaiBB),
                new SqlParameter("@MoTaKetQua", moTa),
                new SqlParameter("@SoTienPhat", soTienPhat),
                new SqlParameter("@BienPhapKhacPhuc", string.IsNullOrEmpty(bienPhap) ? (object)DBNull.Value : bienPhap),
                new SqlParameter("@TrangThai", trangThai),
                new SqlParameter("@MaPhong", maPhong)
            };

            if (Db.ThucThi(sqlInsert, p) > 0)
            {
                // Nếu là kiểm tra định kỳ phát hiện phòng xuống cấp cần tu sửa, cập nhật trạng thái phòng
                if (loaiBB == "Kiểm tra định kỳ 1 năm" && moTa.ToLower().Contains("xuống cấp"))
                {
                    string sqlUpdatePhong = "UPDATE Phong SET TrangThai = N'Cần tu sửa' WHERE MaPhong = @MaPhong";
                    SqlParameter[] pPhong = { new SqlParameter("@MaPhong", maPhong) };
                    Db.ThucThi(sqlUpdatePhong, pPhong);
                }

                FormHelper.ThongBao($"Lập biên bản {maBB} thành công!", true);
                TaiDanhSachBienBan();
                TaiDanhSachPhong();
                TaoMaTuDong();
            }
            else
            {
                FormHelper.ThongBao("Lỗi khi lập biên bản kiểm tra/xử phạt!", false);
            }
        }

        private void btnCapNhatTrangThai_Click(object sender, EventArgs e)
        {
            string maBB = txtMaBB.Text.Trim();
            if (string.IsNullOrEmpty(maBB))
            {
                FormHelper.ThongBao("Vui lòng chọn một biên bản trên danh sách để cập nhật tiến độ!", false);
                return;
            }

            string trangThaiMoi = cboTrangThai.SelectedItem?.ToString() ?? "Hoàn tất";
            string bienPhap = txtBienPhap.Text.Trim();

            string sqlUpdate = @"UPDATE KiemTra_XuPhat 
                                 SET TrangThai = @TrangThai, BienPhapKhacPhuc = @BienPhap 
                                 WHERE MaBB = @MaBB";
            SqlParameter[] p = {
                new SqlParameter("@TrangThai", trangThaiMoi),
                new SqlParameter("@BienPhap", bienPhap),
                new SqlParameter("@MaBB", maBB)
            };

            if (Db.ThucThi(sqlUpdate, p) > 0)
            {
                FormHelper.ThongBao($"Đã cập nhật trạng thái biên bản {maBB} thành '{trangThaiMoi}'!", true);
                TaiDanhSachBienBan();
            }
            else
            {
                FormHelper.ThongBao("Cập nhật thất bại, vui lòng kiểm tra lại!", false);
            }
        }

        private void btnLamMoi_Click(object sender, EventArgs e)
        {
            TaoMaTuDong();
            txtMoTa.Clear();
            cboLoaiBB.SelectedIndex = 0;
            cboTrangThai.SelectedIndex = 0;
            TaiDanhSachBienBan();
            TaiDanhSachPhong();
        }

        private void btnDong_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}