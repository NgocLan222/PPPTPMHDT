﻿namespace QuanLyChoThueCaoOc.Forms
{
    partial class FrmHoaDon
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code
        private void InitializeComponent()
        {
            this.lblTieuDe = new System.Windows.Forms.Label();
            this.gbThongTin = new System.Windows.Forms.GroupBox();
            this.txtThanhTien = new System.Windows.Forms.TextBox();
            this.lblThanhTien = new System.Windows.Forms.Label();
            this.numChiSoCuoi = new System.Windows.Forms.NumericUpDown();
            this.lblChiSoCuoi = new System.Windows.Forms.Label();
            this.numChiSoDau = new System.Windows.Forms.NumericUpDown();
            this.lblChiSoDau = new System.Windows.Forms.Label();
            this.dtpHanThanhToan = new System.Windows.Forms.DateTimePicker();
            this.lblHanTT = new System.Windows.Forms.Label();
            this.numKyNam = new System.Windows.Forms.NumericUpDown();
            this.lblKyNam = new System.Windows.Forms.Label();
            this.numKyThang = new System.Windows.Forms.NumericUpDown();
            this.lblKyThang = new System.Windows.Forms.Label();
            this.cboDichVu = new System.Windows.Forms.ComboBox();
            this.lblDichVu = new System.Windows.Forms.Label();
            this.cboPhong = new System.Windows.Forms.ComboBox();
            this.lblPhong = new System.Windows.Forms.Label();
            this.cboHopDong = new System.Windows.Forms.ComboBox();
            this.lblHopDong = new System.Windows.Forms.Label();
            this.cboLoaiHD = new System.Windows.Forms.ComboBox();
            this.lblLoaiHD = new System.Windows.Forms.Label();
            this.txtMaHoaDon = new System.Windows.Forms.TextBox();
            this.lblMaHoaDon = new System.Windows.Forms.Label();
            this.btnLapHoaDon = new System.Windows.Forms.Button();
            this.btnThanhToan = new System.Windows.Forms.Button();
            this.btnLamMoi = new System.Windows.Forms.Button();
            this.btnDong = new System.Windows.Forms.Button();
            this.gbDanhSach = new System.Windows.Forms.GroupBox();
            this.cboLocTrangThai = new System.Windows.Forms.ComboBox();
            this.lblLoc = new System.Windows.Forms.Label();
            this.dgvHoaDon = new System.Windows.Forms.DataGridView();
            this.gbThongTin.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numChiSoCuoi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numChiSoDau)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numKyNam)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numKyThang)).BeginInit();
            this.gbDanhSach.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHoaDon)).BeginInit();
            this.SuspendLayout();
            // 
            // lblTieuDe
            // 
            this.lblTieuDe.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblTieuDe.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold);
            this.lblTieuDe.ForeColor = System.Drawing.Color.DarkBlue;
            this.lblTieuDe.Location = new System.Drawing.Point(0, 0);
            this.lblTieuDe.Name = "lblTieuDe";
            this.lblTieuDe.Size = new System.Drawing.Size(1034, 55);
            this.lblTieuDe.TabIndex = 0;
            this.lblTieuDe.Text = "QUẢN LÝ HÓA ĐƠN TIỀN THUÊ & PHÍ DỊCH VỤ";
            this.lblTieuDe.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // gbThongTin
            // 
            this.gbThongTin.Controls.Add(this.txtThanhTien);
            this.gbThongTin.Controls.Add(this.lblThanhTien);
            this.gbThongTin.Controls.Add(this.numChiSoCuoi);
            this.gbThongTin.Controls.Add(this.lblChiSoCuoi);
            this.gbThongTin.Controls.Add(this.numChiSoDau);
            this.gbThongTin.Controls.Add(this.lblChiSoDau);
            this.gbThongTin.Controls.Add(this.dtpHanThanhToan);
            this.gbThongTin.Controls.Add(this.lblHanTT);
            this.gbThongTin.Controls.Add(this.numKyNam);
            this.gbThongTin.Controls.Add(this.lblKyNam);
            this.gbThongTin.Controls.Add(this.numKyThang);
            this.gbThongTin.Controls.Add(this.lblKyThang);
            this.gbThongTin.Controls.Add(this.cboDichVu);
            this.gbThongTin.Controls.Add(this.lblDichVu);
            this.gbThongTin.Controls.Add(this.cboPhong);
            this.gbThongTin.Controls.Add(this.lblPhong);
            this.gbThongTin.Controls.Add(this.cboHopDong);
            this.gbThongTin.Controls.Add(this.lblHopDong);
            this.gbThongTin.Controls.Add(this.cboLoaiHD);
            this.gbThongTin.Controls.Add(this.lblLoaiHD);
            this.gbThongTin.Controls.Add(this.txtMaHoaDon);
            this.gbThongTin.Controls.Add(this.lblMaHoaDon);
            this.gbThongTin.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.gbThongTin.Location = new System.Drawing.Point(15, 60);
            this.gbThongTin.Name = "gbThongTin";
            this.gbThongTin.Size = new System.Drawing.Size(1005, 195);
            this.gbThongTin.TabIndex = 1;
            this.gbThongTin.TabStop = false;
            this.gbThongTin.Text = "Lập thông tin hóa đơn";
            // 
            // txtThanhTien
            // 
            this.txtThanhTien.BackColor = System.Drawing.Color.LightYellow;
            this.txtThanhTien.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.txtThanhTien.ForeColor = System.Drawing.Color.DarkRed;
            this.txtThanhTien.Location = new System.Drawing.Point(765, 148);
            this.txtThanhTien.Name = "txtThanhTien";
            this.txtThanhTien.Size = new System.Drawing.Size(220, 30);
            this.txtThanhTien.TabIndex = 21;
            this.txtThanhTien.Text = "0";
            // 
            // lblThanhTien
            // 
            this.lblThanhTien.AutoSize = true;
            this.lblThanhTien.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.lblThanhTien.Location = new System.Drawing.Point(665, 153);
            this.lblThanhTien.Name = "lblThanhTien";
            this.lblThanhTien.Size = new System.Drawing.Size(97, 21);
            this.lblThanhTien.TabIndex = 20;
            this.lblThanhTien.Text = "Thành tiền:";
            // 
            // numChiSoCuoi
            // 
            this.numChiSoCuoi.Enabled = false;
            this.numChiSoCuoi.Location = new System.Drawing.Point(895, 108);
            this.numChiSoCuoi.Maximum = new decimal(new int[] { 999999, 0, 0, 0 });
            this.numChiSoCuoi.Name = "numChiSoCuoi";
            this.numChiSoCuoi.Size = new System.Drawing.Size(90, 29);
            this.numChiSoCuoi.TabIndex = 19;
            // 
            // lblChiSoCuoi
            // 
            this.lblChiSoCuoi.AutoSize = true;
            this.lblChiSoCuoi.Location = new System.Drawing.Point(835, 111);
            this.lblChiSoCuoi.Name = "lblChiSoCuoi";
            this.lblChiSoCuoi.Size = new System.Drawing.Size(58, 21);
            this.lblChiSoCuoi.TabIndex = 18;
            this.lblChiSoCuoi.Text = "Số cuối:";
            // 
            // numChiSoDau
            // 
            this.numChiSoDau.Enabled = false;
            this.numChiSoDau.Location = new System.Drawing.Point(735, 108);
            this.numChiSoDau.Maximum = new decimal(new int[] { 999999, 0, 0, 0 });
            this.numChiSoDau.Name = "numChiSoDau";
            this.numChiSoDau.Size = new System.Drawing.Size(90, 29);
            this.numChiSoDau.TabIndex = 17;
            // 
            // lblChiSoDau
            // 
            this.lblChiSoDau.AutoSize = true;
            this.lblChiSoDau.Location = new System.Drawing.Point(665, 111);
            this.lblChiSoDau.Name = "lblChiSoDau";
            this.lblChiSoDau.Size = new System.Drawing.Size(56, 21);
            this.lblChiSoDau.TabIndex = 16;
            this.lblChiSoDau.Text = "Số đầu:";
            // 
            // dtpHanThanhToan
            // 
            this.dtpHanThanhToan.CustomFormat = "dd/MM/yyyy";
            this.dtpHanThanhToan.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpHanThanhToan.Location = new System.Drawing.Point(765, 68);
            this.dtpHanThanhToan.Name = "dtpHanThanhToan";
            this.dtpHanThanhToan.Size = new System.Drawing.Size(220, 29);
            this.dtpHanThanhToan.TabIndex = 15;
            // 
            // lblHanTT
            // 
            this.lblHanTT.AutoSize = true;
            this.lblHanTT.Location = new System.Drawing.Point(665, 72);
            this.lblHanTT.Name = "lblHanTT";
            this.lblHanTT.Size = new System.Drawing.Size(65, 21);
            this.lblHanTT.TabIndex = 14;
            this.lblHanTT.Text = "Hạn TT:";
            // 
            // numKyNam
            // 
            this.numKyNam.Location = new System.Drawing.Point(895, 28);
            this.numKyNam.Maximum = new decimal(new int[] { 2035, 0, 0, 0 });
            this.numKyNam.Minimum = new decimal(new int[] { 2020, 0, 0, 0 });
            this.numKyNam.Name = "numKyNam";
            this.numKyNam.Size = new System.Drawing.Size(90, 29);
            this.numKyNam.TabIndex = 13;
            this.numKyNam.Value = new decimal(new int[] { 2026, 0, 0, 0 });
            // 
            // lblKyNam
            // 
            this.lblKyNam.AutoSize = true;
            this.lblKyNam.Location = new System.Drawing.Point(845, 32);
            this.lblKyNam.Name = "lblKyNam";
            this.lblKyNam.Size = new System.Drawing.Size(47, 21);
            this.lblKyNam.TabIndex = 12;
            this.lblKyNam.Text = "Năm:";
            // 
            // numKyThang
            // 
            this.numKyThang.Location = new System.Drawing.Point(765, 28);
            this.numKyThang.Maximum = new decimal(new int[] { 12, 0, 0, 0 });
            this.numKyThang.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
            this.numKyThang.Name = "numKyThang";
            this.numKyThang.Size = new System.Drawing.Size(70, 29);
            this.numKyThang.TabIndex = 11;
            this.numKyThang.Value = new decimal(new int[] { 7, 0, 0, 0 });
            // 
            // lblKyThang
            // 
            this.lblKyThang.AutoSize = true;
            this.lblKyThang.Location = new System.Drawing.Point(665, 32);
            this.lblKyThang.Name = "lblKyThang";
            this.lblKyThang.Size = new System.Drawing.Size(74, 21);
            this.lblKyThang.TabIndex = 10;
            this.lblKyThang.Text = "Kỳ tháng:";
            // 
            // cboDichVu
            // 
            this.cboDichVu.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboDichVu.Enabled = false;
            this.cboDichVu.FormattingEnabled = true;
            this.cboDichVu.Items.AddRange(new object[] {
            "Điện sinh hoạt",
            "Nước sinh hoạt",
            "Cáp Internet",
            "Phí vệ sinh"});
            this.cboDichVu.Location = new System.Drawing.Point(125, 150);
            this.cboDichVu.Name = "cboDichVu";
            this.cboDichVu.Size = new System.Drawing.Size(515, 29);
            this.cboDichVu.TabIndex = 9;
            // 
            // lblDichVu
            // 
            this.lblDichVu.AutoSize = true;
            this.lblDichVu.Location = new System.Drawing.Point(20, 153);
            this.lblDichVu.Name = "lblDichVu";
            this.lblDichVu.Size = new System.Drawing.Size(94, 21);
            this.lblDichVu.TabIndex = 8;
            this.lblDichVu.Text = "Tên dịch vụ:";
            // 
            // cboPhong
            // 
            this.cboPhong.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboPhong.FormattingEnabled = true;
            this.cboPhong.Location = new System.Drawing.Point(125, 110);
            this.cboPhong.Name = "cboPhong";
            this.cboPhong.Size = new System.Drawing.Size(515, 29);
            this.cboPhong.TabIndex = 7;
            // 
            // lblPhong
            // 
            this.lblPhong.AutoSize = true;
            this.lblPhong.Location = new System.Drawing.Point(20, 113);
            this.lblPhong.Name = "lblPhong";
            this.lblPhong.Size = new System.Drawing.Size(98, 21);
            this.lblPhong.TabIndex = 6;
            this.lblPhong.Text = "Phòng thuê:";
            // 
            // cboHopDong
            // 
            this.cboHopDong.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboHopDong.FormattingEnabled = true;
            this.cboHopDong.Location = new System.Drawing.Point(125, 70);
            this.cboHopDong.Name = "cboHopDong";
            this.cboHopDong.Size = new System.Drawing.Size(515, 29);
            this.cboHopDong.TabIndex = 5;
            // 
            // lblHopDong
            // 
            this.lblHopDong.AutoSize = true;
            this.lblHopDong.Location = new System.Drawing.Point(20, 73);
            this.lblHopDong.Name = "lblHopDong";
            this.lblHopDong.Size = new System.Drawing.Size(83, 21);
            this.lblHopDong.TabIndex = 4;
            this.lblHopDong.Text = "Hợp đồng:";
            // 
            // cboLoaiHD
            // 
            this.cboLoaiHD.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboLoaiHD.FormattingEnabled = true;
            this.cboLoaiHD.Items.AddRange(new object[] {
            "Tiền phòng",
            "Tiền dịch vụ"});
            this.cboLoaiHD.Location = new System.Drawing.Point(400, 30);
            this.cboLoaiHD.Name = "cboLoaiHD";
            this.cboLoaiHD.Size = new System.Drawing.Size(240, 29);
            this.cboLoaiHD.TabIndex = 3;
            // 
            // lblLoaiHD
            // 
            this.lblLoaiHD.AutoSize = true;
            this.lblLoaiHD.Location = new System.Drawing.Point(325, 33);
            this.lblLoaiHD.Name = "lblLoaiHD";
            this.lblLoaiHD.Size = new System.Drawing.Size(69, 21);
            this.lblLoaiHD.TabIndex = 2;
            this.lblLoaiHD.Text = "Loại HĐ:";
            // 
            // txtMaHoaDon
            // 
            this.txtMaHoaDon.Location = new System.Drawing.Point(125, 30);
            this.txtMaHoaDon.Name = "txtMaHoaDon";
            this.txtMaHoaDon.Size = new System.Drawing.Size(185, 29);
            this.txtMaHoaDon.TabIndex = 1;
            // 
            // lblMaHoaDon
            // 
            this.lblMaHoaDon.AutoSize = true;
            this.lblMaHoaDon.Location = new System.Drawing.Point(20, 33);
            this.lblMaHoaDon.Name = "lblMaHoaDon";
            this.lblMaHoaDon.Size = new System.Drawing.Size(97, 21);
            this.lblMaHoaDon.TabIndex = 0;
            this.lblMaHoaDon.Text = "Mã hóa đơn:";
            // 
            // btnLapHoaDon
            // 
            this.btnLapHoaDon.BackColor = System.Drawing.Color.LightSkyBlue;
            this.btnLapHoaDon.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnLapHoaDon.Location = new System.Drawing.Point(200, 265);
            this.btnLapHoaDon.Name = "btnLapHoaDon";
            this.btnLapHoaDon.Size = new System.Drawing.Size(180, 42);
            this.btnLapHoaDon.TabIndex = 2;
            this.btnLapHoaDon.Text = "Lập Hóa Đơn Mới";
            this.btnLapHoaDon.UseVisualStyleBackColor = false;
            this.btnLapHoaDon.Click += new System.EventHandler(this.btnLapHoaDon_Click);
            // 
            // btnThanhToan
            // 
            this.btnThanhToan.BackColor = System.Drawing.Color.LightGreen;
            this.btnThanhToan.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnThanhToan.Location = new System.Drawing.Point(400, 265);
            this.btnThanhToan.Name = "btnThanhToan";
            this.btnThanhToan.Size = new System.Drawing.Size(200, 42);
            this.btnThanhToan.TabIndex = 3;
            this.btnThanhToan.Text = "Xác Nhận Nộp Tiền";
            this.btnThanhToan.UseVisualStyleBackColor = false;
            this.btnThanhToan.Click += new System.EventHandler(this.btnThanhToan_Click);
            // 
            // btnLamMoi
            // 
            this.btnLamMoi.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnLamMoi.Location = new System.Drawing.Point(620, 265);
            this.btnLamMoi.Name = "btnLamMoi";
            this.btnLamMoi.Size = new System.Drawing.Size(120, 42);
            this.btnLamMoi.TabIndex = 4;
            this.btnLamMoi.Text = "Làm mới";
            this.btnLamMoi.UseVisualStyleBackColor = true;
            this.btnLamMoi.Click += new System.EventHandler(this.btnLamMoi_Click);
            // 
            // btnDong
            // 
            this.btnDong.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnDong.Location = new System.Drawing.Point(760, 265);
            this.btnDong.Name = "btnDong";
            this.btnDong.Size = new System.Drawing.Size(120, 42);
            this.btnDong.TabIndex = 5;
            this.btnDong.Text = "Đóng";
            this.btnDong.UseVisualStyleBackColor = true;
            this.btnDong.Click += new System.EventHandler(this.btnDong_Click);
            // 
            // gbDanhSach
            // 
            this.gbDanhSach.Controls.Add(this.cboLocTrangThai);
            this.gbDanhSach.Controls.Add(this.lblLoc);
            this.gbDanhSach.Controls.Add(this.dgvHoaDon);
            this.gbDanhSach.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.gbDanhSach.Location = new System.Drawing.Point(15, 320);
            this.gbDanhSach.Name = "gbDanhSach";
            this.gbDanhSach.Size = new System.Drawing.Size(1005, 345);
            this.gbDanhSach.TabIndex = 6;
            this.gbDanhSach.TabStop = false;
            this.gbDanhSach.Text = "Danh sách hóa đơn trong hệ thống";
            // 
            // cboLocTrangThai
            // 
            this.cboLocTrangThai.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboLocTrangThai.FormattingEnabled = true;
            this.cboLocTrangThai.Items.AddRange(new object[] {
            "Tất cả",
            "Chưa thanh toán",
            "Đã thanh toán"});
            this.cboLocTrangThai.Location = new System.Drawing.Point(825, 20);
            this.cboLocTrangThai.Name = "cboLocTrangThai";
            this.cboLocTrangThai.Size = new System.Drawing.Size(170, 29);
            this.cboLocTrangThai.TabIndex = 2;
            // 
            // lblLoc
            // 
            this.lblLoc.AutoSize = true;
            this.lblLoc.Location = new System.Drawing.Point(710, 24);
            this.lblLoc.Name = "lblLoc";
            this.lblLoc.Size = new System.Drawing.Size(107, 21);
            this.lblLoc.TabIndex = 1;
            this.lblLoc.Text = "Lọc trạng thái:";
            // 
            // dgvHoaDon
            // 
            this.dgvHoaDon.AllowUserToAddRows = false;
            this.dgvHoaDon.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvHoaDon.BackgroundColor = System.Drawing.Color.White;
            this.dgvHoaDon.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvHoaDon.Location = new System.Drawing.Point(5, 55);
            this.dgvHoaDon.Name = "dgvHoaDon";
            this.dgvHoaDon.ReadOnly = true;
            this.dgvHoaDon.RowHeadersWidth = 51;
            this.dgvHoaDon.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvHoaDon.Size = new System.Drawing.Size(995, 285);
            this.dgvHoaDon.TabIndex = 0;
            // 
            // FrmHoaDon
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(248)))), ((int)(((byte)(250)))));
            this.ClientSize = new System.Drawing.Size(1034, 680);
            this.Controls.Add(this.gbDanhSach);
            this.Controls.Add(this.btnDong);
            this.Controls.Add(this.btnLamMoi);
            this.Controls.Add(this.btnThanhToan);
            this.Controls.Add(this.btnLapHoaDon);
            this.Controls.Add(this.gbThongTin);
            this.Controls.Add(this.lblTieuDe);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "FrmHoaDon";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quản lý Hóa đơn Tiền phòng & Dịch vụ";
            this.Load += new System.EventHandler(this.FrmHoaDon_Load);
            this.gbThongTin.ResumeLayout(false);
            this.gbThongTin.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numChiSoCuoi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numChiSoDau)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numKyNam)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numKyThang)).EndInit();
            this.gbDanhSach.ResumeLayout(false);
            this.gbDanhSach.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHoaDon)).EndInit();
            this.ResumeLayout(false);
        }
        #endregion

        private System.Windows.Forms.Label lblTieuDe;
        private System.Windows.Forms.GroupBox gbThongTin;
        private System.Windows.Forms.Label lblMaHoaDon;
        private System.Windows.Forms.TextBox txtMaHoaDon;
        private System.Windows.Forms.Label lblLoaiHD;
        private System.Windows.Forms.ComboBox cboLoaiHD;
        private System.Windows.Forms.Label lblHopDong;
        private System.Windows.Forms.ComboBox cboHopDong;
        private System.Windows.Forms.Label lblPhong;
        private System.Windows.Forms.ComboBox cboPhong;
        private System.Windows.Forms.Label lblDichVu;
        private System.Windows.Forms.ComboBox cboDichVu;
        private System.Windows.Forms.Label lblKyThang;
        private System.Windows.Forms.NumericUpDown numKyThang;
        private System.Windows.Forms.Label lblKyNam;
        private System.Windows.Forms.NumericUpDown numKyNam;
        private System.Windows.Forms.Label lblHanTT;
        private System.Windows.Forms.DateTimePicker dtpHanThanhToan;
        private System.Windows.Forms.Label lblChiSoDau;
        private System.Windows.Forms.NumericUpDown numChiSoDau;
        private System.Windows.Forms.Label lblChiSoCuoi;
        private System.Windows.Forms.NumericUpDown numChiSoCuoi;
        private System.Windows.Forms.Label lblThanhTien;
        private System.Windows.Forms.TextBox txtThanhTien;
        private System.Windows.Forms.Button btnLapHoaDon;
        private System.Windows.Forms.Button btnThanhToan;
        private System.Windows.Forms.Button btnLamMoi;
        private System.Windows.Forms.Button btnDong;
        private System.Windows.Forms.GroupBox gbDanhSach;
        private System.Windows.Forms.ComboBox cboLocTrangThai;
        private System.Windows.Forms.Label lblLoc;
        private System.Windows.Forms.DataGridView dgvHoaDon;
    }
}