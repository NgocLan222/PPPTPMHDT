﻿namespace QuanLyChoThueCaoOc.Forms
{
    partial class FrmNhanVien_TheXe
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code
        private void InitializeComponent()
        {
            this.lblTieuDe = new System.Windows.Forms.Label();
            this.gbNhanVien = new System.Windows.Forms.GroupBox();
            this.cboPhong = new System.Windows.Forms.ComboBox();
            this.lblPhong = new System.Windows.Forms.Label();
            this.cboCongTy = new System.Windows.Forms.ComboBox();
            this.lblCongTy = new System.Windows.Forms.Label();
            this.dtpNgayBaoCao = new System.Windows.Forms.DateTimePicker();
            this.lblNgayBaoCao = new System.Windows.Forms.Label();
            this.txtChucVu = new System.Windows.Forms.TextBox();
            this.lblChucVu = new System.Windows.Forms.Label();
            this.txtDienThoai = new System.Windows.Forms.TextBox();
            this.lblDienThoai = new System.Windows.Forms.Label();
            this.cboPhai = new System.Windows.Forms.ComboBox();
            this.lblPhai = new System.Windows.Forms.Label();
            this.txtHoTen = new System.Windows.Forms.TextBox();
            this.lblHoTen = new System.Windows.Forms.Label();
            this.txtMaNV = new System.Windows.Forms.TextBox();
            this.lblMaNV = new System.Windows.Forms.Label();
            this.gbTheXe = new System.Windows.Forms.GroupBox();
            this.txtMauXe = new System.Windows.Forms.TextBox();
            this.lblMauXe = new System.Windows.Forms.Label();
            this.txtHieuXe = new System.Windows.Forms.TextBox();
            this.lblHieuXe = new System.Windows.Forms.Label();
            this.cboLoaiXe = new System.Windows.Forms.ComboBox();
            this.lblLoaiXe = new System.Windows.Forms.Label();
            this.txtBienSoXe = new System.Windows.Forms.TextBox();
            this.lblBienSo = new System.Windows.Forms.Label();
            this.txtMaThe = new System.Windows.Forms.TextBox();
            this.lblMaThe = new System.Windows.Forms.Label();
            this.btnThemNV = new System.Windows.Forms.Button();
            this.btnCapThe = new System.Windows.Forms.Button();
            this.btnKhoaThe = new System.Windows.Forms.Button();
            this.btnLamMoi = new System.Windows.Forms.Button();
            this.btnDong = new System.Windows.Forms.Button();
            this.gbDanhSach = new System.Windows.Forms.GroupBox();
            this.dgvNhanVien = new System.Windows.Forms.DataGridView();
            this.gbNhanVien.SuspendLayout();
            this.gbTheXe.SuspendLayout();
            this.gbDanhSach.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvNhanVien)).BeginInit();
            this.SuspendLayout();
            // 
            // lblTieuDe
            // 
            this.lblTieuDe.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblTieuDe.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold);
            this.lblTieuDe.ForeColor = System.Drawing.Color.DarkBlue;
            this.lblTieuDe.Location = new System.Drawing.Point(0, 0);
            this.lblTieuDe.Name = "lblTieuDe";
            this.lblTieuDe.Size = new System.Drawing.Size(1034, 55);
            this.lblTieuDe.TabIndex = 0;
            this.lblTieuDe.Text = "QUẢN LÝ NHÂN VIÊN VĂN PHÒNG & THẺ GIỮ XE";
            this.lblTieuDe.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // gbNhanVien
            // 
            this.gbNhanVien.Controls.Add(this.cboPhong);
            this.gbNhanVien.Controls.Add(this.lblPhong);
            this.gbNhanVien.Controls.Add(this.cboCongTy);
            this.gbNhanVien.Controls.Add(this.lblCongTy);
            this.gbNhanVien.Controls.Add(this.dtpNgayBaoCao);
            this.gbNhanVien.Controls.Add(this.lblNgayBaoCao);
            this.gbNhanVien.Controls.Add(this.txtChucVu);
            this.gbNhanVien.Controls.Add(this.lblChucVu);
            this.gbNhanVien.Controls.Add(this.txtDienThoai);
            this.gbNhanVien.Controls.Add(this.lblDienThoai);
            this.gbNhanVien.Controls.Add(this.cboPhai);
            this.gbNhanVien.Controls.Add(this.lblPhai);
            this.gbNhanVien.Controls.Add(this.txtHoTen);
            this.gbNhanVien.Controls.Add(this.lblHoTen);
            this.gbNhanVien.Controls.Add(this.txtMaNV);
            this.gbNhanVien.Controls.Add(this.lblMaNV);
            this.gbNhanVien.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.gbNhanVien.Location = new System.Drawing.Point(15, 60);
            this.gbNhanVien.Name = "gbNhanVien";
            this.gbNhanVien.Size = new System.Drawing.Size(565, 235);
            this.gbNhanVien.TabIndex = 1;
            this.gbNhanVien.TabStop = false;
            this.gbNhanVien.Text = "1. Thông tin nhân sự công ty báo cáo";
            // 
            // cboPhong
            // 
            this.cboPhong.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboPhong.FormattingEnabled = true;
            this.cboPhong.Location = new System.Drawing.Point(375, 185);
            this.cboPhong.Name = "cboPhong";
            this.cboPhong.Size = new System.Drawing.Size(175, 29);
            this.cboPhong.TabIndex = 15;
            // 
            // lblPhong
            // 
            this.lblPhong.AutoSize = true;
            this.lblPhong.Location = new System.Drawing.Point(295, 189);
            this.lblPhong.Name = "lblPhong";
            this.lblPhong.Size = new System.Drawing.Size(58, 21);
            this.lblPhong.TabIndex = 14;
            this.lblPhong.Text = "Phòng:";
            // 
            // cboCongTy
            // 
            this.cboCongTy.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboCongTy.FormattingEnabled = true;
            this.cboCongTy.Location = new System.Drawing.Point(105, 185);
            this.cboCongTy.Name = "cboCongTy";
            this.cboCongTy.Size = new System.Drawing.Size(175, 29);
            this.cboCongTy.TabIndex = 13;
            // 
            // lblCongTy
            // 
            this.lblCongTy.AutoSize = true;
            this.lblCongTy.Location = new System.Drawing.Point(15, 189);
            this.lblCongTy.Name = "lblCongTy";
            this.lblCongTy.Size = new System.Drawing.Size(68, 21);
            this.lblCongTy.TabIndex = 12;
            this.lblCongTy.Text = "Công ty:";
            // 
            // dtpNgayBaoCao
            // 
            this.dtpNgayBaoCao.CustomFormat = "dd/MM/yyyy";
            this.dtpNgayBaoCao.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpNgayBaoCao.Location = new System.Drawing.Point(375, 145);
            this.dtpNgayBaoCao.Name = "dtpNgayBaoCao";
            this.dtpNgayBaoCao.Size = new System.Drawing.Size(175, 29);
            this.dtpNgayBaoCao.TabIndex = 11;
            // 
            // lblNgayBaoCao
            // 
            this.lblNgayBaoCao.AutoSize = true;
            this.lblNgayBaoCao.Location = new System.Drawing.Point(295, 149);
            this.lblNgayBaoCao.Name = "lblNgayBaoCao";
            this.lblNgayBaoCao.Size = new System.Drawing.Size(78, 21);
            this.lblNgayBaoCao.TabIndex = 10;
            this.lblNgayBaoCao.Text = "Ngày báo:";
            // 
            // txtChucVu
            // 
            this.txtChucVu.Location = new System.Drawing.Point(105, 145);
            this.txtChucVu.Name = "txtChucVu";
            this.txtChucVu.Size = new System.Drawing.Size(175, 29);
            this.txtChucVu.TabIndex = 9;
            // 
            // lblChucVu
            // 
            this.lblChucVu.AutoSize = true;
            this.lblChucVu.Location = new System.Drawing.Point(15, 149);
            this.lblChucVu.Name = "lblChucVu";
            this.lblChucVu.Size = new System.Drawing.Size(69, 21);
            this.lblChucVu.TabIndex = 8;
            this.lblChucVu.Text = "Chức vụ:";
            // 
            // txtDienThoai
            // 
            this.txtDienThoai.Location = new System.Drawing.Point(375, 105);
            this.txtDienThoai.Name = "txtDienThoai";
            this.txtDienThoai.Size = new System.Drawing.Size(175, 29);
            this.txtDienThoai.TabIndex = 7;
            // 
            // lblDienThoai
            // 
            this.lblDienThoai.AutoSize = true;
            this.lblDienThoai.Location = new System.Drawing.Point(295, 109);
            this.lblDienThoai.Name = "lblDienThoai";
            this.lblDienThoai.Size = new System.Drawing.Size(41, 21);
            this.lblDienThoai.TabIndex = 6;
            this.lblDienThoai.Text = "SĐT:";
            // 
            // cboPhai
            // 
            this.cboPhai.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboPhai.FormattingEnabled = true;
            this.cboPhai.Items.AddRange(new object[] {
            "Nam",
            "Nữ"});
            this.cboPhai.Location = new System.Drawing.Point(105, 105);
            this.cboPhai.Name = "cboPhai";
            this.cboPhai.Size = new System.Drawing.Size(175, 29);
            this.cboPhai.TabIndex = 5;
            // 
            // lblPhai
            // 
            this.lblPhai.AutoSize = true;
            this.lblPhai.Location = new System.Drawing.Point(15, 109);
            this.lblPhai.Name = "lblPhai";
            this.lblPhai.Size = new System.Drawing.Size(43, 21);
            this.lblPhai.TabIndex = 4;
            this.lblPhai.Text = "Phái:";
            // 
            // txtHoTen
            // 
            this.txtHoTen.Location = new System.Drawing.Point(105, 65);
            this.txtHoTen.Name = "txtHoTen";
            this.txtHoTen.Size = new System.Drawing.Size(445, 29);
            this.txtHoTen.TabIndex = 3;
            // 
            // lblHoTen
            // 
            this.lblHoTen.AutoSize = true;
            this.lblHoTen.Location = new System.Drawing.Point(15, 69);
            this.lblHoTen.Name = "lblHoTen";
            this.lblHoTen.Size = new System.Drawing.Size(59, 21);
            this.lblHoTen.TabIndex = 2;
            this.lblHoTen.Text = "Họ tên:";
            // 
            // txtMaNV
            // 
            this.txtMaNV.Location = new System.Drawing.Point(105, 25);
            this.txtMaNV.Name = "txtMaNV";
            this.txtMaNV.Size = new System.Drawing.Size(445, 29);
            this.txtMaNV.TabIndex = 1;
            // 
            // lblMaNV
            // 
            this.lblMaNV.AutoSize = true;
            this.lblMaNV.Location = new System.Drawing.Point(15, 29);
            this.lblMaNV.Name = "lblMaNV";
            this.lblMaNV.Size = new System.Drawing.Size(61, 21);
            this.lblMaNV.TabIndex = 0;
            this.lblMaNV.Text = "Mã NV:";
            // 
            // gbTheXe
            // 
            this.gbTheXe.Controls.Add(this.txtMauXe);
            this.gbTheXe.Controls.Add(this.lblMauXe);
            this.gbTheXe.Controls.Add(this.txtHieuXe);
            this.gbTheXe.Controls.Add(this.lblHieuXe);
            this.gbTheXe.Controls.Add(this.cboLoaiXe);
            this.gbTheXe.Controls.Add(this.lblLoaiXe);
            this.gbTheXe.Controls.Add(this.txtBienSoXe);
            this.gbTheXe.Controls.Add(this.lblBienSo);
            this.gbTheXe.Controls.Add(this.txtMaThe);
            this.gbTheXe.Controls.Add(this.lblMaThe);
            this.gbTheXe.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.gbTheXe.Location = new System.Drawing.Point(595, 60);
            this.gbTheXe.Name = "gbTheXe";
            this.gbTheXe.Size = new System.Drawing.Size(425, 235);
            this.gbTheXe.TabIndex = 2;
            this.gbTheXe.TabStop = false;
            this.gbTheXe.Text = "2. Thủ tục cấp Thẻ giữ xe (Quan hệ 1 – 1)";
            // 
            // txtMauXe
            // 
            this.txtMauXe.Location = new System.Drawing.Point(105, 185);
            this.txtMauXe.Name = "txtMauXe";
            this.txtMauXe.Size = new System.Drawing.Size(305, 29);
            this.txtMauXe.TabIndex = 9;
            // 
            // lblMauXe
            // 
            this.lblMauXe.AutoSize = true;
            this.lblMauXe.Location = new System.Drawing.Point(15, 189);
            this.lblMauXe.Name = "lblMauXe";
            this.lblMauXe.Size = new System.Drawing.Size(66, 21);
            this.lblMauXe.TabIndex = 8;
            this.lblMauXe.Text = "Màu xe:";
            // 
            // txtHieuXe
            // 
            this.txtHieuXe.Location = new System.Drawing.Point(105, 145);
            this.txtHieuXe.Name = "txtHieuXe";
            this.txtHieuXe.Size = new System.Drawing.Size(305, 29);
            this.txtHieuXe.TabIndex = 7;
            // 
            // lblHieuXe
            // 
            this.lblHieuXe.AutoSize = true;
            this.lblHieuXe.Location = new System.Drawing.Point(15, 149);
            this.lblHieuXe.Name = "lblHieuXe";
            this.lblHieuXe.Size = new System.Drawing.Size(65, 21);
            this.lblHieuXe.TabIndex = 6;
            this.lblHieuXe.Text = "Hiệu xe:";
            // 
            // cboLoaiXe
            // 
            this.cboLoaiXe.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboLoaiXe.FormattingEnabled = true;
            this.cboLoaiXe.Items.AddRange(new object[] {
            "Xe máy",
            "Ô tô"});
            this.cboLoaiXe.Location = new System.Drawing.Point(105, 105);
            this.cboLoaiXe.Name = "cboLoaiXe";
            this.cboLoaiXe.Size = new System.Drawing.Size(305, 29);
            this.cboLoaiXe.TabIndex = 5;
            // 
            // lblLoaiXe
            // 
            this.lblLoaiXe.AutoSize = true;
            this.lblLoaiXe.Location = new System.Drawing.Point(15, 109);
            this.lblLoaiXe.Name = "lblLoaiXe";
            this.lblLoaiXe.Size = new System.Drawing.Size(62, 21);
            this.lblLoaiXe.TabIndex = 4;
            this.lblLoaiXe.Text = "Loại xe:";
            // 
            // txtBienSoXe
            // 
            this.txtBienSoXe.Location = new System.Drawing.Point(105, 65);
            this.txtBienSoXe.Name = "txtBienSoXe";
            this.txtBienSoXe.Size = new System.Drawing.Size(305, 29);
            this.txtBienSoXe.TabIndex = 3;
            // 
            // lblBienSo
            // 
            this.lblBienSo.AutoSize = true;
            this.lblBienSo.Location = new System.Drawing.Point(15, 69);
            this.lblBienSo.Name = "lblBienSo";
            this.lblBienSo.Size = new System.Drawing.Size(63, 21);
            this.lblBienSo.TabIndex = 2;
            this.lblBienSo.Text = "Biển số:";
            // 
            // txtMaThe
            // 
            this.txtMaThe.Location = new System.Drawing.Point(105, 25);
            this.txtMaThe.Name = "txtMaThe";
            this.txtMaThe.Size = new System.Drawing.Size(305, 29);
            this.txtMaThe.TabIndex = 1;
            // 
            // lblMaThe
            // 
            this.lblMaThe.AutoSize = true;
            this.lblMaThe.Location = new System.Drawing.Point(15, 29);
            this.lblMaThe.Name = "lblMaThe";
            this.lblMaThe.Size = new System.Drawing.Size(61, 21);
            this.lblMaThe.TabIndex = 0;
            this.lblMaThe.Text = "Mã thẻ:";
            // 
            // btnThemNV
            // 
            this.btnThemNV.BackColor = System.Drawing.Color.LightSkyBlue;
            this.btnThemNV.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnThemNV.Location = new System.Drawing.Point(120, 310);
            this.btnThemNV.Name = "btnThemNV";
            this.btnThemNV.Size = new System.Drawing.Size(180, 42);
            this.btnThemNV.TabIndex = 3;
            this.btnThemNV.Text = "+ Thêm Nhân Viên";
            this.btnThemNV.UseVisualStyleBackColor = false;
            this.btnThemNV.Click += new System.EventHandler(this.btnThemNV_Click);
            // 
            // btnCapThe
            // 
            this.btnCapThe.BackColor = System.Drawing.Color.LightGreen;
            this.btnCapThe.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnCapThe.Location = new System.Drawing.Point(320, 310);
            this.btnCapThe.Name = "btnCapThe";
            this.btnCapThe.Size = new System.Drawing.Size(180, 42);
            this.btnCapThe.TabIndex = 4;
            this.btnCapThe.Text = "Cấp Thẻ Giữ Xe";
            this.btnCapThe.UseVisualStyleBackColor = false;
            this.btnCapThe.Click += new System.EventHandler(this.btnCapThe_Click);
            // 
            // btnKhoaThe
            // 
            this.btnKhoaThe.BackColor = System.Drawing.Color.MistyRose;
            this.btnKhoaThe.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnKhoaThe.Location = new System.Drawing.Point(520, 310);
            this.btnKhoaThe.Name = "btnKhoaThe";
            this.btnKhoaThe.Size = new System.Drawing.Size(180, 42);
            this.btnKhoaThe.TabIndex = 5;
            this.btnKhoaThe.Text = "Khóa Thẻ Xe";
            this.btnKhoaThe.UseVisualStyleBackColor = false;
            this.btnKhoaThe.Click += new System.EventHandler(this.btnKhoaThe_Click);
            // 
            // btnLamMoi
            // 
            this.btnLamMoi.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnLamMoi.Location = new System.Drawing.Point(720, 310);
            this.btnLamMoi.Name = "btnLamMoi";
            this.btnLamMoi.Size = new System.Drawing.Size(110, 42);
            this.btnLamMoi.TabIndex = 6;
            this.btnLamMoi.Text = "Làm mới";
            this.btnLamMoi.UseVisualStyleBackColor = true;
            this.btnLamMoi.Click += new System.EventHandler(this.btnLamMoi_Click);
            // 
            // btnDong
            // 
            this.btnDong.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnDong.Location = new System.Drawing.Point(850, 310);
            this.btnDong.Name = "btnDong";
            this.btnDong.Size = new System.Drawing.Size(110, 42);
            this.btnDong.TabIndex = 7;
            this.btnDong.Text = "Đóng";
            this.btnDong.UseVisualStyleBackColor = true;
            this.btnDong.Click += new System.EventHandler(this.btnDong_Click);
            // 
            // gbDanhSach
            // 
            this.gbDanhSach.Controls.Add(this.dgvNhanVien);
            this.gbDanhSach.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.gbDanhSach.Location = new System.Drawing.Point(15, 365);
            this.gbDanhSach.Name = "gbDanhSach";
            this.gbDanhSach.Size = new System.Drawing.Size(1005, 300);
            this.gbDanhSach.TabIndex = 8;
            this.gbDanhSach.TabStop = false;
            this.gbDanhSach.Text = "3. Danh sách nhân sự & tình trạng thẻ xe";
            // 
            // dgvNhanVien
            // 
            this.dgvNhanVien.AllowUserToAddRows = false;
            this.dgvNhanVien.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvNhanVien.BackgroundColor = System.Drawing.Color.White;
            this.dgvNhanVien.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvNhanVien.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvNhanVien.Location = new System.Drawing.Point(3, 25);
            this.dgvNhanVien.Name = "dgvNhanVien";
            this.dgvNhanVien.ReadOnly = true;
            this.dgvNhanVien.RowHeadersWidth = 51;
            this.dgvNhanVien.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvNhanVien.Size = new System.Drawing.Size(999, 272);
            this.dgvNhanVien.TabIndex = 0;
            this.dgvNhanVien.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvNhanVien_CellClick);
            // 
            // FrmNhanVien_TheXe
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(248)))), ((int)(((byte)(250)))));
            this.ClientSize = new System.Drawing.Size(1034, 680);
            this.Controls.Add(this.gbDanhSach);
            this.Controls.Add(this.btnDong);
            this.Controls.Add(this.btnLamMoi);
            this.Controls.Add(this.btnKhoaThe);
            this.Controls.Add(this.btnCapThe);
            this.Controls.Add(this.btnThemNV);
            this.Controls.Add(this.gbTheXe);
            this.Controls.Add(this.gbNhanVien);
            this.Controls.Add(this.lblTieuDe);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "FrmNhanVien_TheXe";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quản lý Nhân sự & Thẻ xe";
            this.Load += new System.EventHandler(this.FrmNhanVien_TheXe_Load);
            this.gbNhanVien.ResumeLayout(false);
            this.gbNhanVien.PerformLayout();
            this.gbTheXe.ResumeLayout(false);
            this.gbTheXe.PerformLayout();
            this.gbDanhSach.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvNhanVien)).EndInit();
            this.ResumeLayout(false);
        }
        #endregion

        private System.Windows.Forms.Label lblTieuDe;
        private System.Windows.Forms.GroupBox gbNhanVien;
        private System.Windows.Forms.Label lblMaNV;
        private System.Windows.Forms.TextBox txtMaNV;
        private System.Windows.Forms.Label lblHoTen;
        private System.Windows.Forms.TextBox txtHoTen;
        private System.Windows.Forms.Label lblPhai;
        private System.Windows.Forms.ComboBox cboPhai;
        private System.Windows.Forms.Label lblDienThoai;
        private System.Windows.Forms.TextBox txtDienThoai;
        private System.Windows.Forms.Label lblChucVu;
        private System.Windows.Forms.TextBox txtChucVu;
        private System.Windows.Forms.Label lblNgayBaoCao;
        private System.Windows.Forms.DateTimePicker dtpNgayBaoCao;
        private System.Windows.Forms.Label lblCongTy;
        private System.Windows.Forms.ComboBox cboCongTy;
        private System.Windows.Forms.Label lblPhong;
        private System.Windows.Forms.ComboBox cboPhong;
        private System.Windows.Forms.GroupBox gbTheXe;
        private System.Windows.Forms.Label lblMaThe;
        private System.Windows.Forms.TextBox txtMaThe;
        private System.Windows.Forms.Label lblBienSo;
        private System.Windows.Forms.TextBox txtBienSoXe;
        private System.Windows.Forms.Label lblLoaiXe;
        private System.Windows.Forms.ComboBox cboLoaiXe;
        private System.Windows.Forms.Label lblHieuXe;
        private System.Windows.Forms.TextBox txtHieuXe;
        private System.Windows.Forms.Label lblMauXe;
        private System.Windows.Forms.TextBox txtMauXe;
        private System.Windows.Forms.Button btnThemNV;
        private System.Windows.Forms.Button btnCapThe;
        private System.Windows.Forms.Button btnKhoaThe;
        private System.Windows.Forms.Button btnLamMoi;
        private System.Windows.Forms.Button btnDong;
        private System.Windows.Forms.GroupBox gbDanhSach;
        private System.Windows.Forms.DataGridView dgvNhanVien;
    }
}