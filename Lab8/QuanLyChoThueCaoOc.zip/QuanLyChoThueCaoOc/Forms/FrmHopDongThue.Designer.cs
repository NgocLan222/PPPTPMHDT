﻿namespace QuanLyChoThueCaoOc.Forms
{
    partial class FrmHopDongThue
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code
        private void InitializeComponent()
        {
            this.lblTieuDe = new System.Windows.Forms.Label();
            this.gbHopDong = new System.Windows.Forms.GroupBox();
            this.txtTong6Thang = new System.Windows.Forms.TextBox();
            this.lblTong6Thang = new System.Windows.Forms.Label();
            this.txtTien1Thang = new System.Windows.Forms.TextBox();
            this.lblTien1Thang = new System.Windows.Forms.Label();
            this.numTienCoc = new System.Windows.Forms.NumericUpDown();
            this.lblTienCoc = new System.Windows.Forms.Label();
            this.dtpNgayKetThuc = new System.Windows.Forms.DateTimePicker();
            this.lblNgayKetThuc = new System.Windows.Forms.Label();
            this.numThoiHanThue = new System.Windows.Forms.NumericUpDown();
            this.lblThoiHan = new System.Windows.Forms.Label();
            this.dtpNgayBatDau = new System.Windows.Forms.DateTimePicker();
            this.lblNgayBatDau = new System.Windows.Forms.Label();
            this.dtpNgayKy = new System.Windows.Forms.DateTimePicker();
            this.lblNgayKy = new System.Windows.Forms.Label();
            this.cboKhachHang = new System.Windows.Forms.ComboBox();
            this.lblKhachHang = new System.Windows.Forms.Label();
            this.txtMaHD = new System.Windows.Forms.TextBox();
            this.lblMaHD = new System.Windows.Forms.Label();
            this.gbChonPhong = new System.Windows.Forms.GroupBox();
            this.dgvPhongChon = new System.Windows.Forms.DataGridView();
            this.txtGhiChuPhong = new System.Windows.Forms.TextBox();
            this.lblGhiChuPhong = new System.Windows.Forms.Label();
            this.btnXoaPhong = new System.Windows.Forms.Button();
            this.btnThemPhong = new System.Windows.Forms.Button();
            this.cboPhongTrong = new System.Windows.Forms.ComboBox();
            this.lblPhongTrong = new System.Windows.Forms.Label();
            this.btnLuuHopDong = new System.Windows.Forms.Button();
            this.btnLamMoi = new System.Windows.Forms.Button();
            this.btnDong = new System.Windows.Forms.Button();
            this.gbDanhSachHD = new System.Windows.Forms.GroupBox();
            this.dgvHopDong = new System.Windows.Forms.DataGridView();
            this.gbHopDong.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numTienCoc)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numThoiHanThue)).BeginInit();
            this.gbChonPhong.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPhongChon)).BeginInit();
            this.gbDanhSachHD.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHopDong)).BeginInit();
            this.SuspendLayout();
            // 
            // lblTieuDe
            // 
            this.lblTieuDe.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblTieuDe.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold);
            this.lblTieuDe.ForeColor = System.Drawing.Color.DarkBlue;
            this.lblTieuDe.Location = new System.Drawing.Point(0, 0);
            this.lblTieuDe.Name = "lblTieuDe";
            this.lblTieuDe.Size = new System.Drawing.Size(1034, 55);
            this.lblTieuDe.TabIndex = 0;
            this.lblTieuDe.Text = "LẬP HỢP ĐỒNG THUÊ VĂN PHÒNG CAO ỐC";
            this.lblTieuDe.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // gbHopDong
            // 
            this.gbHopDong.Controls.Add(this.txtTong6Thang);
            this.gbHopDong.Controls.Add(this.lblTong6Thang);
            this.gbHopDong.Controls.Add(this.txtTien1Thang);
            this.gbHopDong.Controls.Add(this.lblTien1Thang);
            this.gbHopDong.Controls.Add(this.numTienCoc);
            this.gbHopDong.Controls.Add(this.lblTienCoc);
            this.gbHopDong.Controls.Add(this.dtpNgayKetThuc);
            this.gbHopDong.Controls.Add(this.lblNgayKetThuc);
            this.gbHopDong.Controls.Add(this.numThoiHanThue);
            this.gbHopDong.Controls.Add(this.lblThoiHan);
            this.gbHopDong.Controls.Add(this.dtpNgayBatDau);
            this.gbHopDong.Controls.Add(this.lblNgayBatDau);
            this.gbHopDong.Controls.Add(this.dtpNgayKy);
            this.gbHopDong.Controls.Add(this.lblNgayKy);
            this.gbHopDong.Controls.Add(this.cboKhachHang);
            this.gbHopDong.Controls.Add(this.lblKhachHang);
            this.gbHopDong.Controls.Add(this.txtMaHD);
            this.gbHopDong.Controls.Add(this.lblMaHD);
            this.gbHopDong.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.gbHopDong.Location = new System.Drawing.Point(15, 60);
            this.gbHopDong.Name = "gbHopDong";
            this.gbHopDong.Size = new System.Drawing.Size(500, 310);
            this.gbHopDong.TabIndex = 1;
            this.gbHopDong.TabStop = false;
            this.gbHopDong.Text = "1. Thông tin hợp đồng";
            // 
            // txtTong6Thang
            // 
            this.txtTong6Thang.BackColor = System.Drawing.Color.LightYellow;
            this.txtTong6Thang.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.txtTong6Thang.ForeColor = System.Drawing.Color.Red;
            this.txtTong6Thang.Location = new System.Drawing.Point(145, 270);
            this.txtTong6Thang.Name = "txtTong6Thang";
            this.txtTong6Thang.ReadOnly = true;
            this.txtTong6Thang.Size = new System.Drawing.Size(340, 29);
            this.txtTong6Thang.TabIndex = 17;
            this.txtTong6Thang.Text = "0";
            // 
            // lblTong6Thang
            // 
            this.lblTong6Thang.AutoSize = true;
            this.lblTong6Thang.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblTong6Thang.Location = new System.Drawing.Point(15, 274);
            this.lblTong6Thang.Name = "lblTong6Thang";
            this.lblTong6Thang.Size = new System.Drawing.Size(126, 20);
            this.lblTong6Thang.TabIndex = 16;
            this.lblTong6Thang.Text = "Tiền 6 tháng đầu:";
            // 
            // txtTien1Thang
            // 
            this.txtTien1Thang.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtTien1Thang.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.txtTien1Thang.Location = new System.Drawing.Point(145, 235);
            this.txtTien1Thang.Name = "txtTien1Thang";
            this.txtTien1Thang.ReadOnly = true;
            this.txtTien1Thang.Size = new System.Drawing.Size(340, 29);
            this.txtTien1Thang.TabIndex = 15;
            this.txtTien1Thang.Text = "0";
            // 
            // lblTien1Thang
            // 
            this.lblTien1Thang.AutoSize = true;
            this.lblTien1Thang.Location = new System.Drawing.Point(15, 239);
            this.lblTien1Thang.Name = "lblTien1Thang";
            this.lblTien1Thang.Size = new System.Drawing.Size(117, 21);
            this.lblTien1Thang.TabIndex = 14;
            this.lblTien1Thang.Text = "Tổng tiền/tháng:";
            // 
            // numTienCoc
            // 
            this.numTienCoc.Increment = new decimal(new int[] { 5000000, 0, 0, 0 });
            this.numTienCoc.Location = new System.Drawing.Point(145, 200);
            this.numTienCoc.Maximum = new decimal(new int[] { 1410065408, 2, 0, 0 });
            this.numTienCoc.Name = "numTienCoc";
            this.numTienCoc.Size = new System.Drawing.Size(340, 29);
            this.numTienCoc.TabIndex = 13;
            this.numTienCoc.ThousandsSeparator = true;
            // 
            // lblTienCoc
            // 
            this.lblTienCoc.AutoSize = true;
            this.lblTienCoc.Location = new System.Drawing.Point(15, 204);
            this.lblTienCoc.Name = "lblTienCoc";
            this.lblTienCoc.Size = new System.Drawing.Size(71, 21);
            this.lblTienCoc.TabIndex = 12;
            this.lblTienCoc.Text = "Tiền cọc:";
            // 
            // dtpNgayKetThuc
            // 
            this.dtpNgayKetThuc.CustomFormat = "dd/MM/yyyy";
            this.dtpNgayKetThuc.Enabled = false;
            this.dtpNgayKetThuc.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpNgayKetThuc.Location = new System.Drawing.Point(340, 165);
            this.dtpNgayKetThuc.Name = "dtpNgayKetThuc";
            this.dtpNgayKetThuc.Size = new System.Drawing.Size(145, 29);
            this.dtpNgayKetThuc.TabIndex = 11;
            // 
            // lblNgayKetThuc
            // 
            this.lblNgayKetThuc.AutoSize = true;
            this.lblNgayKetThuc.Location = new System.Drawing.Point(265, 170);
            this.lblNgayKetThuc.Name = "lblNgayKetThuc";
            this.lblNgayKetThuc.Size = new System.Drawing.Size(70, 21);
            this.lblNgayKetThuc.TabIndex = 10;
            this.lblNgayKetThuc.Text = "Kết thúc:";
            // 
            // numThoiHanThue
            // 
            this.numThoiHanThue.Location = new System.Drawing.Point(145, 165);
            this.numThoiHanThue.Maximum = new decimal(new int[] { 120, 0, 0, 0 });
            this.numThoiHanThue.Minimum = new decimal(new int[] { 6, 0, 0, 0 });
            this.numThoiHanThue.Name = "numThoiHanThue";
            this.numThoiHanThue.Size = new System.Drawing.Size(110, 29);
            this.numThoiHanThue.TabIndex = 9;
            this.numThoiHanThue.Value = new decimal(new int[] { 12, 0, 0, 0 });
            // 
            // lblThoiHan
            // 
            this.lblThoiHan.AutoSize = true;
            this.lblThoiHan.Location = new System.Drawing.Point(15, 169);
            this.lblThoiHan.Name = "lblThoiHan";
            this.lblThoiHan.Size = new System.Drawing.Size(126, 21);
            this.lblThoiHan.TabIndex = 8;
            this.lblThoiHan.Text = "Thời hạn (tháng):";
            // 
            // dtpNgayBatDau
            // 
            this.dtpNgayBatDau.CustomFormat = "dd/MM/yyyy";
            this.dtpNgayBatDau.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpNgayBatDau.Location = new System.Drawing.Point(145, 130);
            this.dtpNgayBatDau.Name = "dtpNgayBatDau";
            this.dtpNgayBatDau.Size = new System.Drawing.Size(340, 29);
            this.dtpNgayBatDau.TabIndex = 7;
            // 
            // lblNgayBatDau
            // 
            this.lblNgayBatDau.AutoSize = true;
            this.lblNgayBatDau.Location = new System.Drawing.Point(15, 135);
            this.lblNgayBatDau.Name = "lblNgayBatDau";
            this.lblNgayBatDau.Size = new System.Drawing.Size(106, 21);
            this.lblNgayBatDau.TabIndex = 6;
            this.lblNgayBatDau.Text = "Ngày bắt đầu:";
            // 
            // dtpNgayKy
            // 
            this.dtpNgayKy.CustomFormat = "dd/MM/yyyy";
            this.dtpNgayKy.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpNgayKy.Location = new System.Drawing.Point(145, 95);
            this.dtpNgayKy.Name = "dtpNgayKy";
            this.dtpNgayKy.Size = new System.Drawing.Size(340, 29);
            this.dtpNgayKy.TabIndex = 5;
            // 
            // lblNgayKy
            // 
            this.lblNgayKy.AutoSize = true;
            this.lblNgayKy.Location = new System.Drawing.Point(15, 100);
            this.lblNgayKy.Name = "lblNgayKy";
            this.lblNgayKy.Size = new System.Drawing.Size(70, 21);
            this.lblNgayKy.TabIndex = 4;
            this.lblNgayKy.Text = "Ngày ký:";
            // 
            // cboKhachHang
            // 
            this.cboKhachHang.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboKhachHang.FormattingEnabled = true;
            this.cboKhachHang.Location = new System.Drawing.Point(145, 60);
            this.cboKhachHang.Name = "cboKhachHang";
            this.cboKhachHang.Size = new System.Drawing.Size(340, 29);
            this.cboKhachHang.TabIndex = 3;
            // 
            // lblKhachHang
            // 
            this.lblKhachHang.AutoSize = true;
            this.lblKhachHang.Location = new System.Drawing.Point(15, 64);
            this.lblKhachHang.Name = "lblKhachHang";
            this.lblKhachHang.Size = new System.Drawing.Size(94, 21);
            this.lblKhachHang.TabIndex = 2;
            this.lblKhachHang.Text = "Khách hàng:";
            // 
            // txtMaHD
            // 
            this.txtMaHD.Location = new System.Drawing.Point(145, 25);
            this.txtMaHD.Name = "txtMaHD";
            this.txtMaHD.Size = new System.Drawing.Size(340, 29);
            this.txtMaHD.TabIndex = 1;
            // 
            // lblMaHD
            // 
            this.lblMaHD.AutoSize = true;
            this.lblMaHD.Location = new System.Drawing.Point(15, 29);
            this.lblMaHD.Name = "lblMaHD";
            this.lblMaHD.Size = new System.Drawing.Size(61, 21);
            this.lblMaHD.TabIndex = 0;
            this.lblMaHD.Text = "Mã HĐ:";
            // 
            // gbChonPhong
            // 
            this.gbChonPhong.Controls.Add(this.dgvPhongChon);
            this.gbChonPhong.Controls.Add(this.txtGhiChuPhong);
            this.gbChonPhong.Controls.Add(this.lblGhiChuPhong);
            this.gbChonPhong.Controls.Add(this.btnXoaPhong);
            this.gbChonPhong.Controls.Add(this.btnThemPhong);
            this.gbChonPhong.Controls.Add(this.cboPhongTrong);
            this.gbChonPhong.Controls.Add(this.lblPhongTrong);
            this.gbChonPhong.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.gbChonPhong.Location = new System.Drawing.Point(525, 60);
            this.gbChonPhong.Name = "gbChonPhong";
            this.gbChonPhong.Size = new System.Drawing.Size(495, 310);
            this.gbChonPhong.TabIndex = 2;
            this.gbChonPhong.TabStop = false;
            this.gbChonPhong.Text = "2. Chọn danh sách văn phòng thuê (nhiều phòng)";
            // 
            // dgvPhongChon
            // 
            this.dgvPhongChon.AllowUserToAddRows = false;
            this.dgvPhongChon.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvPhongChon.BackgroundColor = System.Drawing.Color.White;
            this.dgvPhongChon.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPhongChon.Location = new System.Drawing.Point(10, 110);
            this.dgvPhongChon.Name = "dgvPhongChon";
            this.dgvPhongChon.ReadOnly = true;
            this.dgvPhongChon.RowHeadersWidth = 51;
            this.dgvPhongChon.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvPhongChon.Size = new System.Drawing.Size(475, 189);
            this.dgvPhongChon.TabIndex = 6;
            // 
            // txtGhiChuPhong
            // 
            this.txtGhiChuPhong.Location = new System.Drawing.Point(110, 68);
            this.txtGhiChuPhong.Name = "txtGhiChuPhong";
            this.txtGhiChuPhong.Size = new System.Drawing.Size(200, 29);
            this.txtGhiChuPhong.TabIndex = 5;
            // 
            // lblGhiChuPhong
            // 
            this.lblGhiChuPhong.AutoSize = true;
            this.lblGhiChuPhong.Location = new System.Drawing.Point(10, 71);
            this.lblGhiChuPhong.Name = "lblGhiChuPhong";
            this.lblGhiChuPhong.Size = new System.Drawing.Size(66, 21);
            this.lblGhiChuPhong.TabIndex = 4;
            this.lblGhiChuPhong.Text = "Ghi chú:";
            // 
            // btnXoaPhong
            // 
            this.btnXoaPhong.BackColor = System.Drawing.Color.MistyRose;
            this.btnXoaPhong.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btnXoaPhong.Location = new System.Drawing.Point(320, 68);
            this.btnXoaPhong.Name = "btnXoaPhong";
            this.btnXoaPhong.Size = new System.Drawing.Size(165, 32);
            this.btnXoaPhong.TabIndex = 3;
            this.btnXoaPhong.Text = "Xóa phòng chọn";
            this.btnXoaPhong.UseVisualStyleBackColor = false;
            this.btnXoaPhong.Click += new System.EventHandler(this.btnXoaPhong_Click);
            // 
            // btnThemPhong
            // 
            this.btnThemPhong.BackColor = System.Drawing.Color.LightCyan;
            this.btnThemPhong.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btnThemPhong.Location = new System.Drawing.Point(320, 28);
            this.btnThemPhong.Name = "btnThemPhong";
            this.btnThemPhong.Size = new System.Drawing.Size(165, 32);
            this.btnThemPhong.TabIndex = 2;
            this.btnThemPhong.Text = "+ Thêm vào HĐ";
            this.btnThemPhong.UseVisualStyleBackColor = false;
            this.btnThemPhong.Click += new System.EventHandler(this.btnThemPhong_Click);
            // 
            // cboPhongTrong
            // 
            this.cboPhongTrong.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboPhongTrong.FormattingEnabled = true;
            this.cboPhongTrong.Location = new System.Drawing.Point(110, 30);
            this.cboPhongTrong.Name = "cboPhongTrong";
            this.cboPhongTrong.Size = new System.Drawing.Size(200, 29);
            this.cboPhongTrong.TabIndex = 1;
            // 
            // lblPhongTrong
            // 
            this.lblPhongTrong.AutoSize = true;
            this.lblPhongTrong.Location = new System.Drawing.Point(10, 34);
            this.lblPhongTrong.Name = "lblPhongTrong";
            this.lblPhongTrong.Size = new System.Drawing.Size(101, 21);
            this.lblPhongTrong.TabIndex = 0;
            this.lblPhongTrong.Text = "Phòng trống:";
            // 
            // btnLuuHopDong
            // 
            this.btnLuuHopDong.BackColor = System.Drawing.Color.LightGreen;
            this.btnLuuHopDong.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.btnLuuHopDong.Location = new System.Drawing.Point(280, 380);
            this.btnLuuHopDong.Name = "btnLuuHopDong";
            this.btnLuuHopDong.Size = new System.Drawing.Size(220, 42);
            this.btnLuuHopDong.TabIndex = 3;
            this.btnLuuHopDong.Text = "Ký & Lưu Hợp Đồng";
            this.btnLuuHopDong.UseVisualStyleBackColor = false;
            this.btnLuuHopDong.Click += new System.EventHandler(this.btnLuuHopDong_Click);
            // 
            // btnLamMoi
            // 
            this.btnLamMoi.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnLamMoi.Location = new System.Drawing.Point(520, 380);
            this.btnLamMoi.Name = "btnLamMoi";
            this.btnLamMoi.Size = new System.Drawing.Size(120, 42);
            this.btnLamMoi.TabIndex = 4;
            this.btnLamMoi.Text = "Làm mới";
            this.btnLamMoi.UseVisualStyleBackColor = true;
            this.btnLamMoi.Click += new System.EventHandler(this.btnLamMoi_Click);
            // 
            // btnDong
            // 
            this.btnDong.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnDong.Location = new System.Drawing.Point(660, 380);
            this.btnDong.Name = "btnDong";
            this.btnDong.Size = new System.Drawing.Size(120, 42);
            this.btnDong.TabIndex = 5;
            this.btnDong.Text = "Đóng";
            this.btnDong.UseVisualStyleBackColor = true;
            this.btnDong.Click += new System.EventHandler(this.btnDong_Click);
            // 
            // gbDanhSachHD
            // 
            this.gbDanhSachHD.Controls.Add(this.dgvHopDong);
            this.gbDanhSachHD.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.gbDanhSachHD.Location = new System.Drawing.Point(15, 430);
            this.gbDanhSachHD.Name = "gbDanhSachHD";
            this.gbDanhSachHD.Size = new System.Drawing.Size(1005, 235);
            this.gbDanhSachHD.TabIndex = 6;
            this.gbDanhSachHD.TabStop = false;
            this.gbDanhSachHD.Text = "3. Danh sách các hợp đồng thuê đang hiệu lực";
            // 
            // dgvHopDong
            // 
            this.dgvHopDong.AllowUserToAddRows = false;
            this.dgvHopDong.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvHopDong.BackgroundColor = System.Drawing.Color.White;
            this.dgvHopDong.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvHopDong.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvHopDong.Location = new System.Drawing.Point(3, 25);
            this.dgvHopDong.Name = "dgvHopDong";
            this.dgvHopDong.ReadOnly = true;
            this.dgvHopDong.RowHeadersWidth = 51;
            this.dgvHopDong.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvHopDong.Size = new System.Drawing.Size(999, 207);
            this.dgvHopDong.TabIndex = 0;
            // 
            // FrmHopDongThue
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(248)))), ((int)(((byte)(250)))));
            this.ClientSize = new System.Drawing.Size(1034, 680);
            this.Controls.Add(this.gbDanhSachHD);
            this.Controls.Add(this.btnDong);
            this.Controls.Add(this.btnLamMoi);
            this.Controls.Add(this.btnLuuHopDong);
            this.Controls.Add(this.gbChonPhong);
            this.Controls.Add(this.gbHopDong);
            this.Controls.Add(this.lblTieuDe);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "FrmHopDongThue";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quản lý Lập Hợp đồng Thuê Văn phòng";
            this.Load += new System.EventHandler(this.FrmHopDongThue_Load);
            this.gbHopDong.ResumeLayout(false);
            this.gbHopDong.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numTienCoc)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numThoiHanThue)).EndInit();
            this.gbChonPhong.ResumeLayout(false);
            this.gbChonPhong.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPhongChon)).EndInit();
            this.gbDanhSachHD.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvHopDong)).EndInit();
            this.ResumeLayout(false);
        }
        #endregion

        private System.Windows.Forms.Label lblTieuDe;
        private System.Windows.Forms.GroupBox gbHopDong;
        private System.Windows.Forms.Label lblMaHD;
        private System.Windows.Forms.TextBox txtMaHD;
        private System.Windows.Forms.Label lblKhachHang;
        private System.Windows.Forms.ComboBox cboKhachHang;
        private System.Windows.Forms.Label lblNgayKy;
        private System.Windows.Forms.DateTimePicker dtpNgayKy;
        private System.Windows.Forms.Label lblNgayBatDau;
        private System.Windows.Forms.DateTimePicker dtpNgayBatDau;
        private System.Windows.Forms.Label lblThoiHan;
        private System.Windows.Forms.NumericUpDown numThoiHanThue;
        private System.Windows.Forms.Label lblNgayKetThuc;
        private System.Windows.Forms.DateTimePicker dtpNgayKetThuc;
        private System.Windows.Forms.Label lblTienCoc;
        private System.Windows.Forms.NumericUpDown numTienCoc;
        private System.Windows.Forms.Label lblTien1Thang;
        private System.Windows.Forms.TextBox txtTien1Thang;
        private System.Windows.Forms.Label lblTong6Thang;
        private System.Windows.Forms.TextBox txtTong6Thang;
        private System.Windows.Forms.GroupBox gbChonPhong;
        private System.Windows.Forms.Label lblPhongTrong;
        private System.Windows.Forms.ComboBox cboPhongTrong;
        private System.Windows.Forms.Button btnThemPhong;
        private System.Windows.Forms.Button btnXoaPhong;
        private System.Windows.Forms.Label lblGhiChuPhong;
        private System.Windows.Forms.TextBox txtGhiChuPhong;
        private System.Windows.Forms.DataGridView dgvPhongChon;
        private System.Windows.Forms.Button btnLuuHopDong;
        private System.Windows.Forms.Button btnLamMoi;
        private System.Windows.Forms.Button btnDong;
        private System.Windows.Forms.GroupBox gbDanhSachHD;
        private System.Windows.Forms.DataGridView dgvHopDong;
    }
}