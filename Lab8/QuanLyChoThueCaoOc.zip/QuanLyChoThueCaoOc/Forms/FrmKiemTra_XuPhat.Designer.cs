﻿namespace QuanLyChoThueCaoOc.Forms
{
    partial class FrmKiemTra_XuPhat
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code
        private void InitializeComponent()
        {
            this.lblTieuDe = new System.Windows.Forms.Label();
            this.gbThongTin = new System.Windows.Forms.GroupBox();
            this.cboTrangThai = new System.Windows.Forms.ComboBox();
            this.lblTrangThai = new System.Windows.Forms.Label();
            this.txtBienPhap = new System.Windows.Forms.TextBox();
            this.lblBienPhap = new System.Windows.Forms.Label();
            this.numTienPhat = new System.Windows.Forms.NumericUpDown();
            this.lblTienPhat = new System.Windows.Forms.Label();
            this.txtMoTa = new System.Windows.Forms.TextBox();
            this.lblMoTa = new System.Windows.Forms.Label();
            this.dtpNgayLap = new System.Windows.Forms.DateTimePicker();
            this.lblNgayLap = new System.Windows.Forms.Label();
            this.cboLoaiBB = new System.Windows.Forms.ComboBox();
            this.lblLoaiBB = new System.Windows.Forms.Label();
            this.cboPhong = new System.Windows.Forms.ComboBox();
            this.lblPhong = new System.Windows.Forms.Label();
            this.txtMaBB = new System.Windows.Forms.TextBox();
            this.lblMaBB = new System.Windows.Forms.Label();
            this.btnLapBB = new System.Windows.Forms.Button();
            this.btnCapNhatTrangThai = new System.Windows.Forms.Button();
            this.btnLamMoi = new System.Windows.Forms.Button();
            this.btnDong = new System.Windows.Forms.Button();
            this.gbDanhSach = new System.Windows.Forms.GroupBox();
            this.dgvBienBan = new System.Windows.Forms.DataGridView();
            this.gbThongTin.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numTienPhat)).BeginInit();
            this.gbDanhSach.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBienBan)).BeginInit();
            this.SuspendLayout();
            // 
            // lblTieuDe
            // 
            this.lblTieuDe.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblTieuDe.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold);
            this.lblTieuDe.ForeColor = System.Drawing.Color.DarkBlue;
            this.lblTieuDe.Location = new System.Drawing.Point(0, 0);
            this.lblTieuDe.Name = "lblTieuDe";
            this.lblTieuDe.Size = new System.Drawing.Size(1034, 55);
            this.lblTieuDe.TabIndex = 0;
            this.lblTieuDe.Text = "KIỂM TRA ĐỊNH KỲ PHÒNG & BIÊN BẢN XỬ PHẠT";
            this.lblTieuDe.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // gbThongTin
            // 
            this.gbThongTin.Controls.Add(this.cboTrangThai);
            this.gbThongTin.Controls.Add(this.lblTrangThai);
            this.gbThongTin.Controls.Add(this.txtBienPhap);
            this.gbThongTin.Controls.Add(this.lblBienPhap);
            this.gbThongTin.Controls.Add(this.numTienPhat);
            this.gbThongTin.Controls.Add(this.lblTienPhat);
            this.gbThongTin.Controls.Add(this.txtMoTa);
            this.gbThongTin.Controls.Add(this.lblMoTa);
            this.gbThongTin.Controls.Add(this.dtpNgayLap);
            this.gbThongTin.Controls.Add(this.lblNgayLap);
            this.gbThongTin.Controls.Add(this.cboLoaiBB);
            this.gbThongTin.Controls.Add(this.lblLoaiBB);
            this.gbThongTin.Controls.Add(this.cboPhong);
            this.gbThongTin.Controls.Add(this.lblPhong);
            this.gbThongTin.Controls.Add(this.txtMaBB);
            this.gbThongTin.Controls.Add(this.lblMaBB);
            this.gbThongTin.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.gbThongTin.Location = new System.Drawing.Point(15, 60);
            this.gbThongTin.Name = "gbThongTin";
            this.gbThongTin.Size = new System.Drawing.Size(1005, 230);
            this.gbThongTin.TabIndex = 1;
            this.gbThongTin.TabStop = false;
            this.gbThongTin.Text = "Thông tin biên bản kiểm tra / vi phạm kết cấu";
            // 
            // cboTrangThai
            // 
            this.cboTrangThai.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboTrangThai.FormattingEnabled = true;
            this.cboTrangThai.Items.AddRange(new object[] {
            "Chờ xử lý",
            "Đã nộp phạt",
            "Hoàn tất"});
            this.cboTrangThai.Location = new System.Drawing.Point(640, 185);
            this.cboTrangThai.Name = "cboTrangThai";
            this.cboTrangThai.Size = new System.Drawing.Size(345, 29);
            this.cboTrangThai.TabIndex = 15;
            // 
            // lblTrangThai
            // 
            this.lblTrangThai.AutoSize = true;
            this.lblTrangThai.Location = new System.Drawing.Point(530, 189);
            this.lblTrangThai.Name = "lblTrangThai";
            this.lblTrangThai.Size = new System.Drawing.Size(82, 21);
            this.lblTrangThai.TabIndex = 14;
            this.lblTrangThai.Text = "Trạng thái:";
            // 
            // txtBienPhap
            // 
            this.txtBienPhap.Location = new System.Drawing.Point(640, 145);
            this.txtBienPhap.Name = "txtBienPhap";
            this.txtBienPhap.Size = new System.Drawing.Size(345, 29);
            this.txtBienPhap.TabIndex = 13;
            // 
            // lblBienPhap
            // 
            this.lblBienPhap.AutoSize = true;
            this.lblBienPhap.Location = new System.Drawing.Point(530, 149);
            this.lblBienPhap.Name = "lblBienPhap";
            this.lblBienPhap.Size = new System.Drawing.Size(81, 21);
            this.lblBienPhap.TabIndex = 12;
            this.lblBienPhap.Text = "Biện pháp:";
            // 
            // numTienPhat
            // 
            this.numTienPhat.Enabled = false;
            this.numTienPhat.Increment = new decimal(new int[] { 500000, 0, 0, 0 });
            this.numTienPhat.Location = new System.Drawing.Point(640, 105);
            this.numTienPhat.Maximum = new decimal(new int[] { 500000000, 0, 0, 0 });
            this.numTienPhat.Name = "numTienPhat";
            this.numTienPhat.Size = new System.Drawing.Size(345, 29);
            this.numTienPhat.TabIndex = 11;
            this.numTienPhat.ThousandsSeparator = true;
            // 
            // lblTienPhat
            // 
            this.lblTienPhat.AutoSize = true;
            this.lblTienPhat.Location = new System.Drawing.Point(530, 109);
            this.lblTienPhat.Name = "lblTienPhat";
            this.lblTienPhat.Size = new System.Drawing.Size(104, 21);
            this.lblTienPhat.TabIndex = 10;
            this.lblTienPhat.Text = "Tiền phạt (đ):";
            // 
            // txtMoTa
            // 
            this.txtMoTa.Location = new System.Drawing.Point(640, 25);
            this.txtMoTa.Multiline = true;
            this.txtMoTa.Name = "txtMoTa";
            this.txtMoTa.Size = new System.Drawing.Size(345, 68);
            this.txtMoTa.TabIndex = 9;
            // 
            // lblMoTa
            // 
            this.lblMoTa.AutoSize = true;
            this.lblMoTa.Location = new System.Drawing.Point(530, 29);
            this.lblMoTa.Name = "lblMoTa";
            this.lblMoTa.Size = new System.Drawing.Size(107, 21);
            this.lblMoTa.TabIndex = 8;
            this.lblMoTa.Text = "Mô tả kết quả:";
            // 
            // dtpNgayLap
            // 
            this.dtpNgayLap.CustomFormat = "dd/MM/yyyy";
            this.dtpNgayLap.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpNgayLap.Location = new System.Drawing.Point(135, 145);
            this.dtpNgayLap.Name = "dtpNgayLap";
            this.dtpNgayLap.Size = new System.Drawing.Size(360, 29);
            this.dtpNgayLap.TabIndex = 7;
            // 
            // lblNgayLap
            // 
            this.lblNgayLap.AutoSize = true;
            this.lblNgayLap.Location = new System.Drawing.Point(20, 149);
            this.lblNgayLap.Name = "lblNgayLap";
            this.lblNgayLap.Size = new System.Drawing.Size(75, 21);
            this.lblNgayLap.TabIndex = 6;
            this.lblNgayLap.Text = "Ngày lập:";
            // 
            // cboLoaiBB
            // 
            this.cboLoaiBB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboLoaiBB.FormattingEnabled = true;
            this.cboLoaiBB.Items.AddRange(new object[] {
            "Kiểm tra định kỳ 1 năm",
            "Phạt thay đổi kết cấu"});
            this.cboLoaiBB.Location = new System.Drawing.Point(135, 105);
            this.cboLoaiBB.Name = "cboLoaiBB";
            this.cboLoaiBB.Size = new System.Drawing.Size(360, 29);
            this.cboLoaiBB.TabIndex = 5;
            // 
            // lblLoaiBB
            // 
            this.lblLoaiBB.AutoSize = true;
            this.lblLoaiBB.Location = new System.Drawing.Point(20, 109);
            this.lblLoaiBB.Name = "lblLoaiBB";
            this.lblLoaiBB.Size = new System.Drawing.Size(104, 21);
            this.lblLoaiBB.TabIndex = 4;
            this.lblLoaiBB.Text = "Loại biên bản:";
            // 
            // cboPhong
            // 
            this.cboPhong.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboPhong.FormattingEnabled = true;
            this.cboPhong.Location = new System.Drawing.Point(135, 65);
            this.cboPhong.Name = "cboPhong";
            this.cboPhong.Size = new System.Drawing.Size(360, 29);
            this.cboPhong.TabIndex = 3;
            // 
            // lblPhong
            // 
            this.lblPhong.AutoSize = true;
            this.lblPhong.Location = new System.Drawing.Point(20, 69);
            this.lblPhong.Name = "lblPhong";
            this.lblPhong.Size = new System.Drawing.Size(98, 21);
            this.lblPhong.TabIndex = 2;
            this.lblPhong.Text = "Phòng kiểm:";
            // 
            // txtMaBB
            // 
            this.txtMaBB.Location = new System.Drawing.Point(135, 25);
            this.txtMaBB.Name = "txtMaBB";
            this.txtMaBB.Size = new System.Drawing.Size(360, 29);
            this.txtMaBB.TabIndex = 1;
            // 
            // lblMaBB
            // 
            this.lblMaBB.AutoSize = true;
            this.lblMaBB.Location = new System.Drawing.Point(20, 29);
            this.lblMaBB.Name = "lblMaBB";
            this.lblMaBB.Size = new System.Drawing.Size(99, 21);
            this.lblMaBB.TabIndex = 0;
            this.lblMaBB.Text = "Mã biên bản:";
            // 
            // btnLapBB
            // 
            this.btnLapBB.BackColor = System.Drawing.Color.LightSkyBlue;
            this.btnLapBB.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnLapBB.Location = new System.Drawing.Point(170, 305);
            this.btnLapBB.Name = "btnLapBB";
            this.btnLapBB.Size = new System.Drawing.Size(190, 42);
            this.btnLapBB.TabIndex = 2;
            this.btnLapBB.Text = "+ Lập Biên Bản";
            this.btnLapBB.UseVisualStyleBackColor = false;
            this.btnLapBB.Click += new System.EventHandler(this.btnLapBB_Click);
            // 
            // btnCapNhatTrangThai
            // 
            this.btnCapNhatTrangThai.BackColor = System.Drawing.Color.LightGreen;
            this.btnCapNhatTrangThai.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnCapNhatTrangThai.Location = new System.Drawing.Point(380, 305);
            this.btnCapNhatTrangThai.Name = "btnCapNhatTrangThai";
            this.btnCapNhatTrangThai.Size = new System.Drawing.Size(210, 42);
            this.btnCapNhatTrangThai.TabIndex = 3;
            this.btnCapNhatTrangThai.Text = "Cập Nhật Xử Lý";
            this.btnCapNhatTrangThai.UseVisualStyleBackColor = false;
            this.btnCapNhatTrangThai.Click += new System.EventHandler(this.btnCapNhatTrangThai_Click);
            // 
            // btnLamMoi
            // 
            this.btnLamMoi.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnLamMoi.Location = new System.Drawing.Point(610, 305);
            this.btnLamMoi.Name = "btnLamMoi";
            this.btnLamMoi.Size = new System.Drawing.Size(120, 42);
            this.btnLamMoi.TabIndex = 4;
            this.btnLamMoi.Text = "Làm mới";
            this.btnLamMoi.UseVisualStyleBackColor = true;
            this.btnLamMoi.Click += new System.EventHandler(this.btnLamMoi_Click);
            // 
            // btnDong
            // 
            this.btnDong.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnDong.Location = new System.Drawing.Point(750, 305);
            this.btnDong.Name = "btnDong";
            this.btnDong.Size = new System.Drawing.Size(120, 42);
            this.btnDong.TabIndex = 5;
            this.btnDong.Text = "Đóng";
            this.btnDong.UseVisualStyleBackColor = true;
            this.btnDong.Click += new System.EventHandler(this.btnDong_Click);
            // 
            // gbDanhSach
            // 
            this.gbDanhSach.Controls.Add(this.dgvBienBan);
            this.gbDanhSach.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.gbDanhSach.Location = new System.Drawing.Point(15, 360);
            this.gbDanhSach.Name = "gbDanhSach";
            this.gbDanhSach.Size = new System.Drawing.Size(1005, 305);
            this.gbDanhSach.TabIndex = 6;
            this.gbDanhSach.TabStop = false;
            this.gbDanhSach.Text = "Danh sách biên bản kiểm tra & xử phạt kết cấu";
            // 
            // dgvBienBan
            // 
            this.dgvBienBan.AllowUserToAddRows = false;
            this.dgvBienBan.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvBienBan.BackgroundColor = System.Drawing.Color.White;
            this.dgvBienBan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvBienBan.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvBienBan.Location = new System.Drawing.Point(3, 25);
            this.dgvBienBan.Name = "dgvBienBan";
            this.dgvBienBan.ReadOnly = true;
            this.dgvBienBan.RowHeadersWidth = 51;
            this.dgvBienBan.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvBienBan.Size = new System.Drawing.Size(999, 277);
            this.dgvBienBan.TabIndex = 0;
            this.dgvBienBan.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvBienBan_CellClick);
            // 
            // FrmKiemTra_XuPhat
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(248)))), ((int)(((byte)(250)))));
            this.ClientSize = new System.Drawing.Size(1034, 680);
            this.Controls.Add(this.gbDanhSach);
            this.Controls.Add(this.btnDong);
            this.Controls.Add(this.btnLamMoi);
            this.Controls.Add(this.btnCapNhatTrangThai);
            this.Controls.Add(this.btnLapBB);
            this.Controls.Add(this.gbThongTin);
            this.Controls.Add(this.lblTieuDe);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "FrmKiemTra_XuPhat";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quản lý Kiểm tra & Xử phạt Kết cấu";
            this.Load += new System.EventHandler(this.FrmKiemTra_XuPhat_Load);
            this.gbThongTin.ResumeLayout(false);
            this.gbThongTin.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numTienPhat)).EndInit();
            this.gbDanhSach.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvBienBan)).EndInit();
            this.ResumeLayout(false);
        }
        #endregion

        private System.Windows.Forms.Label lblTieuDe;
        private System.Windows.Forms.GroupBox gbThongTin;
        private System.Windows.Forms.Label lblMaBB;
        private System.Windows.Forms.TextBox txtMaBB;
        private System.Windows.Forms.Label lblPhong;
        private System.Windows.Forms.ComboBox cboPhong;
        private System.Windows.Forms.Label lblLoaiBB;
        private System.Windows.Forms.ComboBox cboLoaiBB;
        private System.Windows.Forms.Label lblNgayLap;
        private System.Windows.Forms.DateTimePicker dtpNgayLap;
        private System.Windows.Forms.Label lblMoTa;
        private System.Windows.Forms.TextBox txtMoTa;
        private System.Windows.Forms.Label lblTienPhat;
        private System.Windows.Forms.NumericUpDown numTienPhat;
        private System.Windows.Forms.Label lblBienPhap;
        private System.Windows.Forms.TextBox txtBienPhap;
        private System.Windows.Forms.Label lblTrangThai;
        private System.Windows.Forms.ComboBox cboTrangThai;
        private System.Windows.Forms.Button btnLapBB;
        private System.Windows.Forms.Button btnCapNhatTrangThai;
        private System.Windows.Forms.Button btnLamMoi;
        private System.Windows.Forms.Button btnDong;
        private System.Windows.Forms.GroupBox gbDanhSach;
        private System.Windows.Forms.DataGridView dgvBienBan;
    }
}