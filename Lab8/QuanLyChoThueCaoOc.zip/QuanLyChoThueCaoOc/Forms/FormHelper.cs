﻿using System;
using System.Data;
using System.Windows.Forms;

namespace QuanLyChoThueCaoOc.Forms
{
    internal static class FormHelper
    {
        public static void Nap(ComboBox cbo, DataTable dt, string display, string value)
        {
            cbo.DataSource = dt;
            cbo.DisplayMember = display;
            cbo.ValueMember = value;
        }

        public static string Gia(ComboBox cbo)
        {
            return cbo.SelectedValue == null ? "" : cbo.SelectedValue.ToString();
        }

        public static string O(DataGridView dgv, string cot)
        {
            return dgv.CurrentRow == null ? "" : Convert.ToString(dgv.CurrentRow.Cells[cot].Value);
        }

        public static void ThongBao(string nd, bool thanhCong = true)
        {
            MessageBox.Show(nd, thanhCong ? "Thông báo" : "Cảnh báo lỗi",
                MessageBoxButtons.OK, thanhCong ? MessageBoxIcon.Information : MessageBoxIcon.Warning);
        }
    }
}