﻿namespace QuanLyChoThueCaoOc.Forms
{
    partial class FrmPhong_KhachHang
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code
        private void InitializeComponent()
        {
            this.lblTieuDe = new System.Windows.Forms.Label();
            this.tabMain = new System.Windows.Forms.TabControl();
            this.tpPhong = new System.Windows.Forms.TabPage();
            this.gbDanhSachPhong = new System.Windows.Forms.GroupBox();
            this.dgvPhong = new System.Windows.Forms.DataGridView();
            this.btnDong1 = new System.Windows.Forms.Button();
            this.btnLamMoiPhong = new System.Windows.Forms.Button();
            this.btnXoaPhong = new System.Windows.Forms.Button();
            this.btnSuaPhong = new System.Windows.Forms.Button();
            this.btnThemPhong = new System.Windows.Forms.Button();
            this.gbThongTinPhong = new System.Windows.Forms.GroupBox();
            this.cboTrangThai = new System.Windows.Forms.ComboBox();
            this.lblTrangThai = new System.Windows.Forms.Label();
            this.numDonGia = new System.Windows.Forms.NumericUpDown();
            this.lblDonGia = new System.Windows.Forms.Label();
            this.txtHuong = new System.Windows.Forms.TextBox();
            this.lblHuong = new System.Windows.Forms.Label();
            this.numDienTich = new System.Windows.Forms.NumericUpDown();
            this.lblDienTich = new System.Windows.Forms.Label();
            this.numDoCao = new System.Windows.Forms.NumericUpDown();
            this.lblDoCao = new System.Windows.Forms.Label();
            this.numSoTang = new System.Windows.Forms.NumericUpDown();
            this.lblSoTang = new System.Windows.Forms.Label();
            this.txtTenPhong = new System.Windows.Forms.TextBox();
            this.lblTenPhong = new System.Windows.Forms.Label();
            this.txtMaPhong = new System.Windows.Forms.TextBox();
            this.lblMaPhong = new System.Windows.Forms.Label();
            this.tpKhachHang = new System.Windows.Forms.TabPage();
            this.gbDanhSachKH = new System.Windows.Forms.GroupBox();
            this.dgvKhachHang = new System.Windows.Forms.DataGridView();
            this.btnDong2 = new System.Windows.Forms.Button();
            this.btnLamMoiKH = new System.Windows.Forms.Button();
            this.btnXoaKH = new System.Windows.Forms.Button();
            this.btnSuaKH = new System.Windows.Forms.Button();
            this.btnThemKH = new System.Windows.Forms.Button();
            this.gbThongTinKH = new System.Windows.Forms.GroupBox();
            this.txtDiaChi = new System.Windows.Forms.TextBox();
            this.lblDiaChi = new System.Windows.Forms.Label();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.lblEmail = new System.Windows.Forms.Label();
            this.txtDienThoai = new System.Windows.Forms.TextBox();
            this.lblDienThoai = new System.Windows.Forms.Label();
            this.txtMST = new System.Windows.Forms.TextBox();
            this.lblMST = new System.Windows.Forms.Label();
            this.txtNguoiDaiDien = new System.Windows.Forms.TextBox();
            this.lblNguoiDaiDien = new System.Windows.Forms.Label();
            this.txtTenCongTy = new System.Windows.Forms.TextBox();
            this.lblTenCongTy = new System.Windows.Forms.Label();
            this.txtMaKH = new System.Windows.Forms.TextBox();
            this.lblMaKH = new System.Windows.Forms.Label();
            this.tabMain.SuspendLayout();
            this.tpPhong.SuspendLayout();
            this.gbDanhSachPhong.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPhong)).BeginInit();
            this.gbThongTinPhong.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numDonGia)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numDienTich)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numDoCao)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numSoTang)).BeginInit();
            this.tpKhachHang.SuspendLayout();
            this.gbDanhSachKH.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvKhachHang)).BeginInit();
            this.gbThongTinKH.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblTieuDe
            // 
            this.lblTieuDe.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblTieuDe.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold);
            this.lblTieuDe.ForeColor = System.Drawing.Color.DarkBlue;
            this.lblTieuDe.Location = new System.Drawing.Point(0, 0);
            this.lblTieuDe.Name = "lblTieuDe";
            this.lblTieuDe.Size = new System.Drawing.Size(1034, 50);
            this.lblTieuDe.TabIndex = 0;
            this.lblTieuDe.Text = "DANH MỤC VĂN PHÒNG & KHÁCH HÀNG DOANH NGHIỆP";
            this.lblTieuDe.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tabMain
            // 
            this.tabMain.Controls.Add(this.tpPhong);
            this.tabMain.Controls.Add(this.tpKhachHang);
            this.tabMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabMain.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tabMain.Location = new System.Drawing.Point(0, 50);
            this.tabMain.Name = "tabMain";
            this.tabMain.SelectedIndex = 0;
            this.tabMain.Size = new System.Drawing.Size(1034, 630);
            this.tabMain.TabIndex = 1;
            // 
            // tpPhong
            // 
            this.tpPhong.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(248)))), ((int)(((byte)(250)))));
            this.tpPhong.Controls.Add(this.gbDanhSachPhong);
            this.tpPhong.Controls.Add(this.btnDong1);
            this.tpPhong.Controls.Add(this.btnLamMoiPhong);
            this.tpPhong.Controls.Add(this.btnXoaPhong);
            this.tpPhong.Controls.Add(this.btnSuaPhong);
            this.tpPhong.Controls.Add(this.btnThemPhong);
            this.tpPhong.Controls.Add(this.gbThongTinPhong);
            this.tpPhong.Location = new System.Drawing.Point(4, 32);
            this.tpPhong.Name = "tpPhong";
            this.tpPhong.Padding = new System.Windows.Forms.Padding(3);
            this.tpPhong.Size = new System.Drawing.Size(1026, 594);
            this.tpPhong.TabIndex = 0;
            this.tpPhong.Text = "1. Quản lý Văn phòng cho thuê";
            // 
            // gbDanhSachPhong
            // 
            this.gbDanhSachPhong.Controls.Add(this.dgvPhong);
            this.gbDanhSachPhong.Location = new System.Drawing.Point(15, 260);
            this.gbDanhSachPhong.Name = "gbDanhSachPhong";
            this.gbDanhSachPhong.Size = new System.Drawing.Size(995, 320);
            this.gbDanhSachPhong.TabIndex = 6;
            this.gbDanhSachPhong.TabStop = false;
            this.gbDanhSachPhong.Text = "Danh sách văn phòng hiện tại";
            // 
            // dgvPhong
            // 
            this.dgvPhong.AllowUserToAddRows = false;
            this.dgvPhong.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvPhong.BackgroundColor = System.Drawing.Color.White;
            this.dgvPhong.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPhong.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvPhong.Location = new System.Drawing.Point(3, 26);
            this.dgvPhong.Name = "dgvPhong";
            this.dgvPhong.ReadOnly = true;
            this.dgvPhong.RowHeadersWidth = 51;
            this.dgvPhong.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvPhong.Size = new System.Drawing.Size(989, 291);
            this.dgvPhong.TabIndex = 0;
            this.dgvPhong.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvPhong_CellClick);
            // 
            // btnDong1
            // 
            this.btnDong1.Location = new System.Drawing.Point(750, 210);
            this.btnDong1.Name = "btnDong1";
            this.btnDong1.Size = new System.Drawing.Size(110, 40);
            this.btnDong1.TabIndex = 5;
            this.btnDong1.Text = "Đóng";
            this.btnDong1.UseVisualStyleBackColor = true;
            this.btnDong1.Click += new System.EventHandler(this.btnDong_Click);
            // 
            // btnLamMoiPhong
            // 
            this.btnLamMoiPhong.Location = new System.Drawing.Point(620, 210);
            this.btnLamMoiPhong.Name = "btnLamMoiPhong";
            this.btnLamMoiPhong.Size = new System.Drawing.Size(110, 40);
            this.btnLamMoiPhong.TabIndex = 4;
            this.btnLamMoiPhong.Text = "Làm mới";
            this.btnLamMoiPhong.UseVisualStyleBackColor = true;
            this.btnLamMoiPhong.Click += new System.EventHandler(this.btnLamMoiPhong_Click);
            // 
            // btnXoaPhong
            // 
            this.btnXoaPhong.BackColor = System.Drawing.Color.MistyRose;
            this.btnXoaPhong.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnXoaPhong.Location = new System.Drawing.Point(470, 210);
            this.btnXoaPhong.Name = "btnXoaPhong";
            this.btnXoaPhong.Size = new System.Drawing.Size(130, 40);
            this.btnXoaPhong.TabIndex = 3;
            this.btnXoaPhong.Text = "Xóa phòng";
            this.btnXoaPhong.UseVisualStyleBackColor = false;
            this.btnXoaPhong.Click += new System.EventHandler(this.btnXoaPhong_Click);
            // 
            // btnSuaPhong
            // 
            this.btnSuaPhong.BackColor = System.Drawing.Color.LightGoldenrodYellow;
            this.btnSuaPhong.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnSuaPhong.Location = new System.Drawing.Point(320, 210);
            this.btnSuaPhong.Name = "btnSuaPhong";
            this.btnSuaPhong.Size = new System.Drawing.Size(130, 40);
            this.btnSuaPhong.TabIndex = 2;
            this.btnSuaPhong.Text = "Cập nhật";
            this.btnSuaPhong.UseVisualStyleBackColor = false;
            this.btnSuaPhong.Click += new System.EventHandler(this.btnSuaPhong_Click);
            // 
            // btnThemPhong
            // 
            this.btnThemPhong.BackColor = System.Drawing.Color.LightSkyBlue;
            this.btnThemPhong.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnThemPhong.Location = new System.Drawing.Point(170, 210);
            this.btnThemPhong.Name = "btnThemPhong";
            this.btnThemPhong.Size = new System.Drawing.Size(130, 40);
            this.btnThemPhong.TabIndex = 1;
            this.btnThemPhong.Text = "+ Thêm mới";
            this.btnThemPhong.UseVisualStyleBackColor = false;
            this.btnThemPhong.Click += new System.EventHandler(this.btnThemPhong_Click);
            // 
            // gbThongTinPhong
            // 
            this.gbThongTinPhong.Controls.Add(this.cboTrangThai);
            this.gbThongTinPhong.Controls.Add(this.lblTrangThai);
            this.gbThongTinPhong.Controls.Add(this.numDonGia);
            this.gbThongTinPhong.Controls.Add(this.lblDonGia);
            this.gbThongTinPhong.Controls.Add(this.txtHuong);
            this.gbThongTinPhong.Controls.Add(this.lblHuong);
            this.gbThongTinPhong.Controls.Add(this.numDienTich);
            this.gbThongTinPhong.Controls.Add(this.lblDienTich);
            this.gbThongTinPhong.Controls.Add(this.numDoCao);
            this.gbThongTinPhong.Controls.Add(this.lblDoCao);
            this.gbThongTinPhong.Controls.Add(this.numSoTang);
            this.gbThongTinPhong.Controls.Add(this.lblSoTang);
            this.gbThongTinPhong.Controls.Add(this.txtTenPhong);
            this.gbThongTinPhong.Controls.Add(this.lblTenPhong);
            this.gbThongTinPhong.Controls.Add(this.txtMaPhong);
            this.gbThongTinPhong.Controls.Add(this.lblMaPhong);
            this.gbThongTinPhong.Location = new System.Drawing.Point(15, 10);
            this.gbThongTinPhong.Name = "gbThongTinPhong";
            this.gbThongTinPhong.Size = new System.Drawing.Size(995, 185);
            this.gbThongTinPhong.TabIndex = 0;
            this.gbThongTinPhong.TabStop = false;
            this.gbThongTinPhong.Text = "Thông tin phòng";
            // 
            // cboTrangThai
            // 
            this.cboTrangThai.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboTrangThai.FormattingEnabled = true;
            this.cboTrangThai.Items.AddRange(new object[] {
            "Trống",
            "Đang thuê",
            "Cần tu sửa"});
            this.cboTrangThai.Location = new System.Drawing.Point(620, 142);
            this.cboTrangThai.Name = "cboTrangThai";
            this.cboTrangThai.Size = new System.Drawing.Size(345, 31);
            this.cboTrangThai.TabIndex = 15;
            // 
            // lblTrangThai
            // 
            this.lblTrangThai.AutoSize = true;
            this.lblTrangThai.Location = new System.Drawing.Point(510, 146);
            this.lblTrangThai.Name = "lblTrangThai";
            this.lblTrangThai.Size = new System.Drawing.Size(91, 23);
            this.lblTrangThai.TabIndex = 14;
            this.lblTrangThai.Text = "Trạng thái:";
            // 
            // numDonGia
            // 
            this.numDonGia.Increment = new decimal(new int[] { 1000000, 0, 0, 0 });
            this.numDonGia.Location = new System.Drawing.Point(620, 105);
            this.numDonGia.Maximum = new decimal(new int[] { 1000000000, 0, 0, 0 });
            this.numDonGia.Name = "numDonGia";
            this.numDonGia.Size = new System.Drawing.Size(345, 30);
            this.numDonGia.TabIndex = 13;
            this.numDonGia.ThousandsSeparator = true;
            this.numDonGia.Value = new decimal(new int[] { 25000000, 0, 0, 0 });
            // 
            // lblDonGia
            // 
            this.lblDonGia.AutoSize = true;
            this.lblDonGia.Location = new System.Drawing.Point(510, 109);
            this.lblDonGia.Name = "lblDonGia";
            this.lblDonGia.Size = new System.Drawing.Size(107, 23);
            this.lblDonGia.TabIndex = 12;
            this.lblDonGia.Text = "Đơn giá (đ):";
            // 
            // txtHuong
            // 
            this.txtHuong.Location = new System.Drawing.Point(620, 68);
            this.txtHuong.Name = "txtHuong";
            this.txtHuong.Size = new System.Drawing.Size(345, 30);
            this.txtHuong.TabIndex = 11;
            this.txtHuong.Text = "Đông Nam";
            // 
            // lblHuong
            // 
            this.lblHuong.AutoSize = true;
            this.lblHuong.Location = new System.Drawing.Point(510, 72);
            this.lblHuong.Name = "lblHuong";
            this.lblHuong.Size = new System.Drawing.Size(120, 23);
            this.lblHuong.TabIndex = 10;
            this.lblHuong.Text = "Hướng phòng:";
            // 
            // numDienTich
            // 
            this.numDienTich.DecimalPlaces = 2;
            this.numDienTich.Location = new System.Drawing.Point(620, 31);
            this.numDienTich.Maximum = new decimal(new int[] { 10000, 0, 0, 0 });
            this.numDienTich.Name = "numDienTich";
            this.numDienTich.Size = new System.Drawing.Size(345, 30);
            this.numDienTich.TabIndex = 9;
            this.numDienTich.Value = new decimal(new int[] { 85, 0, 0, 0 });
            // 
            // lblDienTich
            // 
            this.lblDienTich.AutoSize = true;
            this.lblDienTich.Location = new System.Drawing.Point(510, 35);
            this.lblDienTich.Name = "lblDienTich";
            this.lblDienTich.Size = new System.Drawing.Size(120, 23);
            this.lblDienTich.TabIndex = 8;
            this.lblDienTich.Text = "Diện tích (m²):";
            // 
            // numDoCao
            // 
            this.numDoCao.DecimalPlaces = 2;
            this.numDoCao.Location = new System.Drawing.Point(125, 142);
            this.numDoCao.Maximum = new decimal(new int[] { 20, 0, 0, 0 });
            this.numDoCao.Name = "numDoCao";
            this.numDoCao.Size = new System.Drawing.Size(345, 30);
            this.numDoCao.TabIndex = 7;
            this.numDoCao.Value = new decimal(new int[] { 33, 0, 0, 65536 });
            // 
            // lblDoCao
            // 
            this.lblDoCao.AutoSize = true;
            this.lblDoCao.Location = new System.Drawing.Point(20, 146);
            this.lblDoCao.Name = "lblDoCao";
            this.lblDoCao.Size = new System.Drawing.Size(100, 23);
            this.lblDoCao.TabIndex = 6;
            this.lblDoCao.Text = "Độ cao (m):";
            // 
            // numSoTang
            // 
            this.numSoTang.Location = new System.Drawing.Point(125, 105);
            this.numSoTang.Maximum = new decimal(new int[] { 100, 0, 0, 0 });
            this.numSoTang.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
            this.numSoTang.Name = "numSoTang";
            this.numSoTang.Size = new System.Drawing.Size(345, 30);
            this.numSoTang.TabIndex = 5;
            this.numSoTang.Value = new decimal(new int[] { 5, 0, 0, 0 });
            // 
            // lblSoTang
            // 
            this.lblSoTang.AutoSize = true;
            this.lblSoTang.Location = new System.Drawing.Point(20, 109);
            this.lblSoTang.Name = "lblSoTang";
            this.lblSoTang.Size = new System.Drawing.Size(73, 23);
            this.lblSoTang.TabIndex = 4;
            this.lblSoTang.Text = "Số tầng:";
            // 
            // txtTenPhong
            // 
            this.txtTenPhong.Location = new System.Drawing.Point(125, 68);
            this.txtTenPhong.Name = "txtTenPhong";
            this.txtTenPhong.Size = new System.Drawing.Size(345, 30);
            this.txtTenPhong.TabIndex = 3;
            // 
            // lblTenPhong
            // 
            this.lblTenPhong.AutoSize = true;
            this.lblTenPhong.Location = new System.Drawing.Point(20, 72);
            this.lblTenPhong.Name = "lblTenPhong";
            this.lblTenPhong.Size = new System.Drawing.Size(95, 23);
            this.lblTenPhong.TabIndex = 2;
            this.lblTenPhong.Text = "Tên phòng:";
            // 
            // txtMaPhong
            // 
            this.txtMaPhong.Location = new System.Drawing.Point(125, 31);
            this.txtMaPhong.Name = "txtMaPhong";
            this.txtMaPhong.Size = new System.Drawing.Size(345, 30);
            this.txtMaPhong.TabIndex = 1;
            // 
            // lblMaPhong
            // 
            this.lblMaPhong.AutoSize = true;
            this.lblMaPhong.Location = new System.Drawing.Point(20, 35);
            this.lblMaPhong.Name = "lblMaPhong";
            this.lblMaPhong.Size = new System.Drawing.Size(93, 23);
            this.lblMaPhong.TabIndex = 0;
            this.lblMaPhong.Text = "Mã phòng:";
            // 
            // tpKhachHang
            // 
            this.tpKhachHang.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(248)))), ((int)(((byte)(250)))));
            this.tpKhachHang.Controls.Add(this.gbDanhSachKH);
            this.tpKhachHang.Controls.Add(this.btnDong2);
            this.tpKhachHang.Controls.Add(this.btnLamMoiKH);
            this.tpKhachHang.Controls.Add(this.btnXoaKH);
            this.tpKhachHang.Controls.Add(this.btnSuaKH);
            this.tpKhachHang.Controls.Add(this.btnThemKH);
            this.tpKhachHang.Controls.Add(this.gbThongTinKH);
            this.tpKhachHang.Location = new System.Drawing.Point(4, 32);
            this.tpKhachHang.Name = "tpKhachHang";
            this.tpKhachHang.Padding = new System.Windows.Forms.Padding(3);
            this.tpKhachHang.Size = new System.Drawing.Size(1026, 594);
            this.tpKhachHang.TabIndex = 1;
            this.tpKhachHang.Text = "2. Quản lý Khách hàng Doanh nghiệp";
            // 
            // gbDanhSachKH
            // 
            this.gbDanhSachKH.Controls.Add(this.dgvKhachHang);
            this.gbDanhSachKH.Location = new System.Drawing.Point(15, 260);
            this.gbDanhSachKH.Name = "gbDanhSachKH";
            this.gbDanhSachKH.Size = new System.Drawing.Size(995, 320);
            this.gbDanhSachKH.TabIndex = 6;
            this.gbDanhSachKH.TabStop = false;
            this.gbDanhSachKH.Text = "Danh sách khách hàng doanh nghiệp";
            // 
            // dgvKhachHang
            // 
            this.dgvKhachHang.AllowUserToAddRows = false;
            this.dgvKhachHang.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvKhachHang.BackgroundColor = System.Drawing.Color.White;
            this.dgvKhachHang.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvKhachHang.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvKhachHang.Location = new System.Drawing.Point(3, 26);
            this.dgvKhachHang.Name = "dgvKhachHang";
            this.dgvKhachHang.ReadOnly = true;
            this.dgvKhachHang.RowHeadersWidth = 51;
            this.dgvKhachHang.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvKhachHang.Size = new System.Drawing.Size(989, 291);
            this.dgvKhachHang.TabIndex = 0;
            this.dgvKhachHang.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvKhachHang_CellClick);
            // 
            // btnDong2
            // 
            this.btnDong2.Location = new System.Drawing.Point(750, 210);
            this.btnDong2.Name = "btnDong2";
            this.btnDong2.Size = new System.Drawing.Size(110, 40);
            this.btnDong2.TabIndex = 5;
            this.btnDong2.Text = "Đóng";
            this.btnDong2.UseVisualStyleBackColor = true;
            this.btnDong2.Click += new System.EventHandler(this.btnDong_Click);
            // 
            // btnLamMoiKH
            // 
            this.btnLamMoiKH.Location = new System.Drawing.Point(620, 210);
            this.btnLamMoiKH.Name = "btnLamMoiKH";
            this.btnLamMoiKH.Size = new System.Drawing.Size(110, 40);
            this.btnLamMoiKH.TabIndex = 4;
            this.btnLamMoiKH.Text = "Làm mới";
            this.btnLamMoiKH.UseVisualStyleBackColor = true;
            this.btnLamMoiKH.Click += new System.EventHandler(this.btnLamMoiKH_Click);
            // 
            // btnXoaKH
            // 
            this.btnXoaKH.BackColor = System.Drawing.Color.MistyRose;
            this.btnXoaKH.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnXoaKH.Location = new System.Drawing.Point(470, 210);
            this.btnXoaKH.Name = "btnXoaKH";
            this.btnXoaKH.Size = new System.Drawing.Size(130, 40);
            this.btnXoaKH.TabIndex = 3;
            this.btnXoaKH.Text = "Xóa KH";
            this.btnXoaKH.UseVisualStyleBackColor = false;
            this.btnXoaKH.Click += new System.EventHandler(this.btnXoaKH_Click);
            // 
            // btnSuaKH
            // 
            this.btnSuaKH.BackColor = System.Drawing.Color.LightGoldenrodYellow;
            this.btnSuaKH.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnSuaKH.Location = new System.Drawing.Point(320, 210);
            this.btnSuaKH.Name = "btnSuaKH";
            this.btnSuaKH.Size = new System.Drawing.Size(130, 40);
            this.btnSuaKH.TabIndex = 2;
            this.btnSuaKH.Text = "Cập nhật";
            this.btnSuaKH.UseVisualStyleBackColor = false;
            this.btnSuaKH.Click += new System.EventHandler(this.btnSuaKH_Click);
            // 
            // btnThemKH
            // 
            this.btnThemKH.BackColor = System.Drawing.Color.LightSkyBlue;
            this.btnThemKH.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnThemKH.Location = new System.Drawing.Point(170, 210);
            this.btnThemKH.Name = "btnThemKH";
            this.btnThemKH.Size = new System.Drawing.Size(130, 40);
            this.btnThemKH.TabIndex = 1;
            this.btnThemKH.Text = "+ Thêm mới";
            this.btnThemKH.UseVisualStyleBackColor = false;
            this.btnThemKH.Click += new System.EventHandler(this.btnThemKH_Click);
            // 
            // gbThongTinKH
            // 
            this.gbThongTinKH.Controls.Add(this.txtDiaChi);
            this.gbThongTinKH.Controls.Add(this.lblDiaChi);
            this.gbThongTinKH.Controls.Add(this.txtEmail);
            this.gbThongTinKH.Controls.Add(this.lblEmail);
            this.gbThongTinKH.Controls.Add(this.txtDienThoai);
            this.gbThongTinKH.Controls.Add(this.lblDienThoai);
            this.gbThongTinKH.Controls.Add(this.txtMST);
            this.gbThongTinKH.Controls.Add(this.lblMST);
            this.gbThongTinKH.Controls.Add(this.txtNguoiDaiDien);
            this.gbThongTinKH.Controls.Add(this.lblNguoiDaiDien);
            this.gbThongTinKH.Controls.Add(this.txtTenCongTy);
            this.gbThongTinKH.Controls.Add(this.lblTenCongTy);
            this.gbThongTinKH.Controls.Add(this.txtMaKH);
            this.gbThongTinKH.Controls.Add(this.lblMaKH);
            this.gbThongTinKH.Location = new System.Drawing.Point(15, 10);
            this.gbThongTinKH.Name = "gbThongTinKH";
            this.gbThongTinKH.Size = new System.Drawing.Size(995, 185);
            this.gbThongTinKH.TabIndex = 0;
            this.gbThongTinKH.TabStop = false;
            this.gbThongTinKH.Text = "Thông tin doanh nghiệp";
            // 
            // txtDiaChi
            // 
            this.txtDiaChi.Location = new System.Drawing.Point(620, 105);
            this.txtDiaChi.Multiline = true;
            this.txtDiaChi.Name = "txtDiaChi";
            this.txtDiaChi.Size = new System.Drawing.Size(345, 67);
            this.txtDiaChi.TabIndex = 13;
            // 
            // lblDiaChi
            // 
            this.lblDiaChi.AutoSize = true;
            this.lblDiaChi.Location = new System.Drawing.Point(510, 109);
            this.lblDiaChi.Name = "lblDiaChi";
            this.lblDiaChi.Size = new System.Drawing.Size(66, 23);
            this.lblDiaChi.TabIndex = 12;
            this.lblDiaChi.Text = "Địa chỉ:";
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(620, 68);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(345, 30);
            this.txtEmail.TabIndex = 11;
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Location = new System.Drawing.Point(510, 72);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(55, 23);
            this.lblEmail.TabIndex = 10;
            this.lblEmail.Text = "Email:";
            // 
            // txtDienThoai
            // 
            this.txtDienThoai.Location = new System.Drawing.Point(620, 31);
            this.txtDienThoai.Name = "txtDienThoai";
            this.txtDienThoai.Size = new System.Drawing.Size(345, 30);
            this.txtDienThoai.TabIndex = 9;
            // 
            // lblDienThoai
            // 
            this.lblDienThoai.AutoSize = true;
            this.lblDienThoai.Location = new System.Drawing.Point(510, 35);
            this.lblDienThoai.Name = "lblDienThoai";
            this.lblDienThoai.Size = new System.Drawing.Size(93, 23);
            this.lblDienThoai.TabIndex = 8;
            this.lblDienThoai.Text = "Điện thoại:";
            // 
            // txtMST
            // 
            this.txtMST.Location = new System.Drawing.Point(145, 142);
            this.txtMST.Name = "txtMST";
            this.txtMST.Size = new System.Drawing.Size(325, 30);
            this.txtMST.TabIndex = 7;
            // 
            // lblMST
            // 
            this.lblMST.AutoSize = true;
            this.lblMST.Location = new System.Drawing.Point(20, 146);
            this.lblMST.Name = "lblMST";
            this.lblMST.Size = new System.Drawing.Size(100, 23);
            this.lblMST.TabIndex = 6;
            this.lblMST.Text = "Mã số thuế:";
            // 
            // txtNguoiDaiDien
            // 
            this.txtNguoiDaiDien.Location = new System.Drawing.Point(145, 105);
            this.txtNguoiDaiDien.Name = "txtNguoiDaiDien";
            this.txtNguoiDaiDien.Size = new System.Drawing.Size(325, 30);
            this.txtNguoiDaiDien.TabIndex = 5;
            // 
            // lblNguoiDaiDien
            // 
            this.lblNguoiDaiDien.AutoSize = true;
            this.lblNguoiDaiDien.Location = new System.Drawing.Point(20, 109);
            this.lblNguoiDaiDien.Name = "lblNguoiDaiDien";
            this.lblNguoiDaiDien.Size = new System.Drawing.Size(126, 23);
            this.lblNguoiDaiDien.TabIndex = 4;
            this.lblNguoiDaiDien.Text = "Người đại diện:";
            // 
            // txtTenCongTy
            // 
            this.txtTenCongTy.Location = new System.Drawing.Point(145, 68);
            this.txtTenCongTy.Name = "txtTenCongTy";
            this.txtTenCongTy.Size = new System.Drawing.Size(325, 30);
            this.txtTenCongTy.TabIndex = 3;
            // 
            // lblTenCongTy
            // 
            this.lblTenCongTy.AutoSize = true;
            this.lblTenCongTy.Location = new System.Drawing.Point(20, 72);
            this.lblTenCongTy.Name = "lblTenCongTy";
            this.lblTenCongTy.Size = new System.Drawing.Size(103, 23);
            this.lblTenCongTy.TabIndex = 2;
            this.lblTenCongTy.Text = "Tên công ty:";
            // 
            // txtMaKH
            // 
            this.txtMaKH.Location = new System.Drawing.Point(145, 31);
            this.txtMaKH.Name = "txtMaKH";
            this.txtMaKH.Size = new System.Drawing.Size(325, 30);
            this.txtMaKH.TabIndex = 1;
            // 
            // lblMaKH
            // 
            this.lblMaKH.AutoSize = true;
            this.lblMaKH.Location = new System.Drawing.Point(20, 35);
            this.lblMaKH.Name = "lblMaKH";
            this.lblMaKH.Size = new System.Drawing.Size(65, 23);
            this.lblMaKH.TabIndex = 0;
            this.lblMaKH.Text = "Mã KH:";
            // 
            // FrmPhong_KhachHang
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(248)))), ((int)(((byte)(250)))));
            this.ClientSize = new System.Drawing.Size(1034, 680);
            this.Controls.Add(this.tabMain);
            this.Controls.Add(this.lblTieuDe);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "FrmPhong_KhachHang";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quản lý Văn phòng & Khách hàng Doanh nghiệp";
            this.Load += new System.EventHandler(this.FrmPhong_KhachHang_Load);
            this.tabMain.ResumeLayout(false);
            this.tpPhong.ResumeLayout(false);
            this.gbDanhSachPhong.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvPhong)).EndInit();
            this.gbThongTinPhong.ResumeLayout(false);
            this.gbThongTinPhong.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numDonGia)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numDienTich)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numDoCao)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numSoTang)).EndInit();
            this.tpKhachHang.ResumeLayout(false);
            this.gbDanhSachKH.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvKhachHang)).EndInit();
            this.gbThongTinKH.ResumeLayout(false);
            this.gbThongTinKH.PerformLayout();
            this.ResumeLayout(false);
        }
        #endregion

        private System.Windows.Forms.Label lblTieuDe;
        private System.Windows.Forms.TabControl tabMain;
        private System.Windows.Forms.TabPage tpPhong;
        private System.Windows.Forms.GroupBox gbThongTinPhong;
        private System.Windows.Forms.Label lblMaPhong;
        private System.Windows.Forms.TextBox txtMaPhong;
        private System.Windows.Forms.Label lblTenPhong;
        private System.Windows.Forms.TextBox txtTenPhong;
        private System.Windows.Forms.Label lblSoTang;
        private System.Windows.Forms.NumericUpDown numSoTang;
        private System.Windows.Forms.Label lblDoCao;
        private System.Windows.Forms.NumericUpDown numDoCao;
        private System.Windows.Forms.Label lblDienTich;
        private System.Windows.Forms.NumericUpDown numDienTich;
        private System.Windows.Forms.Label lblHuong;
        private System.Windows.Forms.TextBox txtHuong;
        private System.Windows.Forms.Label lblDonGia;
        private System.Windows.Forms.NumericUpDown numDonGia;
        private System.Windows.Forms.Label lblTrangThai;
        private System.Windows.Forms.ComboBox cboTrangThai;
        private System.Windows.Forms.Button btnThemPhong;
        private System.Windows.Forms.Button btnSuaPhong;
        private System.Windows.Forms.Button btnXoaPhong;
        private System.Windows.Forms.Button btnLamMoiPhong;
        private System.Windows.Forms.Button btnDong1;
        private System.Windows.Forms.GroupBox gbDanhSachPhong;
        private System.Windows.Forms.DataGridView dgvPhong;
        private System.Windows.Forms.TabPage tpKhachHang;
        private System.Windows.Forms.GroupBox gbThongTinKH;
        private System.Windows.Forms.Label lblMaKH;
        private System.Windows.Forms.TextBox txtMaKH;
        private System.Windows.Forms.Label lblTenCongTy;
        private System.Windows.Forms.TextBox txtTenCongTy;
        private System.Windows.Forms.Label lblNguoiDaiDien;
        private System.Windows.Forms.TextBox txtNguoiDaiDien;
        private System.Windows.Forms.Label lblMST;
        private System.Windows.Forms.TextBox txtMST;
        private System.Windows.Forms.Label lblDienThoai;
        private System.Windows.Forms.TextBox txtDienThoai;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label lblDiaChi;
        private System.Windows.Forms.TextBox txtDiaChi;
        private System.Windows.Forms.Button btnThemKH;
        private System.Windows.Forms.Button btnSuaKH;
        private System.Windows.Forms.Button btnXoaKH;
        private System.Windows.Forms.Button btnLamMoiKH;
        private System.Windows.Forms.Button btnDong2;
        private System.Windows.Forms.GroupBox gbDanhSachKH;
        private System.Windows.Forms.DataGridView dgvKhachHang;
    }
}