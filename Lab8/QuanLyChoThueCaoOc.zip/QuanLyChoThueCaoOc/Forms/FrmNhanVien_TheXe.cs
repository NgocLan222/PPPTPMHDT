﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using QuanLyChoThueCaoOc.Data;

namespace QuanLyChoThueCaoOc.Forms
{
    public partial class FrmNhanVien_TheXe : Form
    {
        public FrmNhanVien_TheXe()
        {
            InitializeComponent();
        }

        private void FrmNhanVien_TheXe_Load(object sender, EventArgs e)
        {
            cboPhai.SelectedIndex = 0;
            cboLoaiXe.SelectedIndex = 0;
            TaiDanhSachCongTy();
            TaiDanhSachPhong();
            TaiDanhSachTongHop();
            TaoMaTuDong();
        }

        private void TaoMaTuDong()
        {
            string thoiGian = DateTime.Now.ToString("yyMMddHHmm").Substring(2, 6);
            txtMaNV.Text = "NV" + thoiGian;
            txtMaThe.Text = "CARD" + thoiGian;
        }

        private void TaiDanhSachCongTy()
        {
            string sql = "SELECT MaKH, MaKH + ' - ' + TenCongTy AS HienThi FROM KhachHang";
            DataTable dt = Db.LayBang(sql);
            FormHelper.Nap(cboCongTy, dt, "HienThi", "MaKH");
        }

        private void TaiDanhSachPhong()
        {
            string sql = "SELECT MaPhong, MaPhong + ' - ' + TenPhong AS HienThi FROM Phong";
            DataTable dt = Db.LayBang(sql);
            FormHelper.Nap(cboPhong, dt, "HienThi", "MaPhong");
        }

        private void TaiDanhSachTongHop()
        {
            // Kết hợp thông tin Nhân viên và Thẻ xe (LEFT JOIN vì có nhân viên chưa cấp thẻ)
            string sql = @"SELECT nv.MaNV, nv.HoTen, nv.Phai, nv.DienThoai, nv.ChucVu, 
                                  kh.TenCongTy, nv.MaPhong, nv.NgayBaoCao, nv.TrangThaiLamViec,
                                  tx.MaThe, tx.BienSoXe, tx.LoaiXe, tx.TrangThaiThe
                           FROM NhanVienVanPhong nv
                           JOIN KhachHang kh ON nv.MaKH = kh.MaKH
                           LEFT JOIN TheGiuXe tx ON nv.MaNV = tx.MaNV
                           ORDER BY nv.NgayBaoCao DESC";
            dgvNhanVien.DataSource = Db.LayBang(sql);
        }

        private void dgvNhanVien_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvNhanVien.CurrentRow == null) return;

            txtMaNV.Text = FormHelper.O(dgvNhanVien, "MaNV");
            txtHoTen.Text = FormHelper.O(dgvNhanVien, "HoTen");
            cboPhai.SelectedItem = FormHelper.O(dgvNhanVien, "Phai");
            txtDienThoai.Text = FormHelper.O(dgvNhanVien, "DienThoai");
            txtChucVu.Text = FormHelper.O(dgvNhanVien, "ChucVu");
            cboPhong.SelectedValue = FormHelper.O(dgvNhanVien, "MaPhong");

            // Nạp thông tin thẻ xe nếu đã có
            string maThe = FormHelper.O(dgvNhanVien, "MaThe");
            if (!string.IsNullOrEmpty(maThe))
            {
                txtMaThe.Text = maThe;
                txtBienSoXe.Text = FormHelper.O(dgvNhanVien, "BienSoXe");
                cboLoaiXe.SelectedItem = FormHelper.O(dgvNhanVien, "LoaiXe");
            }
            else
            {
                txtMaThe.Text = "CARD" + DateTime.Now.ToString("yyMMddHHmm").Substring(2, 6);
                txtBienSoXe.Clear();
                txtHieuXe.Clear();
                txtMauXe.Clear();
            }
        }

        private void btnThemNV_Click(object sender, EventArgs e)
        {
            string maNV = txtMaNV.Text.Trim();
            string hoTen = txtHoTen.Text.Trim();
            string phai = cboPhai.SelectedItem?.ToString() ?? "Nam";
            string dienThoai = txtDienThoai.Text.Trim();
            string chucVu = txtChucVu.Text.Trim();
            string maKH = FormHelper.Gia(cboCongTy);
            string maPhong = FormHelper.Gia(cboPhong);

            if (string.IsNullOrEmpty(maNV) || string.IsNullOrEmpty(hoTen) || string.IsNullOrEmpty(chucVu))
            {
                FormHelper.ThongBao("Vui lòng nhập đầy đủ Mã NV, Họ tên và Chức vụ!", false);
                return;
            }

            // Kiểm tra trùng mã
            string sqlCheck = "SELECT COUNT(*) FROM NhanVienVanPhong WHERE MaNV = @MaNV";
            SqlParameter[] pCheck = { new SqlParameter("@MaNV", maNV) };
            if (Convert.ToInt32(Db.LayGiaTri(sqlCheck, pCheck)) > 0)
            {
                FormHelper.ThongBao("Mã Nhân viên đã tồn tại!", false);
                return;
            }

            string sqlInsert = @"INSERT INTO NhanVienVanPhong (MaNV, HoTen, Phai, DienThoai, ChucVu, NgayBaoCao, TrangThaiLamViec, MaKH, MaPhong)
                                 VALUES (@MaNV, @HoTen, @Phai, @DienThoai, @ChucVu, @NgayBaoCao, N'Đang làm việc', @MaKH, @MaPhong)";
            SqlParameter[] p = {
                new SqlParameter("@MaNV", maNV),
                new SqlParameter("@HoTen", hoTen),
                new SqlParameter("@Phai", phai),
                new SqlParameter("@DienThoai", string.IsNullOrEmpty(dienThoai) ? (object)DBNull.Value : dienThoai),
                new SqlParameter("@ChucVu", chucVu),
                new SqlParameter("@NgayBaoCao", dtpNgayBaoCao.Value.Date),
                new SqlParameter("@MaKH", maKH),
                new SqlParameter("@MaPhong", maPhong)
            };

            if (Db.ThucThi(sqlInsert, p) > 0)
            {
                FormHelper.ThongBao($"Tiếp nhận báo cáo nhân viên mới {hoTen} thành công!", true);
                TaiDanhSachTongHop();
            }
            else
            {
                FormHelper.ThongBao("Lỗi khi thêm hồ sơ nhân viên!", false);
            }
        }

        private void btnCapThe_Click(object sender, EventArgs e)
        {
            string maNV = txtMaNV.Text.Trim();
            string maThe = txtMaThe.Text.Trim();
            string bienSo = txtBienSoXe.Text.Trim();
            string loaiXe = cboLoaiXe.SelectedItem?.ToString() ?? "Xe máy";
            string hieuXe = txtHieuXe.Text.Trim();
            string mauXe = txtMauXe.Text.Trim();

            if (string.IsNullOrEmpty(maNV) || string.IsNullOrEmpty(maThe) || string.IsNullOrEmpty(bienSo))
            {
                FormHelper.ThongBao("Vui lòng chọn nhân viên và nhập đầy đủ Mã thẻ, Biển số xe!", false);
                return;
            }

            // Kiểm tra ràng buộc 1 - 1: Nhân viên này đã có thẻ xe chưa?
            string sqlCheckNV = "SELECT COUNT(*) FROM TheGiuXe WHERE MaNV = @MaNV";
            SqlParameter[] pCheckNV = { new SqlParameter("@MaNV", maNV) };
            if (Convert.ToInt32(Db.LayGiaTri(sqlCheckNV, pCheckNV)) > 0)
            {
                FormHelper.ThongBao($"Nhân viên {maNV} đã được cấp thẻ giữ xe rồi (Quan hệ 1 - 1)! Mỗi người chỉ được cấp 1 thẻ.", false);
                return;
            }

            // Kiểm tra trùng mã thẻ
            string sqlCheckThe = "SELECT COUNT(*) FROM TheGiuXe WHERE MaThe = @MaThe";
            SqlParameter[] pCheckThe = { new SqlParameter("@MaThe", maThe) };
            if (Convert.ToInt32(Db.LayGiaTri(sqlCheckThe, pCheckThe)) > 0)
            {
                FormHelper.ThongBao("Mã thẻ này đã tồn tại trong hệ thống!", false);
                return;
            }

            string sqlInsertThe = @"INSERT INTO TheGiuXe (MaThe, NgayCap, BienSoXe, LoaiXe, HieuXe, MauXe, TrangThaiThe, MaNV)
                                   VALUES (@MaThe, GETDATE(), @BienSoXe, @LoaiXe, @HieuXe, @MauXe, N'Đang dùng', @MaNV)";
            SqlParameter[] p = {
                new SqlParameter("@MaThe", maThe),
                new SqlParameter("@BienSoXe", bienSo),
                new SqlParameter("@LoaiXe", loaiXe),
                new SqlParameter("@HieuXe", string.IsNullOrEmpty(hieuXe) ? (object)DBNull.Value : hieuXe),
                new SqlParameter("@MauXe", string.IsNullOrEmpty(mauXe) ? (object)DBNull.Value : mauXe),
                new SqlParameter("@MaNV", maNV)
            };

            if (Db.ThucThi(sqlInsertThe, p) > 0)
            {
                FormHelper.ThongBao($"Cấp thẻ xe {maThe} cho nhân viên {maNV} thành công!", true);
                TaiDanhSachTongHop();
            }
            else
            {
                FormHelper.ThongBao("Không thể cấp thẻ xe, vui lòng kiểm tra lại!", false);
            }
        }

        private void btnKhoaThe_Click(object sender, EventArgs e)
        {
            string maNV = txtMaNV.Text.Trim();
            if (string.IsNullOrEmpty(maNV))
            {
                FormHelper.ThongBao("Vui lòng chọn nhân viên cần khóa thẻ xe!", false);
                return;
            }

            DialogResult dr = MessageBox.Show($"Bạn có chắc chắn muốn khóa thẻ xe của nhân viên {maNV} (Ví dụ: nghỉ việc/mất thẻ)?",
                                              "Xác nhận khóa thẻ", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dr == DialogResult.Yes)
            {
                string sqlKhoa = "UPDATE TheGiuXe SET TrangThaiThe = N'Đã khóa' WHERE MaNV = @MaNV";
                SqlParameter[] p = { new SqlParameter("@MaNV", maNV) };

                if (Db.ThucThi(sqlKhoa, p) > 0)
                {
                    FormHelper.ThongBao($"Đã khóa thẻ giữ xe của nhân viên {maNV} thành công!", true);
                    TaiDanhSachTongHop();
                }
                else
                {
                    FormHelper.ThongBao("Nhân viên này chưa có thẻ xe để khóa!", false);
                }
            }
        }

        private void btnLamMoi_Click(object sender, EventArgs e)
        {
            TaoMaTuDong();
            txtHoTen.Clear();
            txtDienThoai.Clear();
            txtChucVu.Clear();
            txtBienSoXe.Clear();
            txtHieuXe.Clear();
            txtMauXe.Clear();
            TaiDanhSachTongHop();
        }

        private void btnDong_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}