﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace QuanLyChoThueCaoOc.Data
{
    public static class Db
    {
        // Chuỗi kết nối trực tiếp (nếu dùng SQL Express thì đổi Data Source=.\\SQLEXPRESS)
        private static readonly string strConn = @"Data Source=.;Initial Catalog=QuanLyChoThueCaoOc;Integrated Security=True";

        public static SqlConnection GetConnection()
        {
            return new SqlConnection(strConn);
        }

        public static DataTable LayBang(string sql, SqlParameter[] p = null)
        {
            DataTable dt = new DataTable();
            using (SqlConnection c = GetConnection())
            {
                c.Open();
                using (SqlCommand cmd = new SqlCommand(sql, c))
                {
                    if (p != null) cmd.Parameters.AddRange(p);
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd)) { da.Fill(dt); }
                }
            }
            return dt;
        }

        public static int ThucThi(string sql, SqlParameter[] p = null)
        {
            using (SqlConnection c = GetConnection())
            {
                c.Open();
                using (SqlCommand cmd = new SqlCommand(sql, c))
                {
                    if (p != null) cmd.Parameters.AddRange(p);
                    return cmd.ExecuteNonQuery();
                }
            }
        }

        public static object LayGiaTri(string sql, SqlParameter[] p = null)
        {
            using (SqlConnection c = GetConnection())
            {
                c.Open();
                using (SqlCommand cmd = new SqlCommand(sql, c))
                {
                    if (p != null) cmd.Parameters.AddRange(p);
                    return cmd.ExecuteScalar();
                }
            }
        }
    }
}