﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace QuanLyNhanSu.Data
{
    public class Db
    {
        // Chuỗi kết nối tới cơ sở dữ liệu QLNS
        // Nếu dùng SQL Server Express thì đổi thành: @"Data Source=.\SQLEXPRESS;Initial Catalog=QLNS;Integrated Security=True"
        private static string strKetNoi = @"Data Source=.;Initial Catalog=QLNS;Integrated Security=True";

        public static SqlConnection GetConnection()
        {
            return new SqlConnection(strKetNoi);
        }

        // 1. Lấy dữ liệu SELECT trả về DataTable để nạp lên DataGridView / ComboBox
        public static DataTable LayDuLieu(string sql, SqlParameter[] parameters = null)
        {
            DataTable dt = new DataTable();
            using (SqlConnection conn = GetConnection())
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {
                    if (parameters != null)
                    {
                        cmd.Parameters.AddRange(parameters);
                    }
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        da.Fill(dt);
                    }
                }
            }
            return dt;
        }

        // 2. Thực thi lệnh INSERT, UPDATE, DELETE (trả về số dòng bị tác động)
        public static int ThucThi(string sql, SqlParameter[] parameters = null)
        {
            using (SqlConnection conn = GetConnection())
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {
                    if (parameters != null)
                    {
                        cmd.Parameters.AddRange(parameters);
                    }
                    return cmd.ExecuteNonQuery();
                }
            }
        }

        // 3. Thực thi lấy giá trị đơn lẻ (COUNT, MAX, SUM...)
        public static object LayGiaTriDon(string sql, SqlParameter[] parameters = null)
        {
            using (SqlConnection conn = GetConnection())
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {
                    if (parameters != null)
                    {
                        cmd.Parameters.AddRange(parameters);
                    }
                    return cmd.ExecuteScalar();
                }
            }
        }
    }
}