﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using QuanLyNhanSu.Data;

namespace QuanLyNhanSu.Forms
{
    public partial class FrmNhanSu_TuyenDung : Form
    {
        public FrmNhanSu_TuyenDung()
        {
            InitializeComponent();
        }

        private void FrmNhanSu_TuyenDung_Load(object sender, EventArgs e)
        {
            KhoiTaoDuLieuMauNeuChuaCo();
            TaiDanhSachPhongBan();
            TaiDanhSachNhanVien();
            TaiDanhSachQDTD();

            cboGioiTinh.SelectedIndex = 0;
            cboTrangThaiNV.SelectedIndex = 0; // Thử việc
            cboTrangThaiQDTD.SelectedIndex = 0; // Đang thử việc

            txtMaNV.Text = "NV" + DateTime.Now.ToString("ddHHmmss");
            txtMaQDTD.Text = "TD" + DateTime.Now.ToString("ddHHmmss");
            txtDieuKhoan.Text = "Thử việc 02 tháng theo quy định Luật Lao động.";
        }

        // Tự động chèn 3 phòng ban nếu CSDL mới chưa có dữ liệu phòng ban
        private void KhoiTaoDuLieuMauNeuChuaCo()
        {
            try
            {
                string sqlCheck = "SELECT COUNT(*) FROM PhongBan";
                int count = Convert.ToInt32(Db.LayGiaTriDon(sqlCheck));
                if (count == 0)
                {
                    Db.ThucThi("INSERT INTO PhongBan VALUES ('PB01', N'Phòng Kỹ thuật pha sơn', '02838112233', N'Nguyễn Văn A')");
                    Db.ThucThi("INSERT INTO PhongBan VALUES ('PB02', N'Phòng Phân xưởng sản xuất', '02838112234', N'Trần Văn B')");
                    Db.ThucThi("INSERT INTO PhongBan VALUES ('PB03', N'Phòng Tài chính Kế toán', '02838112235', N'Lê Thị C')");
                }
            }
            catch { }
        }

        private void TaiDanhSachPhongBan()
        {
            string sql = "SELECT MaPB, TenPB FROM PhongBan";
            DataTable dt = Db.LayDuLieu(sql);

            // Cho Tab 1
            cboPhongBan.DataSource = dt;
            cboPhongBan.DisplayMember = "TenPB";
            cboPhongBan.ValueMember = "MaPB";

            // Cho Tab 2
            DataTable dt2 = dt.Copy();
            cboPB_QDTD.DataSource = dt2;
            cboPB_QDTD.DisplayMember = "TenPB";
            cboPB_QDTD.ValueMember = "MaPB";
        }

        // ==================== PHẦN 1: HỒ SƠ NHÂN VIÊN ====================

        private void TaiDanhSachNhanVien()
        {
            string sql = @"SELECT nv.MaNV, nv.HoTen, nv.NgaySinh, nv.GioiTinh, nv.DiaChi, nv.DienThoai, 
                                  pb.TenPB, nv.TrangThai, nv.MaPB
                           FROM NhanVien nv 
                           LEFT JOIN PhongBan pb ON nv.MaPB = pb.MaPB";
            DataTable dt = Db.LayDuLieu(sql);
            dgvNhanVien.DataSource = dt;

            dgvNhanVien.Columns["MaNV"].HeaderText = "Mã NV";
            dgvNhanVien.Columns["HoTen"].HeaderText = "Họ và tên";
            dgvNhanVien.Columns["NgaySinh"].HeaderText = "Ngày sinh";
            dgvNhanVien.Columns["GioiTinh"].HeaderText = "Giới tính";
            dgvNhanVien.Columns["DiaChi"].HeaderText = "Địa chỉ";
            dgvNhanVien.Columns["DienThoai"].HeaderText = "Điện thoại";
            dgvNhanVien.Columns["TenPB"].HeaderText = "Phòng ban";
            dgvNhanVien.Columns["TrangThai"].HeaderText = "Trạng thái";

            dgvNhanVien.Columns["MaPB"].Visible = false;

            // Đồng thời nạp vào ComboBox chọn nhân viên ở Tab 2
            DataTable dtNV = Db.LayDuLieu("SELECT MaNV, HoTen FROM NhanVien");
            cboNV_QDTD.DataSource = dtNV;
            cboNV_QDTD.DisplayMember = "HoTen";
            cboNV_QDTD.ValueMember = "MaNV";
        }

        private void btnThemNV_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtMaNV.Text.Trim()) || string.IsNullOrEmpty(txtHoTen.Text.Trim()))
            {
                MessageBox.Show("Mã nhân viên và Họ tên không được để trống!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string sql = @"INSERT INTO NhanVien (MaNV, HoTen, NgaySinh, GioiTinh, DiaChi, DienThoai, MaPB, TrangThai)
                           VALUES (@MaNV, @HoTen, @NgaySinh, @GioiTinh, @DiaChi, @DienThoai, @MaPB, @TrangThai)";

            SqlParameter[] prms = new SqlParameter[]
            {
                new SqlParameter("@MaNV", txtMaNV.Text.Trim()),
                new SqlParameter("@HoTen", txtHoTen.Text.Trim()),
                new SqlParameter("@NgaySinh", dtpNgaySinh.Value),
                new SqlParameter("@GioiTinh", cboGioiTinh.Text),
                new SqlParameter("@DiaChi", txtDiaChi.Text.Trim()),
                new SqlParameter("@DienThoai", txtDienThoai.Text.Trim()),
                new SqlParameter("@MaPB", cboPhongBan.SelectedValue ?? DBNull.Value),
                new SqlParameter("@TrangThai", cboTrangThaiNV.Text)
            };

            try
            {
                Db.ThucThi(sql, prms);
                MessageBox.Show("Thêm nhân viên thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                TaiDanhSachNhanVien();
                btnLamMoiNV_Click(null, null);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi thêm nhân viên: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnSuaNV_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtMaNV.Text.Trim()))
            {
                MessageBox.Show("Vui lòng chọn nhân viên cần cập nhật!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string sql = @"UPDATE NhanVien 
                           SET HoTen = @HoTen, NgaySinh = @NgaySinh, GioiTinh = @GioiTinh, 
                               DiaChi = @DiaChi, DienThoai = @DienThoai, MaPB = @MaPB, TrangThai = @TrangThai
                           WHERE MaNV = @MaNV";

            SqlParameter[] prms = new SqlParameter[]
            {
                new SqlParameter("@MaNV", txtMaNV.Text.Trim()),
                new SqlParameter("@HoTen", txtHoTen.Text.Trim()),
                new SqlParameter("@NgaySinh", dtpNgaySinh.Value),
                new SqlParameter("@GioiTinh", cboGioiTinh.Text),
                new SqlParameter("@DiaChi", txtDiaChi.Text.Trim()),
                new SqlParameter("@DienThoai", txtDienThoai.Text.Trim()),
                new SqlParameter("@MaPB", cboPhongBan.SelectedValue ?? DBNull.Value),
                new SqlParameter("@TrangThai", cboTrangThaiNV.Text)
            };

            try
            {
                Db.ThucThi(sql, prms);
                MessageBox.Show("Cập nhật thông tin nhân viên thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                TaiDanhSachNhanVien();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi cập nhật: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnXoaNV_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtMaNV.Text.Trim()))
            {
                MessageBox.Show("Vui lòng chọn nhân viên cần xóa!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (MessageBox.Show("Bạn có chắc chắn muốn xóa nhân viên này?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                try
                {
                    string sql = "DELETE FROM NhanVien WHERE MaNV = @MaNV";
                    Db.ThucThi(sql, new SqlParameter[] { new SqlParameter("@MaNV", txtMaNV.Text.Trim()) });
                    MessageBox.Show("Xóa nhân viên thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    TaiDanhSachNhanVien();
                    btnLamMoiNV_Click(null, null);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Không thể xóa do nhân viên này đã có các quyết định/hợp đồng liên quan!\nLỗi: " + ex.Message, "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
        }

        private void btnLamMoiNV_Click(object sender, EventArgs e)
        {
            txtMaNV.Text = "NV" + DateTime.Now.ToString("yyMMddHHmmss");
            txtHoTen.Clear();
            dtpNgaySinh.Value = new DateTime(2000, 1, 1);
            cboGioiTinh.SelectedIndex = 0;
            txtDiaChi.Clear();
            txtDienThoai.Clear();
            cboTrangThaiNV.SelectedIndex = 0;
        }

        private void dgvNhanVien_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvNhanVien.CurrentRow != null && dgvNhanVien.CurrentRow.Index >= 0)
            {
                DataGridViewRow row = dgvNhanVien.CurrentRow;
                txtMaNV.Text = row.Cells["MaNV"].Value?.ToString();
                txtHoTen.Text = row.Cells["HoTen"].Value?.ToString();
                if (DateTime.TryParse(row.Cells["NgaySinh"].Value?.ToString(), out DateTime ns))
                    dtpNgaySinh.Value = ns;
                cboGioiTinh.Text = row.Cells["GioiTinh"].Value?.ToString();
                txtDiaChi.Text = row.Cells["DiaChi"].Value?.ToString();
                txtDienThoai.Text = row.Cells["DienThoai"].Value?.ToString();
                cboPhongBan.SelectedValue = row.Cells["MaPB"].Value?.ToString();
                cboTrangThaiNV.Text = row.Cells["TrangThai"].Value?.ToString();
            }
        }

        // ==================== PHẦN 2: QUYẾT ĐỊNH TUYỂN DỤNG & THỬ VIỆC ====================

        private void TaiDanhSachQDTD()
        {
            string sql = @"SELECT qd.MaQDTD, nv.HoTen, pb.TenPB, qd.NgayKy, qd.NgayBatDauThuViec, 
                                  qd.NgayKetThucThuViec, qd.LuongThuViec, qd.DieuKhoan, qd.TrangThai,
                                  qd.MaNV, qd.MaPB
                           FROM QuyetDinhTuyenDung qd
                           JOIN NhanVien nv ON qd.MaNV = nv.MaNV
                           JOIN PhongBan pb ON qd.MaPB = pb.MaPB";
            DataTable dt = Db.LayDuLieu(sql);
            dgvQDTD.DataSource = dt;

            dgvQDTD.Columns["MaQDTD"].HeaderText = "Mã QĐTD";
            dgvQDTD.Columns["HoTen"].HeaderText = "Nhân viên";
            dgvQDTD.Columns["TenPB"].HeaderText = "Phòng ban";
            dgvQDTD.Columns["NgayKy"].HeaderText = "Ngày ký";
            dgvQDTD.Columns["NgayBatDauThuViec"].HeaderText = "Từ ngày";
            dgvQDTD.Columns["NgayKetThucThuViec"].HeaderText = "Đến ngày";
            dgvQDTD.Columns["LuongThuViec"].HeaderText = "Lương TV";
            dgvQDTD.Columns["DieuKhoan"].HeaderText = "Điều khoản";
            dgvQDTD.Columns["TrangThai"].HeaderText = "Kết quả";

            dgvQDTD.Columns["LuongThuViec"].DefaultCellStyle.Format = "N0";
            dgvQDTD.Columns["MaNV"].Visible = false;
            dgvQDTD.Columns["MaPB"].Visible = false;
        }

        private void btnLapQDTD_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtMaQDTD.Text.Trim()))
            {
                MessageBox.Show("Mã QĐ tuyển dụng không được để trống!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (cboNV_QDTD.SelectedValue == null || cboPB_QDTD.SelectedValue == null)
            {
                MessageBox.Show("Vui lòng chọn Nhân viên và Phòng ban!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!decimal.TryParse(txtLuongThuViec.Text.Trim(), out decimal luongTV))
            {
                MessageBox.Show("Mức lương thử việc không hợp lệ!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string sql = @"INSERT INTO QuyetDinhTuyenDung 
                           (MaQDTD, MaNV, MaPB, NgayKy, NgayBatDauThuViec, NgayKetThucThuViec, LuongThuViec, DieuKhoan, TrangThai)
                           VALUES (@MaQDTD, @MaNV, @MaPB, @NgayKy, @NgayBatDau, @NgayKetThuc, @LuongTV, @DieuKhoan, @TrangThai)";

            SqlParameter[] prms = new SqlParameter[]
            {
                new SqlParameter("@MaQDTD", txtMaQDTD.Text.Trim()),
                new SqlParameter("@MaNV", cboNV_QDTD.SelectedValue),
                new SqlParameter("@MaPB", cboPB_QDTD.SelectedValue),
                new SqlParameter("@NgayKy", dtpNgayKyQDTD.Value),
                new SqlParameter("@NgayBatDau", dtpNgayBatDau.Value),
                new SqlParameter("@NgayKetThuc", dtpNgayKetThuc.Value),
                new SqlParameter("@LuongTV", luongTV),
                new SqlParameter("@DieuKhoan", txtDieuKhoan.Text.Trim()),
                new SqlParameter("@TrangThai", cboTrangThaiQDTD.Text)
            };

            try
            {
                Db.ThucThi(sql, prms);
                MessageBox.Show("Lập Quyết định tuyển dụng & thử việc thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                TaiDanhSachQDTD();
                btnLamMoiQDTD_Click(null, null);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi lập quyết định: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Đánh giá thử việc: Cập nhật trạng thái Đạt / Không đạt (Khớp Activity Diagram Câu 5)
        private void btnCapNhatKetQua_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtMaQDTD.Text.Trim()))
            {
                MessageBox.Show("Vui lòng chọn quyết định cần đánh giá kết quả!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string sql = "UPDATE QuyetDinhTuyenDung SET TrangThai = @TrangThai WHERE MaQDTD = @MaQDTD";
            SqlParameter[] prms = new SqlParameter[]
            {
                new SqlParameter("@TrangThai", cboTrangThaiQDTD.Text),
                new SqlParameter("@MaQDTD", txtMaQDTD.Text.Trim())
            };

            try
            {
                Db.ThucThi(sql, prms);

                // Nếu đánh giá "Đạt", tự động đổi trạng thái nhân viên sang "Chính thức" để chuẩn bị ký hợp đồng
                if (cboTrangThaiQDTD.Text == "Đạt" && cboNV_QDTD.SelectedValue != null)
                {
                    Db.ThucThi("UPDATE NhanVien SET TrangThai = N'Chính thức' WHERE MaNV = @MaNV",
                        new SqlParameter[] { new SqlParameter("@MaNV", cboNV_QDTD.SelectedValue) });
                    TaiDanhSachNhanVien();
                }

                MessageBox.Show("Cập nhật kết quả đánh giá thử việc thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                TaiDanhSachQDTD();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi cập nhật kết quả: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnLamMoiQDTD_Click(object sender, EventArgs e)
        {
            txtMaQDTD.Text = "TD" + DateTime.Now.ToString("yyMMddHHmmss");
            dtpNgayKyQDTD.Value = DateTime.Now;
            dtpNgayBatDau.Value = DateTime.Now;
            dtpNgayKetThuc.Value = DateTime.Now.AddMonths(2);
            txtLuongThuViec.Text = "5000000";
            cboTrangThaiQDTD.SelectedIndex = 0;
        }

        private void dgvQDTD_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvQDTD.CurrentRow != null && dgvQDTD.CurrentRow.Index >= 0)
            {
                DataGridViewRow row = dgvQDTD.CurrentRow;
                txtMaQDTD.Text = row.Cells["MaQDTD"].Value?.ToString();
                cboNV_QDTD.SelectedValue = row.Cells["MaNV"].Value?.ToString();
                cboPB_QDTD.SelectedValue = row.Cells["MaPB"].Value?.ToString();
                if (DateTime.TryParse(row.Cells["NgayKy"].Value?.ToString(), out DateTime nk))
                    dtpNgayKyQDTD.Value = nk;
                if (DateTime.TryParse(row.Cells["NgayBatDauThuViec"].Value?.ToString(), out DateTime nbd))
                    dtpNgayBatDau.Value = nbd;
                if (DateTime.TryParse(row.Cells["NgayKetThucThuViec"].Value?.ToString(), out DateTime nkt))
                    dtpNgayKetThuc.Value = nkt;
                txtLuongThuViec.Text = row.Cells["LuongThuViec"].Value?.ToString();
                txtDieuKhoan.Text = row.Cells["DieuKhoan"].Value?.ToString();
                cboTrangThaiQDTD.Text = row.Cells["TrangThai"].Value?.ToString();
            }
        }

        private void btnDong_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}