﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Windows.Forms;
using QuanLyNhanSu.Data;

namespace QuanLyNhanSu.Forms
{
    public partial class FrmChamCong_PhuTroi : Form
    {
        public FrmChamCong_PhuTroi()
        {
            InitializeComponent();
        }

        private void FrmChamCong_PhuTroi_Load(object sender, EventArgs e)
        {
            NapDanhSachPhongBan();
            NapDanhSachNhanVien();
            NapThangNam();

            TaiDanhSachKeHoach();
            TaiDanhSachChamCong();
            TaiDanhSachPhieuPhuTroi();

            btnLamMoiKH_Click(null, null);
            btnLamMoiCC_Click(null, null);
            btnLamMoiPPT_Click(null, null);
        }

        private void NapDanhSachPhongBan()
        {
            string sql = "SELECT MaPB, TenPB FROM PhongBan";
            DataTable dt = Db.LayDuLieu(sql);

            cboPB_KH.DisplayMember = "TenPB";
            cboPB_KH.ValueMember = "MaPB";
            cboPB_KH.DataSource = dt.Copy();

            cboPB_PPT.DisplayMember = "TenPB";
            cboPB_PPT.ValueMember = "MaPB";
            cboPB_PPT.DataSource = dt.Copy();
        }

        private void NapDanhSachNhanVien()
        {
            string sql = "SELECT MaNV, HoTen FROM NhanVien";
            DataTable dt = Db.LayDuLieu(sql);

            cboNV_CC.DisplayMember = "HoTen";
            cboNV_CC.ValueMember = "MaNV";
            cboNV_CC.DataSource = dt.Copy();

            cboNV_PT.DisplayMember = "HoTen";
            cboNV_PT.ValueMember = "MaNV";
            cboNV_PT.DataSource = dt.Copy();
        }

        private void NapThangNam()
        {
            for (int i = 1; i <= 12; i++)
            {
                cboThang.Items.Add(i);
            }
            cboThang.SelectedItem = DateTime.Now.Month;

            int currentYear = DateTime.Now.Year;
            for (int y = currentYear - 2; y <= currentYear + 2; y++)
            {
                cboNam.Items.Add(y);
            }
            cboNam.SelectedItem = currentYear;
        }

        // ==================== TAB 1: KẾ HOẠCH PHÂN CÔNG ====================

        private void TaiDanhSachKeHoach()
        {
            string sql = @"SELECT kh.MaKH, pb.TenPB, kh.TuNgay, kh.DenNgay, kh.NguoiLap, kh.NgayLap, kh.MaPB
                           FROM KeHoachPhanCong kh
                           JOIN PhongBan pb ON kh.MaPB = pb.MaPB";
            DataTable dt = Db.LayDuLieu(sql);
            dgvKeHoach.DataSource = dt;

            dgvKeHoach.Columns["MaKH"].HeaderText = "Mã KH";
            dgvKeHoach.Columns["TenPB"].HeaderText = "Phòng ban";
            dgvKeHoach.Columns["TuNgay"].HeaderText = "Từ ngày";
            dgvKeHoach.Columns["DenNgay"].HeaderText = "Đến ngày";
            dgvKeHoach.Columns["NguoiLap"].HeaderText = "Người lập";
            dgvKeHoach.Columns["NgayLap"].HeaderText = "Ngày lập";
            dgvKeHoach.Columns["MaPB"].Visible = false;
        }

        private void btnLapKH_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtMaKH.Text.Trim()) || cboPB_KH.SelectedValue == null)
            {
                MessageBox.Show("Mã kế hoạch và Phòng ban không được để trống!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string sql = @"INSERT INTO KeHoachPhanCong (MaKH, MaPB, TuNgay, DenNgay, NguoiLap, NgayLap)
                           VALUES (@MaKH, @MaPB, @TuNgay, @DenNgay, @NguoiLap, @NgayLap)";

            SqlParameter[] prms = new SqlParameter[]
            {
                new SqlParameter("@MaKH", txtMaKH.Text.Trim()),
                new SqlParameter("@MaPB", cboPB_KH.SelectedValue),
                new SqlParameter("@TuNgay", dtpTuNgay.Value),
                new SqlParameter("@DenNgay", dtpDenNgay.Value),
                new SqlParameter("@NguoiLap", txtNguoiLap.Text.Trim()),
                new SqlParameter("@NgayLap", dtpNgayLap.Value)
            };

            try
            {
                Db.ThucThi(sql, prms);
                MessageBox.Show("Lập kế hoạch phân công thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                TaiDanhSachKeHoach();
                btnLamMoiKH_Click(null, null);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi lập kế hoạch: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnSuaKH_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtMaKH.Text.Trim())) return;

            string sql = @"UPDATE KeHoachPhanCong 
                           SET MaPB = @MaPB, TuNgay = @TuNgay, DenNgay = @DenNgay, NguoiLap = @NguoiLap, NgayLap = @NgayLap
                           WHERE MaKH = @MaKH";

            SqlParameter[] prms = new SqlParameter[]
            {
                new SqlParameter("@MaKH", txtMaKH.Text.Trim()),
                new SqlParameter("@MaPB", cboPB_KH.SelectedValue),
                new SqlParameter("@TuNgay", dtpTuNgay.Value),
                new SqlParameter("@DenNgay", dtpDenNgay.Value),
                new SqlParameter("@NguoiLap", txtNguoiLap.Text.Trim()),
                new SqlParameter("@NgayLap", dtpNgayLap.Value)
            };

            try
            {
                Db.ThucThi(sql, prms);
                MessageBox.Show("Cập nhật kế hoạch thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                TaiDanhSachKeHoach();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi cập nhật: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnXoaKH_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtMaKH.Text.Trim())) return;

            if (MessageBox.Show("Bạn có chắc chắn muốn xóa kế hoạch này?", "Xác nhận", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                Db.ThucThi("DELETE FROM KeHoachPhanCong WHERE MaKH = @Ma", new SqlParameter[] { new SqlParameter("@Ma", txtMaKH.Text.Trim()) });
                TaiDanhSachKeHoach();
                btnLamMoiKH_Click(null, null);
            }
        }

        private void btnLamMoiKH_Click(object sender, EventArgs e)
        {
            // Rút ngắn còn đúng 10 ký tự: "KH" + 8 chữ số
            txtMaKH.Text = "KH" + DateTime.Now.ToString("ddHHmmss");
            dtpTuNgay.Value = DateTime.Now;
            dtpDenNgay.Value = DateTime.Now.AddDays(7);
            dtpNgayLap.Value = DateTime.Now;
            txtNguoiLap.Text = "Trưởng phòng phân xưởng";
        }

        private void dgvKeHoach_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvKeHoach.CurrentRow != null && dgvKeHoach.CurrentRow.Index >= 0)
            {
                DataGridViewRow row = dgvKeHoach.CurrentRow;
                txtMaKH.Text = row.Cells["MaKH"].Value?.ToString();
                cboPB_KH.SelectedValue = row.Cells["MaPB"].Value?.ToString();
                if (DateTime.TryParse(row.Cells["TuNgay"].Value?.ToString(), out DateTime tn)) dtpTuNgay.Value = tn;
                if (DateTime.TryParse(row.Cells["DenNgay"].Value?.ToString(), out DateTime dn)) dtpDenNgay.Value = dn;
                txtNguoiLap.Text = row.Cells["NguoiLap"].Value?.ToString();
                if (DateTime.TryParse(row.Cells["NgayLap"].Value?.ToString(), out DateTime nl)) dtpNgayLap.Value = nl;
            }
        }

        // ==================== TAB 2: BẢNG CHẤM CÔNG ====================

        private void TaiDanhSachChamCong()
        {
            string sql = @"SELECT cc.MaCC, nv.HoTen, cc.Thang, cc.Nam, cc.SoNgayCongChuan, 
                                  cc.SoNgayDiLam, cc.SoNgayNghiCoPhep, cc.SoNgayNghiKhongPhep, cc.MaNV
                           FROM BangChamCong cc
                           JOIN NhanVien nv ON cc.MaNV = nv.MaNV";
            DataTable dt = Db.LayDuLieu(sql);
            dgvChamCong.DataSource = dt;

            dgvChamCong.Columns["MaCC"].HeaderText = "Mã CC";
            dgvChamCong.Columns["HoTen"].HeaderText = "Nhân viên";
            dgvChamCong.Columns["Thang"].HeaderText = "Tháng";
            dgvChamCong.Columns["Nam"].HeaderText = "Năm";
            dgvChamCong.Columns["SoNgayCongChuan"].HeaderText = "Công chuẩn";
            dgvChamCong.Columns["SoNgayDiLam"].HeaderText = "Đi làm";
            dgvChamCong.Columns["SoNgayNghiCoPhep"].HeaderText = "Có phép";
            dgvChamCong.Columns["SoNgayNghiKhongPhep"].HeaderText = "Không phép";
            dgvChamCong.Columns["MaNV"].Visible = false;
        }

        private void btnGhiNhanCC_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtMaCC.Text.Trim()) || cboNV_CC.SelectedValue == null)
            {
                MessageBox.Show("Mã CC và Nhân viên không được để trống!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            decimal.TryParse(txtCongChuan.Text.Trim().Replace(',', '.'), NumberStyles.Any, CultureInfo.InvariantCulture, out decimal ccChuan);
            decimal.TryParse(txtDiLam.Text.Trim().Replace(',', '.'), NumberStyles.Any, CultureInfo.InvariantCulture, out decimal diLam);
            decimal.TryParse(txtNghiCoPhep.Text.Trim().Replace(',', '.'), NumberStyles.Any, CultureInfo.InvariantCulture, out decimal phep);
            decimal.TryParse(txtNghiKhongPhep.Text.Trim().Replace(',', '.'), NumberStyles.Any, CultureInfo.InvariantCulture, out decimal koPhep);

            string sql = @"INSERT INTO BangChamCong (MaCC, MaNV, Thang, Nam, SoNgayCongChuan, SoNgayDiLam, SoNgayNghiCoPhep, SoNgayNghiKhongPhep)
                           VALUES (@MaCC, @MaNV, @Thang, @Nam, @CongChuan, @DiLam, @CoPhep, @KoPhep)";

            SqlParameter[] prms = new SqlParameter[]
            {
                new SqlParameter("@MaCC", txtMaCC.Text.Trim()),
                new SqlParameter("@MaNV", cboNV_CC.SelectedValue),
                new SqlParameter("@Thang", Convert.ToInt32(cboThang.SelectedItem)),
                new SqlParameter("@Nam", Convert.ToInt32(cboNam.SelectedItem)),
                new SqlParameter("@CongChuan", ccChuan),
                new SqlParameter("@DiLam", diLam),
                new SqlParameter("@CoPhep", phep),
                new SqlParameter("@KoPhep", koPhep)
            };

            try
            {
                Db.ThucThi(sql, prms);
                MessageBox.Show("Ghi nhận chấm công thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                TaiDanhSachChamCong();
                btnLamMoiCC_Click(null, null);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi ghi nhận công: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnSuaCC_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtMaCC.Text.Trim())) return;

            decimal.TryParse(txtCongChuan.Text.Trim().Replace(',', '.'), NumberStyles.Any, CultureInfo.InvariantCulture, out decimal ccChuan);
            decimal.TryParse(txtDiLam.Text.Trim().Replace(',', '.'), NumberStyles.Any, CultureInfo.InvariantCulture, out decimal diLam);
            decimal.TryParse(txtNghiCoPhep.Text.Trim().Replace(',', '.'), NumberStyles.Any, CultureInfo.InvariantCulture, out decimal phep);
            decimal.TryParse(txtNghiKhongPhep.Text.Trim().Replace(',', '.'), NumberStyles.Any, CultureInfo.InvariantCulture, out decimal koPhep);

            string sql = @"UPDATE BangChamCong 
                           SET SoNgayCongChuan = @CongChuan, SoNgayDiLam = @DiLam, 
                               SoNgayNghiCoPhep = @CoPhep, SoNgayNghiKhongPhep = @KoPhep
                           WHERE MaCC = @MaCC";

            SqlParameter[] prms = new SqlParameter[]
            {
                new SqlParameter("@MaCC", txtMaCC.Text.Trim()),
                new SqlParameter("@CongChuan", ccChuan),
                new SqlParameter("@DiLam", diLam),
                new SqlParameter("@CoPhep", phep),
                new SqlParameter("@KoPhep", koPhep)
            };

            try
            {
                Db.ThucThi(sql, prms);
                MessageBox.Show("Cập nhật ngày công thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                TaiDanhSachChamCong();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnXoaCC_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtMaCC.Text.Trim())) return;
            if (MessageBox.Show("Xóa bảng công này?", "Xác nhận", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                Db.ThucThi("DELETE FROM BangChamCong WHERE MaCC = @Ma", new SqlParameter[] { new SqlParameter("@Ma", txtMaCC.Text.Trim()) });
                TaiDanhSachChamCong();
                btnLamMoiCC_Click(null, null);
            }
        }

        private void btnLamMoiCC_Click(object sender, EventArgs e)
        {
            // Rút ngắn còn đúng 10 ký tự: "CC" + 8 chữ số
            txtMaCC.Text = "CC" + DateTime.Now.ToString("ddHHmmss");
            txtCongChuan.Text = "26";
            txtDiLam.Text = "26";
            txtNghiCoPhep.Text = "0";
            txtNghiKhongPhep.Text = "0";
        }

        private void dgvChamCong_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvChamCong.CurrentRow != null && dgvChamCong.CurrentRow.Index >= 0)
            {
                DataGridViewRow row = dgvChamCong.CurrentRow;
                txtMaCC.Text = row.Cells["MaCC"].Value?.ToString();
                cboNV_CC.SelectedValue = row.Cells["MaNV"].Value?.ToString();
                cboThang.SelectedItem = Convert.ToInt32(row.Cells["Thang"].Value);
                cboNam.SelectedItem = Convert.ToInt32(row.Cells["Nam"].Value);
                txtCongChuan.Text = row.Cells["SoNgayCongChuan"].Value?.ToString();
                txtDiLam.Text = row.Cells["SoNgayDiLam"].Value?.ToString();
                txtNghiCoPhep.Text = row.Cells["SoNgayNghiCoPhep"].Value?.ToString();
                txtNghiKhongPhep.Text = row.Cells["SoNgayNghiKhongPhep"].Value?.ToString();
            }
        }

        // ==================== TAB 3: PHIẾU PHỤ TRỘI & CHI TIẾT (MASTER-DETAIL) ====================

        private void TaiDanhSachPhieuPhuTroi()
        {
            string sql = @"SELECT ppt.MaPPT, pb.TenPB, ppt.NgayPhuTroi, ppt.HinhThucPhuTroi, 
                                  ppt.HeSoPhuTroi, ppt.NguoiXacNhan, ppt.MaPB
                           FROM PhieuGhiNhanPhuTroi ppt
                           JOIN PhongBan pb ON ppt.MaPB = pb.MaPB";
            DataTable dt = Db.LayDuLieu(sql);
            dgvPhieuPT.DataSource = dt;

            dgvPhieuPT.Columns["MaPPT"].HeaderText = "Mã Phiếu";
            dgvPhieuPT.Columns["TenPB"].HeaderText = "Phòng ban";
            dgvPhieuPT.Columns["NgayPhuTroi"].HeaderText = "Ngày";
            dgvPhieuPT.Columns["HinhThucPhuTroi"].HeaderText = "Hình thức";
            dgvPhieuPT.Columns["HeSoPhuTroi"].HeaderText = "Hệ số";
            dgvPhieuPT.Columns["NguoiXacNhan"].HeaderText = "Người xác nhận";
            dgvPhieuPT.Columns["MaPB"].Visible = false;
        }

        private void TaiChiTietTheoPhieu(string maPPT)
        {
            string sql = @"SELECT ct.MaCTPT, nv.HoTen, ct.SoGioPhuTroi, ct.CongViecCuThe, ct.MaNV
                           FROM ChiTietPhuTroi ct
                           JOIN NhanVien nv ON ct.MaNV = nv.MaNV
                           WHERE ct.MaPPT = @MaPPT";
            DataTable dt = Db.LayDuLieu(sql, new SqlParameter[] { new SqlParameter("@MaPPT", maPPT) });
            dgvChiTietPT.DataSource = dt;

            dgvChiTietPT.Columns["MaCTPT"].HeaderText = "Mã CT";
            dgvChiTietPT.Columns["HoTen"].HeaderText = "Nhân viên";
            dgvChiTietPT.Columns["SoGioPhuTroi"].HeaderText = "Số giờ";
            dgvChiTietPT.Columns["CongViecCuThe"].HeaderText = "Công việc";
            dgvChiTietPT.Columns["MaNV"].Visible = false;
        }

        private void btnLapPPT_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtMaPPT.Text.Trim()) || cboPB_PPT.SelectedValue == null)
            {
                MessageBox.Show("Mã phiếu và Phòng ban không được để trống!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string strHeSo = txtHeSo.Text.Trim().Replace(',', '.');
            decimal.TryParse(strHeSo, NumberStyles.Any, CultureInfo.InvariantCulture, out decimal heSo);
            if (heSo <= 0) heSo = 1.5m;

            string sql = @"INSERT INTO PhieuGhiNhanPhuTroi (MaPPT, MaPB, NgayPhuTroi, HinhThucPhuTroi, HeSoPhuTroi, NguoiXacNhan)
                           VALUES (@MaPPT, @MaPB, @NgayPT, @HinhThuc, @HeSo, @NguoiXN)";

            SqlParameter[] prms = new SqlParameter[]
            {
                new SqlParameter("@MaPPT", txtMaPPT.Text.Trim()),
                new SqlParameter("@MaPB", cboPB_PPT.SelectedValue),
                new SqlParameter("@NgayPT", dtpNgayPT.Value),
                new SqlParameter("@HinhThuc", cboHinhThucPT.Text),
                new SqlParameter("@HeSo", heSo),
                new SqlParameter("@NguoiXN", txtNguoiXacNhan.Text.Trim())
            };

            try
            {
                Db.ThucThi(sql, prms);
                MessageBox.Show("Lập phiếu ghi nhận phụ trội thành công! Bạn có thể thêm chi tiết nhân viên bên phải.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                TaiDanhSachPhieuPhuTroi();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnXoaPPT_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtMaPPT.Text.Trim())) return;

            if (MessageBox.Show("Xóa phiếu phụ trội sẽ xóa luôn danh sách nhân viên tham gia ca này. Bạn có chắc không?", "Xác nhận", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                try
                {
                    Db.ThucThi("DELETE FROM ChiTietPhuTroi WHERE MaPPT = @Ma", new SqlParameter[] { new SqlParameter("@Ma", txtMaPPT.Text.Trim()) });
                    Db.ThucThi("DELETE FROM PhieuGhiNhanPhuTroi WHERE MaPPT = @Ma", new SqlParameter[] { new SqlParameter("@Ma", txtMaPPT.Text.Trim()) });
                    TaiDanhSachPhieuPhuTroi();
                    TaiChiTietTheoPhieu("");
                    btnLamMoiPPT_Click(null, null);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnThemCTPT_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtMaPPT.Text.Trim()))
            {
                MessageBox.Show("Vui lòng chọn hoặc lập phiếu phụ trội trước!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (cboNV_PT.SelectedValue == null)
            {
                MessageBox.Show("Vui lòng chọn nhân viên làm phụ trội!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string strSoGio = txtSoGioPT.Text.Trim().Replace(',', '.');
            decimal.TryParse(strSoGio, NumberStyles.Any, CultureInfo.InvariantCulture, out decimal soGio);

            // Sửa còn đúng 10 ký tự: "CT" + 8 chữ số
            string maCT = "CT" + DateTime.Now.ToString("ddHHmmss");

            string sql = @"INSERT INTO ChiTietPhuTroi (MaCTPT, MaPPT, MaNV, SoGioPhuTroi, CongViecCuThe)
                           VALUES (@MaCT, @MaPPT, @MaNV, @SoGio, @CongViec)";

            SqlParameter[] prms = new SqlParameter[]
            {
                new SqlParameter("@MaCT", maCT),
                new SqlParameter("@MaPPT", txtMaPPT.Text.Trim()),
                new SqlParameter("@MaNV", cboNV_PT.SelectedValue),
                new SqlParameter("@SoGio", soGio),
                new SqlParameter("@CongViec", txtCongViec.Text.Trim())
            };

            try
            {
                Db.ThucThi(sql, prms);
                TaiChiTietTheoPhieu(txtMaPPT.Text.Trim());
                txtCongViec.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi thêm chi tiết phụ trội: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnXoaCTPT_Click(object sender, EventArgs e)
        {
            if (dgvChiTietPT.CurrentRow != null && dgvChiTietPT.CurrentRow.Index >= 0)
            {
                string maCT = dgvChiTietPT.CurrentRow.Cells["MaCTPT"].Value?.ToString();
                Db.ThucThi("DELETE FROM ChiTietPhuTroi WHERE MaCTPT = @Ma", new SqlParameter[] { new SqlParameter("@Ma", maCT) });
                TaiChiTietTheoPhieu(txtMaPPT.Text.Trim());
            }
            else
            {
                MessageBox.Show("Vui lòng chọn dòng nhân viên cần xóa khỏi ca!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btnLamMoiPPT_Click(object sender, EventArgs e)
        {
            // Rút ngắn còn đúng 10 ký tự: "PT" + 8 chữ số
            txtMaPPT.Text = "PT" + DateTime.Now.ToString("ddHHmmss");
            dtpNgayPT.Value = DateTime.Now;
            cboHinhThucPT.SelectedIndex = 0;
            txtHeSo.Text = "1.5";
            txtNguoiXacNhan.Text = "Trưởng ca sản xuất";
            txtSoGioPT.Text = "4";
            txtCongViec.Text = "Tăng ca đóng gói và phân loại sơn";
        }

        private void dgvPhieuPT_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvPhieuPT.CurrentRow != null && dgvPhieuPT.CurrentRow.Index >= 0)
            {
                DataGridViewRow row = dgvPhieuPT.CurrentRow;
                string maPPT = row.Cells["MaPPT"].Value?.ToString();
                txtMaPPT.Text = maPPT;
                cboPB_PPT.SelectedValue = row.Cells["MaPB"].Value?.ToString();
                if (DateTime.TryParse(row.Cells["NgayPhuTroi"].Value?.ToString(), out DateTime npt)) dtpNgayPT.Value = npt;
                cboHinhThucPT.Text = row.Cells["HinhThucPhuTroi"].Value?.ToString();
                txtHeSo.Text = row.Cells["HeSoPhuTroi"].Value?.ToString();
                txtNguoiXacNhan.Text = row.Cells["NguoiXacNhan"].Value?.ToString();

                TaiChiTietTheoPhieu(maPPT);
            }
        }

        private void btnDong_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}