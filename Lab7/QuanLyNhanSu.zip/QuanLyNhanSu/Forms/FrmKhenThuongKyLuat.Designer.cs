﻿namespace QuanLyNhanSu.Forms
{
    partial class FrmKhenThuongKyLuat
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblTieuDe = new System.Windows.Forms.Label();
            this.grpThongTinQD = new System.Windows.Forms.GroupBox();
            this.txtNguoiKy = new System.Windows.Forms.TextBox();
            this.lblNguoiKy = new System.Windows.Forms.Label();
            this.txtNoiDung = new System.Windows.Forms.TextBox();
            this.lblNoiDung = new System.Windows.Forms.Label();
            this.txtTongTien = new System.Windows.Forms.TextBox();
            this.lblTongTien = new System.Windows.Forms.Label();
            this.dtpNgayKy = new System.Windows.Forms.DateTimePicker();
            this.lblNgayKy = new System.Windows.Forms.Label();
            this.txtHinhThuc = new System.Windows.Forms.TextBox();
            this.lblHinhThuc = new System.Windows.Forms.Label();
            this.cboLoaiQD = new System.Windows.Forms.ComboBox();
            this.lblLoaiQD = new System.Windows.Forms.Label();
            this.txtMaQD = new System.Windows.Forms.TextBox();
            this.lblMaQD = new System.Windows.Forms.Label();
            this.grpChiTiet = new System.Windows.Forms.GroupBox();
            this.dgvChiTiet = new System.Windows.Forms.DataGridView();
            this.btnXoaDoiTuong = new System.Windows.Forms.Button();
            this.btnThemDoiTuong = new System.Windows.Forms.Button();
            this.txtGhiChu = new System.Windows.Forms.TextBox();
            this.lblGhiChu = new System.Windows.Forms.Label();
            this.txtSoTienCuThe = new System.Windows.Forms.TextBox();
            this.lblSoTienCuThe = new System.Windows.Forms.Label();
            this.cboPhongBan = new System.Windows.Forms.ComboBox();
            this.lblPhongBan = new System.Windows.Forms.Label();
            this.cboNhanVien = new System.Windows.Forms.ComboBox();
            this.lblNhanVien = new System.Windows.Forms.Label();
            this.rdoTapThe = new System.Windows.Forms.RadioButton();
            this.rdoCaNhan = new System.Windows.Forms.RadioButton();
            this.btnLuuQuyetDinh = new System.Windows.Forms.Button();
            this.btnLamMoi = new System.Windows.Forms.Button();
            this.btnDong = new System.Windows.Forms.Button();
            this.grpThongTinQD.SuspendLayout();
            this.grpChiTiet.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvChiTiet)).BeginInit();
            this.SuspendLayout();
            // 
            // lblTieuDe
            // 
            this.lblTieuDe.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblTieuDe.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold);
            this.lblTieuDe.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.lblTieuDe.Location = new System.Drawing.Point(0, 0);
            this.lblTieuDe.Name = "lblTieuDe";
            this.lblTieuDe.Size = new System.Drawing.Size(984, 55);
            this.lblTieuDe.TabIndex = 0;
            this.lblTieuDe.Text = "LẬP QUYẾT ĐỊNH KHEN THƯỞNG / KỶ LUẬT";
            this.lblTieuDe.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // grpThongTinQD
            // 
            this.grpThongTinQD.Controls.Add(this.txtNguoiKy);
            this.grpThongTinQD.Controls.Add(this.lblNguoiKy);
            this.grpThongTinQD.Controls.Add(this.txtNoiDung);
            this.grpThongTinQD.Controls.Add(this.lblNoiDung);
            this.grpThongTinQD.Controls.Add(this.txtTongTien);
            this.grpThongTinQD.Controls.Add(this.lblTongTien);
            this.grpThongTinQD.Controls.Add(this.dtpNgayKy);
            this.grpThongTinQD.Controls.Add(this.lblNgayKy);
            this.grpThongTinQD.Controls.Add(this.txtHinhThuc);
            this.grpThongTinQD.Controls.Add(this.lblHinhThuc);
            this.grpThongTinQD.Controls.Add(this.cboLoaiQD);
            this.grpThongTinQD.Controls.Add(this.lblLoaiQD);
            this.grpThongTinQD.Controls.Add(this.txtMaQD);
            this.grpThongTinQD.Controls.Add(this.lblMaQD);
            this.grpThongTinQD.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.grpThongTinQD.Location = new System.Drawing.Point(15, 60);
            this.grpThongTinQD.Name = "grpThongTinQD";
            this.grpThongTinQD.Size = new System.Drawing.Size(950, 180);
            this.grpThongTinQD.TabIndex = 1;
            this.grpThongTinQD.TabStop = false;
            this.grpThongTinQD.Text = "1. Thông tin chung Quyết định";
            // 
            // txtNguoiKy
            // 
            this.txtNguoiKy.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.txtNguoiKy.Location = new System.Drawing.Point(740, 75);
            this.txtNguoiKy.Name = "txtNguoiKy";
            this.txtNguoiKy.Size = new System.Drawing.Size(190, 30);
            this.txtNguoiKy.TabIndex = 13;
            // 
            // lblNguoiKy
            // 
            this.lblNguoiKy.AutoSize = true;
            this.lblNguoiKy.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblNguoiKy.Location = new System.Drawing.Point(645, 80);
            this.lblNguoiKy.Name = "lblNguoiKy";
            this.lblNguoiKy.Size = new System.Drawing.Size(77, 21);
            this.lblNguoiKy.TabIndex = 12;
            this.lblNguoiKy.Text = "Người ký:";
            // 
            // txtNoiDung
            // 
            this.txtNoiDung.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.txtNoiDung.Location = new System.Drawing.Point(120, 120);
            this.txtNoiDung.Name = "txtNoiDung";
            this.txtNoiDung.Size = new System.Drawing.Size(810, 30);
            this.txtNoiDung.TabIndex = 11;
            // 
            // lblNoiDung
            // 
            this.lblNoiDung.AutoSize = true;
            this.lblNoiDung.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblNoiDung.Location = new System.Drawing.Point(20, 125);
            this.lblNoiDung.Name = "lblNoiDung";
            this.lblNoiDung.Size = new System.Drawing.Size(78, 21);
            this.lblNoiDung.TabIndex = 10;
            this.lblNoiDung.Text = "Nội dung:";
            // 
            // txtTongTien
            // 
            this.txtTongTien.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.txtTongTien.Location = new System.Drawing.Point(435, 75);
            this.txtTongTien.Name = "txtTongTien";
            this.txtTongTien.Size = new System.Drawing.Size(185, 30);
            this.txtTongTien.TabIndex = 9;
            this.txtTongTien.Text = "0";
            // 
            // lblTongTien
            // 
            this.lblTongTien.AutoSize = true;
            this.lblTongTien.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblTongTien.Location = new System.Drawing.Point(340, 80);
            this.lblTongTien.Name = "lblTongTien";
            this.lblTongTien.Size = new System.Drawing.Size(79, 21);
            this.lblTongTien.TabIndex = 8;
            this.lblTongTien.Text = "Tổng tiền:";
            // 
            // dtpNgayKy
            // 
            this.dtpNgayKy.CustomFormat = "dd/MM/yyyy";
            this.dtpNgayKy.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.dtpNgayKy.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpNgayKy.Location = new System.Drawing.Point(120, 75);
            this.dtpNgayKy.Name = "dtpNgayKy";
            this.dtpNgayKy.Size = new System.Drawing.Size(190, 30);
            this.dtpNgayKy.TabIndex = 7;
            // 
            // lblNgayKy
            // 
            this.lblNgayKy.AutoSize = true;
            this.lblNgayKy.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblNgayKy.Location = new System.Drawing.Point(20, 80);
            this.lblNgayKy.Name = "lblNgayKy";
            this.lblNgayKy.Size = new System.Drawing.Size(70, 21);
            this.lblNgayKy.TabIndex = 6;
            this.lblNgayKy.Text = "Ngày ký:";
            // 
            // txtHinhThuc
            // 
            this.txtHinhThuc.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.txtHinhThuc.Location = new System.Drawing.Point(740, 30);
            this.txtHinhThuc.Name = "txtHinhThuc";
            this.txtHinhThuc.Size = new System.Drawing.Size(190, 30);
            this.txtHinhThuc.TabIndex = 5;
            // 
            // lblHinhThuc
            // 
            this.lblHinhThuc.AutoSize = true;
            this.lblHinhThuc.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblHinhThuc.Location = new System.Drawing.Point(645, 35);
            this.lblHinhThuc.Name = "lblHinhThuc";
            this.lblHinhThuc.Size = new System.Drawing.Size(81, 21);
            this.lblHinhThuc.TabIndex = 4;
            this.lblHinhThuc.Text = "Hình thức:";
            // 
            // cboLoaiQD
            // 
            this.cboLoaiQD.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboLoaiQD.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.cboLoaiQD.FormattingEnabled = true;
            this.cboLoaiQD.Items.AddRange(new object[] {
            "Khen thưởng",
            "Kỷ luật"});
            this.cboLoaiQD.Location = new System.Drawing.Point(435, 30);
            this.cboLoaiQD.Name = "cboLoaiQD";
            this.cboLoaiQD.Size = new System.Drawing.Size(185, 31);
            this.cboLoaiQD.TabIndex = 3;
            // 
            // lblLoaiQD
            // 
            this.lblLoaiQD.AutoSize = true;
            this.lblLoaiQD.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblLoaiQD.Location = new System.Drawing.Point(340, 35);
            this.lblLoaiQD.Name = "lblLoaiQD";
            this.lblLoaiQD.Size = new System.Drawing.Size(68, 21);
            this.lblLoaiQD.TabIndex = 2;
            this.lblLoaiQD.Text = "Loại QĐ:";
            // 
            // txtMaQD
            // 
            this.txtMaQD.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.txtMaQD.Location = new System.Drawing.Point(120, 30);
            this.txtMaQD.Name = "txtMaQD";
            this.txtMaQD.Size = new System.Drawing.Size(190, 30);
            this.txtMaQD.TabIndex = 1;
            // 
            // lblMaQD
            // 
            this.lblMaQD.AutoSize = true;
            this.lblMaQD.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblMaQD.Location = new System.Drawing.Point(20, 35);
            this.lblMaQD.Name = "lblMaQD";
            this.lblMaQD.Size = new System.Drawing.Size(61, 21);
            this.lblMaQD.TabIndex = 0;
            this.lblMaQD.Text = "Mã QĐ:";
            // 
            // grpChiTiet
            // 
            this.grpChiTiet.Controls.Add(this.dgvChiTiet);
            this.grpChiTiet.Controls.Add(this.btnXoaDoiTuong);
            this.grpChiTiet.Controls.Add(this.btnThemDoiTuong);
            this.grpChiTiet.Controls.Add(this.txtGhiChu);
            this.grpChiTiet.Controls.Add(this.lblGhiChu);
            this.grpChiTiet.Controls.Add(this.txtSoTienCuThe);
            this.grpChiTiet.Controls.Add(this.lblSoTienCuThe);
            this.grpChiTiet.Controls.Add(this.cboPhongBan);
            this.grpChiTiet.Controls.Add(this.lblPhongBan);
            this.grpChiTiet.Controls.Add(this.cboNhanVien);
            this.grpChiTiet.Controls.Add(this.lblNhanVien);
            this.grpChiTiet.Controls.Add(this.rdoTapThe);
            this.grpChiTiet.Controls.Add(this.rdoCaNhan);
            this.grpChiTiet.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.grpChiTiet.Location = new System.Drawing.Point(15, 250);
            this.grpChiTiet.Name = "grpChiTiet";
            this.grpChiTiet.Size = new System.Drawing.Size(950, 310);
            this.grpChiTiet.TabIndex = 2;
            this.grpChiTiet.TabStop = false;
            this.grpChiTiet.Text = "2. Danh sách Đối tượng thụ hưởng (Cá nhân NV hoặc Tập thể PB)";
            // 
            // dgvChiTiet
            // 
            this.dgvChiTiet.AllowUserToAddRows = false;
            this.dgvChiTiet.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvChiTiet.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvChiTiet.Location = new System.Drawing.Point(20, 115);
            this.dgvChiTiet.Name = "dgvChiTiet";
            this.dgvChiTiet.ReadOnly = true;
            this.dgvChiTiet.RowHeadersWidth = 40;
            this.dgvChiTiet.RowTemplate.Height = 24;
            this.dgvChiTiet.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvChiTiet.Size = new System.Drawing.Size(910, 180);
            this.dgvChiTiet.TabIndex = 12;
            // 
            // btnXoaDoiTuong
            // 
            this.btnXoaDoiTuong.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnXoaDoiTuong.Location = new System.Drawing.Point(825, 70);
            this.btnXoaDoiTuong.Name = "btnXoaDoiTuong";
            this.btnXoaDoiTuong.Size = new System.Drawing.Size(105, 32);
            this.btnXoaDoiTuong.TabIndex = 11;
            this.btnXoaDoiTuong.Text = "Xóa dòng";
            this.btnXoaDoiTuong.UseVisualStyleBackColor = true;
            this.btnXoaDoiTuong.Click += new System.EventHandler(this.btnXoaDoiTuong_Click);
            // 
            // btnThemDoiTuong
            // 
            this.btnThemDoiTuong.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.btnThemDoiTuong.ForeColor = System.Drawing.Color.DarkGreen;
            this.btnThemDoiTuong.Location = new System.Drawing.Point(710, 70);
            this.btnThemDoiTuong.Name = "btnThemDoiTuong";
            this.btnThemDoiTuong.Size = new System.Drawing.Size(105, 32);
            this.btnThemDoiTuong.TabIndex = 10;
            this.btnThemDoiTuong.Text = "+ Thêm";
            this.btnThemDoiTuong.UseVisualStyleBackColor = true;
            this.btnThemDoiTuong.Click += new System.EventHandler(this.btnThemDoiTuong_Click);
            // 
            // txtGhiChu
            // 
            this.txtGhiChu.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.txtGhiChu.Location = new System.Drawing.Point(400, 70);
            this.txtGhiChu.Name = "txtGhiChu";
            this.txtGhiChu.Size = new System.Drawing.Size(280, 30);
            this.txtGhiChu.TabIndex = 9;
            // 
            // lblGhiChu
            // 
            this.lblGhiChu.AutoSize = true;
            this.lblGhiChu.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblGhiChu.Location = new System.Drawing.Point(325, 75);
            this.lblGhiChu.Name = "lblGhiChu";
            this.lblGhiChu.Size = new System.Drawing.Size(66, 21);
            this.lblGhiChu.TabIndex = 8;
            this.lblGhiChu.Text = "Ghi chú:";
            // 
            // txtSoTienCuThe
            // 
            this.txtSoTienCuThe.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.txtSoTienCuThe.Location = new System.Drawing.Point(120, 70);
            this.txtSoTienCuThe.Name = "txtSoTienCuThe";
            this.txtSoTienCuThe.Size = new System.Drawing.Size(180, 30);
            this.txtSoTienCuThe.TabIndex = 7;
            this.txtSoTienCuThe.Text = "0";
            // 
            // lblSoTienCuThe
            // 
            this.lblSoTienCuThe.AutoSize = true;
            this.lblSoTienCuThe.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblSoTienCuThe.Location = new System.Drawing.Point(20, 75);
            this.lblSoTienCuThe.Name = "lblSoTienCuThe";
            this.lblSoTienCuThe.Size = new System.Drawing.Size(60, 21);
            this.lblSoTienCuThe.TabIndex = 6;
            this.lblSoTienCuThe.Text = "Số tiền:";
            // 
            // cboPhongBan
            // 
            this.cboPhongBan.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboPhongBan.Enabled = false;
            this.cboPhongBan.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.cboPhongBan.FormattingEnabled = true;
            this.cboPhongBan.Location = new System.Drawing.Point(680, 25);
            this.cboPhongBan.Name = "cboPhongBan";
            this.cboPhongBan.Size = new System.Drawing.Size(250, 31);
            this.cboPhongBan.TabIndex = 5;
            // 
            // lblPhongBan
            // 
            this.lblPhongBan.AutoSize = true;
            this.lblPhongBan.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblPhongBan.Location = new System.Drawing.Point(585, 30);
            this.lblPhongBan.Name = "lblPhongBan";
            this.lblPhongBan.Size = new System.Drawing.Size(89, 21);
            this.lblPhongBan.TabIndex = 4;
            this.lblPhongBan.Text = "Phòng ban:";
            // 
            // cboNhanVien
            // 
            this.cboNhanVien.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboNhanVien.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.cboNhanVien.FormattingEnabled = true;
            this.cboNhanVien.Location = new System.Drawing.Point(325, 25);
            this.cboNhanVien.Name = "cboNhanVien";
            this.cboNhanVien.Size = new System.Drawing.Size(240, 31);
            this.cboNhanVien.TabIndex = 3;
            // 
            // lblNhanVien
            // 
            this.lblNhanVien.AutoSize = true;
            this.lblNhanVien.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblNhanVien.Location = new System.Drawing.Point(235, 30);
            this.lblNhanVien.Name = "lblNhanVien";
            this.lblNhanVien.Size = new System.Drawing.Size(84, 21);
            this.lblNhanVien.TabIndex = 2;
            this.lblNhanVien.Text = "Nhân viên:";
            // 
            // rdoTapThe
            // 
            this.rdoTapThe.AutoSize = true;
            this.rdoTapThe.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.rdoTapThe.Location = new System.Drawing.Point(125, 28);
            this.rdoTapThe.Name = "rdoTapThe";
            this.rdoTapThe.Size = new System.Drawing.Size(83, 25);
            this.rdoTapThe.TabIndex = 1;
            this.rdoTapThe.Text = "Tập thể";
            this.rdoTapThe.UseVisualStyleBackColor = true;
            this.rdoTapThe.CheckedChanged += new System.EventHandler(this.rdoDoiTuong_CheckedChanged);
            // 
            // rdoCaNhan
            // 
            this.rdoCaNhan.AutoSize = true;
            this.rdoCaNhan.Checked = true;
            this.rdoCaNhan.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.rdoCaNhan.Location = new System.Drawing.Point(25, 28);
            this.rdoCaNhan.Name = "rdoCaNhan";
            this.rdoCaNhan.Size = new System.Drawing.Size(89, 25);
            this.rdoCaNhan.TabIndex = 0;
            this.rdoCaNhan.TabStop = true;
            this.rdoCaNhan.Text = "Cá nhân";
            this.rdoCaNhan.UseVisualStyleBackColor = true;
            this.rdoCaNhan.CheckedChanged += new System.EventHandler(this.rdoDoiTuong_CheckedChanged);
            // 
            // btnLuuQuyetDinh
            // 
            this.btnLuuQuyetDinh.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.btnLuuQuyetDinh.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.btnLuuQuyetDinh.Location = new System.Drawing.Point(280, 575);
            this.btnLuuQuyetDinh.Name = "btnLuuQuyetDinh";
            this.btnLuuQuyetDinh.Size = new System.Drawing.Size(200, 45);
            this.btnLuuQuyetDinh.TabIndex = 3;
            this.btnLuuQuyetDinh.Text = "LƯU QUYẾT ĐỊNH";
            this.btnLuuQuyetDinh.UseVisualStyleBackColor = true;
            this.btnLuuQuyetDinh.Click += new System.EventHandler(this.btnLuuQuyetDinh_Click);
            // 
            // btnLamMoi
            // 
            this.btnLamMoi.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnLamMoi.Location = new System.Drawing.Point(500, 575);
            this.btnLamMoi.Name = "btnLamMoi";
            this.btnLamMoi.Size = new System.Drawing.Size(120, 45);
            this.btnLamMoi.TabIndex = 4;
            this.btnLamMoi.Text = "Làm mới";
            this.btnLamMoi.UseVisualStyleBackColor = true;
            this.btnLamMoi.Click += new System.EventHandler(this.btnLamMoi_Click);
            // 
            // btnDong
            // 
            this.btnDong.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnDong.Location = new System.Drawing.Point(640, 575);
            this.btnDong.Name = "btnDong";
            this.btnDong.Size = new System.Drawing.Size(120, 45);
            this.btnDong.TabIndex = 5;
            this.btnDong.Text = "Đóng";
            this.btnDong.UseVisualStyleBackColor = true;
            this.btnDong.Click += new System.EventHandler(this.btnDong_Click);
            // 
            // FrmKhenThuongKyLuat
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(984, 635);
            this.Controls.Add(this.btnDong);
            this.Controls.Add(this.btnLamMoi);
            this.Controls.Add(this.btnLuuQuyetDinh);
            this.Controls.Add(this.grpChiTiet);
            this.Controls.Add(this.grpThongTinQD);
            this.Controls.Add(this.lblTieuDe);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Lập quyết định Khen thưởng / Kỷ luật";
            this.Load += new System.EventHandler(this.FrmKhenThuongKyLuat_Load);
            this.grpThongTinQD.ResumeLayout(false);
            this.grpThongTinQD.PerformLayout();
            this.grpChiTiet.ResumeLayout(false);
            this.grpChiTiet.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvChiTiet)).EndInit();
            this.ResumeLayout(false);
        }

        private System.Windows.Forms.Label lblTieuDe;
        private System.Windows.Forms.GroupBox grpThongTinQD;
        private System.Windows.Forms.TextBox txtNguoiKy;
        private System.Windows.Forms.Label lblNguoiKy;
        private System.Windows.Forms.TextBox txtNoiDung;
        private System.Windows.Forms.Label lblNoiDung;
        private System.Windows.Forms.TextBox txtTongTien;
        private System.Windows.Forms.Label lblTongTien;
        private System.Windows.Forms.DateTimePicker dtpNgayKy;
        private System.Windows.Forms.Label lblNgayKy;
        private System.Windows.Forms.TextBox txtHinhThuc;
        private System.Windows.Forms.Label lblHinhThuc;
        private System.Windows.Forms.ComboBox cboLoaiQD;
        private System.Windows.Forms.Label lblLoaiQD;
        private System.Windows.Forms.TextBox txtMaQD;
        private System.Windows.Forms.Label lblMaQD;
        private System.Windows.Forms.GroupBox grpChiTiet;
        private System.Windows.Forms.RadioButton rdoTapThe;
        private System.Windows.Forms.RadioButton rdoCaNhan;
        private System.Windows.Forms.ComboBox cboPhongBan;
        private System.Windows.Forms.Label lblPhongBan;
        private System.Windows.Forms.ComboBox cboNhanVien;
        private System.Windows.Forms.Label lblNhanVien;
        private System.Windows.Forms.TextBox txtGhiChu;
        private System.Windows.Forms.Label lblGhiChu;
        private System.Windows.Forms.TextBox txtSoTienCuThe;
        private System.Windows.Forms.Label lblSoTienCuThe;
        private System.Windows.Forms.Button btnXoaDoiTuong;
        private System.Windows.Forms.Button btnThemDoiTuong;
        private System.Windows.Forms.DataGridView dgvChiTiet;
        private System.Windows.Forms.Button btnLuuQuyetDinh;
        private System.Windows.Forms.Button btnLamMoi;
        private System.Windows.Forms.Button btnDong;
    }
}