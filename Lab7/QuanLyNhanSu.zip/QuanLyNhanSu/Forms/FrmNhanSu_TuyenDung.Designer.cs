﻿namespace QuanLyNhanSu.Forms
{
    partial class FrmNhanSu_TuyenDung
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblTieuDe = new System.Windows.Forms.Label();
            this.tabNhanSu = new System.Windows.Forms.TabControl();
            this.tabHoSoNV = new System.Windows.Forms.TabPage();
            this.dgvNhanVien = new System.Windows.Forms.DataGridView();
            this.grpThongTinNV = new System.Windows.Forms.GroupBox();
            this.btnLamMoiNV = new System.Windows.Forms.Button();
            this.btnXoaNV = new System.Windows.Forms.Button();
            this.btnSuaNV = new System.Windows.Forms.Button();
            this.btnThemNV = new System.Windows.Forms.Button();
            this.cboTrangThaiNV = new System.Windows.Forms.ComboBox();
            this.lblTrangThaiNV = new System.Windows.Forms.Label();
            this.cboPhongBan = new System.Windows.Forms.ComboBox();
            this.lblPhongBan = new System.Windows.Forms.Label();
            this.txtDienThoai = new System.Windows.Forms.TextBox();
            this.lblDienThoai = new System.Windows.Forms.Label();
            this.txtDiaChi = new System.Windows.Forms.TextBox();
            this.lblDiaChi = new System.Windows.Forms.Label();
            this.cboGioiTinh = new System.Windows.Forms.ComboBox();
            this.lblGioiTinh = new System.Windows.Forms.Label();
            this.dtpNgaySinh = new System.Windows.Forms.DateTimePicker();
            this.lblNgaySinh = new System.Windows.Forms.Label();
            this.txtHoTen = new System.Windows.Forms.TextBox();
            this.lblHoTen = new System.Windows.Forms.Label();
            this.txtMaNV = new System.Windows.Forms.TextBox();
            this.lblMaNV = new System.Windows.Forms.Label();
            this.tabQDTD = new System.Windows.Forms.TabPage();
            this.dgvQDTD = new System.Windows.Forms.DataGridView();
            this.grpThongTinQDTD = new System.Windows.Forms.GroupBox();
            this.btnLamMoiQDTD = new System.Windows.Forms.Button();
            this.btnCapNhatKetQua = new System.Windows.Forms.Button();
            this.btnLapQDTD = new System.Windows.Forms.Button();
            this.cboTrangThaiQDTD = new System.Windows.Forms.ComboBox();
            this.lblTrangThaiQDTD = new System.Windows.Forms.Label();
            this.txtDieuKhoan = new System.Windows.Forms.TextBox();
            this.lblDieuKhoan = new System.Windows.Forms.Label();
            this.txtLuongThuViec = new System.Windows.Forms.TextBox();
            this.lblLuongThuViec = new System.Windows.Forms.Label();
            this.dtpNgayKetThuc = new System.Windows.Forms.DateTimePicker();
            this.lblNgayKetThuc = new System.Windows.Forms.Label();
            this.dtpNgayBatDau = new System.Windows.Forms.DateTimePicker();
            this.lblNgayBatDau = new System.Windows.Forms.Label();
            this.dtpNgayKyQDTD = new System.Windows.Forms.DateTimePicker();
            this.lblNgayKyQDTD = new System.Windows.Forms.Label();
            this.cboPB_QDTD = new System.Windows.Forms.ComboBox();
            this.lblPB_QDTD = new System.Windows.Forms.Label();
            this.cboNV_QDTD = new System.Windows.Forms.ComboBox();
            this.lblNV_QDTD = new System.Windows.Forms.Label();
            this.txtMaQDTD = new System.Windows.Forms.TextBox();
            this.lblMaQDTD = new System.Windows.Forms.Label();
            this.btnDong = new System.Windows.Forms.Button();
            this.tabNhanSu.SuspendLayout();
            this.tabHoSoNV.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvNhanVien)).BeginInit();
            this.grpThongTinNV.SuspendLayout();
            this.tabQDTD.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvQDTD)).BeginInit();
            this.grpThongTinQDTD.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblTieuDe
            // 
            this.lblTieuDe.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblTieuDe.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold);
            this.lblTieuDe.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.lblTieuDe.Location = new System.Drawing.Point(0, 0);
            this.lblTieuDe.Name = "lblTieuDe";
            this.lblTieuDe.Size = new System.Drawing.Size(1004, 50);
            this.lblTieuDe.TabIndex = 0;
            this.lblTieuDe.Text = "QUẢN LÝ HỒ SƠ NHÂN VIÊN VÀ QUYẾT ĐỊNH TUYỂN DỤNG";
            this.lblTieuDe.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tabNhanSu
            // 
            this.tabNhanSu.Controls.Add(this.tabHoSoNV);
            this.tabNhanSu.Controls.Add(this.tabQDTD);
            this.tabNhanSu.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.tabNhanSu.Location = new System.Drawing.Point(12, 55);
            this.tabNhanSu.Name = "tabNhanSu";
            this.tabNhanSu.SelectedIndex = 0;
            this.tabNhanSu.Size = new System.Drawing.Size(980, 565);
            this.tabNhanSu.TabIndex = 1;
            // 
            // tabHoSoNV
            // 
            this.tabHoSoNV.Controls.Add(this.dgvNhanVien);
            this.tabHoSoNV.Controls.Add(this.grpThongTinNV);
            this.tabHoSoNV.Location = new System.Drawing.Point(4, 32);
            this.tabHoSoNV.Name = "tabHoSoNV";
            this.tabHoSoNV.Padding = new System.Windows.Forms.Padding(3);
            this.tabHoSoNV.Size = new System.Drawing.Size(972, 529);
            this.tabHoSoNV.TabIndex = 0;
            this.tabHoSoNV.Text = "1. Hồ sơ Nhân viên";
            this.tabHoSoNV.UseVisualStyleBackColor = true;
            // 
            // dgvNhanVien
            // 
            this.dgvNhanVien.AllowUserToAddRows = false;
            this.dgvNhanVien.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvNhanVien.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvNhanVien.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.dgvNhanVien.Location = new System.Drawing.Point(15, 230);
            this.dgvNhanVien.Name = "dgvNhanVien";
            this.dgvNhanVien.ReadOnly = true;
            this.dgvNhanVien.RowHeadersWidth = 35;
            this.dgvNhanVien.RowTemplate.Height = 24;
            this.dgvNhanVien.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvNhanVien.Size = new System.Drawing.Size(940, 285);
            this.dgvNhanVien.TabIndex = 1;
            this.dgvNhanVien.SelectionChanged += new System.EventHandler(this.dgvNhanVien_SelectionChanged);
            // 
            // grpThongTinNV
            // 
            this.grpThongTinNV.Controls.Add(this.btnLamMoiNV);
            this.grpThongTinNV.Controls.Add(this.btnXoaNV);
            this.grpThongTinNV.Controls.Add(this.btnSuaNV);
            this.grpThongTinNV.Controls.Add(this.btnThemNV);
            this.grpThongTinNV.Controls.Add(this.cboTrangThaiNV);
            this.grpThongTinNV.Controls.Add(this.lblTrangThaiNV);
            this.grpThongTinNV.Controls.Add(this.cboPhongBan);
            this.grpThongTinNV.Controls.Add(this.lblPhongBan);
            this.grpThongTinNV.Controls.Add(this.txtDienThoai);
            this.grpThongTinNV.Controls.Add(this.lblDienThoai);
            this.grpThongTinNV.Controls.Add(this.txtDiaChi);
            this.grpThongTinNV.Controls.Add(this.lblDiaChi);
            this.grpThongTinNV.Controls.Add(this.cboGioiTinh);
            this.grpThongTinNV.Controls.Add(this.lblGioiTinh);
            this.grpThongTinNV.Controls.Add(this.dtpNgaySinh);
            this.grpThongTinNV.Controls.Add(this.lblNgaySinh);
            this.grpThongTinNV.Controls.Add(this.txtHoTen);
            this.grpThongTinNV.Controls.Add(this.lblHoTen);
            this.grpThongTinNV.Controls.Add(this.txtMaNV);
            this.grpThongTinNV.Controls.Add(this.lblMaNV);
            this.grpThongTinNV.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.grpThongTinNV.Location = new System.Drawing.Point(15, 10);
            this.grpThongTinNV.Name = "grpThongTinNV";
            this.grpThongTinNV.Size = new System.Drawing.Size(940, 210);
            this.grpThongTinNV.TabIndex = 0;
            this.grpThongTinNV.TabStop = false;
            this.grpThongTinNV.Text = "Thông tin cá nhân & Đơn vị";
            // 
            // btnLamMoiNV
            // 
            this.btnLamMoiNV.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnLamMoiNV.Location = new System.Drawing.Point(620, 160);
            this.btnLamMoiNV.Name = "btnLamMoiNV";
            this.btnLamMoiNV.Size = new System.Drawing.Size(110, 35);
            this.btnLamMoiNV.TabIndex = 19;
            this.btnLamMoiNV.Text = "Làm mới";
            this.btnLamMoiNV.UseVisualStyleBackColor = true;
            this.btnLamMoiNV.Click += new System.EventHandler(this.btnLamMoiNV_Click);
            // 
            // btnXoaNV
            // 
            this.btnXoaNV.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnXoaNV.ForeColor = System.Drawing.Color.DarkRed;
            this.btnXoaNV.Location = new System.Drawing.Point(490, 160);
            this.btnXoaNV.Name = "btnXoaNV";
            this.btnXoaNV.Size = new System.Drawing.Size(110, 35);
            this.btnXoaNV.TabIndex = 18;
            this.btnXoaNV.Text = "Xóa";
            this.btnXoaNV.UseVisualStyleBackColor = true;
            this.btnXoaNV.Click += new System.EventHandler(this.btnXoaNV_Click);
            // 
            // btnSuaNV
            // 
            this.btnSuaNV.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnSuaNV.Location = new System.Drawing.Point(360, 160);
            this.btnSuaNV.Name = "btnSuaNV";
            this.btnSuaNV.Size = new System.Drawing.Size(110, 35);
            this.btnSuaNV.TabIndex = 17;
            this.btnSuaNV.Text = "Cập nhật";
            this.btnSuaNV.UseVisualStyleBackColor = true;
            this.btnSuaNV.Click += new System.EventHandler(this.btnSuaNV_Click);
            // 
            // btnThemNV
            // 
            this.btnThemNV.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.btnThemNV.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.btnThemNV.Location = new System.Drawing.Point(230, 160);
            this.btnThemNV.Name = "btnThemNV";
            this.btnThemNV.Size = new System.Drawing.Size(110, 35);
            this.btnThemNV.TabIndex = 16;
            this.btnThemNV.Text = "+ Thêm mới";
            this.btnThemNV.UseVisualStyleBackColor = true;
            this.btnThemNV.Click += new System.EventHandler(this.btnThemNV_Click);
            // 
            // cboTrangThaiNV
            // 
            this.cboTrangThaiNV.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboTrangThaiNV.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.cboTrangThaiNV.FormattingEnabled = true;
            this.cboTrangThaiNV.Items.AddRange(new object[] {
            "Thử việc",
            "Chính thức",
            "Đã nghỉ việc"});
            this.cboTrangThaiNV.Location = new System.Drawing.Point(740, 115);
            this.cboTrangThaiNV.Name = "cboTrangThaiNV";
            this.cboTrangThaiNV.Size = new System.Drawing.Size(175, 29);
            this.cboTrangThaiNV.TabIndex = 15;
            // 
            // lblTrangThaiNV
            // 
            this.lblTrangThaiNV.AutoSize = true;
            this.lblTrangThaiNV.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblTrangThaiNV.Location = new System.Drawing.Point(645, 120);
            this.lblTrangThaiNV.Name = "lblTrangThaiNV";
            this.lblTrangThaiNV.Size = new System.Drawing.Size(82, 21);
            this.lblTrangThaiNV.TabIndex = 14;
            this.lblTrangThaiNV.Text = "Trạng thái:";
            // 
            // cboPhongBan
            // 
            this.cboPhongBan.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboPhongBan.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.cboPhongBan.FormattingEnabled = true;
            this.cboPhongBan.Location = new System.Drawing.Point(420, 115);
            this.cboPhongBan.Name = "cboPhongBan";
            this.cboPhongBan.Size = new System.Drawing.Size(200, 29);
            this.cboPhongBan.TabIndex = 13;
            // 
            // lblPhongBan
            // 
            this.lblPhongBan.AutoSize = true;
            this.lblPhongBan.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblPhongBan.Location = new System.Drawing.Point(325, 120);
            this.lblPhongBan.Name = "lblPhongBan";
            this.lblPhongBan.Size = new System.Drawing.Size(89, 21);
            this.lblPhongBan.TabIndex = 12;
            this.lblPhongBan.Text = "Phòng ban:";
            // 
            // txtDienThoai
            // 
            this.txtDienThoai.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtDienThoai.Location = new System.Drawing.Point(105, 115);
            this.txtDienThoai.Name = "txtDienThoai";
            this.txtDienThoai.Size = new System.Drawing.Size(195, 29);
            this.txtDienThoai.TabIndex = 11;
            // 
            // lblDienThoai
            // 
            this.lblDienThoai.AutoSize = true;
            this.lblDienThoai.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblDienThoai.Location = new System.Drawing.Point(15, 120);
            this.lblDienThoai.Name = "lblDienThoai";
            this.lblDienThoai.Size = new System.Drawing.Size(84, 21);
            this.lblDienThoai.TabIndex = 10;
            this.lblDienThoai.Text = "Điện thoại:";
            // 
            // txtDiaChi
            // 
            this.txtDiaChi.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtDiaChi.Location = new System.Drawing.Point(420, 75);
            this.txtDiaChi.Name = "txtDiaChi";
            this.txtDiaChi.Size = new System.Drawing.Size(495, 29);
            this.txtDiaChi.TabIndex = 9;
            // 
            // lblDiaChi
            // 
            this.lblDiaChi.AutoSize = true;
            this.lblDiaChi.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblDiaChi.Location = new System.Drawing.Point(325, 80);
            this.lblDiaChi.Name = "lblDiaChi";
            this.lblDiaChi.Size = new System.Drawing.Size(60, 21);
            this.lblDiaChi.TabIndex = 8;
            this.lblDiaChi.Text = "Địa chỉ:";
            // 
            // cboGioiTinh
            // 
            this.cboGioiTinh.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboGioiTinh.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.cboGioiTinh.FormattingEnabled = true;
            this.cboGioiTinh.Items.AddRange(new object[] {
            "Nam",
            "Nữ"});
            this.cboGioiTinh.Location = new System.Drawing.Point(105, 75);
            this.cboGioiTinh.Name = "cboGioiTinh";
            this.cboGioiTinh.Size = new System.Drawing.Size(195, 29);
            this.cboGioiTinh.TabIndex = 7;
            // 
            // lblGioiTinh
            // 
            this.lblGioiTinh.AutoSize = true;
            this.lblGioiTinh.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblGioiTinh.Location = new System.Drawing.Point(15, 80);
            this.lblGioiTinh.Name = "lblGioiTinh";
            this.lblGioiTinh.Size = new System.Drawing.Size(73, 21);
            this.lblGioiTinh.TabIndex = 6;
            this.lblGioiTinh.Text = "Giới tính:";
            // 
            // dtpNgaySinh
            // 
            this.dtpNgaySinh.CustomFormat = "dd/MM/yyyy";
            this.dtpNgaySinh.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.dtpNgaySinh.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpNgaySinh.Location = new System.Drawing.Point(740, 35);
            this.dtpNgaySinh.Name = "dtpNgaySinh";
            this.dtpNgaySinh.Size = new System.Drawing.Size(175, 29);
            this.dtpNgaySinh.TabIndex = 5;
            // 
            // lblNgaySinh
            // 
            this.lblNgaySinh.AutoSize = true;
            this.lblNgaySinh.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblNgaySinh.Location = new System.Drawing.Point(645, 40);
            this.lblNgaySinh.Name = "lblNgaySinh";
            this.lblNgaySinh.Size = new System.Drawing.Size(83, 21);
            this.lblNgaySinh.TabIndex = 4;
            this.lblNgaySinh.Text = "Ngày sinh:";
            // 
            // txtHoTen
            // 
            this.txtHoTen.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtHoTen.Location = new System.Drawing.Point(420, 35);
            this.txtHoTen.Name = "txtHoTen";
            this.txtHoTen.Size = new System.Drawing.Size(200, 29);
            this.txtHoTen.TabIndex = 3;
            // 
            // lblHoTen
            // 
            this.lblHoTen.AutoSize = true;
            this.lblHoTen.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblHoTen.Location = new System.Drawing.Point(325, 40);
            this.lblHoTen.Name = "lblHoTen";
            this.lblHoTen.Size = new System.Drawing.Size(59, 21);
            this.lblHoTen.TabIndex = 2;
            this.lblHoTen.Text = "Họ tên:";
            // 
            // txtMaNV
            // 
            this.txtMaNV.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtMaNV.Location = new System.Drawing.Point(105, 35);
            this.txtMaNV.Name = "txtMaNV";
            this.txtMaNV.Size = new System.Drawing.Size(195, 29);
            this.txtMaNV.TabIndex = 1;
            // 
            // lblMaNV
            // 
            this.lblMaNV.AutoSize = true;
            this.lblMaNV.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblMaNV.Location = new System.Drawing.Point(15, 40);
            this.lblMaNV.Name = "lblMaNV";
            this.lblMaNV.Size = new System.Drawing.Size(61, 21);
            this.lblMaNV.TabIndex = 0;
            this.lblMaNV.Text = "Mã NV:";
            // 
            // tabQDTD
            // 
            this.tabQDTD.Controls.Add(this.dgvQDTD);
            this.tabQDTD.Controls.Add(this.grpThongTinQDTD);
            this.tabQDTD.Location = new System.Drawing.Point(4, 32);
            this.tabQDTD.Name = "tabQDTD";
            this.tabQDTD.Padding = new System.Windows.Forms.Padding(3);
            this.tabQDTD.Size = new System.Drawing.Size(972, 529);
            this.tabQDTD.TabIndex = 1;
            this.tabQDTD.Text = "2. Quyết định Tuyển dụng & Thử việc";
            this.tabQDTD.UseVisualStyleBackColor = true;
            // 
            // dgvQDTD
            // 
            this.dgvQDTD.AllowUserToAddRows = false;
            this.dgvQDTD.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvQDTD.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvQDTD.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.dgvQDTD.Location = new System.Drawing.Point(15, 245);
            this.dgvQDTD.Name = "dgvQDTD";
            this.dgvQDTD.ReadOnly = true;
            this.dgvQDTD.RowHeadersWidth = 35;
            this.dgvQDTD.RowTemplate.Height = 24;
            this.dgvQDTD.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvQDTD.Size = new System.Drawing.Size(940, 270);
            this.dgvQDTD.TabIndex = 1;
            this.dgvQDTD.SelectionChanged += new System.EventHandler(this.dgvQDTD_SelectionChanged);
            // 
            // grpThongTinQDTD
            // 
            this.grpThongTinQDTD.Controls.Add(this.btnLamMoiQDTD);
            this.grpThongTinQDTD.Controls.Add(this.btnCapNhatKetQua);
            this.grpThongTinQDTD.Controls.Add(this.btnLapQDTD);
            this.grpThongTinQDTD.Controls.Add(this.cboTrangThaiQDTD);
            this.grpThongTinQDTD.Controls.Add(this.lblTrangThaiQDTD);
            this.grpThongTinQDTD.Controls.Add(this.txtDieuKhoan);
            this.grpThongTinQDTD.Controls.Add(this.lblDieuKhoan);
            this.grpThongTinQDTD.Controls.Add(this.txtLuongThuViec);
            this.grpThongTinQDTD.Controls.Add(this.lblLuongThuViec);
            this.grpThongTinQDTD.Controls.Add(this.dtpNgayKetThuc);
            this.grpThongTinQDTD.Controls.Add(this.lblNgayKetThuc);
            this.grpThongTinQDTD.Controls.Add(this.dtpNgayBatDau);
            this.grpThongTinQDTD.Controls.Add(this.lblNgayBatDau);
            this.grpThongTinQDTD.Controls.Add(this.dtpNgayKyQDTD);
            this.grpThongTinQDTD.Controls.Add(this.lblNgayKyQDTD);
            this.grpThongTinQDTD.Controls.Add(this.cboPB_QDTD);
            this.grpThongTinQDTD.Controls.Add(this.lblPB_QDTD);
            this.grpThongTinQDTD.Controls.Add(this.cboNV_QDTD);
            this.grpThongTinQDTD.Controls.Add(this.lblNV_QDTD);
            this.grpThongTinQDTD.Controls.Add(this.txtMaQDTD);
            this.grpThongTinQDTD.Controls.Add(this.lblMaQDTD);
            this.grpThongTinQDTD.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.grpThongTinQDTD.Location = new System.Drawing.Point(15, 10);
            this.grpThongTinQDTD.Name = "grpThongTinQDTD";
            this.grpThongTinQDTD.Size = new System.Drawing.Size(940, 225);
            this.grpThongTinQDTD.TabIndex = 0;
            this.grpThongTinQDTD.TabStop = false;
            this.grpThongTinQDTD.Text = "Chi tiết Quyết định & Thỏa thuận thử việc";
            // 
            // lblMaQDTD
            // 
            this.lblMaQDTD.AutoSize = true;
            this.lblMaQDTD.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblMaQDTD.Location = new System.Drawing.Point(15, 35);
            this.lblMaQDTD.Name = "lblMaQDTD";
            this.lblMaQDTD.Size = new System.Drawing.Size(82, 21);
            this.lblMaQDTD.TabIndex = 0;
            this.lblMaQDTD.Text = "Mã QĐTD:";
            // 
            // txtMaQDTD
            // 
            this.txtMaQDTD.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtMaQDTD.Location = new System.Drawing.Point(115, 30);
            this.txtMaQDTD.Name = "txtMaQDTD";
            this.txtMaQDTD.Size = new System.Drawing.Size(195, 29);
            this.txtMaQDTD.TabIndex = 1;
            // 
            // lblNV_QDTD
            // 
            this.lblNV_QDTD.AutoSize = true;
            this.lblNV_QDTD.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblNV_QDTD.Location = new System.Drawing.Point(330, 35);
            this.lblNV_QDTD.Name = "lblNV_QDTD";
            this.lblNV_QDTD.Size = new System.Drawing.Size(84, 21);
            this.lblNV_QDTD.TabIndex = 2;
            this.lblNV_QDTD.Text = "Nhân viên:";
            // 
            // cboNV_QDTD
            // 
            this.cboNV_QDTD.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboNV_QDTD.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.cboNV_QDTD.FormattingEnabled = true;
            this.cboNV_QDTD.Location = new System.Drawing.Point(425, 30);
            this.cboNV_QDTD.Name = "cboNV_QDTD";
            this.cboNV_QDTD.Size = new System.Drawing.Size(195, 29);
            this.cboNV_QDTD.TabIndex = 3;
            // 
            // lblPB_QDTD
            // 
            this.lblPB_QDTD.AutoSize = true;
            this.lblPB_QDTD.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblPB_QDTD.Location = new System.Drawing.Point(640, 35);
            this.lblPB_QDTD.Name = "lblPB_QDTD";
            this.lblPB_QDTD.Size = new System.Drawing.Size(89, 21);
            this.lblPB_QDTD.TabIndex = 4;
            this.lblPB_QDTD.Text = "Phòng ban:";
            // 
            // cboPB_QDTD
            // 
            this.cboPB_QDTD.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboPB_QDTD.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.cboPB_QDTD.FormattingEnabled = true;
            this.cboPB_QDTD.Location = new System.Drawing.Point(740, 30);
            this.cboPB_QDTD.Name = "cboPB_QDTD";
            this.cboPB_QDTD.Size = new System.Drawing.Size(180, 29);
            this.cboPB_QDTD.TabIndex = 5;
            // 
            // lblNgayKyQDTD
            // 
            this.lblNgayKyQDTD.AutoSize = true;
            this.lblNgayKyQDTD.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblNgayKyQDTD.Location = new System.Drawing.Point(15, 75);
            this.lblNgayKyQDTD.Name = "lblNgayKyQDTD";
            this.lblNgayKyQDTD.Size = new System.Drawing.Size(70, 21);
            this.lblNgayKyQDTD.TabIndex = 6;
            this.lblNgayKyQDTD.Text = "Ngày ký:";
            // 
            // dtpNgayKyQDTD
            // 
            this.dtpNgayKyQDTD.CustomFormat = "dd/MM/yyyy";
            this.dtpNgayKyQDTD.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.dtpNgayKyQDTD.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpNgayKyQDTD.Location = new System.Drawing.Point(115, 70);
            this.dtpNgayKyQDTD.Name = "dtpNgayKyQDTD";
            this.dtpNgayKyQDTD.Size = new System.Drawing.Size(195, 29);
            this.dtpNgayKyQDTD.TabIndex = 7;
            // 
            // lblNgayBatDau
            // 
            this.lblNgayBatDau.AutoSize = true;
            this.lblNgayBatDau.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblNgayBatDau.Location = new System.Drawing.Point(330, 75);
            this.lblNgayBatDau.Name = "lblNgayBatDau";
            this.lblNgayBatDau.Size = new System.Drawing.Size(68, 21);
            this.lblNgayBatDau.TabIndex = 8;
            this.lblNgayBatDau.Text = "Từ ngày:";
            // 
            // dtpNgayBatDau
            // 
            this.dtpNgayBatDau.CustomFormat = "dd/MM/yyyy";
            this.dtpNgayBatDau.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.dtpNgayBatDau.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpNgayBatDau.Location = new System.Drawing.Point(425, 70);
            this.dtpNgayBatDau.Name = "dtpNgayBatDau";
            this.dtpNgayBatDau.Size = new System.Drawing.Size(195, 29);
            this.dtpNgayBatDau.TabIndex = 9;
            // 
            // lblNgayKetThuc
            // 
            this.lblNgayKetThuc.AutoSize = true;
            this.lblNgayKetThuc.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblNgayKetThuc.Location = new System.Drawing.Point(640, 75);
            this.lblNgayKetThuc.Name = "lblNgayKetThuc";
            this.lblNgayKetThuc.Size = new System.Drawing.Size(79, 21);
            this.lblNgayKetThuc.TabIndex = 10;
            this.lblNgayKetThuc.Text = "Đến ngày:";
            // 
            // dtpNgayKetThuc
            // 
            this.dtpNgayKetThuc.CustomFormat = "dd/MM/yyyy";
            this.dtpNgayKetThuc.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.dtpNgayKetThuc.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpNgayKetThuc.Location = new System.Drawing.Point(740, 70);
            this.dtpNgayKetThuc.Name = "dtpNgayKetThuc";
            this.dtpNgayKetThuc.Size = new System.Drawing.Size(180, 29);
            this.dtpNgayKetThuc.TabIndex = 11;
            // 
            // lblLuongThuViec
            // 
            this.lblLuongThuViec.AutoSize = true;
            this.lblLuongThuViec.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblLuongThuViec.Location = new System.Drawing.Point(15, 115);
            this.lblLuongThuViec.Name = "lblLuongThuViec";
            this.lblLuongThuViec.Size = new System.Drawing.Size(77, 21);
            this.lblLuongThuViec.TabIndex = 12;
            this.lblLuongThuViec.Text = "Lương TV:";
            // 
            // txtLuongThuViec
            // 
            this.txtLuongThuViec.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtLuongThuViec.Location = new System.Drawing.Point(115, 110);
            this.txtLuongThuViec.Name = "txtLuongThuViec";
            this.txtLuongThuViec.Size = new System.Drawing.Size(195, 29);
            this.txtLuongThuViec.TabIndex = 13;
            this.txtLuongThuViec.Text = "5000000";
            // 
            // lblTrangThaiQDTD
            // 
            this.lblTrangThaiQDTD.AutoSize = true;
            this.lblTrangThaiQDTD.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblTrangThaiQDTD.Location = new System.Drawing.Point(330, 115);
            this.lblTrangThaiQDTD.Name = "lblTrangThaiQDTD";
            this.lblTrangThaiQDTD.Size = new System.Drawing.Size(82, 21);
            this.lblTrangThaiQDTD.TabIndex = 14;
            this.lblTrangThaiQDTD.Text = "Trạng thái:";
            // 
            // cboTrangThaiQDTD
            // 
            this.cboTrangThaiQDTD.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboTrangThaiQDTD.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.cboTrangThaiQDTD.FormattingEnabled = true;
            this.cboTrangThaiQDTD.Items.AddRange(new object[] {
            "Đang thử việc",
            "Đạt",
            "Không đạt"});
            this.cboTrangThaiQDTD.Location = new System.Drawing.Point(425, 110);
            this.cboTrangThaiQDTD.Name = "cboTrangThaiQDTD";
            this.cboTrangThaiQDTD.Size = new System.Drawing.Size(195, 29);
            this.cboTrangThaiQDTD.TabIndex = 15;
            // 
            // lblDieuKhoan
            // 
            this.lblDieuKhoan.AutoSize = true;
            this.lblDieuKhoan.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblDieuKhoan.Location = new System.Drawing.Point(640, 115);
            this.lblDieuKhoan.Name = "lblDieuKhoan";
            this.lblDieuKhoan.Size = new System.Drawing.Size(92, 21);
            this.lblDieuKhoan.TabIndex = 16;
            this.lblDieuKhoan.Text = "Điều khoản:";
            // 
            // txtDieuKhoan
            // 
            this.txtDieuKhoan.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtDieuKhoan.Location = new System.Drawing.Point(740, 110);
            this.txtDieuKhoan.Name = "txtDieuKhoan";
            this.txtDieuKhoan.Size = new System.Drawing.Size(180, 29);
            this.txtDieuKhoan.TabIndex = 17;
            // 
            // btnLapQDTD
            // 
            this.btnLapQDTD.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.btnLapQDTD.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.btnLapQDTD.Location = new System.Drawing.Point(215, 165);
            this.btnLapQDTD.Name = "btnLapQDTD";
            this.btnLapQDTD.Size = new System.Drawing.Size(160, 38);
            this.btnLapQDTD.TabIndex = 18;
            this.btnLapQDTD.Text = "+ Lập QĐ Tuyển";
            this.btnLapQDTD.UseVisualStyleBackColor = true;
            this.btnLapQDTD.Click += new System.EventHandler(this.btnLapQDTD_Click);
            // 
            // btnCapNhatKetQua
            // 
            this.btnCapNhatKetQua.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnCapNhatKetQua.Location = new System.Drawing.Point(395, 165);
            this.btnCapNhatKetQua.Name = "btnCapNhatKetQua";
            this.btnCapNhatKetQua.Size = new System.Drawing.Size(180, 38);
            this.btnCapNhatKetQua.TabIndex = 19;
            this.btnCapNhatKetQua.Text = "Đánh giá kết quả TV";
            this.btnCapNhatKetQua.UseVisualStyleBackColor = true;
            this.btnCapNhatKetQua.Click += new System.EventHandler(this.btnCapNhatKetQua_Click);
            // 
            // btnLamMoiQDTD
            // 
            this.btnLamMoiQDTD.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnLamMoiQDTD.Location = new System.Drawing.Point(595, 165);
            this.btnLamMoiQDTD.Name = "btnLamMoiQDTD";
            this.btnLamMoiQDTD.Size = new System.Drawing.Size(120, 38);
            this.btnLamMoiQDTD.TabIndex = 20;
            this.btnLamMoiQDTD.Text = "Làm mới";
            this.btnLamMoiQDTD.UseVisualStyleBackColor = true;
            this.btnLamMoiQDTD.Click += new System.EventHandler(this.btnLamMoiQDTD_Click);
            // 
            // btnDong
            // 
            this.btnDong.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnDong.Location = new System.Drawing.Point(860, 625);
            this.btnDong.Name = "btnDong";
            this.btnDong.Size = new System.Drawing.Size(130, 40);
            this.btnDong.TabIndex = 2;
            this.btnDong.Text = "Đóng";
            this.btnDong.UseVisualStyleBackColor = true;
            this.btnDong.Click += new System.EventHandler(this.btnDong_Click);
            // 
            // FrmNhanSu_TuyenDung
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1004, 675);
            this.Controls.Add(this.btnDong);
            this.Controls.Add(this.tabNhanSu);
            this.Controls.Add(this.lblTieuDe);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Quản lý Nhân sự & Tuyển dụng thử việc";
            this.Load += new System.EventHandler(this.FrmNhanSu_TuyenDung_Load);
            this.tabNhanSu.ResumeLayout(false);
            this.tabHoSoNV.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvNhanVien)).EndInit();
            this.grpThongTinNV.ResumeLayout(false);
            this.grpThongTinNV.PerformLayout();
            this.tabQDTD.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvQDTD)).EndInit();
            this.grpThongTinQDTD.ResumeLayout(false);
            this.grpThongTinQDTD.PerformLayout();
            this.ResumeLayout(false);
        }

        private System.Windows.Forms.Label lblTieuDe;
        private System.Windows.Forms.TabControl tabNhanSu;
        private System.Windows.Forms.TabPage tabHoSoNV;
        private System.Windows.Forms.TabPage tabQDTD;
        private System.Windows.Forms.Button btnDong;
        private System.Windows.Forms.GroupBox grpThongTinNV;
        private System.Windows.Forms.TextBox txtMaNV;
        private System.Windows.Forms.Label lblMaNV;
        private System.Windows.Forms.TextBox txtHoTen;
        private System.Windows.Forms.Label lblHoTen;
        private System.Windows.Forms.DateTimePicker dtpNgaySinh;
        private System.Windows.Forms.Label lblNgaySinh;
        private System.Windows.Forms.ComboBox cboGioiTinh;
        private System.Windows.Forms.Label lblGioiTinh;
        private System.Windows.Forms.TextBox txtDiaChi;
        private System.Windows.Forms.Label lblDiaChi;
        private System.Windows.Forms.TextBox txtDienThoai;
        private System.Windows.Forms.Label lblDienThoai;
        private System.Windows.Forms.ComboBox cboPhongBan;
        private System.Windows.Forms.Label lblPhongBan;
        private System.Windows.Forms.ComboBox cboTrangThaiNV;
        private System.Windows.Forms.Label lblTrangThaiNV;
        private System.Windows.Forms.Button btnLamMoiNV;
        private System.Windows.Forms.Button btnXoaNV;
        private System.Windows.Forms.Button btnSuaNV;
        private System.Windows.Forms.Button btnThemNV;
        private System.Windows.Forms.DataGridView dgvNhanVien;
        private System.Windows.Forms.GroupBox grpThongTinQDTD;
        private System.Windows.Forms.TextBox txtMaQDTD;
        private System.Windows.Forms.Label lblMaQDTD;
        private System.Windows.Forms.ComboBox cboNV_QDTD;
        private System.Windows.Forms.Label lblNV_QDTD;
        private System.Windows.Forms.ComboBox cboPB_QDTD;
        private System.Windows.Forms.Label lblPB_QDTD;
        private System.Windows.Forms.DateTimePicker dtpNgayKyQDTD;
        private System.Windows.Forms.Label lblNgayKyQDTD;
        private System.Windows.Forms.DateTimePicker dtpNgayBatDau;
        private System.Windows.Forms.Label lblNgayBatDau;
        private System.Windows.Forms.DateTimePicker dtpNgayKetThuc;
        private System.Windows.Forms.Label lblNgayKetThuc;
        private System.Windows.Forms.TextBox txtLuongThuViec;
        private System.Windows.Forms.Label lblLuongThuViec;
        private System.Windows.Forms.TextBox txtDieuKhoan;
        private System.Windows.Forms.Label lblDieuKhoan;
        private System.Windows.Forms.ComboBox cboTrangThaiQDTD;
        private System.Windows.Forms.Label lblTrangThaiQDTD;
        private System.Windows.Forms.Button btnLamMoiQDTD;
        private System.Windows.Forms.Button btnCapNhatKetQua;
        private System.Windows.Forms.Button btnLapQDTD;
        private System.Windows.Forms.DataGridView dgvQDTD;
    }
}