﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using QuanLyNhanSu.Data;

namespace QuanLyNhanSu.Forms
{
    public partial class FrmBangLuong : Form
    {
        private DataTable dtBangLuong;

        public FrmBangLuong()
        {
            InitializeComponent();
        }

        private void FrmBangLuong_Load(object sender, EventArgs e)
        {
            KhoiTaoThangNam();
            KhoiTaoBangLuongTable();
            btnXemBangLuong_Click(null, null);
        }

        private void KhoiTaoThangNam()
        {
            for (int i = 1; i <= 12; i++) cboThang.Items.Add(i);
            cboThang.SelectedItem = DateTime.Now.Month;

            int curYear = DateTime.Now.Year;
            for (int y = curYear - 2; y <= curYear + 2; y++) cboNam.Items.Add(y);
            cboNam.SelectedItem = curYear;
        }

        private void KhoiTaoBangLuongTable()
        {
            dtBangLuong = new DataTable();
            dtBangLuong.Columns.Add("MaBL", typeof(string));
            dtBangLuong.Columns.Add("MaNV", typeof(string));
            dtBangLuong.Columns.Add("HoTen", typeof(string));
            dtBangLuong.Columns.Add("Thang", typeof(int));
            dtBangLuong.Columns.Add("Nam", typeof(int));
            dtBangLuong.Columns.Add("LuongChinh", typeof(decimal));
            dtBangLuong.Columns.Add("TienPhuTroi", typeof(decimal));
            dtBangLuong.Columns.Add("TienPhuCap", typeof(decimal));
            dtBangLuong.Columns.Add("TienThuong", typeof(decimal));
            dtBangLuong.Columns.Add("TienPhat", typeof(decimal));
            dtBangLuong.Columns.Add("TrichBaoHiem", typeof(decimal));
            dtBangLuong.Columns.Add("ThucLinh", typeof(decimal));

            dgvBangLuong.DataSource = dtBangLuong;

            dgvBangLuong.Columns["MaBL"].HeaderText = "Mã BL";
            dgvBangLuong.Columns["MaNV"].HeaderText = "Mã NV";
            dgvBangLuong.Columns["HoTen"].HeaderText = "Họ tên";
            dgvBangLuong.Columns["Thang"].HeaderText = "Tháng";
            dgvBangLuong.Columns["Nam"].HeaderText = "Năm";
            dgvBangLuong.Columns["LuongChinh"].HeaderText = "Lương chính";
            dgvBangLuong.Columns["TienPhuTroi"].HeaderText = "Phụ trội";
            dgvBangLuong.Columns["TienPhuCap"].HeaderText = "Phụ cấp";
            dgvBangLuong.Columns["TienThuong"].HeaderText = "Thưởng";
            dgvBangLuong.Columns["TienPhat"].HeaderText = "Phạt";
            dgvBangLuong.Columns["TrichBaoHiem"].HeaderText = "Trích BH";
            dgvBangLuong.Columns["ThucLinh"].HeaderText = "Thực lĩnh";

            dgvBangLuong.Columns["LuongChinh"].DefaultCellStyle.Format = "N0";
            dgvBangLuong.Columns["TienPhuTroi"].DefaultCellStyle.Format = "N0";
            dgvBangLuong.Columns["TienPhuCap"].DefaultCellStyle.Format = "N0";
            dgvBangLuong.Columns["TienThuong"].DefaultCellStyle.Format = "N0";
            dgvBangLuong.Columns["TienPhat"].DefaultCellStyle.Format = "N0";
            dgvBangLuong.Columns["TrichBaoHiem"].DefaultCellStyle.Format = "N0";
            dgvBangLuong.Columns["ThucLinh"].DefaultCellStyle.Format = "N0";
        }

        private void btnXemBangLuong_Click(object sender, EventArgs e)
        {
            int thang = Convert.ToInt32(cboThang.SelectedItem);
            int nam = Convert.ToInt32(cboNam.SelectedItem);

            string sql = @"SELECT bl.MaBL, bl.MaNV, nv.HoTen, bl.Thang, bl.Nam, 
                                  bl.LuongChinh, bl.TienPhuTroi, bl.TienPhuCap, bl.TienThuong, 
                                  bl.TienPhat, bl.TrichBaoHiem, bl.ThucLinh
                           FROM BangLuong bl
                           JOIN NhanVien nv ON bl.MaNV = nv.MaNV
                           WHERE bl.Thang = @Thang AND bl.Nam = @Nam";

            DataTable dt = Db.LayDuLieu(sql, new SqlParameter[]
            {
                new SqlParameter("@Thang", thang),
                new SqlParameter("@Nam", nam)
            });

            dtBangLuong.Clear();
            foreach (DataRow r in dt.Rows)
            {
                dtBangLuong.ImportRow(r);
            }

            if (dtBangLuong.Rows.Count == 0)
            {
                XoaFormChiTiet();
            }
        }

        private void btnTinhLuong_Click(object sender, EventArgs e)
        {
            int thang = Convert.ToInt32(cboThang.SelectedItem);
            int nam = Convert.ToInt32(cboNam.SelectedItem);

            string sqlNV = @"SELECT nv.MaNV, nv.HoTen, nv.MaPB, cc.SoNgayCongChuan, cc.SoNgayDiLam
                             FROM NhanVien nv
                             JOIN BangChamCong cc ON nv.MaNV = cc.MaNV
                             WHERE cc.Thang = @Thang AND cc.Nam = @Nam AND nv.TrangThai != N'Đã nghỉ việc'";

            DataTable dtNV = Db.LayDuLieu(sqlNV, new SqlParameter[]
            {
                new SqlParameter("@Thang", thang),
                new SqlParameter("@Nam", nam)
            });

            if (dtNV.Rows.Count == 0)
            {
                MessageBox.Show($"Không tìm thấy dữ liệu chấm công của tháng {thang}/{nam}!\nVui lòng qua phân hệ Chấm công ghi nhận công trước.",
                                "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            dtBangLuong.Clear();

            foreach (DataRow rNV in dtNV.Rows)
            {
                string maNV = rNV["MaNV"].ToString();
                string hoTen = rNV["HoTen"].ToString();
                string maPB = rNV["MaPB"] != DBNull.Value ? rNV["MaPB"].ToString() : "";
                decimal congChuan = Convert.ToDecimal(rNV["SoNgayCongChuan"]);
                decimal diLam = Convert.ToDecimal(rNV["SoNgayDiLam"]);

                decimal luongCoBan = 0;
                decimal phuCapLuong = 0;
                decimal phuCapDocHai = 0;
                string sqlL = @"SELECT TOP 1 LuongCoBan, PhuCapLuong, PhuCapDocHai 
                                FROM QuyetDinhLuong 
                                WHERE MaNV = @MaNV 
                                ORDER BY NgayHieuLuc DESC";
                DataTable dtL = Db.LayDuLieu(sqlL, new SqlParameter[] { new SqlParameter("@MaNV", maNV) });
                if (dtL.Rows.Count > 0)
                {
                    luongCoBan = Convert.ToDecimal(dtL.Rows[0]["LuongCoBan"]);
                    phuCapLuong = Convert.ToDecimal(dtL.Rows[0]["PhuCapLuong"]);
                    phuCapDocHai = Convert.ToDecimal(dtL.Rows[0]["PhuCapDocHai"]);
                }

                decimal phuCapChucVu = 0;
                string sqlCV = @"SELECT TOP 1 PhuCapChucVu 
                                 FROM QuyetDinhChucVu 
                                 WHERE MaNV = @MaNV 
                                 ORDER BY NgayHieuLuc DESC";
                DataTable dtCV = Db.LayDuLieu(sqlCV, new SqlParameter[] { new SqlParameter("@MaNV", maNV) });
                if (dtCV.Rows.Count > 0)
                {
                    phuCapChucVu = Convert.ToDecimal(dtCV.Rows[0]["PhuCapChucVu"]);
                }

                decimal luongChinh = 0;
                if (congChuan > 0)
                {
                    luongChinh = Math.Round((luongCoBan / congChuan) * diLam, 0);
                }

                decimal tienPhuTroi = 0;
                string sqlPT = @"SELECT ct.SoGioPhuTroi, ppt.HeSoPhuTroi
                                 FROM ChiTietPhuTroi ct
                                 JOIN PhieuGhiNhanPhuTroi ppt ON ct.MaPPT = ppt.MaPPT
                                 WHERE ct.MaNV = @MaNV 
                                   AND MONTH(ppt.NgayPhuTroi) = @Thang 
                                   AND YEAR(ppt.NgayPhuTroi) = @Nam";
                DataTable dtPT = Db.LayDuLieu(sqlPT, new SqlParameter[]
                {
                    new SqlParameter("@MaNV", maNV),
                    new SqlParameter("@Thang", thang),
                    new SqlParameter("@Nam", nam)
                });

                decimal donGiaGio = (congChuan > 0) ? (luongCoBan / (congChuan * 8)) : 0;
                foreach (DataRow rPT in dtPT.Rows)
                {
                    decimal soGio = Convert.ToDecimal(rPT["SoGioPhuTroi"]);
                    decimal heSo = Convert.ToDecimal(rPT["HeSoPhuTroi"]);
                    tienPhuTroi += Math.Round(soGio * heSo * donGiaGio, 0);
                }

                decimal tienPhuCap = phuCapChucVu + phuCapLuong + phuCapDocHai;

                decimal tienThuong = 0;
                decimal tienPhat = 0;
                string sqlKTKL = @"SELECT qd.LoaiQuyetDinh, ct.SoTienCuThe
                                   FROM ChiTietKhenThuongKyLuat ct
                                   JOIN QuyetDinhKhenThuongKyLuat qd ON ct.MaQDKTKL = qd.MaQDKTKL
                                   WHERE (ct.MaNV = @MaNV OR ct.MaPB = @MaPB)
                                     AND MONTH(qd.NgayKy) = @Thang 
                                     AND YEAR(qd.NgayKy) = @Nam";
                DataTable dtKTKL = Db.LayDuLieu(sqlKTKL, new SqlParameter[]
                {
                    new SqlParameter("@MaNV", maNV),
                    new SqlParameter("@MaPB", string.IsNullOrEmpty(maPB) ? (object)DBNull.Value : maPB),
                    new SqlParameter("@Thang", thang),
                    new SqlParameter("@Nam", nam)
                });

                foreach (DataRow rKT in dtKTKL.Rows)
                {
                    string loai = rKT["LoaiQuyetDinh"].ToString();
                    decimal tien = Convert.ToDecimal(rKT["SoTienCuThe"]);
                    if (loai == "Khen thưởng") tienThuong += tien;
                    else if (loai == "Kỷ luật") tienPhat += tien;
                }

                decimal trichBaoHiem = 0;
                string sqlBH = "SELECT TOP 1 TyLeDongNV FROM BaoHiem WHERE MaNV = @MaNV";
                DataTable dtBH = Db.LayDuLieu(sqlBH, new SqlParameter[] { new SqlParameter("@MaNV", maNV) });
                if (dtBH.Rows.Count > 0)
                {
                    decimal tyLeNV = Convert.ToDecimal(dtBH.Rows[0]["TyLeDongNV"]);
                    trichBaoHiem = Math.Round(luongCoBan * (tyLeNV / 100), 0);
                }

                decimal thucLinh = (luongChinh + tienPhuTroi + tienPhuCap + tienThuong) - (trichBaoHiem + tienPhat);
                if (thucLinh < 0) thucLinh = 0;

                string maBL = "BL" + nam.ToString().Substring(2) + thang.ToString("D2") + "_" + maNV;
                DataRow rMoi = dtBangLuong.NewRow();
                rMoi["MaBL"] = maBL;
                rMoi["MaNV"] = maNV;
                rMoi["HoTen"] = hoTen;
                rMoi["Thang"] = thang;
                rMoi["Nam"] = nam;
                rMoi["LuongChinh"] = luongChinh;
                rMoi["TienPhuTroi"] = tienPhuTroi;
                rMoi["TienPhuCap"] = tienPhuCap;
                rMoi["TienThuong"] = tienThuong;
                rMoi["TienPhat"] = tienPhat;
                rMoi["TrichBaoHiem"] = trichBaoHiem;
                rMoi["ThucLinh"] = thucLinh;
                dtBangLuong.Rows.Add(rMoi);
            }

            MessageBox.Show($"Đã tính toán xong bảng lương cho {dtBangLuong.Rows.Count} nhân viên trong tháng {thang}/{nam}!\nNhấn nút 'LƯU VÀO CSDL' để hoàn tất.",
                            "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnLuuBangLuong_Click(object sender, EventArgs e)
        {
            if (dtBangLuong.Rows.Count == 0)
            {
                MessageBox.Show("Chưa có dữ liệu bảng lương để lưu!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int thang = Convert.ToInt32(cboThang.SelectedItem);
            int nam = Convert.ToInt32(cboNam.SelectedItem);

            using (SqlConnection conn = Db.GetConnection())
            {
                conn.Open();
                SqlTransaction trans = conn.BeginTransaction();

                try
                {
                    string sqlXoa = "DELETE FROM BangLuong WHERE Thang = @Thang AND Nam = @Nam";
                    using (SqlCommand cmdXoa = new SqlCommand(sqlXoa, conn, trans))
                    {
                        cmdXoa.Parameters.AddWithValue("@Thang", thang);
                        cmdXoa.Parameters.AddWithValue("@Nam", nam);
                        cmdXoa.ExecuteNonQuery();
                    }

                    string sqlChen = @"INSERT INTO BangLuong 
                                      (MaBL, MaNV, Thang, Nam, LuongChinh, TienPhuTroi, TienPhuCap, TienThuong, TienPhat, TrichBaoHiem, ThucLinh)
                                      VALUES (@MaBL, @MaNV, @Thang, @Nam, @LC, @PT, @PC, @Thuong, @Phat, @BH, @TL)";

                    foreach (DataRow r in dtBangLuong.Rows)
                    {
                        using (SqlCommand cmdChen = new SqlCommand(sqlChen, conn, trans))
                        {
                            cmdChen.Parameters.AddWithValue("@MaBL", r["MaBL"]);
                            cmdChen.Parameters.AddWithValue("@MaNV", r["MaNV"]);
                            cmdChen.Parameters.AddWithValue("@Thang", r["Thang"]);
                            cmdChen.Parameters.AddWithValue("@Nam", r["Nam"]);
                            cmdChen.Parameters.AddWithValue("@LC", r["LuongChinh"]);
                            cmdChen.Parameters.AddWithValue("@PT", r["TienPhuTroi"]);
                            cmdChen.Parameters.AddWithValue("@PC", r["TienPhuCap"]);
                            cmdChen.Parameters.AddWithValue("@Thuong", r["TienThuong"]);
                            cmdChen.Parameters.AddWithValue("@Phat", r["TienPhat"]);
                            cmdChen.Parameters.AddWithValue("@BH", r["TrichBaoHiem"]);
                            cmdChen.Parameters.AddWithValue("@TL", r["ThucLinh"]);
                            cmdChen.ExecuteNonQuery();
                        }
                    }

                    trans.Commit();
                    MessageBox.Show($"Đã lưu bảng lương tháng {thang}/{nam} vào CSDL thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    trans.Rollback();
                    MessageBox.Show("Lỗi lưu bảng lương: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnInPhieuLuong_Click(object sender, EventArgs e)
        {
            if (dgvBangLuong.CurrentRow == null)
            {
                MessageBox.Show("Vui lòng chọn nhân viên cần in phiếu lương trên bảng!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DataGridViewRow r = dgvBangLuong.CurrentRow;
            string phieu = "============= PHIẾU LƯƠNG NHÂN VIÊN =============\n\n" +
                           $"Họ tên: {r.Cells["HoTen"].Value} (Mã NV: {r.Cells["MaNV"].Value})\n" +
                           $"Kỳ lương: Tháng {r.Cells["Thang"].Value}/{r.Cells["Nam"].Value}\n" +
                           "--------------------------------------------------\n" +
                           $"+ Lương chính thực tế: {Convert.ToDecimal(r.Cells["LuongChinh"].Value):N0} VNĐ\n" +
                           $"+ Tiền làm thêm phụ trội: {Convert.ToDecimal(r.Cells["TienPhuTroi"].Value):N0} VNĐ\n" +
                           $"+ Phụ cấp (CV + Độc hại): {Convert.ToDecimal(r.Cells["TienPhuCap"].Value):N0} VNĐ\n" +
                           $"+ Tiền thưởng (Lễ/Tết/QĐ): {Convert.ToDecimal(r.Cells["TienThuong"].Value):N0} VNĐ\n" +
                           $"- Tiền phạt kỷ luật: {Convert.ToDecimal(r.Cells["TienPhat"].Value):N0} VNĐ\n" +
                           $"- Trích nộp bảo hiểm (BHYT, BHXH): {Convert.ToDecimal(r.Cells["TrichBaoHiem"].Value):N0} VNĐ\n" +
                           "--------------------------------------------------\n" +
                           $"==> THỰC LĨNH: {Convert.ToDecimal(r.Cells["ThucLinh"].Value):N0} VNĐ\n\n" +
                           "==================================================";

            MessageBox.Show(phieu, "Phiếu lương điện tử", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void dgvBangLuong_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvBangLuong.CurrentRow != null && dgvBangLuong.CurrentRow.Index >= 0)
            {
                DataGridViewRow r = dgvBangLuong.CurrentRow;
                txtMaBL.Text = r.Cells["MaBL"].Value?.ToString();
                txtHoTenNV.Text = r.Cells["HoTen"].Value?.ToString();
                txtLuongChinh.Text = Convert.ToDecimal(r.Cells["LuongChinh"].Value).ToString("N0");
                txtTienPhuTroi.Text = Convert.ToDecimal(r.Cells["TienPhuTroi"].Value).ToString("N0");
                txtTienPhuCap.Text = Convert.ToDecimal(r.Cells["TienPhuCap"].Value).ToString("N0");
                txtTienThuong.Text = Convert.ToDecimal(r.Cells["TienThuong"].Value).ToString("N0");
                txtTienPhat.Text = Convert.ToDecimal(r.Cells["TienPhat"].Value).ToString("N0");
                txtTrichBaoHiem.Text = Convert.ToDecimal(r.Cells["TrichBaoHiem"].Value).ToString("N0");
                txtThucLinh.Text = Convert.ToDecimal(r.Cells["ThucLinh"].Value).ToString("N0");
            }
        }

        private void XoaFormChiTiet()
        {
            txtMaBL.Clear();
            txtHoTenNV.Clear();
            txtLuongChinh.Text = "0";
            txtTienPhuTroi.Text = "0";
            txtTienPhuCap.Text = "0";
            txtTienThuong.Text = "0";
            txtTienPhat.Text = "0";
            txtTrichBaoHiem.Text = "0";
            txtThucLinh.Text = "0";
        }

        private void btnDong_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}