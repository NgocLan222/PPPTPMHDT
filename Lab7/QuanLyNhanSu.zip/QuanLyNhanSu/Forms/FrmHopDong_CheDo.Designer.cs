﻿namespace QuanLyNhanSu.Forms
{
    partial class FrmHopDong_CheDo
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblTieuDe = new System.Windows.Forms.Label();
            this.tabHopDongCheDo = new System.Windows.Forms.TabControl();
            this.tabHopDong = new System.Windows.Forms.TabPage();
            this.dgvHopDong = new System.Windows.Forms.DataGridView();
            this.grpThongTinHD = new System.Windows.Forms.GroupBox();
            this.btnLamMoiHD = new System.Windows.Forms.Button();
            this.btnXoaHD = new System.Windows.Forms.Button();
            this.btnSuaHD = new System.Windows.Forms.Button();
            this.btnLapHD = new System.Windows.Forms.Button();
            this.txtNoiDungHD = new System.Windows.Forms.TextBox();
            this.lblNoiDungHD = new System.Windows.Forms.Label();
            this.dtpNgayHetHan = new System.Windows.Forms.DateTimePicker();
            this.lblNgayHetHan = new System.Windows.Forms.Label();
            this.dtpNgayHieuLuc = new System.Windows.Forms.DateTimePicker();
            this.lblNgayHieuLuc = new System.Windows.Forms.Label();
            this.dtpNgayKyHD = new System.Windows.Forms.DateTimePicker();
            this.lblNgayKyHD = new System.Windows.Forms.Label();
            this.cboLoaiHD = new System.Windows.Forms.ComboBox();
            this.lblLoaiHD = new System.Windows.Forms.Label();
            this.cboNV_HD = new System.Windows.Forms.ComboBox();
            this.lblNV_HD = new System.Windows.Forms.Label();
            this.txtMaHD = new System.Windows.Forms.TextBox();
            this.lblMaHD = new System.Windows.Forms.Label();
            this.tabChucVu = new System.Windows.Forms.TabPage();
            this.dgvChucVu = new System.Windows.Forms.DataGridView();
            this.grpThongTinCV = new System.Windows.Forms.GroupBox();
            this.btnLamMoiCV = new System.Windows.Forms.Button();
            this.btnXoaCV = new System.Windows.Forms.Button();
            this.btnSuaCV = new System.Windows.Forms.Button();
            this.btnLapQDCV = new System.Windows.Forms.Button();
            this.txtLyDoCV = new System.Windows.Forms.TextBox();
            this.lblLyDoCV = new System.Windows.Forms.Label();
            this.dtpNgayHLCV = new System.Windows.Forms.DateTimePicker();
            this.lblNgayHLCV = new System.Windows.Forms.Label();
            this.txtPhuCapCV = new System.Windows.Forms.TextBox();
            this.lblPhuCapCV = new System.Windows.Forms.Label();
            this.txtChucVu = new System.Windows.Forms.TextBox();
            this.lblChucVu = new System.Windows.Forms.Label();
            this.cboNV_CV = new System.Windows.Forms.ComboBox();
            this.lblNV_CV = new System.Windows.Forms.Label();
            this.txtMaQDCV = new System.Windows.Forms.TextBox();
            this.lblMaQDCV = new System.Windows.Forms.Label();
            this.tabLuong = new System.Windows.Forms.TabPage();
            this.dgvLuong = new System.Windows.Forms.DataGridView();
            this.grpThongTinLuong = new System.Windows.Forms.GroupBox();
            this.btnLamMoiLuong = new System.Windows.Forms.Button();
            this.btnXoaLuong = new System.Windows.Forms.Button();
            this.btnSuaLuong = new System.Windows.Forms.Button();
            this.btnLapQDL = new System.Windows.Forms.Button();
            this.dtpNgayHLLuong = new System.Windows.Forms.DateTimePicker();
            this.lblNgayHLLuong = new System.Windows.Forms.Label();
            this.txtPhuCapDocHai = new System.Windows.Forms.TextBox();
            this.lblPhuCapDocHai = new System.Windows.Forms.Label();
            this.txtPhuCapLuong = new System.Windows.Forms.TextBox();
            this.lblPhuCapLuong = new System.Windows.Forms.Label();
            this.txtLuongCoBan = new System.Windows.Forms.TextBox();
            this.lblLuongCoBan = new System.Windows.Forms.Label();
            this.cboNV_Luong = new System.Windows.Forms.ComboBox();
            this.lblNV_Luong = new System.Windows.Forms.Label();
            this.txtMaQDL = new System.Windows.Forms.TextBox();
            this.lblMaQDL = new System.Windows.Forms.Label();
            this.tabBaoHiem = new System.Windows.Forms.TabPage();
            this.dgvBaoHiem = new System.Windows.Forms.DataGridView();
            this.grpThongTinBH = new System.Windows.Forms.GroupBox();
            this.btnLamMoiBH = new System.Windows.Forms.Button();
            this.btnXoaBH = new System.Windows.Forms.Button();
            this.btnSuaBH = new System.Windows.Forms.Button();
            this.btnLapBH = new System.Windows.Forms.Button();
            this.txtTyLeCT = new System.Windows.Forms.TextBox();
            this.lblTyLeCT = new System.Windows.Forms.Label();
            this.txtTyLeNV = new System.Windows.Forms.TextBox();
            this.lblTyLeNV = new System.Windows.Forms.Label();
            this.dtpNgayThamGia = new System.Windows.Forms.DateTimePicker();
            this.lblNgayThamGia = new System.Windows.Forms.Label();
            this.txtSoSoBHXH = new System.Windows.Forms.TextBox();
            this.lblSoSoBHXH = new System.Windows.Forms.Label();
            this.txtSoTheBHYT = new System.Windows.Forms.TextBox();
            this.lblSoTheBHYT = new System.Windows.Forms.Label();
            this.cboNV_BH = new System.Windows.Forms.ComboBox();
            this.lblNV_BH = new System.Windows.Forms.Label();
            this.txtMaBH = new System.Windows.Forms.TextBox();
            this.lblMaBH = new System.Windows.Forms.Label();
            this.btnDong = new System.Windows.Forms.Button();
            this.tabHopDongCheDo.SuspendLayout();
            this.tabHopDong.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHopDong)).BeginInit();
            this.grpThongTinHD.SuspendLayout();
            this.tabChucVu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvChucVu)).BeginInit();
            this.grpThongTinCV.SuspendLayout();
            this.tabLuong.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLuong)).BeginInit();
            this.grpThongTinLuong.SuspendLayout();
            this.tabBaoHiem.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBaoHiem)).BeginInit();
            this.grpThongTinBH.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblTieuDe
            // 
            this.lblTieuDe.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblTieuDe.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold);
            this.lblTieuDe.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.lblTieuDe.Location = new System.Drawing.Point(0, 0);
            this.lblTieuDe.Name = "lblTieuDe";
            this.lblTieuDe.Size = new System.Drawing.Size(1004, 50);
            this.lblTieuDe.TabIndex = 0;
            this.lblTieuDe.Text = "QUẢN LÝ HỢP ĐỒNG LAO ĐỘNG VÀ CHẾ ĐỘ NHÂN VIÊN";
            this.lblTieuDe.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tabHopDongCheDo
            // 
            this.tabHopDongCheDo.Controls.Add(this.tabHopDong);
            this.tabHopDongCheDo.Controls.Add(this.tabChucVu);
            this.tabHopDongCheDo.Controls.Add(this.tabLuong);
            this.tabHopDongCheDo.Controls.Add(this.tabBaoHiem);
            this.tabHopDongCheDo.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.tabHopDongCheDo.Location = new System.Drawing.Point(12, 55);
            this.tabHopDongCheDo.Name = "tabHopDongCheDo";
            this.tabHopDongCheDo.SelectedIndex = 0;
            this.tabHopDongCheDo.Size = new System.Drawing.Size(980, 580);
            this.tabHopDongCheDo.TabIndex = 1;
            // 
            // tabHopDong
            // 
            this.tabHopDong.Controls.Add(this.dgvHopDong);
            this.tabHopDong.Controls.Add(this.grpThongTinHD);
            this.tabHopDong.Location = new System.Drawing.Point(4, 32);
            this.tabHopDong.Name = "tabHopDong";
            this.tabHopDong.Padding = new System.Windows.Forms.Padding(3);
            this.tabHopDong.Size = new System.Drawing.Size(972, 544);
            this.tabHopDong.TabIndex = 0;
            this.tabHopDong.Text = "1. Hợp đồng lao động";
            this.tabHopDong.UseVisualStyleBackColor = true;
            // 
            // dgvHopDong
            // 
            this.dgvHopDong.AllowUserToAddRows = false;
            this.dgvHopDong.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvHopDong.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvHopDong.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.dgvHopDong.Location = new System.Drawing.Point(15, 235);
            this.dgvHopDong.Name = "dgvHopDong";
            this.dgvHopDong.ReadOnly = true;
            this.dgvHopDong.RowHeadersWidth = 35;
            this.dgvHopDong.RowTemplate.Height = 24;
            this.dgvHopDong.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvHopDong.Size = new System.Drawing.Size(940, 290);
            this.dgvHopDong.TabIndex = 1;
            this.dgvHopDong.SelectionChanged += new System.EventHandler(this.dgvHopDong_SelectionChanged);
            // 
            // grpThongTinHD
            // 
            this.grpThongTinHD.Controls.Add(this.btnLamMoiHD);
            this.grpThongTinHD.Controls.Add(this.btnXoaHD);
            this.grpThongTinHD.Controls.Add(this.btnSuaHD);
            this.grpThongTinHD.Controls.Add(this.btnLapHD);
            this.grpThongTinHD.Controls.Add(this.txtNoiDungHD);
            this.grpThongTinHD.Controls.Add(this.lblNoiDungHD);
            this.grpThongTinHD.Controls.Add(this.dtpNgayHetHan);
            this.grpThongTinHD.Controls.Add(this.lblNgayHetHan);
            this.grpThongTinHD.Controls.Add(this.dtpNgayHieuLuc);
            this.grpThongTinHD.Controls.Add(this.lblNgayHieuLuc);
            this.grpThongTinHD.Controls.Add(this.dtpNgayKyHD);
            this.grpThongTinHD.Controls.Add(this.lblNgayKyHD);
            this.grpThongTinHD.Controls.Add(this.cboLoaiHD);
            this.grpThongTinHD.Controls.Add(this.lblLoaiHD);
            this.grpThongTinHD.Controls.Add(this.cboNV_HD);
            this.grpThongTinHD.Controls.Add(this.lblNV_HD);
            this.grpThongTinHD.Controls.Add(this.txtMaHD);
            this.grpThongTinHD.Controls.Add(this.lblMaHD);
            this.grpThongTinHD.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.grpThongTinHD.Location = new System.Drawing.Point(15, 10);
            this.grpThongTinHD.Name = "grpThongTinHD";
            this.grpThongTinHD.Size = new System.Drawing.Size(940, 215);
            this.grpThongTinHD.TabIndex = 0;
            this.grpThongTinHD.TabStop = false;
            this.grpThongTinHD.Text = "Thông tin Hợp đồng lao động";
            // 
            // btnLamMoiHD
            // 
            this.btnLamMoiHD.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnLamMoiHD.Location = new System.Drawing.Point(600, 165);
            this.btnLamMoiHD.Name = "btnLamMoiHD";
            this.btnLamMoiHD.Size = new System.Drawing.Size(110, 35);
            this.btnLamMoiHD.TabIndex = 17;
            this.btnLamMoiHD.Text = "Làm mới";
            this.btnLamMoiHD.UseVisualStyleBackColor = true;
            this.btnLamMoiHD.Click += new System.EventHandler(this.btnLamMoiHD_Click);
            // 
            // btnXoaHD
            // 
            this.btnXoaHD.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnXoaHD.ForeColor = System.Drawing.Color.DarkRed;
            this.btnXoaHD.Location = new System.Drawing.Point(475, 165);
            this.btnXoaHD.Name = "btnXoaHD";
            this.btnXoaHD.Size = new System.Drawing.Size(110, 35);
            this.btnXoaHD.TabIndex = 16;
            this.btnXoaHD.Text = "Xóa HĐ";
            this.btnXoaHD.UseVisualStyleBackColor = true;
            this.btnXoaHD.Click += new System.EventHandler(this.btnXoaHD_Click);
            // 
            // btnSuaHD
            // 
            this.btnSuaHD.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnSuaHD.Location = new System.Drawing.Point(345, 165);
            this.btnSuaHD.Name = "btnSuaHD";
            this.btnSuaHD.Size = new System.Drawing.Size(115, 35);
            this.btnSuaHD.TabIndex = 15;
            this.btnSuaHD.Text = "Cập nhật";
            this.btnSuaHD.UseVisualStyleBackColor = true;
            this.btnSuaHD.Click += new System.EventHandler(this.btnSuaHD_Click);
            // 
            // btnLapHD
            // 
            this.btnLapHD.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.btnLapHD.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.btnLapHD.Location = new System.Drawing.Point(175, 165);
            this.btnLapHD.Name = "btnLapHD";
            this.btnLapHD.Size = new System.Drawing.Size(155, 35);
            this.btnLapHD.TabIndex = 14;
            this.btnLapHD.Text = "+ Ký hợp đồng";
            this.btnLapHD.UseVisualStyleBackColor = true;
            this.btnLapHD.Click += new System.EventHandler(this.btnLapHD_Click);
            // 
            // txtNoiDungHD
            // 
            this.txtNoiDungHD.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtNoiDungHD.Location = new System.Drawing.Point(120, 115);
            this.txtNoiDungHD.Name = "txtNoiDungHD";
            this.txtNoiDungHD.Size = new System.Drawing.Size(800, 29);
            this.txtNoiDungHD.TabIndex = 13;
            // 
            // lblNoiDungHD
            // 
            this.lblNoiDungHD.AutoSize = true;
            this.lblNoiDungHD.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblNoiDungHD.Location = new System.Drawing.Point(15, 120);
            this.lblNoiDungHD.Name = "lblNoiDungHD";
            this.lblNoiDungHD.Size = new System.Drawing.Size(78, 21);
            this.lblNoiDungHD.TabIndex = 12;
            this.lblNoiDungHD.Text = "Nội dung:";
            // 
            // dtpNgayHetHan
            // 
            this.dtpNgayHetHan.CustomFormat = "dd/MM/yyyy";
            this.dtpNgayHetHan.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.dtpNgayHetHan.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpNgayHetHan.Location = new System.Drawing.Point(740, 70);
            this.dtpNgayHetHan.Name = "dtpNgayHetHan";
            this.dtpNgayHetHan.Size = new System.Drawing.Size(180, 29);
            this.dtpNgayHetHan.TabIndex = 11;
            // 
            // lblNgayHetHan
            // 
            this.lblNgayHetHan.AutoSize = true;
            this.lblNgayHetHan.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblNgayHetHan.Location = new System.Drawing.Point(640, 75);
            this.lblNgayHetHan.Name = "lblNgayHetHan";
            this.lblNgayHetHan.Size = new System.Drawing.Size(71, 21);
            this.lblNgayHetHan.TabIndex = 10;
            this.lblNgayHetHan.Text = "Hết hạn:";
            // 
            // dtpNgayHieuLuc
            // 
            this.dtpNgayHieuLuc.CustomFormat = "dd/MM/yyyy";
            this.dtpNgayHieuLuc.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.dtpNgayHieuLuc.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpNgayHieuLuc.Location = new System.Drawing.Point(420, 70);
            this.dtpNgayHieuLuc.Name = "dtpNgayHieuLuc";
            this.dtpNgayHieuLuc.Size = new System.Drawing.Size(200, 29);
            this.dtpNgayHieuLuc.TabIndex = 9;
            // 
            // lblNgayHieuLuc
            // 
            this.lblNgayHieuLuc.AutoSize = true;
            this.lblNgayHieuLuc.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblNgayHieuLuc.Location = new System.Drawing.Point(320, 75);
            this.lblNgayHieuLuc.Name = "lblNgayHieuLuc";
            this.lblNgayHieuLuc.Size = new System.Drawing.Size(74, 21);
            this.lblNgayHieuLuc.TabIndex = 8;
            this.lblNgayHieuLuc.Text = "Hiệu lực:";
            // 
            // dtpNgayKyHD
            // 
            this.dtpNgayKyHD.CustomFormat = "dd/MM/yyyy";
            this.dtpNgayKyHD.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.dtpNgayKyHD.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpNgayKyHD.Location = new System.Drawing.Point(120, 70);
            this.dtpNgayKyHD.Name = "dtpNgayKyHD";
            this.dtpNgayKyHD.Size = new System.Drawing.Size(180, 29);
            this.dtpNgayKyHD.TabIndex = 7;
            // 
            // lblNgayKyHD
            // 
            this.lblNgayKyHD.AutoSize = true;
            this.lblNgayKyHD.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblNgayKyHD.Location = new System.Drawing.Point(15, 75);
            this.lblNgayKyHD.Name = "lblNgayKyHD";
            this.lblNgayKyHD.Size = new System.Drawing.Size(70, 21);
            this.lblNgayKyHD.TabIndex = 6;
            this.lblNgayKyHD.Text = "Ngày ký:";
            // 
            // cboLoaiHD
            // 
            this.cboLoaiHD.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboLoaiHD.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.cboLoaiHD.FormattingEnabled = true;
            this.cboLoaiHD.Items.AddRange(new object[] {
            "Dài hạn",
            "Ngắn hạn"});
            this.cboLoaiHD.Location = new System.Drawing.Point(740, 25);
            this.cboLoaiHD.Name = "cboLoaiHD";
            this.cboLoaiHD.Size = new System.Drawing.Size(180, 29);
            this.cboLoaiHD.TabIndex = 5;
            // 
            // lblLoaiHD
            // 
            this.lblLoaiHD.AutoSize = true;
            this.lblLoaiHD.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblLoaiHD.Location = new System.Drawing.Point(640, 30);
            this.lblLoaiHD.Name = "lblLoaiHD";
            this.lblLoaiHD.Size = new System.Drawing.Size(69, 21);
            this.lblLoaiHD.TabIndex = 4;
            this.lblLoaiHD.Text = "Loại HĐ:";
            // 
            // cboNV_HD
            // 
            this.cboNV_HD.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboNV_HD.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.cboNV_HD.FormattingEnabled = true;
            this.cboNV_HD.Location = new System.Drawing.Point(420, 25);
            this.cboNV_HD.Name = "cboNV_HD";
            this.cboNV_HD.Size = new System.Drawing.Size(200, 29);
            this.cboNV_HD.TabIndex = 3;
            // 
            // lblNV_HD
            // 
            this.lblNV_HD.AutoSize = true;
            this.lblNV_HD.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblNV_HD.Location = new System.Drawing.Point(320, 30);
            this.lblNV_HD.Name = "lblNV_HD";
            this.lblNV_HD.Size = new System.Drawing.Size(84, 21);
            this.lblNV_HD.TabIndex = 2;
            this.lblNV_HD.Text = "Nhân viên:";
            // 
            // txtMaHD
            // 
            this.txtMaHD.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtMaHD.Location = new System.Drawing.Point(120, 25);
            this.txtMaHD.Name = "txtMaHD";
            this.txtMaHD.Size = new System.Drawing.Size(180, 29);
            this.txtMaHD.TabIndex = 1;
            // 
            // lblMaHD
            // 
            this.lblMaHD.AutoSize = true;
            this.lblMaHD.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblMaHD.Location = new System.Drawing.Point(15, 30);
            this.lblMaHD.Name = "lblMaHD";
            this.lblMaHD.Size = new System.Drawing.Size(62, 21);
            this.lblMaHD.TabIndex = 0;
            this.lblMaHD.Text = "Mã HĐ:";
            // 
            // tabChucVu
            // 
            this.tabChucVu.Controls.Add(this.dgvChucVu);
            this.tabChucVu.Controls.Add(this.grpThongTinCV);
            this.tabChucVu.Location = new System.Drawing.Point(4, 32);
            this.tabChucVu.Name = "tabChucVu";
            this.tabChucVu.Padding = new System.Windows.Forms.Padding(3);
            this.tabChucVu.Size = new System.Drawing.Size(972, 544);
            this.tabChucVu.TabIndex = 1;
            this.tabChucVu.Text = "2. Quyết định chức vụ";
            this.tabChucVu.UseVisualStyleBackColor = true;
            // 
            // dgvChucVu
            // 
            this.dgvChucVu.AllowUserToAddRows = false;
            this.dgvChucVu.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvChucVu.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvChucVu.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.dgvChucVu.Location = new System.Drawing.Point(15, 230);
            this.dgvChucVu.Name = "dgvChucVu";
            this.dgvChucVu.ReadOnly = true;
            this.dgvChucVu.RowHeadersWidth = 35;
            this.dgvChucVu.RowTemplate.Height = 24;
            this.dgvChucVu.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvChucVu.Size = new System.Drawing.Size(940, 295);
            this.dgvChucVu.TabIndex = 1;
            this.dgvChucVu.SelectionChanged += new System.EventHandler(this.dgvChucVu_SelectionChanged);
            // 
            // grpThongTinCV
            // 
            this.grpThongTinCV.Controls.Add(this.btnLamMoiCV);
            this.grpThongTinCV.Controls.Add(this.btnXoaCV);
            this.grpThongTinCV.Controls.Add(this.btnSuaCV);
            this.grpThongTinCV.Controls.Add(this.btnLapQDCV);
            this.grpThongTinCV.Controls.Add(this.txtLyDoCV);
            this.grpThongTinCV.Controls.Add(this.lblLyDoCV);
            this.grpThongTinCV.Controls.Add(this.dtpNgayHLCV);
            this.grpThongTinCV.Controls.Add(this.lblNgayHLCV);
            this.grpThongTinCV.Controls.Add(this.txtPhuCapCV);
            this.grpThongTinCV.Controls.Add(this.lblPhuCapCV);
            this.grpThongTinCV.Controls.Add(this.txtChucVu);
            this.grpThongTinCV.Controls.Add(this.lblChucVu);
            this.grpThongTinCV.Controls.Add(this.cboNV_CV);
            this.grpThongTinCV.Controls.Add(this.lblNV_CV);
            this.grpThongTinCV.Controls.Add(this.txtMaQDCV);
            this.grpThongTinCV.Controls.Add(this.lblMaQDCV);
            this.grpThongTinCV.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.grpThongTinCV.Location = new System.Drawing.Point(15, 10);
            this.grpThongTinCV.Name = "grpThongTinCV";
            this.grpThongTinCV.Size = new System.Drawing.Size(940, 205);
            this.grpThongTinCV.TabIndex = 0;
            this.grpThongTinCV.TabStop = false;
            this.grpThongTinCV.Text = "Chi tiết Bổ nhiệm / Miễn nhiệm Chức vụ";
            // 
            // btnLamMoiCV
            // 
            this.btnLamMoiCV.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnLamMoiCV.Location = new System.Drawing.Point(620, 155);
            this.btnLamMoiCV.Name = "btnLamMoiCV";
            this.btnLamMoiCV.Size = new System.Drawing.Size(110, 35);
            this.btnLamMoiCV.TabIndex = 15;
            this.btnLamMoiCV.Text = "Làm mới";
            this.btnLamMoiCV.UseVisualStyleBackColor = true;
            this.btnLamMoiCV.Click += new System.EventHandler(this.btnLamMoiCV_Click);
            // 
            // btnXoaCV
            // 
            this.btnXoaCV.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnXoaCV.ForeColor = System.Drawing.Color.DarkRed;
            this.btnXoaCV.Location = new System.Drawing.Point(490, 155);
            this.btnXoaCV.Name = "btnXoaCV";
            this.btnXoaCV.Size = new System.Drawing.Size(110, 35);
            this.btnXoaCV.TabIndex = 14;
            this.btnXoaCV.Text = "Xóa";
            this.btnXoaCV.UseVisualStyleBackColor = true;
            this.btnXoaCV.Click += new System.EventHandler(this.btnXoaCV_Click);
            // 
            // btnSuaCV
            // 
            this.btnSuaCV.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnSuaCV.Location = new System.Drawing.Point(360, 155);
            this.btnSuaCV.Name = "btnSuaCV";
            this.btnSuaCV.Size = new System.Drawing.Size(110, 35);
            this.btnSuaCV.TabIndex = 13;
            this.btnSuaCV.Text = "Cập nhật";
            this.btnSuaCV.UseVisualStyleBackColor = true;
            this.btnSuaCV.Click += new System.EventHandler(this.btnSuaCV_Click);
            // 
            // btnLapQDCV
            // 
            this.btnLapQDCV.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.btnLapQDCV.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.btnLapQDCV.Location = new System.Drawing.Point(210, 155);
            this.btnLapQDCV.Name = "btnLapQDCV";
            this.btnLapQDCV.Size = new System.Drawing.Size(130, 35);
            this.btnLapQDCV.TabIndex = 12;
            this.btnLapQDCV.Text = "+ Lập QĐ";
            this.btnLapQDCV.UseVisualStyleBackColor = true;
            this.btnLapQDCV.Click += new System.EventHandler(this.btnLapQDCV_Click);
            // 
            // txtLyDoCV
            // 
            this.txtLyDoCV.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtLyDoCV.Location = new System.Drawing.Point(740, 70);
            this.txtLyDoCV.Name = "txtLyDoCV";
            this.txtLyDoCV.Size = new System.Drawing.Size(180, 29);
            this.txtLyDoCV.TabIndex = 11;
            // 
            // lblLyDoCV
            // 
            this.lblLyDoCV.AutoSize = true;
            this.lblLyDoCV.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblLyDoCV.Location = new System.Drawing.Point(640, 75);
            this.lblLyDoCV.Name = "lblLyDoCV";
            this.lblLyDoCV.Size = new System.Drawing.Size(51, 21);
            this.lblLyDoCV.TabIndex = 10;
            this.lblLyDoCV.Text = "Lý do:";
            // 
            // dtpNgayHLCV
            // 
            this.dtpNgayHLCV.CustomFormat = "dd/MM/yyyy";
            this.dtpNgayHLCV.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.dtpNgayHLCV.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpNgayHLCV.Location = new System.Drawing.Point(420, 70);
            this.dtpNgayHLCV.Name = "dtpNgayHLCV";
            this.dtpNgayHLCV.Size = new System.Drawing.Size(200, 29);
            this.dtpNgayHLCV.TabIndex = 9;
            // 
            // lblNgayHLCV
            // 
            this.lblNgayHLCV.AutoSize = true;
            this.lblNgayHLCV.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblNgayHLCV.Location = new System.Drawing.Point(320, 75);
            this.lblNgayHLCV.Name = "lblNgayHLCV";
            this.lblNgayHLCV.Size = new System.Drawing.Size(74, 21);
            this.lblNgayHLCV.TabIndex = 8;
            this.lblNgayHLCV.Text = "Hiệu lực:";
            // 
            // txtPhuCapCV
            // 
            this.txtPhuCapCV.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtPhuCapCV.Location = new System.Drawing.Point(120, 70);
            this.txtPhuCapCV.Name = "txtPhuCapCV";
            this.txtPhuCapCV.Size = new System.Drawing.Size(180, 29);
            this.txtPhuCapCV.TabIndex = 7;
            this.txtPhuCapCV.Text = "0";
            // 
            // lblPhuCapCV
            // 
            this.lblPhuCapCV.AutoSize = true;
            this.lblPhuCapCV.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblPhuCapCV.Location = new System.Drawing.Point(15, 75);
            this.lblPhuCapCV.Name = "lblPhuCapCV";
            this.lblPhuCapCV.Size = new System.Drawing.Size(89, 21);
            this.lblPhuCapCV.TabIndex = 6;
            this.lblPhuCapCV.Text = "Phụ cấp CV:";
            // 
            // txtChucVu
            // 
            this.txtChucVu.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtChucVu.Location = new System.Drawing.Point(740, 25);
            this.txtChucVu.Name = "txtChucVu";
            this.txtChucVu.Size = new System.Drawing.Size(180, 29);
            this.txtChucVu.TabIndex = 5;
            // 
            // lblChucVu
            // 
            this.lblChucVu.AutoSize = true;
            this.lblChucVu.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblChucVu.Location = new System.Drawing.Point(640, 30);
            this.lblChucVu.Name = "lblChucVu";
            this.lblChucVu.Size = new System.Drawing.Size(69, 21);
            this.lblChucVu.TabIndex = 4;
            this.lblChucVu.Text = "Chức vụ:";
            // 
            // cboNV_CV
            // 
            this.cboNV_CV.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboNV_CV.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.cboNV_CV.FormattingEnabled = true;
            this.cboNV_CV.Location = new System.Drawing.Point(420, 25);
            this.cboNV_CV.Name = "cboNV_CV";
            this.cboNV_CV.Size = new System.Drawing.Size(200, 29);
            this.cboNV_CV.TabIndex = 3;
            // 
            // lblNV_CV
            // 
            this.lblNV_CV.AutoSize = true;
            this.lblNV_CV.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblNV_CV.Location = new System.Drawing.Point(320, 30);
            this.lblNV_CV.Name = "lblNV_CV";
            this.lblNV_CV.Size = new System.Drawing.Size(84, 21);
            this.lblNV_CV.TabIndex = 2;
            this.lblNV_CV.Text = "Nhân viên:";
            // 
            // txtMaQDCV
            // 
            this.txtMaQDCV.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtMaQDCV.Location = new System.Drawing.Point(120, 25);
            this.txtMaQDCV.Name = "txtMaQDCV";
            this.txtMaQDCV.Size = new System.Drawing.Size(180, 29);
            this.txtMaQDCV.TabIndex = 1;
            // 
            // lblMaQDCV
            // 
            this.lblMaQDCV.AutoSize = true;
            this.lblMaQDCV.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblMaQDCV.Location = new System.Drawing.Point(15, 30);
            this.lblMaQDCV.Name = "lblMaQDCV";
            this.lblMaQDCV.Size = new System.Drawing.Size(81, 21);
            this.lblMaQDCV.TabIndex = 0;
            this.lblMaQDCV.Text = "Mã QĐCV:";
            // 
            // tabLuong
            // 
            this.tabLuong.Controls.Add(this.dgvLuong);
            this.tabLuong.Controls.Add(this.grpThongTinLuong);
            this.tabLuong.Location = new System.Drawing.Point(4, 32);
            this.tabLuong.Name = "tabLuong";
            this.tabLuong.Padding = new System.Windows.Forms.Padding(3);
            this.tabLuong.Size = new System.Drawing.Size(972, 544);
            this.tabLuong.TabIndex = 2;
            this.tabLuong.Text = "3. Quyết định lương";
            this.tabLuong.UseVisualStyleBackColor = true;
            // 
            // dgvLuong
            // 
            this.dgvLuong.AllowUserToAddRows = false;
            this.dgvLuong.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvLuong.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvLuong.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.dgvLuong.Location = new System.Drawing.Point(15, 230);
            this.dgvLuong.Name = "dgvLuong";
            this.dgvLuong.ReadOnly = true;
            this.dgvLuong.RowHeadersWidth = 35;
            this.dgvLuong.RowTemplate.Height = 24;
            this.dgvLuong.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvLuong.Size = new System.Drawing.Size(940, 295);
            this.dgvLuong.TabIndex = 1;
            this.dgvLuong.SelectionChanged += new System.EventHandler(this.dgvLuong_SelectionChanged);
            // 
            // grpThongTinLuong
            // 
            this.grpThongTinLuong.Controls.Add(this.btnLamMoiLuong);
            this.grpThongTinLuong.Controls.Add(this.btnXoaLuong);
            this.grpThongTinLuong.Controls.Add(this.btnSuaLuong);
            this.grpThongTinLuong.Controls.Add(this.btnLapQDL);
            this.grpThongTinLuong.Controls.Add(this.dtpNgayHLLuong);
            this.grpThongTinLuong.Controls.Add(this.lblNgayHLLuong);
            this.grpThongTinLuong.Controls.Add(this.txtPhuCapDocHai);
            this.grpThongTinLuong.Controls.Add(this.lblPhuCapDocHai);
            this.grpThongTinLuong.Controls.Add(this.txtPhuCapLuong);
            this.grpThongTinLuong.Controls.Add(this.lblPhuCapLuong);
            this.grpThongTinLuong.Controls.Add(this.txtLuongCoBan);
            this.grpThongTinLuong.Controls.Add(this.lblLuongCoBan);
            this.grpThongTinLuong.Controls.Add(this.cboNV_Luong);
            this.grpThongTinLuong.Controls.Add(this.lblNV_Luong);
            this.grpThongTinLuong.Controls.Add(this.txtMaQDL);
            this.grpThongTinLuong.Controls.Add(this.lblMaQDL);
            this.grpThongTinLuong.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.grpThongTinLuong.Location = new System.Drawing.Point(15, 10);
            this.grpThongTinLuong.Name = "grpThongTinLuong";
            this.grpThongTinLuong.Size = new System.Drawing.Size(940, 205);
            this.grpThongTinLuong.TabIndex = 0;
            this.grpThongTinLuong.TabStop = false;
            this.grpThongTinLuong.Text = "Chi tiết Quyết định Lương & Phụ cấp độc hại";
            // 
            // btnLamMoiLuong
            // 
            this.btnLamMoiLuong.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnLamMoiLuong.Location = new System.Drawing.Point(620, 155);
            this.btnLamMoiLuong.Name = "btnLamMoiLuong";
            this.btnLamMoiLuong.Size = new System.Drawing.Size(110, 35);
            this.btnLamMoiLuong.TabIndex = 15;
            this.btnLamMoiLuong.Text = "Làm mới";
            this.btnLamMoiLuong.UseVisualStyleBackColor = true;
            this.btnLamMoiLuong.Click += new System.EventHandler(this.btnLamMoiLuong_Click);
            // 
            // btnXoaLuong
            // 
            this.btnXoaLuong.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnXoaLuong.ForeColor = System.Drawing.Color.DarkRed;
            this.btnXoaLuong.Location = new System.Drawing.Point(490, 155);
            this.btnXoaLuong.Name = "btnXoaLuong";
            this.btnXoaLuong.Size = new System.Drawing.Size(110, 35);
            this.btnXoaLuong.TabIndex = 14;
            this.btnXoaLuong.Text = "Xóa";
            this.btnXoaLuong.UseVisualStyleBackColor = true;
            this.btnXoaLuong.Click += new System.EventHandler(this.btnXoaLuong_Click);
            // 
            // btnSuaLuong
            // 
            this.btnSuaLuong.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnSuaLuong.Location = new System.Drawing.Point(360, 155);
            this.btnSuaLuong.Name = "btnSuaLuong";
            this.btnSuaLuong.Size = new System.Drawing.Size(110, 35);
            this.btnSuaLuong.TabIndex = 13;
            this.btnSuaLuong.Text = "Cập nhật";
            this.btnSuaLuong.UseVisualStyleBackColor = true;
            this.btnSuaLuong.Click += new System.EventHandler(this.btnSuaLuong_Click);
            // 
            // btnLapQDL
            // 
            this.btnLapQDL.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.btnLapQDL.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.btnLapQDL.Location = new System.Drawing.Point(210, 155);
            this.btnLapQDL.Name = "btnLapQDL";
            this.btnLapQDL.Size = new System.Drawing.Size(130, 35);
            this.btnLapQDL.TabIndex = 12;
            this.btnLapQDL.Text = "+ Lập QĐ";
            this.btnLapQDL.UseVisualStyleBackColor = true;
            this.btnLapQDL.Click += new System.EventHandler(this.btnLapQDL_Click);
            // 
            // dtpNgayHLLuong
            // 
            this.dtpNgayHLLuong.CustomFormat = "dd/MM/yyyy";
            this.dtpNgayHLLuong.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.dtpNgayHLLuong.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpNgayHLLuong.Location = new System.Drawing.Point(740, 70);
            this.dtpNgayHLLuong.Name = "dtpNgayHLLuong";
            this.dtpNgayHLLuong.Size = new System.Drawing.Size(180, 29);
            this.dtpNgayHLLuong.TabIndex = 11;
            // 
            // lblNgayHLLuong
            // 
            this.lblNgayHLLuong.AutoSize = true;
            this.lblNgayHLLuong.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblNgayHLLuong.Location = new System.Drawing.Point(640, 75);
            this.lblNgayHLLuong.Name = "lblNgayHLLuong";
            this.lblNgayHLLuong.Size = new System.Drawing.Size(74, 21);
            this.lblNgayHLLuong.TabIndex = 10;
            this.lblNgayHLLuong.Text = "Hiệu lực:";
            // 
            // txtPhuCapDocHai
            // 
            this.txtPhuCapDocHai.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtPhuCapDocHai.Location = new System.Drawing.Point(420, 70);
            this.txtPhuCapDocHai.Name = "txtPhuCapDocHai";
            this.txtPhuCapDocHai.Size = new System.Drawing.Size(200, 29);
            this.txtPhuCapDocHai.TabIndex = 9;
            this.txtPhuCapDocHai.Text = "0";
            // 
            // lblPhuCapDocHai
            // 
            this.lblPhuCapDocHai.AutoSize = true;
            this.lblPhuCapDocHai.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblPhuCapDocHai.Location = new System.Drawing.Point(320, 75);
            this.lblPhuCapDocHai.Name = "lblPhuCapDocHai";
            this.lblPhuCapDocHai.Size = new System.Drawing.Size(95, 21);
            this.lblPhuCapDocHai.TabIndex = 8;
            this.lblPhuCapDocHai.Text = "PC độc hại:";
            // 
            // txtPhuCapLuong
            // 
            this.txtPhuCapLuong.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtPhuCapLuong.Location = new System.Drawing.Point(120, 70);
            this.txtPhuCapLuong.Name = "txtPhuCapLuong";
            this.txtPhuCapLuong.Size = new System.Drawing.Size(180, 29);
            this.txtPhuCapLuong.TabIndex = 7;
            this.txtPhuCapLuong.Text = "0";
            // 
            // lblPhuCapLuong
            // 
            this.lblPhuCapLuong.AutoSize = true;
            this.lblPhuCapLuong.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblPhuCapLuong.Location = new System.Drawing.Point(15, 75);
            this.lblPhuCapLuong.Name = "lblPhuCapLuong";
            this.lblPhuCapLuong.Size = new System.Drawing.Size(81, 21);
            this.lblPhuCapLuong.TabIndex = 6;
            this.lblPhuCapLuong.Text = "Phụ cấp L:";
            // 
            // txtLuongCoBan
            // 
            this.txtLuongCoBan.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtLuongCoBan.Location = new System.Drawing.Point(740, 25);
            this.txtLuongCoBan.Name = "txtLuongCoBan";
            this.txtLuongCoBan.Size = new System.Drawing.Size(180, 29);
            this.txtLuongCoBan.TabIndex = 5;
            this.txtLuongCoBan.Text = "6000000";
            // 
            // lblLuongCoBan
            // 
            this.lblLuongCoBan.AutoSize = true;
            this.lblLuongCoBan.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblLuongCoBan.Location = new System.Drawing.Point(640, 30);
            this.lblLuongCoBan.Name = "lblLuongCoBan";
            this.lblLuongCoBan.Size = new System.Drawing.Size(78, 21);
            this.lblLuongCoBan.TabIndex = 4;
            this.lblLuongCoBan.Text = "Lương CB:";
            // 
            // cboNV_Luong
            // 
            this.cboNV_Luong.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboNV_Luong.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.cboNV_Luong.FormattingEnabled = true;
            this.cboNV_Luong.Location = new System.Drawing.Point(420, 25);
            this.cboNV_Luong.Name = "cboNV_Luong";
            this.cboNV_Luong.Size = new System.Drawing.Size(200, 29);
            this.cboNV_Luong.TabIndex = 3;
            // 
            // lblNV_Luong
            // 
            this.lblNV_Luong.AutoSize = true;
            this.lblNV_Luong.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblNV_Luong.Location = new System.Drawing.Point(320, 30);
            this.lblNV_Luong.Name = "lblNV_Luong";
            this.lblNV_Luong.Size = new System.Drawing.Size(84, 21);
            this.lblNV_Luong.TabIndex = 2;
            this.lblNV_Luong.Text = "Nhân viên:";
            // 
            // txtMaQDL
            // 
            this.txtMaQDL.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtMaQDL.Location = new System.Drawing.Point(120, 25);
            this.txtMaQDL.Name = "txtMaQDL";
            this.txtMaQDL.Size = new System.Drawing.Size(180, 29);
            this.txtMaQDL.TabIndex = 1;
            // 
            // lblMaQDL
            // 
            this.lblMaQDL.AutoSize = true;
            this.lblMaQDL.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblMaQDL.Location = new System.Drawing.Point(15, 30);
            this.lblMaQDL.Name = "lblMaQDL";
            this.lblMaQDL.Size = new System.Drawing.Size(70, 21);
            this.lblMaQDL.TabIndex = 0;
            this.lblMaQDL.Text = "Mã QĐL:";
            // 
            // tabBaoHiem
            // 
            this.tabBaoHiem.Controls.Add(this.dgvBaoHiem);
            this.tabBaoHiem.Controls.Add(this.grpThongTinBH);
            this.tabBaoHiem.Location = new System.Drawing.Point(4, 32);
            this.tabBaoHiem.Name = "tabBaoHiem";
            this.tabBaoHiem.Padding = new System.Windows.Forms.Padding(3);
            this.tabBaoHiem.Size = new System.Drawing.Size(972, 544);
            this.tabBaoHiem.TabIndex = 3;
            this.tabBaoHiem.Text = "4. Hồ sơ bảo hiểm (BHYT, BHXH)";
            this.tabBaoHiem.UseVisualStyleBackColor = true;
            // 
            // dgvBaoHiem
            // 
            this.dgvBaoHiem.AllowUserToAddRows = false;
            this.dgvBaoHiem.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvBaoHiem.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvBaoHiem.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.dgvBaoHiem.Location = new System.Drawing.Point(15, 230);
            this.dgvBaoHiem.Name = "dgvBaoHiem";
            this.dgvBaoHiem.ReadOnly = true;
            this.dgvBaoHiem.RowHeadersWidth = 35;
            this.dgvBaoHiem.RowTemplate.Height = 24;
            this.dgvBaoHiem.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvBaoHiem.Size = new System.Drawing.Size(940, 295);
            this.dgvBaoHiem.TabIndex = 1;
            this.dgvBaoHiem.SelectionChanged += new System.EventHandler(this.dgvBaoHiem_SelectionChanged);
            // 
            // grpThongTinBH
            // 
            this.grpThongTinBH.Controls.Add(this.btnLamMoiBH);
            this.grpThongTinBH.Controls.Add(this.btnXoaBH);
            this.grpThongTinBH.Controls.Add(this.btnSuaBH);
            this.grpThongTinBH.Controls.Add(this.btnLapBH);
            this.grpThongTinBH.Controls.Add(this.txtTyLeCT);
            this.grpThongTinBH.Controls.Add(this.lblTyLeCT);
            this.grpThongTinBH.Controls.Add(this.txtTyLeNV);
            this.grpThongTinBH.Controls.Add(this.lblTyLeNV);
            this.grpThongTinBH.Controls.Add(this.dtpNgayThamGia);
            this.grpThongTinBH.Controls.Add(this.lblNgayThamGia);
            this.grpThongTinBH.Controls.Add(this.txtSoSoBHXH);
            this.grpThongTinBH.Controls.Add(this.lblSoSoBHXH);
            this.grpThongTinBH.Controls.Add(this.txtSoTheBHYT);
            this.grpThongTinBH.Controls.Add(this.lblSoTheBHYT);
            this.grpThongTinBH.Controls.Add(this.cboNV_BH);
            this.grpThongTinBH.Controls.Add(this.lblNV_BH);
            this.grpThongTinBH.Controls.Add(this.txtMaBH);
            this.grpThongTinBH.Controls.Add(this.lblMaBH);
            this.grpThongTinBH.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.grpThongTinBH.Location = new System.Drawing.Point(15, 10);
            this.grpThongTinBH.Name = "grpThongTinBH";
            this.grpThongTinBH.Size = new System.Drawing.Size(940, 205);
            this.grpThongTinBH.TabIndex = 0;
            this.grpThongTinBH.TabStop = false;
            this.grpThongTinBH.Text = "Hồ sơ trích đóng Bảo hiểm y tế & Bảo hiểm xã hội";
            // 
            // btnLamMoiBH
            // 
            this.btnLamMoiBH.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnLamMoiBH.Location = new System.Drawing.Point(620, 155);
            this.btnLamMoiBH.Name = "btnLamMoiBH";
            this.btnLamMoiBH.Size = new System.Drawing.Size(110, 35);
            this.btnLamMoiBH.TabIndex = 17;
            this.btnLamMoiBH.Text = "Làm mới";
            this.btnLamMoiBH.UseVisualStyleBackColor = true;
            this.btnLamMoiBH.Click += new System.EventHandler(this.btnLamMoiBH_Click);
            // 
            // btnXoaBH
            // 
            this.btnXoaBH.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnXoaBH.ForeColor = System.Drawing.Color.DarkRed;
            this.btnXoaBH.Location = new System.Drawing.Point(490, 155);
            this.btnXoaBH.Name = "btnXoaBH";
            this.btnXoaBH.Size = new System.Drawing.Size(110, 35);
            this.btnXoaBH.TabIndex = 16;
            this.btnXoaBH.Text = "Xóa";
            this.btnXoaBH.UseVisualStyleBackColor = true;
            this.btnXoaBH.Click += new System.EventHandler(this.btnXoaBH_Click);
            // 
            // btnSuaBH
            // 
            this.btnSuaBH.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnSuaBH.Location = new System.Drawing.Point(360, 155);
            this.btnSuaBH.Name = "btnSuaBH";
            this.btnSuaBH.Size = new System.Drawing.Size(110, 35);
            this.btnSuaBH.TabIndex = 15;
            this.btnSuaBH.Text = "Cập nhật";
            this.btnSuaBH.UseVisualStyleBackColor = true;
            this.btnSuaBH.Click += new System.EventHandler(this.btnSuaBH_Click);
            // 
            // btnLapBH
            // 
            this.btnLapBH.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.btnLapBH.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.btnLapBH.Location = new System.Drawing.Point(210, 155);
            this.btnLapBH.Name = "btnLapBH";
            this.btnLapBH.Size = new System.Drawing.Size(130, 35);
            this.btnLapBH.TabIndex = 14;
            this.btnLapBH.Text = "+ Lập hồ sơ";
            this.btnLapBH.UseVisualStyleBackColor = true;
            this.btnLapBH.Click += new System.EventHandler(this.btnLapBH_Click);
            // 
            // txtTyLeCT
            // 
            this.txtTyLeCT.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtTyLeCT.Location = new System.Drawing.Point(860, 70);
            this.txtTyLeCT.Name = "txtTyLeCT";
            this.txtTyLeCT.Size = new System.Drawing.Size(60, 29);
            this.txtTyLeCT.TabIndex = 13;
            this.txtTyLeCT.Text = "21.5";
            // 
            // lblTyLeCT
            // 
            this.lblTyLeCT.AutoSize = true;
            this.lblTyLeCT.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblTyLeCT.Location = new System.Drawing.Point(800, 75);
            this.lblTyLeCT.Name = "lblTyLeCT";
            this.lblTyLeCT.Size = new System.Drawing.Size(56, 21);
            this.lblTyLeCT.TabIndex = 12;
            this.lblTyLeCT.Text = "% Cty:";
            // 
            // txtTyLeNV
            // 
            this.txtTyLeNV.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtTyLeNV.Location = new System.Drawing.Point(735, 70);
            this.txtTyLeNV.Name = "txtTyLeNV";
            this.txtTyLeNV.Size = new System.Drawing.Size(55, 29);
            this.txtTyLeNV.TabIndex = 11;
            this.txtTyLeNV.Text = "10.5";
            // 
            // lblTyLeNV
            // 
            this.lblTyLeNV.AutoSize = true;
            this.lblTyLeNV.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblTyLeNV.Location = new System.Drawing.Point(675, 75);
            this.lblTyLeNV.Name = "lblTyLeNV";
            this.lblTyLeNV.Size = new System.Drawing.Size(53, 21);
            this.lblTyLeNV.TabIndex = 10;
            this.lblTyLeNV.Text = "% NV:";
            // 
            // dtpNgayThamGia
            // 
            this.dtpNgayThamGia.CustomFormat = "dd/MM/yyyy";
            this.dtpNgayThamGia.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.dtpNgayThamGia.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpNgayThamGia.Location = new System.Drawing.Point(740, 25);
            this.dtpNgayThamGia.Name = "dtpNgayThamGia";
            this.dtpNgayThamGia.Size = new System.Drawing.Size(180, 29);
            this.dtpNgayThamGia.TabIndex = 9;
            // 
            // lblNgayThamGia
            // 
            this.lblNgayThamGia.AutoSize = true;
            this.lblNgayThamGia.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblNgayThamGia.Location = new System.Drawing.Point(640, 30);
            this.lblNgayThamGia.Name = "lblNgayThamGia";
            this.lblNgayThamGia.Size = new System.Drawing.Size(84, 21);
            this.lblNgayThamGia.TabIndex = 8;
            this.lblNgayThamGia.Text = "Tham gia:";
            // 
            // txtSoSoBHXH
            // 
            this.txtSoSoBHXH.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtSoSoBHXH.Location = new System.Drawing.Point(420, 70);
            this.txtSoSoBHXH.Name = "txtSoSoBHXH";
            this.txtSoSoBHXH.Size = new System.Drawing.Size(200, 29);
            this.txtSoSoBHXH.TabIndex = 7;
            // 
            // lblSoSoBHXH
            // 
            this.lblSoSoBHXH.AutoSize = true;
            this.lblSoSoBHXH.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblSoSoBHXH.Location = new System.Drawing.Point(320, 75);
            this.lblSoSoBHXH.Name = "lblSoSoBHXH";
            this.lblSoSoBHXH.Size = new System.Drawing.Size(89, 21);
            this.lblSoSoBHXH.TabIndex = 6;
            this.lblSoSoBHXH.Text = "Sổ BHXH:";
            // 
            // txtSoTheBHYT
            // 
            this.txtSoTheBHYT.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtSoTheBHYT.Location = new System.Drawing.Point(120, 70);
            this.txtSoTheBHYT.Name = "txtSoTheBHYT";
            this.txtSoTheBHYT.Size = new System.Drawing.Size(180, 29);
            this.txtSoTheBHYT.TabIndex = 5;
            // 
            // lblSoTheBHYT
            // 
            this.lblSoTheBHYT.AutoSize = true;
            this.lblSoTheBHYT.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblSoTheBHYT.Location = new System.Drawing.Point(15, 75);
            this.lblSoTheBHYT.Name = "lblSoTheBHYT";
            this.lblSoTheBHYT.Size = new System.Drawing.Size(89, 21);
            this.lblSoTheBHYT.TabIndex = 4;
            this.lblSoTheBHYT.Text = "Thẻ BHYT:";
            // 
            // cboNV_BH
            // 
            this.cboNV_BH.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboNV_BH.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.cboNV_BH.FormattingEnabled = true;
            this.cboNV_BH.Location = new System.Drawing.Point(420, 25);
            this.cboNV_BH.Name = "cboNV_BH";
            this.cboNV_BH.Size = new System.Drawing.Size(200, 29);
            this.cboNV_BH.TabIndex = 3;
            // 
            // lblNV_BH
            // 
            this.lblNV_BH.AutoSize = true;
            this.lblNV_BH.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblNV_BH.Location = new System.Drawing.Point(320, 30);
            this.lblNV_BH.Name = "lblNV_BH";
            this.lblNV_BH.Size = new System.Drawing.Size(84, 21);
            this.lblNV_BH.TabIndex = 2;
            this.lblNV_BH.Text = "Nhân viên:";
            // 
            // txtMaBH
            // 
            this.txtMaBH.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtMaBH.Location = new System.Drawing.Point(120, 25);
            this.txtMaBH.Name = "txtMaBH";
            this.txtMaBH.Size = new System.Drawing.Size(180, 29);
            this.txtMaBH.TabIndex = 1;
            // 
            // lblMaBH
            // 
            this.lblMaBH.AutoSize = true;
            this.lblMaBH.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblMaBH.Location = new System.Drawing.Point(15, 30);
            this.lblMaBH.Name = "lblMaBH";
            this.lblMaBH.Size = new System.Drawing.Size(61, 21);
            this.lblMaBH.TabIndex = 0;
            this.lblMaBH.Text = "Mã BH:";
            // 
            // btnDong
            // 
            this.btnDong.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnDong.Location = new System.Drawing.Point(860, 642);
            this.btnDong.Name = "btnDong";
            this.btnDong.Size = new System.Drawing.Size(130, 40);
            this.btnDong.TabIndex = 2;
            this.btnDong.Text = "Đóng";
            this.btnDong.UseVisualStyleBackColor = true;
            this.btnDong.Click += new System.EventHandler(this.btnDong_Click);
            // 
            // FrmHopDong_CheDo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1004, 695);
            this.Controls.Add(this.btnDong);
            this.Controls.Add(this.tabHopDongCheDo);
            this.Controls.Add(this.lblTieuDe);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Quản lý Hợp đồng và Chế độ";
            this.Load += new System.EventHandler(this.FrmHopDong_CheDo_Load);
            this.tabHopDongCheDo.ResumeLayout(false);
            this.tabHopDong.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvHopDong)).EndInit();
            this.grpThongTinHD.ResumeLayout(false);
            this.grpThongTinHD.PerformLayout();
            this.tabChucVu.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvChucVu)).EndInit();
            this.grpThongTinCV.ResumeLayout(false);
            this.grpThongTinCV.PerformLayout();
            this.tabLuong.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvLuong)).EndInit();
            this.grpThongTinLuong.ResumeLayout(false);
            this.grpThongTinLuong.PerformLayout();
            this.tabBaoHiem.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvBaoHiem)).EndInit();
            this.grpThongTinBH.ResumeLayout(false);
            this.grpThongTinBH.PerformLayout();
            this.ResumeLayout(false);
        }

        private System.Windows.Forms.Label lblTieuDe;
        private System.Windows.Forms.TabControl tabHopDongCheDo;
        private System.Windows.Forms.TabPage tabHopDong;
        private System.Windows.Forms.TabPage tabChucVu;
        private System.Windows.Forms.TabPage tabLuong;
        private System.Windows.Forms.TabPage tabBaoHiem;
        private System.Windows.Forms.Button btnDong;
        private System.Windows.Forms.GroupBox grpThongTinHD;
        private System.Windows.Forms.TextBox txtMaHD;
        private System.Windows.Forms.Label lblMaHD;
        private System.Windows.Forms.ComboBox cboNV_HD;
        private System.Windows.Forms.Label lblNV_HD;
        private System.Windows.Forms.ComboBox cboLoaiHD;
        private System.Windows.Forms.Label lblLoaiHD;
        private System.Windows.Forms.DateTimePicker dtpNgayKyHD;
        private System.Windows.Forms.Label lblNgayKyHD;
        private System.Windows.Forms.DateTimePicker dtpNgayHieuLuc;
        private System.Windows.Forms.Label lblNgayHieuLuc;
        private System.Windows.Forms.DateTimePicker dtpNgayHetHan;
        private System.Windows.Forms.Label lblNgayHetHan;
        private System.Windows.Forms.TextBox txtNoiDungHD;
        private System.Windows.Forms.Label lblNoiDungHD;
        private System.Windows.Forms.Button btnLamMoiHD;
        private System.Windows.Forms.Button btnXoaHD;
        private System.Windows.Forms.Button btnSuaHD;
        private System.Windows.Forms.Button btnLapHD;
        private System.Windows.Forms.DataGridView dgvHopDong;
        private System.Windows.Forms.GroupBox grpThongTinCV;
        private System.Windows.Forms.TextBox txtMaQDCV;
        private System.Windows.Forms.Label lblMaQDCV;
        private System.Windows.Forms.ComboBox cboNV_CV;
        private System.Windows.Forms.Label lblNV_CV;
        private System.Windows.Forms.TextBox txtChucVu;
        private System.Windows.Forms.Label lblChucVu;
        private System.Windows.Forms.TextBox txtPhuCapCV;
        private System.Windows.Forms.Label lblPhuCapCV;
        private System.Windows.Forms.DateTimePicker dtpNgayHLCV;
        private System.Windows.Forms.Label lblNgayHLCV;
        private System.Windows.Forms.TextBox txtLyDoCV;
        private System.Windows.Forms.Label lblLyDoCV;
        private System.Windows.Forms.Button btnLamMoiCV;
        private System.Windows.Forms.Button btnXoaCV;
        private System.Windows.Forms.Button btnSuaCV;
        private System.Windows.Forms.Button btnLapQDCV;
        private System.Windows.Forms.DataGridView dgvChucVu;
        private System.Windows.Forms.GroupBox grpThongTinLuong;
        private System.Windows.Forms.TextBox txtMaQDL;
        private System.Windows.Forms.Label lblMaQDL;
        private System.Windows.Forms.ComboBox cboNV_Luong;
        private System.Windows.Forms.Label lblNV_Luong;
        private System.Windows.Forms.TextBox txtLuongCoBan;
        private System.Windows.Forms.Label lblLuongCoBan;
        private System.Windows.Forms.TextBox txtPhuCapLuong;
        private System.Windows.Forms.Label lblPhuCapLuong;
        private System.Windows.Forms.TextBox txtPhuCapDocHai;
        private System.Windows.Forms.Label lblPhuCapDocHai;
        private System.Windows.Forms.DateTimePicker dtpNgayHLLuong;
        private System.Windows.Forms.Label lblNgayHLLuong;
        private System.Windows.Forms.Button btnLamMoiLuong;
        private System.Windows.Forms.Button btnXoaLuong;
        private System.Windows.Forms.Button btnSuaLuong;
        private System.Windows.Forms.Button btnLapQDL;
        private System.Windows.Forms.DataGridView dgvLuong;
        private System.Windows.Forms.GroupBox grpThongTinBH;
        private System.Windows.Forms.TextBox txtMaBH;
        private System.Windows.Forms.Label lblMaBH;
        private System.Windows.Forms.ComboBox cboNV_BH;
        private System.Windows.Forms.Label lblNV_BH;
        private System.Windows.Forms.TextBox txtSoTheBHYT;
        private System.Windows.Forms.Label lblSoTheBHYT;
        private System.Windows.Forms.TextBox txtSoSoBHXH;
        private System.Windows.Forms.Label lblSoSoBHXH;
        private System.Windows.Forms.DateTimePicker dtpNgayThamGia;
        private System.Windows.Forms.Label lblNgayThamGia;
        private System.Windows.Forms.TextBox txtTyLeNV;
        private System.Windows.Forms.Label lblTyLeNV;
        private System.Windows.Forms.TextBox txtTyLeCT;
        private System.Windows.Forms.Label lblTyLeCT;
        private System.Windows.Forms.Button btnLamMoiBH;
        private System.Windows.Forms.Button btnXoaBH;
        private System.Windows.Forms.Button btnSuaBH;
        private System.Windows.Forms.Button btnLapBH;
        private System.Windows.Forms.DataGridView dgvBaoHiem;
    }
}