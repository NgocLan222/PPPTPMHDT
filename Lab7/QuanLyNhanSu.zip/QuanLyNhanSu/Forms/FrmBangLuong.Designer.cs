﻿namespace QuanLyNhanSu.Forms
{
    partial class FrmBangLuong
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblTieuDe = new System.Windows.Forms.Label();
            this.grpBoLoc = new System.Windows.Forms.GroupBox();
            this.btnDong = new System.Windows.Forms.Button();
            this.btnInPhieuLuong = new System.Windows.Forms.Button();
            this.btnLuuBangLuong = new System.Windows.Forms.Button();
            this.btnTinhLuong = new System.Windows.Forms.Button();
            this.btnXemBangLuong = new System.Windows.Forms.Button();
            this.cboNam = new System.Windows.Forms.ComboBox();
            this.lblNam = new System.Windows.Forms.Label();
            this.cboThang = new System.Windows.Forms.ComboBox();
            this.lblThang = new System.Windows.Forms.Label();
            this.grpChiTiet = new System.Windows.Forms.GroupBox();
            this.txtThucLinh = new System.Windows.Forms.TextBox();
            this.lblThucLinh = new System.Windows.Forms.Label();
            this.txtTrichBaoHiem = new System.Windows.Forms.TextBox();
            this.lblTrichBH = new System.Windows.Forms.Label();
            this.txtTienPhat = new System.Windows.Forms.TextBox();
            this.lblTienPhat = new System.Windows.Forms.Label();
            this.txtTienThuong = new System.Windows.Forms.TextBox();
            this.lblTienThuong = new System.Windows.Forms.Label();
            this.txtTienPhuCap = new System.Windows.Forms.TextBox();
            this.lblPhuCap = new System.Windows.Forms.Label();
            this.txtTienPhuTroi = new System.Windows.Forms.TextBox();
            this.lblPhuTroi = new System.Windows.Forms.Label();
            this.txtLuongChinh = new System.Windows.Forms.TextBox();
            this.lblLuongChinh = new System.Windows.Forms.Label();
            this.txtHoTenNV = new System.Windows.Forms.TextBox();
            this.lblHoTen = new System.Windows.Forms.Label();
            this.txtMaBL = new System.Windows.Forms.TextBox();
            this.lblMaBL = new System.Windows.Forms.Label();
            this.dgvBangLuong = new System.Windows.Forms.DataGridView();
            this.grpBoLoc.SuspendLayout();
            this.grpChiTiet.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBangLuong)).BeginInit();
            this.SuspendLayout();
            // 
            // lblTieuDe
            // 
            this.lblTieuDe.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblTieuDe.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold);
            this.lblTieuDe.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.lblTieuDe.Location = new System.Drawing.Point(0, 0);
            this.lblTieuDe.Name = "lblTieuDe";
            this.lblTieuDe.Size = new System.Drawing.Size(1024, 50);
            this.lblTieuDe.TabIndex = 0;
            this.lblTieuDe.Text = "BẢNG TÍNH LƯƠNG HẰNG THÁNG CHO NHÂN VIÊN";
            this.lblTieuDe.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // grpBoLoc
            // 
            this.grpBoLoc.Controls.Add(this.btnDong);
            this.grpBoLoc.Controls.Add(this.btnInPhieuLuong);
            this.grpBoLoc.Controls.Add(this.btnLuuBangLuong);
            this.grpBoLoc.Controls.Add(this.btnTinhLuong);
            this.grpBoLoc.Controls.Add(this.btnXemBangLuong);
            this.grpBoLoc.Controls.Add(this.cboNam);
            this.grpBoLoc.Controls.Add(this.lblNam);
            this.grpBoLoc.Controls.Add(this.cboThang);
            this.grpBoLoc.Controls.Add(this.lblThang);
            this.grpBoLoc.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.grpBoLoc.Location = new System.Drawing.Point(15, 55);
            this.grpBoLoc.Name = "grpBoLoc";
            this.grpBoLoc.Size = new System.Drawing.Size(990, 85);
            this.grpBoLoc.TabIndex = 1;
            this.grpBoLoc.TabStop = false;
            this.grpBoLoc.Text = "Kỳ tính lương";
            // 
            // btnDong
            // 
            this.btnDong.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnDong.Location = new System.Drawing.Point(885, 30);
            this.btnDong.Name = "btnDong";
            this.btnDong.Size = new System.Drawing.Size(90, 36);
            this.btnDong.TabIndex = 8;
            this.btnDong.Text = "Đóng";
            this.btnDong.UseVisualStyleBackColor = true;
            this.btnDong.Click += new System.EventHandler(this.btnDong_Click);
            // 
            // btnInPhieuLuong
            // 
            this.btnInPhieuLuong.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnInPhieuLuong.Location = new System.Drawing.Point(745, 30);
            this.btnInPhieuLuong.Name = "btnInPhieuLuong";
            this.btnInPhieuLuong.Size = new System.Drawing.Size(130, 36);
            this.btnInPhieuLuong.TabIndex = 7;
            this.btnInPhieuLuong.Text = "In phiếu lương";
            this.btnInPhieuLuong.UseVisualStyleBackColor = true;
            this.btnInPhieuLuong.Click += new System.EventHandler(this.btnInPhieuLuong_Click);
            // 
            // btnLuuBangLuong
            // 
            this.btnLuuBangLuong.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.btnLuuBangLuong.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.btnLuuBangLuong.Location = new System.Drawing.Point(585, 30);
            this.btnLuuBangLuong.Name = "btnLuuBangLuong";
            this.btnLuuBangLuong.Size = new System.Drawing.Size(150, 36);
            this.btnLuuBangLuong.TabIndex = 6;
            this.btnLuuBangLuong.Text = "LƯU VÀO CSDL";
            this.btnLuuBangLuong.UseVisualStyleBackColor = true;
            this.btnLuuBangLuong.Click += new System.EventHandler(this.btnLuuBangLuong_Click);
            // 
            // btnTinhLuong
            // 
            this.btnTinhLuong.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.btnTinhLuong.ForeColor = System.Drawing.Color.DarkGreen;
            this.btnTinhLuong.Location = new System.Drawing.Point(400, 30);
            this.btnTinhLuong.Name = "btnTinhLuong";
            this.btnTinhLuong.Size = new System.Drawing.Size(175, 36);
            this.btnTinhLuong.TabIndex = 5;
            this.btnTinhLuong.Text = "⚡ TÍNH LƯƠNG TỰ ĐỘNG";
            this.btnTinhLuong.UseVisualStyleBackColor = true;
            this.btnTinhLuong.Click += new System.EventHandler(this.btnTinhLuong_Click);
            // 
            // btnXemBangLuong
            // 
            this.btnXemBangLuong.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnXemBangLuong.Location = new System.Drawing.Point(280, 30);
            this.btnXemBangLuong.Name = "btnXemBangLuong";
            this.btnXemBangLuong.Size = new System.Drawing.Size(110, 36);
            this.btnXemBangLuong.TabIndex = 4;
            this.btnXemBangLuong.Text = "Xem đã lưu";
            this.btnXemBangLuong.UseVisualStyleBackColor = true;
            this.btnXemBangLuong.Click += new System.EventHandler(this.btnXemBangLuong_Click);
            // 
            // cboNam
            // 
            this.cboNam.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboNam.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.cboNam.FormattingEnabled = true;
            this.cboNam.Location = new System.Drawing.Point(185, 35);
            this.cboNam.Name = "cboNam";
            this.cboNam.Size = new System.Drawing.Size(80, 29);
            this.cboNam.TabIndex = 3;
            // 
            // lblNam
            // 
            this.lblNam.AutoSize = true;
            this.lblNam.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblNam.Location = new System.Drawing.Point(140, 40);
            this.lblNam.Name = "lblNam";
            this.lblNam.Size = new System.Drawing.Size(47, 21);
            this.lblNam.TabIndex = 2;
            this.lblNam.Text = "Năm:";
            // 
            // cboThang
            // 
            this.cboThang.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboThang.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.cboThang.FormattingEnabled = true;
            this.cboThang.Location = new System.Drawing.Point(70, 35);
            this.cboThang.Name = "cboThang";
            this.cboThang.Size = new System.Drawing.Size(60, 29);
            this.cboThang.TabIndex = 1;
            // 
            // lblThang
            // 
            this.lblThang.AutoSize = true;
            this.lblThang.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblThang.Location = new System.Drawing.Point(15, 40);
            this.lblThang.Name = "lblThang";
            this.lblThang.Size = new System.Drawing.Size(56, 21);
            this.lblThang.TabIndex = 0;
            this.lblThang.Text = "Tháng:";
            // 
            // grpChiTiet
            // 
            this.grpChiTiet.Controls.Add(this.txtThucLinh);
            this.grpChiTiet.Controls.Add(this.lblThucLinh);
            this.grpChiTiet.Controls.Add(this.txtTrichBaoHiem);
            this.grpChiTiet.Controls.Add(this.lblTrichBH);
            this.grpChiTiet.Controls.Add(this.txtTienPhat);
            this.grpChiTiet.Controls.Add(this.lblTienPhat);
            this.grpChiTiet.Controls.Add(this.txtTienThuong);
            this.grpChiTiet.Controls.Add(this.lblTienThuong);
            this.grpChiTiet.Controls.Add(this.txtTienPhuCap);
            this.grpChiTiet.Controls.Add(this.lblPhuCap);
            this.grpChiTiet.Controls.Add(this.txtTienPhuTroi);
            this.grpChiTiet.Controls.Add(this.lblPhuTroi);
            this.grpChiTiet.Controls.Add(this.txtLuongChinh);
            this.grpChiTiet.Controls.Add(this.lblLuongChinh);
            this.grpChiTiet.Controls.Add(this.txtHoTenNV);
            this.grpChiTiet.Controls.Add(this.lblHoTen);
            this.grpChiTiet.Controls.Add(this.txtMaBL);
            this.grpChiTiet.Controls.Add(this.lblMaBL);
            this.grpChiTiet.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.grpChiTiet.Location = new System.Drawing.Point(15, 145);
            this.grpChiTiet.Name = "grpChiTiet";
            this.grpChiTiet.Size = new System.Drawing.Size(990, 160);
            this.grpChiTiet.TabIndex = 2;
            this.grpChiTiet.TabStop = false;
            this.grpChiTiet.Text = "Chi tiết cấu thành lương của Nhân viên được chọn";
            // 
            // txtThucLinh
            // 
            this.txtThucLinh.BackColor = System.Drawing.Color.LightYellow;
            this.txtThucLinh.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.txtThucLinh.ForeColor = System.Drawing.Color.DarkRed;
            this.txtThucLinh.Location = new System.Drawing.Point(770, 110);
            this.txtThucLinh.Name = "txtThucLinh";
            this.txtThucLinh.ReadOnly = true;
            this.txtThucLinh.Size = new System.Drawing.Size(205, 32);
            this.txtThucLinh.TabIndex = 17;
            this.txtThucLinh.Text = "0";
            // 
            // lblThucLinh
            // 
            this.lblThucLinh.AutoSize = true;
            this.lblThucLinh.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.lblThucLinh.ForeColor = System.Drawing.Color.DarkRed;
            this.lblThucLinh.Location = new System.Drawing.Point(670, 115);
            this.lblThucLinh.Name = "lblThucLinh";
            this.lblThucLinh.Size = new System.Drawing.Size(89, 23);
            this.lblThucLinh.TabIndex = 16;
            this.lblThucLinh.Text = "Thực lĩnh:";
            // 
            // txtTrichBaoHiem
            // 
            this.txtTrichBaoHiem.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtTrichBaoHiem.Location = new System.Drawing.Point(445, 110);
            this.txtTrichBaoHiem.Name = "txtTrichBaoHiem";
            this.txtTrichBaoHiem.ReadOnly = true;
            this.txtTrichBaoHiem.Size = new System.Drawing.Size(195, 29);
            this.txtTrichBaoHiem.TabIndex = 15;
            this.txtTrichBaoHiem.Text = "0";
            // 
            // lblTrichBH
            // 
            this.lblTrichBH.AutoSize = true;
            this.lblTrichBH.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblTrichBH.Location = new System.Drawing.Point(345, 115);
            this.lblTrichBH.Name = "lblTrichBH";
            this.lblTrichBH.Size = new System.Drawing.Size(97, 21);
            this.lblTrichBH.TabIndex = 14;
            this.lblTrichBH.Text = "Trích BHXH:";
            // 
            // txtTienPhat
            // 
            this.txtTienPhat.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtTienPhat.Location = new System.Drawing.Point(120, 110);
            this.txtTienPhat.Name = "txtTienPhat";
            this.txtTienPhat.ReadOnly = true;
            this.txtTienPhat.Size = new System.Drawing.Size(195, 29);
            this.txtTienPhat.TabIndex = 13;
            this.txtTienPhat.Text = "0";
            // 
            // lblTienPhat
            // 
            this.lblTienPhat.AutoSize = true;
            this.lblTienPhat.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblTienPhat.Location = new System.Drawing.Point(15, 115);
            this.lblTienPhat.Name = "lblTienPhat";
            this.lblTienPhat.Size = new System.Drawing.Size(78, 21);
            this.lblTienPhat.TabIndex = 12;
            this.lblTienPhat.Text = "Tiền phạt:";
            // 
            // txtTienThuong
            // 
            this.txtTienThuong.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtTienThuong.Location = new System.Drawing.Point(770, 70);
            this.txtTienThuong.Name = "txtTienThuong";
            this.txtTienThuong.ReadOnly = true;
            this.txtTienThuong.Size = new System.Drawing.Size(205, 29);
            this.txtTienThuong.TabIndex = 11;
            this.txtTienThuong.Text = "0";
            // 
            // lblTienThuong
            // 
            this.lblTienThuong.AutoSize = true;
            this.lblTienThuong.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblTienThuong.Location = new System.Drawing.Point(670, 75);
            this.lblTienThuong.Name = "lblTienThuong";
            this.lblTienThuong.Size = new System.Drawing.Size(98, 21);
            this.lblTienThuong.TabIndex = 10;
            this.lblTienThuong.Text = "Tiền thưởng:";
            // 
            // txtTienPhuCap
            // 
            this.txtTienPhuCap.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtTienPhuCap.Location = new System.Drawing.Point(445, 70);
            this.txtTienPhuCap.Name = "txtTienPhuCap";
            this.txtTienPhuCap.ReadOnly = true;
            this.txtTienPhuCap.Size = new System.Drawing.Size(195, 29);
            this.txtTienPhuCap.TabIndex = 9;
            this.txtTienPhuCap.Text = "0";
            // 
            // lblPhuCap
            // 
            this.lblPhuCap.AutoSize = true;
            this.lblPhuCap.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblPhuCap.Location = new System.Drawing.Point(345, 75);
            this.lblPhuCap.Name = "lblPhuCap";
            this.lblPhuCap.Size = new System.Drawing.Size(99, 21);
            this.lblPhuCap.TabIndex = 8;
            this.lblPhuCap.Text = "Tiền phụ cấp:";
            // 
            // txtTienPhuTroi
            // 
            this.txtTienPhuTroi.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtTienPhuTroi.Location = new System.Drawing.Point(120, 70);
            this.txtTienPhuTroi.Name = "txtTienPhuTroi";
            this.txtTienPhuTroi.ReadOnly = true;
            this.txtTienPhuTroi.Size = new System.Drawing.Size(195, 29);
            this.txtTienPhuTroi.TabIndex = 7;
            this.txtTienPhuTroi.Text = "0";
            // 
            // lblPhuTroi
            // 
            this.lblPhuTroi.AutoSize = true;
            this.lblPhuTroi.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblPhuTroi.Location = new System.Drawing.Point(15, 75);
            this.lblPhuTroi.Name = "lblPhuTroi";
            this.lblPhuTroi.Size = new System.Drawing.Size(100, 21);
            this.lblPhuTroi.TabIndex = 6;
            this.lblPhuTroi.Text = "Tiền phụ trội:";
            // 
            // txtLuongChinh
            // 
            this.txtLuongChinh.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtLuongChinh.Location = new System.Drawing.Point(770, 30);
            this.txtLuongChinh.Name = "txtLuongChinh";
            this.txtLuongChinh.ReadOnly = true;
            this.txtLuongChinh.Size = new System.Drawing.Size(205, 29);
            this.txtLuongChinh.TabIndex = 5;
            this.txtLuongChinh.Text = "0";
            // 
            // lblLuongChinh
            // 
            this.lblLuongChinh.AutoSize = true;
            this.lblLuongChinh.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblLuongChinh.Location = new System.Drawing.Point(670, 35);
            this.lblLuongChinh.Name = "lblLuongChinh";
            this.lblLuongChinh.Size = new System.Drawing.Size(99, 21);
            this.lblLuongChinh.TabIndex = 4;
            this.lblLuongChinh.Text = "Lương chính:";
            // 
            // txtHoTenNV
            // 
            this.txtHoTenNV.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtHoTenNV.Location = new System.Drawing.Point(445, 30);
            this.txtHoTenNV.Name = "txtHoTenNV";
            this.txtHoTenNV.ReadOnly = true;
            this.txtHoTenNV.Size = new System.Drawing.Size(195, 29);
            this.txtHoTenNV.TabIndex = 3;
            // 
            // lblHoTen
            // 
            this.lblHoTen.AutoSize = true;
            this.lblHoTen.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblHoTen.Location = new System.Drawing.Point(345, 35);
            this.lblHoTen.Name = "lblHoTen";
            this.lblHoTen.Size = new System.Drawing.Size(84, 21);
            this.lblHoTen.TabIndex = 2;
            this.lblHoTen.Text = "Nhân viên:";
            // 
            // txtMaBL
            // 
            this.txtMaBL.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtMaBL.Location = new System.Drawing.Point(120, 30);
            this.txtMaBL.Name = "txtMaBL";
            this.txtMaBL.ReadOnly = true;
            this.txtMaBL.Size = new System.Drawing.Size(195, 29);
            this.txtMaBL.TabIndex = 1;
            // 
            // lblMaBL
            // 
            this.lblMaBL.AutoSize = true;
            this.lblMaBL.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblMaBL.Location = new System.Drawing.Point(15, 35);
            this.lblMaBL.Name = "lblMaBL";
            this.lblMaBL.Size = new System.Drawing.Size(59, 21);
            this.lblMaBL.TabIndex = 0;
            this.lblMaBL.Text = "Mã BL:";
            // 
            // dgvBangLuong
            // 
            this.dgvBangLuong.AllowUserToAddRows = false;
            this.dgvBangLuong.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvBangLuong.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvBangLuong.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.dgvBangLuong.Location = new System.Drawing.Point(15, 315);
            this.dgvBangLuong.Name = "dgvBangLuong";
            this.dgvBangLuong.ReadOnly = true;
            this.dgvBangLuong.RowHeadersWidth = 35;
            this.dgvBangLuong.RowTemplate.Height = 24;
            this.dgvBangLuong.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvBangLuong.Size = new System.Drawing.Size(990, 315);
            this.dgvBangLuong.TabIndex = 3;
            this.dgvBangLuong.SelectionChanged += new System.EventHandler(this.dgvBangLuong_SelectionChanged);
            // 
            // FrmBangLuong
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1024, 645);
            this.Controls.Add(this.dgvBangLuong);
            this.Controls.Add(this.grpChiTiet);
            this.Controls.Add(this.grpBoLoc);
            this.Controls.Add(this.lblTieuDe);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Tính bảng lương nhân viên";
            this.Load += new System.EventHandler(this.FrmBangLuong_Load);
            this.grpBoLoc.ResumeLayout(false);
            this.grpBoLoc.PerformLayout();
            this.grpChiTiet.ResumeLayout(false);
            this.grpChiTiet.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBangLuong)).EndInit();
            this.ResumeLayout(false);
        }

        private System.Windows.Forms.Label lblTieuDe;
        private System.Windows.Forms.GroupBox grpBoLoc;
        private System.Windows.Forms.ComboBox cboThang;
        private System.Windows.Forms.Label lblThang;
        private System.Windows.Forms.ComboBox cboNam;
        private System.Windows.Forms.Label lblNam;
        private System.Windows.Forms.Button btnXemBangLuong;
        private System.Windows.Forms.Button btnTinhLuong;
        private System.Windows.Forms.Button btnLuuBangLuong;
        private System.Windows.Forms.Button btnInPhieuLuong;
        private System.Windows.Forms.Button btnDong;
        private System.Windows.Forms.GroupBox grpChiTiet;
        private System.Windows.Forms.TextBox txtMaBL;
        private System.Windows.Forms.Label lblMaBL;
        private System.Windows.Forms.TextBox txtHoTenNV;
        private System.Windows.Forms.Label lblHoTen;
        private System.Windows.Forms.TextBox txtLuongChinh;
        private System.Windows.Forms.Label lblLuongChinh;
        private System.Windows.Forms.TextBox txtTienPhuTroi;
        private System.Windows.Forms.Label lblPhuTroi;
        private System.Windows.Forms.TextBox txtTienPhuCap;
        private System.Windows.Forms.Label lblPhuCap;
        private System.Windows.Forms.TextBox txtTienThuong;
        private System.Windows.Forms.Label lblTienThuong;
        private System.Windows.Forms.TextBox txtTienPhat;
        private System.Windows.Forms.Label lblTienPhat;
        private System.Windows.Forms.TextBox txtTrichBaoHiem;
        private System.Windows.Forms.Label lblTrichBH;
        private System.Windows.Forms.TextBox txtThucLinh;
        private System.Windows.Forms.Label lblThucLinh;
        private System.Windows.Forms.DataGridView dgvBangLuong;
    }
}