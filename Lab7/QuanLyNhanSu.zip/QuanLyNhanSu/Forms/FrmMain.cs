﻿using System;
using System.Windows.Forms;

namespace QuanLyNhanSu.Forms
{
    public partial class FrmMain : Form
    {
        public FrmMain()
        {
            InitializeComponent();
        }

        private void btnNhanSu_Click(object sender, EventArgs e)
        {
            using (FrmNhanSu_TuyenDung frm = new FrmNhanSu_TuyenDung())
            {
                frm.ShowDialog(this);
            }
        }

        private void btnHopDong_Click(object sender, EventArgs e)
        {
            using (FrmHopDong_CheDo frm = new FrmHopDong_CheDo())
            {
                frm.ShowDialog(this);
            }
        }

        private void btnChamCong_Click(object sender, EventArgs e)
        {
            using (FrmChamCong_PhuTroi frm = new FrmChamCong_PhuTroi())
            {
                frm.ShowDialog(this);
            }
        }

        private void btnKhenThuong_Click(object sender, EventArgs e)
        {
            using (FrmKhenThuongKyLuat frm = new FrmKhenThuongKyLuat())
            {
                frm.ShowDialog(this);
            }
        }

        private void btnBangLuong_Click(object sender, EventArgs e)
        {
            using (FrmBangLuong frm = new FrmBangLuong())
            {
                frm.ShowDialog(this);
            }
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Bạn có chắc chắn muốn thoát khỏi hệ thống?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }
    }
}