﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using QuanLyNhanSu.Data;

namespace QuanLyNhanSu.Forms
{
    public partial class FrmKhenThuongKyLuat : Form
    {
        // Bảng tạm chứa danh sách chi tiết trước khi lưu vào CSDL
        private DataTable dtChiTiet;

        public FrmKhenThuongKyLuat()
        {
            InitializeComponent();
        }

        private void FrmKhenThuongKyLuat_Load(object sender, EventArgs e)
        {
            cboLoaiQD.SelectedIndex = 0; // Mặc định là Khen thưởng
            txtMaQD.Text = "QD" + DateTime.Now.ToString("ddHHmmss");

            KhoiTaoBangChiTiet();
            NapDuLieuComboBox();
        }

        // Tạo cấu trúc bảng tạm hiển thị trên DataGridView
        private void KhoiTaoBangChiTiet()
        {
            dtChiTiet = new DataTable();
            dtChiTiet.Columns.Add("LoaiDoiTuong", typeof(string));
            dtChiTiet.Columns.Add("MaDoiTuong", typeof(string));
            dtChiTiet.Columns.Add("TenDoiTuong", typeof(string));
            dtChiTiet.Columns.Add("SoTienCuThe", typeof(decimal));
            dtChiTiet.Columns.Add("GhiChu", typeof(string));

            dgvChiTiet.DataSource = dtChiTiet;

            // Đặt tiêu đề cột
            dgvChiTiet.Columns["LoaiDoiTuong"].HeaderText = "Phân loại";
            dgvChiTiet.Columns["MaDoiTuong"].HeaderText = "Mã ĐT";
            dgvChiTiet.Columns["TenDoiTuong"].HeaderText = "Tên Đối tượng";
            dgvChiTiet.Columns["SoTienCuThe"].HeaderText = "Số tiền";
            dgvChiTiet.Columns["GhiChu"].HeaderText = "Ghi chú";

            // Định dạng tiền tệ
            dgvChiTiet.Columns["SoTienCuThe"].DefaultCellStyle.Format = "N0";
        }

        // Nạp danh sách Nhân viên và Phòng ban từ CSDL
        private void NapDuLieuComboBox()
        {
            try
            {
                // Danh sách Nhân viên
                string sqlNV = "SELECT MaNV, HoTen FROM NhanVien";
                DataTable dtNV = Db.LayDuLieu(sqlNV);
                cboNhanVien.DisplayMember = "HoTen";
                cboNhanVien.ValueMember = "MaNV";
                cboNhanVien.DataSource = dtNV;

                // Danh sách Phòng ban
                string sqlPB = "SELECT MaPB, TenPB FROM PhongBan";
                DataTable dtPB = Db.LayDuLieu(sqlPB);
                cboPhongBan.DisplayMember = "TenPB";
                cboPhongBan.ValueMember = "MaPB";
                cboPhongBan.DataSource = dtPB;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi nạp danh mục: " + ex.Message, "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Chuyển đổi giữa Cá nhân và Tập thể
        private void rdoDoiTuong_CheckedChanged(object sender, EventArgs e)
        {
            if (rdoCaNhan.Checked)
            {
                cboNhanVien.Enabled = true;
                cboPhongBan.Enabled = false;
            }
            else
            {
                cboNhanVien.Enabled = false;
                cboPhongBan.Enabled = true;
            }
        }

        // Thêm đối tượng vào danh sách chi tiết (loop trong Sequence Diagram)
        private void btnThemDoiTuong_Click(object sender, EventArgs e)
        {
            string strTien = txtSoTienCuThe.Text.Replace(",", "").Replace(".", "").Trim();
            if (!decimal.TryParse(strTien, out decimal soTien) || soTien < 0)
            {
                MessageBox.Show("Số tiền cụ thể không hợp lệ!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtSoTienCuThe.Focus();
                return;
            }

            string loaiDT = rdoCaNhan.Checked ? "Cá nhân" : "Tập thể";
            string maDT = "";
            string tenDT = "";

            if (rdoCaNhan.Checked)
            {
                if (cboNhanVien.SelectedValue == null)
                {
                    MessageBox.Show("Vui lòng chọn nhân viên!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                maDT = cboNhanVien.SelectedValue.ToString();
                tenDT = cboNhanVien.Text;
            }
            else
            {
                if (cboPhongBan.SelectedValue == null)
                {
                    MessageBox.Show("Vui lòng chọn phòng ban!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                maDT = cboPhongBan.SelectedValue.ToString();
                tenDT = cboPhongBan.Text;
            }

            // Kiểm tra trùng đối tượng
            foreach (DataRow r in dtChiTiet.Rows)
            {
                if (r["MaDoiTuong"].ToString() == maDT && r["LoaiDoiTuong"].ToString() == loaiDT)
                {
                    MessageBox.Show("Đối tượng này đã có trong danh sách!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
            }

            // Thêm dòng mới
            DataRow row = dtChiTiet.NewRow();
            row["LoaiDoiTuong"] = loaiDT;
            row["MaDoiTuong"] = maDT;
            row["TenDoiTuong"] = tenDT;
            row["SoTienCuThe"] = soTien;
            row["GhiChu"] = txtGhiChu.Text.Trim();
            dtChiTiet.Rows.Add(row);

            // Tự động cộng dồn tổng tiền
            CapNhatTongTien();

            txtGhiChu.Clear();
        }

        private void btnXoaDoiTuong_Click(object sender, EventArgs e)
        {
            if (dgvChiTiet.CurrentRow != null && dgvChiTiet.CurrentRow.Index >= 0)
            {
                dtChiTiet.Rows.RemoveAt(dgvChiTiet.CurrentRow.Index);
                CapNhatTongTien();
            }
            else
            {
                MessageBox.Show("Vui lòng chọn dòng cần xóa!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void CapNhatTongTien()
        {
            decimal tong = 0;
            foreach (DataRow r in dtChiTiet.Rows)
            {
                tong += Convert.ToDecimal(r["SoTienCuThe"]);
            }
            txtTongTien.Text = tong.ToString("N0");
        }

        // Xử lý lưu quyết định (Khớp với Controller trong Sequence Diagram)
        private void btnLuuQuyetDinh_Click(object sender, EventArgs e)
        {
            // 1. Kiểm tra thông tin hợp lệ (kiemTraThongTinHopLe)
            string maQD = txtMaQD.Text.Trim();
            if (string.IsNullOrEmpty(maQD))
            {
                MessageBox.Show("Vui lòng nhập Mã quyết định!", "Lỗi nhập liệu", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtMaQD.Focus();
                return;
            }

            if (dtChiTiet.Rows.Count == 0)
            {
                MessageBox.Show("Danh sách đối tượng thụ hưởng không được để trống!", "Lỗi nhập liệu", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string loaiQD = cboLoaiQD.SelectedItem.ToString();
            string hinhThuc = txtHinhThuc.Text.Trim();
            DateTime ngayKy = dtpNgayKy.Value;
            decimal tongTien = 0;
            decimal.TryParse(txtTongTien.Text.Replace(",", "").Replace(".", "").Trim(), out tongTien);
            string noiDung = txtNoiDung.Text.Trim();
            string nguoiKy = txtNguoiKy.Text.Trim();

            // 2. Thực thi lưu dữ liệu vào CSDL
            using (SqlConnection conn = Db.GetConnection())
            {
                conn.Open();
                SqlTransaction trans = conn.BeginTransaction();

                try
                {
                    // Lưu bảng cha: QuyetDinhKhenThuongKyLuat
                    string sqlQD = @"INSERT INTO QuyetDinhKhenThuongKyLuat 
                                    (MaQDKTKL, LoaiQuyetDinh, HinhThuc, NgayKy, SoTien, NoiDung, NguoiKy)
                                    VALUES (@MaQD, @LoaiQD, @HinhThuc, @NgayKy, @SoTien, @NoiDung, @NguoiKy)";

                    using (SqlCommand cmdQD = new SqlCommand(sqlQD, conn, trans))
                    {
                        cmdQD.Parameters.AddWithValue("@MaQD", maQD);
                        cmdQD.Parameters.AddWithValue("@LoaiQD", loaiQD);
                        cmdQD.Parameters.AddWithValue("@HinhThuc", (object)hinhThuc ?? DBNull.Value);
                        cmdQD.Parameters.AddWithValue("@NgayKy", ngayKy);
                        cmdQD.Parameters.AddWithValue("@SoTien", tongTien);
                        cmdQD.Parameters.AddWithValue("@NoiDung", (object)noiDung ?? DBNull.Value);
                        cmdQD.Parameters.AddWithValue("@NguoiKy", (object)nguoiKy ?? DBNull.Value);

                        cmdQD.ExecuteNonQuery();
                    }

                    // Lưu các bản ghi con: ChiTietKhenThuongKyLuat (Vòng lặp loop)
                    int count = 1;
                    foreach (DataRow r in dtChiTiet.Rows)
                    {
                        // "CT" (2) + ddHHmm (6) + count (2) = đúng 10 ký tự
                        string maCT = "CT" + DateTime.Now.ToString("ddHHmm") + (count % 100).ToString("D2");
                        string loaiDT = r["LoaiDoiTuong"].ToString();
                        string maDT = r["MaDoiTuong"].ToString();
                        decimal soTienCuThe = Convert.ToDecimal(r["SoTienCuThe"]);
                        string ghiChu = r["GhiChu"].ToString();

                        string sqlCT = @"INSERT INTO ChiTietKhenThuongKyLuat 
                                        (MaCTKTKL, MaQDKTKL, MaNV, MaPB, SoTienCuThe, GhiChu)
                                        VALUES (@MaCT, @MaQD, @MaNV, @MaPB, @SoTienCuThe, @GhiChu)";

                        using (SqlCommand cmdCT = new SqlCommand(sqlCT, conn, trans))
                        {
                            cmdCT.Parameters.AddWithValue("@MaCT", maCT);
                            cmdCT.Parameters.AddWithValue("@MaQD", maQD);

                            if (loaiDT == "Cá nhân")
                            {
                                cmdCT.Parameters.AddWithValue("@MaNV", maDT);
                                cmdCT.Parameters.AddWithValue("@MaPB", DBNull.Value);
                            }
                            else
                            {
                                cmdCT.Parameters.AddWithValue("@MaNV", DBNull.Value);
                                cmdCT.Parameters.AddWithValue("@MaPB", maDT);
                            }

                            cmdCT.Parameters.AddWithValue("@SoTienCuThe", soTienCuThe);
                            cmdCT.Parameters.AddWithValue("@GhiChu", (object)ghiChu ?? DBNull.Value);

                            cmdCT.ExecuteNonQuery();
                        }
                        count++;
                    }

                    trans.Commit();
                    MessageBox.Show("Lập quyết định " + loaiQD + " thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    btnLamMoi_Click(null, null);
                }
                catch (Exception ex)
                {
                    trans.Rollback();
                    MessageBox.Show("Lỗi khi lưu quyết định: " + ex.Message, "Thông báo lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnLamMoi_Click(object sender, EventArgs e)
        {
            // Rút ngắn còn đúng 10 ký tự: "QD" + 8 chữ số
            txtMaQD.Text = "QD" + DateTime.Now.ToString("ddHHmmss");
            cboLoaiQD.SelectedIndex = 0;
            txtHinhThuc.Clear();
            dtpNgayKy.Value = DateTime.Now;
            txtTongTien.Text = "0";
            txtNguoiKy.Clear();
            txtNoiDung.Clear();

            dtChiTiet.Clear();
            txtSoTienCuThe.Text = "0";
            txtGhiChu.Clear();
            rdoCaNhan.Checked = true;
        }

        private void btnDong_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}