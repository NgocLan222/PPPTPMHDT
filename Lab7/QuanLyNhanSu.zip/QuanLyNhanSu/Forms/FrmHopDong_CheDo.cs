﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Windows.Forms;
using QuanLyNhanSu.Data;

namespace QuanLyNhanSu.Forms
{
    public partial class FrmHopDong_CheDo : Form
    {
        public FrmHopDong_CheDo()
        {
            InitializeComponent();
        }

        private void FrmHopDong_CheDo_Load(object sender, EventArgs e)
        {
            TaiDanhSachNhanVienVaoComboBox();
            TaiDanhSachHopDong();
            TaiDanhSachChucVu();
            TaiDanhSachLuong();
            TaiDanhSachBaoHiem();

            btnLamMoiHD_Click(null, null);
            btnLamMoiCV_Click(null, null);
            btnLamMoiLuong_Click(null, null);
            btnLamMoiBH_Click(null, null);
        }

        private void TaiDanhSachNhanVienVaoComboBox()
        {
            string sql = "SELECT MaNV, HoTen FROM NhanVien";
            DataTable dt = Db.LayDuLieu(sql);

            // Tab Hợp đồng
            cboNV_HD.DisplayMember = "HoTen";
            cboNV_HD.ValueMember = "MaNV";
            cboNV_HD.DataSource = dt.Copy();

            // Tab Chức vụ
            cboNV_CV.DisplayMember = "HoTen";
            cboNV_CV.ValueMember = "MaNV";
            cboNV_CV.DataSource = dt.Copy();

            // Tab Lương
            cboNV_Luong.DisplayMember = "HoTen";
            cboNV_Luong.ValueMember = "MaNV";
            cboNV_Luong.DataSource = dt.Copy();

            // Tab Bảo hiểm
            cboNV_BH.DisplayMember = "HoTen";
            cboNV_BH.ValueMember = "MaNV";
            cboNV_BH.DataSource = dt.Copy();
        }

        // ==================== TAB 1: HỢP ĐỒNG LAO ĐỘNG ====================

        private void TaiDanhSachHopDong()
        {
            string sql = @"SELECT hd.MaHD, nv.HoTen, hd.LoaiHopDong, hd.NgayKy, 
                                  hd.NgayHieuLuc, hd.NgayHetHan, hd.NoiDung, hd.MaNV
                           FROM HopDongLaoDong hd
                           JOIN NhanVien nv ON hd.MaNV = nv.MaNV";
            DataTable dt = Db.LayDuLieu(sql);
            dgvHopDong.DataSource = dt;

            dgvHopDong.Columns["MaHD"].HeaderText = "Mã HĐ";
            dgvHopDong.Columns["HoTen"].HeaderText = "Nhân viên";
            dgvHopDong.Columns["LoaiHopDong"].HeaderText = "Loại HĐ";
            dgvHopDong.Columns["NgayKy"].HeaderText = "Ngày ký";
            dgvHopDong.Columns["NgayHieuLuc"].HeaderText = "Hiệu lực";
            dgvHopDong.Columns["NgayHetHan"].HeaderText = "Hết hạn";
            dgvHopDong.Columns["NoiDung"].HeaderText = "Nội dung";
            dgvHopDong.Columns["MaNV"].Visible = false;
        }

        private void btnLapHD_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtMaHD.Text.Trim()) || cboNV_HD.SelectedValue == null)
            {
                MessageBox.Show("Vui lòng nhập Mã HĐ và chọn Nhân viên!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string sql = @"INSERT INTO HopDongLaoDong (MaHD, MaNV, LoaiHopDong, NgayKy, NgayHieuLuc, NgayHetHan, NoiDung)
                           VALUES (@MaHD, @MaNV, @LoaiHD, @NgayKy, @NgayHL, @NgayHH, @NoiDung)";

            SqlParameter[] prms = new SqlParameter[]
            {
                new SqlParameter("@MaHD", txtMaHD.Text.Trim()),
                new SqlParameter("@MaNV", cboNV_HD.SelectedValue),
                new SqlParameter("@LoaiHD", cboLoaiHD.Text),
                new SqlParameter("@NgayKy", dtpNgayKyHD.Value),
                new SqlParameter("@NgayHL", dtpNgayHieuLuc.Value),
                new SqlParameter("@NgayHH", cboLoaiHD.Text == "Ngắn hạn" ? (object)dtpNgayHetHan.Value : DBNull.Value),
                new SqlParameter("@NoiDung", txtNoiDungHD.Text.Trim())
            };

            try
            {
                Db.ThucThi(sql, prms);

                if (cboLoaiHD.Text == "Dài hạn")
                {
                    MessageBox.Show("Ký hợp đồng DÀI HẠN thành công!\nVui lòng qua Tab '4. Hồ sơ bảo hiểm' để hoàn tất thủ tục BHYT/BHXH cho nhân viên này.",
                                    "Thông báo liên kết bảo hiểm", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("Ký hợp đồng lao động thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

                TaiDanhSachHopDong();
                btnLamMoiHD_Click(null, null);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi lập hợp đồng: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnSuaHD_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtMaHD.Text.Trim())) return;

            string sql = @"UPDATE HopDongLaoDong 
                           SET LoaiHopDong = @LoaiHD, NgayKy = @NgayKy, NgayHieuLuc = @NgayHL, 
                               NgayHetHan = @NgayHH, NoiDung = @NoiDung
                           WHERE MaHD = @MaHD";

            SqlParameter[] prms = new SqlParameter[]
            {
                new SqlParameter("@MaHD", txtMaHD.Text.Trim()),
                new SqlParameter("@LoaiHD", cboLoaiHD.Text),
                new SqlParameter("@NgayKy", dtpNgayKyHD.Value),
                new SqlParameter("@NgayHL", dtpNgayHieuLuc.Value),
                new SqlParameter("@NgayHH", cboLoaiHD.Text == "Ngắn hạn" ? (object)dtpNgayHetHan.Value : DBNull.Value),
                new SqlParameter("@NoiDung", txtNoiDungHD.Text.Trim())
            };

            try
            {
                Db.ThucThi(sql, prms);
                MessageBox.Show("Cập nhật hợp đồng thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                TaiDanhSachHopDong();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi cập nhật: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnXoaHD_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtMaHD.Text.Trim())) return;

            if (MessageBox.Show("Bạn có chắc chắn muốn xóa hợp đồng này?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                try
                {
                    Db.ThucThi("DELETE FROM HopDongLaoDong WHERE MaHD = @MaHD", new SqlParameter[] { new SqlParameter("@MaHD", txtMaHD.Text.Trim()) });
                    TaiDanhSachHopDong();
                    btnLamMoiHD_Click(null, null);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi xóa: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnLamMoiHD_Click(object sender, EventArgs e)
        {
            // Sửa còn đúng 10 ký tự: "HD" + 8 chữ số
            txtMaHD.Text = "HD" + DateTime.Now.ToString("ddHHmmss");
            cboLoaiHD.SelectedIndex = 0; // Dài hạn
            dtpNgayKyHD.Value = DateTime.Now;
            dtpNgayHieuLuc.Value = DateTime.Now;
            dtpNgayHetHan.Value = DateTime.Now.AddYears(1);
            txtNoiDungHD.Text = "Hợp đồng lao động chính thức tại Công ty Sơn Đông Á.";
        }

        private void dgvHopDong_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvHopDong.CurrentRow != null && dgvHopDong.CurrentRow.Index >= 0)
            {
                DataGridViewRow row = dgvHopDong.CurrentRow;
                txtMaHD.Text = row.Cells["MaHD"].Value?.ToString();
                cboNV_HD.SelectedValue = row.Cells["MaNV"].Value?.ToString();
                cboLoaiHD.Text = row.Cells["LoaiHopDong"].Value?.ToString();
                if (DateTime.TryParse(row.Cells["NgayKy"].Value?.ToString(), out DateTime nk)) dtpNgayKyHD.Value = nk;
                if (DateTime.TryParse(row.Cells["NgayHieuLuc"].Value?.ToString(), out DateTime nhl)) dtpNgayHieuLuc.Value = nhl;
                if (DateTime.TryParse(row.Cells["NgayHetHan"].Value?.ToString(), out DateTime nhh)) dtpNgayHetHan.Value = nhh;
                txtNoiDungHD.Text = row.Cells["NoiDung"].Value?.ToString();
            }
        }

        // ==================== TAB 2: QUYẾT ĐỊNH CHỨC VỤ ====================

        private void TaiDanhSachChucVu()
        {
            string sql = @"SELECT cv.MaQDCV, nv.HoTen, cv.ChucVu, cv.PhuCapChucVu, cv.NgayHieuLuc, cv.LyDo, cv.MaNV
                           FROM QuyetDinhChucVu cv
                           JOIN NhanVien nv ON cv.MaNV = nv.MaNV";
            DataTable dt = Db.LayDuLieu(sql);
            dgvChucVu.DataSource = dt;

            dgvChucVu.Columns["MaQDCV"].HeaderText = "Mã QĐCV";
            dgvChucVu.Columns["HoTen"].HeaderText = "Nhân viên";
            dgvChucVu.Columns["ChucVu"].HeaderText = "Chức vụ";
            dgvChucVu.Columns["PhuCapChucVu"].HeaderText = "Phụ cấp CV";
            dgvChucVu.Columns["NgayHieuLuc"].HeaderText = "Hiệu lực";
            dgvChucVu.Columns["LyDo"].HeaderText = "Lý do bổ nhiệm";
            dgvChucVu.Columns["PhuCapChucVu"].DefaultCellStyle.Format = "N0";
            dgvChucVu.Columns["MaNV"].Visible = false;
        }

        private void btnLapQDCV_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtMaQDCV.Text.Trim()) || cboNV_CV.SelectedValue == null)
            {
                MessageBox.Show("Vui lòng nhập Mã QĐ và chọn Nhân viên!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            decimal.TryParse(txtPhuCapCV.Text.Replace(",", "").Replace(".", "").Trim(), out decimal pcCV);

            string sql = @"INSERT INTO QuyetDinhChucVu (MaQDCV, MaNV, ChucVu, PhuCapChucVu, NgayHieuLuc, LyDo)
                           VALUES (@MaQDCV, @MaNV, @ChucVu, @PhuCapCV, @NgayHL, @LyDo)";

            SqlParameter[] prms = new SqlParameter[]
            {
                new SqlParameter("@MaQDCV", txtMaQDCV.Text.Trim()),
                new SqlParameter("@MaNV", cboNV_CV.SelectedValue),
                new SqlParameter("@ChucVu", txtChucVu.Text.Trim()),
                new SqlParameter("@PhuCapCV", pcCV),
                new SqlParameter("@NgayHL", dtpNgayHLCV.Value),
                new SqlParameter("@LyDo", txtLyDoCV.Text.Trim())
            };

            try
            {
                Db.ThucThi(sql, prms);
                MessageBox.Show("Lập Quyết định Chức vụ thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                TaiDanhSachChucVu();
                btnLamMoiCV_Click(null, null);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnSuaCV_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtMaQDCV.Text.Trim())) return;
            decimal.TryParse(txtPhuCapCV.Text.Replace(",", "").Replace(".", "").Trim(), out decimal pcCV);

            string sql = @"UPDATE QuyetDinhChucVu 
                           SET ChucVu = @ChucVu, PhuCapChucVu = @PhuCapCV, NgayHieuLuc = @NgayHL, LyDo = @LyDo
                           WHERE MaQDCV = @MaQDCV";

            SqlParameter[] prms = new SqlParameter[]
            {
                new SqlParameter("@MaQDCV", txtMaQDCV.Text.Trim()),
                new SqlParameter("@ChucVu", txtChucVu.Text.Trim()),
                new SqlParameter("@PhuCapCV", pcCV),
                new SqlParameter("@NgayHL", dtpNgayHLCV.Value),
                new SqlParameter("@LyDo", txtLyDoCV.Text.Trim())
            };

            try
            {
                Db.ThucThi(sql, prms);
                MessageBox.Show("Cập nhật QĐ chức vụ thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                TaiDanhSachChucVu();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnXoaCV_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtMaQDCV.Text.Trim())) return;
            if (MessageBox.Show("Xóa quyết định chức vụ này?", "Xác nhận", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                Db.ThucThi("DELETE FROM QuyetDinhChucVu WHERE MaQDCV = @Ma", new SqlParameter[] { new SqlParameter("@Ma", txtMaQDCV.Text.Trim()) });
                TaiDanhSachChucVu();
                btnLamMoiCV_Click(null, null);
            }
        }

        private void btnLamMoiCV_Click(object sender, EventArgs e)
        {
            // Sửa còn đúng 10 ký tự: "CV" + 8 chữ số
            txtMaQDCV.Text = "CV" + DateTime.Now.ToString("ddHHmmss");
            txtChucVu.Text = "Kỹ thuật viên";
            txtPhuCapCV.Text = "500000";
            dtpNgayHLCV.Value = DateTime.Now;
            txtLyDoCV.Text = "Bổ nhiệm sau thử việc đạt yêu cầu.";
        }

        private void dgvChucVu_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvChucVu.CurrentRow != null && dgvChucVu.CurrentRow.Index >= 0)
            {
                DataGridViewRow row = dgvChucVu.CurrentRow;
                txtMaQDCV.Text = row.Cells["MaQDCV"].Value?.ToString();
                cboNV_CV.SelectedValue = row.Cells["MaNV"].Value?.ToString();
                txtChucVu.Text = row.Cells["ChucVu"].Value?.ToString();
                txtPhuCapCV.Text = row.Cells["PhuCapChucVu"].Value?.ToString();
                if (DateTime.TryParse(row.Cells["NgayHieuLuc"].Value?.ToString(), out DateTime nhl)) dtpNgayHLCV.Value = nhl;
                txtLyDoCV.Text = row.Cells["LyDo"].Value?.ToString();
            }
        }

        // ==================== TAB 3: QUYẾT ĐỊNH LƯƠNG ====================

        private void TaiDanhSachLuong()
        {
            string sql = @"SELECT l.MaQDL, nv.HoTen, l.LuongCoBan, l.PhuCapLuong, l.PhuCapDocHai, l.NgayHieuLuc, l.MaNV
                           FROM QuyetDinhLuong l
                           JOIN NhanVien nv ON l.MaNV = nv.MaNV";
            DataTable dt = Db.LayDuLieu(sql);
            dgvLuong.DataSource = dt;

            dgvLuong.Columns["MaQDL"].HeaderText = "Mã QĐL";
            dgvLuong.Columns["HoTen"].HeaderText = "Nhân viên";
            dgvLuong.Columns["LuongCoBan"].HeaderText = "Lương cơ bản";
            dgvLuong.Columns["PhuCapLuong"].HeaderText = "Phụ cấp lương";
            dgvLuong.Columns["PhuCapDocHai"].HeaderText = "PC Độc hại";
            dgvLuong.Columns["NgayHieuLuc"].HeaderText = "Hiệu lực";
            dgvLuong.Columns["LuongCoBan"].DefaultCellStyle.Format = "N0";
            dgvLuong.Columns["PhuCapLuong"].DefaultCellStyle.Format = "N0";
            dgvLuong.Columns["PhuCapDocHai"].DefaultCellStyle.Format = "N0";
            dgvLuong.Columns["MaNV"].Visible = false;
        }

        private void btnLapQDL_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtMaQDL.Text.Trim()) || cboNV_Luong.SelectedValue == null)
            {
                MessageBox.Show("Vui lòng nhập Mã QĐL và chọn Nhân viên!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            decimal.TryParse(txtLuongCoBan.Text.Replace(",", "").Replace(".", "").Trim(), out decimal lcb);
            decimal.TryParse(txtPhuCapLuong.Text.Replace(",", "").Replace(".", "").Trim(), out decimal pcl);
            decimal.TryParse(txtPhuCapDocHai.Text.Replace(",", "").Replace(".", "").Trim(), out decimal pcdh);

            string sql = @"INSERT INTO QuyetDinhLuong (MaQDL, MaNV, LuongCoBan, PhuCapLuong, PhuCapDocHai, NgayHieuLuc)
                           VALUES (@MaQDL, @MaNV, @LCB, @PCL, @PCDH, @NgayHL)";

            SqlParameter[] prms = new SqlParameter[]
            {
                new SqlParameter("@MaQDL", txtMaQDL.Text.Trim()),
                new SqlParameter("@MaNV", cboNV_Luong.SelectedValue),
                new SqlParameter("@LCB", lcb),
                new SqlParameter("@PCL", pcl),
                new SqlParameter("@PCDH", pcdh),
                new SqlParameter("@NgayHL", dtpNgayHLLuong.Value)
            };

            try
            {
                Db.ThucThi(sql, prms);
                MessageBox.Show("Lập Quyết định Lương thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                TaiDanhSachLuong();
                btnLamMoiLuong_Click(null, null);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnSuaLuong_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtMaQDL.Text.Trim())) return;
            decimal.TryParse(txtLuongCoBan.Text.Replace(",", "").Replace(".", "").Trim(), out decimal lcb);
            decimal.TryParse(txtPhuCapLuong.Text.Replace(",", "").Replace(".", "").Trim(), out decimal pcl);
            decimal.TryParse(txtPhuCapDocHai.Text.Replace(",", "").Replace(".", "").Trim(), out decimal pcdh);

            string sql = @"UPDATE QuyetDinhLuong 
                           SET LuongCoBan = @LCB, PhuCapLuong = @PCL, PhuCapDocHai = @PCDH, NgayHieuLuc = @NgayHL
                           WHERE MaQDL = @MaQDL";

            SqlParameter[] prms = new SqlParameter[]
            {
                new SqlParameter("@MaQDL", txtMaQDL.Text.Trim()),
                new SqlParameter("@LCB", lcb),
                new SqlParameter("@PCL", pcl),
                new SqlParameter("@PCDH", pcdh),
                new SqlParameter("@NgayHL", dtpNgayHLLuong.Value)
            };

            try
            {
                Db.ThucThi(sql, prms);
                MessageBox.Show("Cập nhật quyết định lương thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                TaiDanhSachLuong();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnXoaLuong_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtMaQDL.Text.Trim())) return;
            if (MessageBox.Show("Xóa quyết định lương này?", "Xác nhận", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                Db.ThucThi("DELETE FROM QuyetDinhLuong WHERE MaQDL = @Ma", new SqlParameter[] { new SqlParameter("@Ma", txtMaQDL.Text.Trim()) });
                TaiDanhSachLuong();
                btnLamMoiLuong_Click(null, null);
            }
        }

        private void btnLamMoiLuong_Click(object sender, EventArgs e)
        {
            // Sửa còn đúng 10 ký tự: "QL" + 8 chữ số
            txtMaQDL.Text = "QL" + DateTime.Now.ToString("ddHHmmss");
            txtLuongCoBan.Text = "6000000";
            txtPhuCapLuong.Text = "0";
            txtPhuCapDocHai.Text = "300000";
            dtpNgayHLLuong.Value = DateTime.Now;
        }

        private void dgvLuong_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvLuong.CurrentRow != null && dgvLuong.CurrentRow.Index >= 0)
            {
                DataGridViewRow row = dgvLuong.CurrentRow;
                txtMaQDL.Text = row.Cells["MaQDL"].Value?.ToString();
                cboNV_Luong.SelectedValue = row.Cells["MaNV"].Value?.ToString();
                txtLuongCoBan.Text = row.Cells["LuongCoBan"].Value?.ToString();
                txtPhuCapLuong.Text = row.Cells["PhuCapLuong"].Value?.ToString();
                txtPhuCapDocHai.Text = row.Cells["PhuCapDocHai"].Value?.ToString();
                if (DateTime.TryParse(row.Cells["NgayHieuLuc"].Value?.ToString(), out DateTime nhl)) dtpNgayHLLuong.Value = nhl;
            }
        }

        // ==================== TAB 4: HỒ SƠ BẢO HIỂM ====================

        private void TaiDanhSachBaoHiem()
        {
            string sql = @"SELECT bh.MaBH, nv.HoTen, bh.SoTheBHYT, bh.SoSoBHXH, 
                                  bh.TyLeDongNV, bh.TyLeDongCT, bh.NgayThamGia, bh.MaNV
                           FROM BaoHiem bh
                           JOIN NhanVien nv ON bh.MaNV = nv.MaNV";
            DataTable dt = Db.LayDuLieu(sql);
            dgvBaoHiem.DataSource = dt;

            dgvBaoHiem.Columns["MaBH"].HeaderText = "Mã BH";
            dgvBaoHiem.Columns["HoTen"].HeaderText = "Nhân viên";
            dgvBaoHiem.Columns["SoTheBHYT"].HeaderText = "Thẻ BHYT";
            dgvBaoHiem.Columns["SoSoBHXH"].HeaderText = "Sổ BHXH";
            dgvBaoHiem.Columns["TyLeDongNV"].HeaderText = "% NV đóng";
            dgvBaoHiem.Columns["TyLeDongCT"].HeaderText = "% Cty đóng";
            dgvBaoHiem.Columns["NgayThamGia"].HeaderText = "Ngày tham gia";
            dgvBaoHiem.Columns["MaNV"].Visible = false;
        }

        private void btnLapBH_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtMaBH.Text.Trim()) || cboNV_BH.SelectedValue == null)
            {
                MessageBox.Show("Vui lòng nhập Mã BH và chọn Nhân viên!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Xử lý chống nhảy số tỷ lệ % do khác văn hóa máy tính
            string strTyLeNV = txtTyLeNV.Text.Trim().Replace(',', '.');
            decimal.TryParse(strTyLeNV, NumberStyles.Any, CultureInfo.InvariantCulture, out decimal tlNV);

            string strTyLeCT = txtTyLeCT.Text.Trim().Replace(',', '.');
            decimal.TryParse(strTyLeCT, NumberStyles.Any, CultureInfo.InvariantCulture, out decimal tlCT);

            string sql = @"INSERT INTO BaoHiem (MaBH, MaNV, SoTheBHYT, SoSoBHXH, TyLeDongNV, TyLeDongCT, NgayThamGia)
                           VALUES (@MaBH, @MaNV, @BHYT, @BHXH, @TyLeNV, @TyLeCT, @NgayTG)";

            SqlParameter[] prms = new SqlParameter[]
            {
                new SqlParameter("@MaBH", txtMaBH.Text.Trim()),
                new SqlParameter("@MaNV", cboNV_BH.SelectedValue),
                new SqlParameter("@BHYT", txtSoTheBHYT.Text.Trim()),
                new SqlParameter("@BHXH", txtSoSoBHXH.Text.Trim()),
                new SqlParameter("@TyLeNV", tlNV),
                new SqlParameter("@TyLeCT", tlCT),
                new SqlParameter("@NgayTG", dtpNgayThamGia.Value)
            };

            try
            {
                Db.ThucThi(sql, prms);
                MessageBox.Show("Lập hồ sơ Bảo hiểm thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                TaiDanhSachBaoHiem();
                btnLamMoiBH_Click(null, null);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi lập bảo hiểm: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnSuaBH_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtMaBH.Text.Trim())) return;

            string strTyLeNV = txtTyLeNV.Text.Trim().Replace(',', '.');
            decimal.TryParse(strTyLeNV, NumberStyles.Any, CultureInfo.InvariantCulture, out decimal tlNV);

            string strTyLeCT = txtTyLeCT.Text.Trim().Replace(',', '.');
            decimal.TryParse(strTyLeCT, NumberStyles.Any, CultureInfo.InvariantCulture, out decimal tlCT);

            string sql = @"UPDATE BaoHiem 
                           SET SoTheBHYT = @BHYT, SoSoBHXH = @BHXH, TyLeDongNV = @TyLeNV, 
                               TyLeDongCT = @TyLeCT, NgayThamGia = @NgayTG
                           WHERE MaBH = @MaBH";

            SqlParameter[] prms = new SqlParameter[]
            {
                new SqlParameter("@MaBH", txtMaBH.Text.Trim()),
                new SqlParameter("@BHYT", txtSoTheBHYT.Text.Trim()),
                new SqlParameter("@BHXH", txtSoSoBHXH.Text.Trim()),
                new SqlParameter("@TyLeNV", tlNV),
                new SqlParameter("@TyLeCT", tlCT),
                new SqlParameter("@NgayTG", dtpNgayThamGia.Value)
            };

            try
            {
                Db.ThucThi(sql, prms);
                MessageBox.Show("Cập nhật hồ sơ bảo hiểm thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                TaiDanhSachBaoHiem();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnXoaBH_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtMaBH.Text.Trim())) return;
            if (MessageBox.Show("Xóa hồ sơ bảo hiểm này?", "Xác nhận", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                Db.ThucThi("DELETE FROM BaoHiem WHERE MaBH = @Ma", new SqlParameter[] { new SqlParameter("@Ma", txtMaBH.Text.Trim()) });
                TaiDanhSachBaoHiem();
                btnLamMoiBH_Click(null, null);
            }
        }

        private void btnLamMoiBH_Click(object sender, EventArgs e)
        {
            // Sửa còn đúng 10 ký tự: "BH" + 8 chữ số
            txtMaBH.Text = "BH" + DateTime.Now.ToString("ddHHmmss");
            txtSoTheBHYT.Text = "DN479" + DateTime.Now.ToString("yyMMdd");
            txtSoSoBHXH.Text = "79" + DateTime.Now.ToString("yyMMddHH");
            txtTyLeNV.Text = "10.5";
            txtTyLeCT.Text = "21.5";
            dtpNgayThamGia.Value = DateTime.Now;
        }

        private void dgvBaoHiem_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvBaoHiem.CurrentRow != null && dgvBaoHiem.CurrentRow.Index >= 0)
            {
                DataGridViewRow row = dgvBaoHiem.CurrentRow;
                txtMaBH.Text = row.Cells["MaBH"].Value?.ToString();
                cboNV_BH.SelectedValue = row.Cells["MaNV"].Value?.ToString();
                txtSoTheBHYT.Text = row.Cells["SoTheBHYT"].Value?.ToString();
                txtSoSoBHXH.Text = row.Cells["SoSoBHXH"].Value?.ToString();
                txtTyLeNV.Text = row.Cells["TyLeDongNV"].Value?.ToString();
                txtTyLeCT.Text = row.Cells["TyLeDongCT"].Value?.ToString();
                if (DateTime.TryParse(row.Cells["NgayThamGia"].Value?.ToString(), out DateTime ntg)) dtpNgayThamGia.Value = ntg;
            }
        }

        private void btnDong_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}