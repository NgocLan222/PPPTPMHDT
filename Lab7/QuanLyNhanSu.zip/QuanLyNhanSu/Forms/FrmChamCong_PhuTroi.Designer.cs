﻿namespace QuanLyNhanSu.Forms
{
    partial class FrmChamCong_PhuTroi
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblTieuDe = new System.Windows.Forms.Label();
            this.tabChamCongPhuTroi = new System.Windows.Forms.TabControl();
            this.tabKeHoach = new System.Windows.Forms.TabPage();
            this.dgvKeHoach = new System.Windows.Forms.DataGridView();
            this.grpThongTinKH = new System.Windows.Forms.GroupBox();
            this.btnLamMoiKH = new System.Windows.Forms.Button();
            this.btnXoaKH = new System.Windows.Forms.Button();
            this.btnSuaKH = new System.Windows.Forms.Button();
            this.btnLapKH = new System.Windows.Forms.Button();
            this.dtpNgayLap = new System.Windows.Forms.DateTimePicker();
            this.lblNgayLap = new System.Windows.Forms.Label();
            this.txtNguoiLap = new System.Windows.Forms.TextBox();
            this.lblNguoiLap = new System.Windows.Forms.Label();
            this.dtpDenNgay = new System.Windows.Forms.DateTimePicker();
            this.lblDenNgay = new System.Windows.Forms.Label();
            this.dtpTuNgay = new System.Windows.Forms.DateTimePicker();
            this.lblTuNgay = new System.Windows.Forms.Label();
            this.cboPB_KH = new System.Windows.Forms.ComboBox();
            this.lblPB_KH = new System.Windows.Forms.Label();
            this.txtMaKH = new System.Windows.Forms.TextBox();
            this.lblMaKH = new System.Windows.Forms.Label();
            this.tabChamCong = new System.Windows.Forms.TabPage();
            this.dgvChamCong = new System.Windows.Forms.DataGridView();
            this.grpThongTinCC = new System.Windows.Forms.GroupBox();
            this.btnLamMoiCC = new System.Windows.Forms.Button();
            this.btnXoaCC = new System.Windows.Forms.Button();
            this.btnSuaCC = new System.Windows.Forms.Button();
            this.btnGhiNhanCC = new System.Windows.Forms.Button();
            this.txtNghiKhongPhep = new System.Windows.Forms.TextBox();
            this.lblNghiKhongPhep = new System.Windows.Forms.Label();
            this.txtNghiCoPhep = new System.Windows.Forms.TextBox();
            this.lblNghiCoPhep = new System.Windows.Forms.Label();
            this.txtDiLam = new System.Windows.Forms.TextBox();
            this.lblDiLam = new System.Windows.Forms.Label();
            this.txtCongChuan = new System.Windows.Forms.TextBox();
            this.lblCongChuan = new System.Windows.Forms.Label();
            this.cboNam = new System.Windows.Forms.ComboBox();
            this.lblNam = new System.Windows.Forms.Label();
            this.cboThang = new System.Windows.Forms.ComboBox();
            this.lblThang = new System.Windows.Forms.Label();
            this.cboNV_CC = new System.Windows.Forms.ComboBox();
            this.lblNV_CC = new System.Windows.Forms.Label();
            this.txtMaCC = new System.Windows.Forms.TextBox();
            this.lblMaCC = new System.Windows.Forms.Label();
            this.tabPhuTroi = new System.Windows.Forms.TabPage();
            this.grpChiTietPT = new System.Windows.Forms.GroupBox();
            this.btnXoaCTPT = new System.Windows.Forms.Button();
            this.btnThemCTPT = new System.Windows.Forms.Button();
            this.txtCongViec = new System.Windows.Forms.TextBox();
            this.lblCongViec = new System.Windows.Forms.Label();
            this.txtSoGioPT = new System.Windows.Forms.TextBox();
            this.lblSoGioPT = new System.Windows.Forms.Label();
            this.cboNV_PT = new System.Windows.Forms.ComboBox();
            this.lblNV_PT = new System.Windows.Forms.Label();
            this.dgvChiTietPT = new System.Windows.Forms.DataGridView();
            this.dgvPhieuPT = new System.Windows.Forms.DataGridView();
            this.grpPhieuPT = new System.Windows.Forms.GroupBox();
            this.btnLamMoiPPT = new System.Windows.Forms.Button();
            this.btnXoaPPT = new System.Windows.Forms.Button();
            this.btnLapPPT = new System.Windows.Forms.Button();
            this.txtNguoiXacNhan = new System.Windows.Forms.TextBox();
            this.lblNguoiXacNhan = new System.Windows.Forms.Label();
            this.txtHeSo = new System.Windows.Forms.TextBox();
            this.lblHeSo = new System.Windows.Forms.Label();
            this.cboHinhThucPT = new System.Windows.Forms.ComboBox();
            this.lblHinhThucPT = new System.Windows.Forms.Label();
            this.dtpNgayPT = new System.Windows.Forms.DateTimePicker();
            this.lblNgayPT = new System.Windows.Forms.Label();
            this.cboPB_PPT = new System.Windows.Forms.ComboBox();
            this.lblPB_PPT = new System.Windows.Forms.Label();
            this.txtMaPPT = new System.Windows.Forms.TextBox();
            this.lblMaPPT = new System.Windows.Forms.Label();
            this.btnDong = new System.Windows.Forms.Button();
            this.tabChamCongPhuTroi.SuspendLayout();
            this.tabKeHoach.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvKeHoach)).BeginInit();
            this.grpThongTinKH.SuspendLayout();
            this.tabChamCong.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvChamCong)).BeginInit();
            this.grpThongTinCC.SuspendLayout();
            this.tabPhuTroi.SuspendLayout();
            this.grpChiTietPT.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvChiTietPT)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPhieuPT)).BeginInit();
            this.grpPhieuPT.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblTieuDe
            // 
            this.lblTieuDe.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblTieuDe.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold);
            this.lblTieuDe.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.lblTieuDe.Location = new System.Drawing.Point(0, 0);
            this.lblTieuDe.Name = "lblTieuDe";
            this.lblTieuDe.Size = new System.Drawing.Size(1024, 50);
            this.lblTieuDe.TabIndex = 0;
            this.lblTieuDe.Text = "KẾ HOẠCH PHÂN CÔNG - CHẤM CÔNG - GIỜ LÀM PHỤ TRỘI";
            this.lblTieuDe.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tabChamCongPhuTroi
            // 
            this.tabChamCongPhuTroi.Controls.Add(this.tabKeHoach);
            this.tabChamCongPhuTroi.Controls.Add(this.tabChamCong);
            this.tabChamCongPhuTroi.Controls.Add(this.tabPhuTroi);
            this.tabChamCongPhuTroi.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.tabChamCongPhuTroi.Location = new System.Drawing.Point(12, 55);
            this.tabChamCongPhuTroi.Name = "tabChamCongPhuTroi";
            this.tabChamCongPhuTroi.SelectedIndex = 0;
            this.tabChamCongPhuTroi.Size = new System.Drawing.Size(1000, 595);
            this.tabChamCongPhuTroi.TabIndex = 1;
            // 
            // tabKeHoach
            // 
            this.tabKeHoach.Controls.Add(this.dgvKeHoach);
            this.tabKeHoach.Controls.Add(this.grpThongTinKH);
            this.tabKeHoach.Location = new System.Drawing.Point(4, 32);
            this.tabKeHoach.Name = "tabKeHoach";
            this.tabKeHoach.Padding = new System.Windows.Forms.Padding(3);
            this.tabKeHoach.Size = new System.Drawing.Size(992, 559);
            this.tabKeHoach.TabIndex = 0;
            this.tabKeHoach.Text = "1. Kế hoạch phân công tuần";
            this.tabKeHoach.UseVisualStyleBackColor = true;
            // 
            // dgvKeHoach
            // 
            this.dgvKeHoach.AllowUserToAddRows = false;
            this.dgvKeHoach.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvKeHoach.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvKeHoach.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.dgvKeHoach.Location = new System.Drawing.Point(15, 215);
            this.dgvKeHoach.Name = "dgvKeHoach";
            this.dgvKeHoach.ReadOnly = true;
            this.dgvKeHoach.RowHeadersWidth = 35;
            this.dgvKeHoach.RowTemplate.Height = 24;
            this.dgvKeHoach.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvKeHoach.Size = new System.Drawing.Size(960, 325);
            this.dgvKeHoach.TabIndex = 1;
            this.dgvKeHoach.SelectionChanged += new System.EventHandler(this.dgvKeHoach_SelectionChanged);
            // 
            // grpThongTinKH
            // 
            this.grpThongTinKH.Controls.Add(this.btnLamMoiKH);
            this.grpThongTinKH.Controls.Add(this.btnXoaKH);
            this.grpThongTinKH.Controls.Add(this.btnSuaKH);
            this.grpThongTinKH.Controls.Add(this.btnLapKH);
            this.grpThongTinKH.Controls.Add(this.dtpNgayLap);
            this.grpThongTinKH.Controls.Add(this.lblNgayLap);
            this.grpThongTinKH.Controls.Add(this.txtNguoiLap);
            this.grpThongTinKH.Controls.Add(this.lblNguoiLap);
            this.grpThongTinKH.Controls.Add(this.dtpDenNgay);
            this.grpThongTinKH.Controls.Add(this.lblDenNgay);
            this.grpThongTinKH.Controls.Add(this.dtpTuNgay);
            this.grpThongTinKH.Controls.Add(this.lblTuNgay);
            this.grpThongTinKH.Controls.Add(this.cboPB_KH);
            this.grpThongTinKH.Controls.Add(this.lblPB_KH);
            this.grpThongTinKH.Controls.Add(this.txtMaKH);
            this.grpThongTinKH.Controls.Add(this.lblMaKH);
            this.grpThongTinKH.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.grpThongTinKH.Location = new System.Drawing.Point(15, 10);
            this.grpThongTinKH.Name = "grpThongTinKH";
            this.grpThongTinKH.Size = new System.Drawing.Size(960, 190);
            this.grpThongTinKH.TabIndex = 0;
            this.grpThongTinKH.TabStop = false;
            this.grpThongTinKH.Text = "Kế hoạch phân ca làm việc của Trưởng phòng ban";
            // 
            // btnLamMoiKH
            // 
            this.btnLamMoiKH.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnLamMoiKH.Location = new System.Drawing.Point(600, 135);
            this.btnLamMoiKH.Name = "btnLamMoiKH";
            this.btnLamMoiKH.Size = new System.Drawing.Size(110, 35);
            this.btnLamMoiKH.TabIndex = 15;
            this.btnLamMoiKH.Text = "Làm mới";
            this.btnLamMoiKH.UseVisualStyleBackColor = true;
            this.btnLamMoiKH.Click += new System.EventHandler(this.btnLamMoiKH_Click);
            // 
            // btnXoaKH
            // 
            this.btnXoaKH.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnXoaKH.ForeColor = System.Drawing.Color.DarkRed;
            this.btnXoaKH.Location = new System.Drawing.Point(475, 135);
            this.btnXoaKH.Name = "btnXoaKH";
            this.btnXoaKH.Size = new System.Drawing.Size(110, 35);
            this.btnXoaKH.TabIndex = 14;
            this.btnXoaKH.Text = "Xóa";
            this.btnXoaKH.UseVisualStyleBackColor = true;
            this.btnXoaKH.Click += new System.EventHandler(this.btnXoaKH_Click);
            // 
            // btnSuaKH
            // 
            this.btnSuaKH.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnSuaKH.Location = new System.Drawing.Point(345, 135);
            this.btnSuaKH.Name = "btnSuaKH";
            this.btnSuaKH.Size = new System.Drawing.Size(115, 35);
            this.btnSuaKH.TabIndex = 13;
            this.btnSuaKH.Text = "Cập nhật";
            this.btnSuaKH.UseVisualStyleBackColor = true;
            this.btnSuaKH.Click += new System.EventHandler(this.btnSuaKH_Click);
            // 
            // btnLapKH
            // 
            this.btnLapKH.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.btnLapKH.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.btnLapKH.Location = new System.Drawing.Point(175, 135);
            this.btnLapKH.Name = "btnLapKH";
            this.btnLapKH.Size = new System.Drawing.Size(155, 35);
            this.btnLapKH.TabIndex = 12;
            this.btnLapKH.Text = "+ Lập kế hoạch";
            this.btnLapKH.UseVisualStyleBackColor = true;
            this.btnLapKH.Click += new System.EventHandler(this.btnLapKH_Click);
            // 
            // dtpNgayLap
            // 
            this.dtpNgayLap.CustomFormat = "dd/MM/yyyy";
            this.dtpNgayLap.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.dtpNgayLap.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpNgayLap.Location = new System.Drawing.Point(740, 75);
            this.dtpNgayLap.Name = "dtpNgayLap";
            this.dtpNgayLap.Size = new System.Drawing.Size(190, 29);
            this.dtpNgayLap.TabIndex = 11;
            // 
            // lblNgayLap
            // 
            this.lblNgayLap.AutoSize = true;
            this.lblNgayLap.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblNgayLap.Location = new System.Drawing.Point(645, 80);
            this.lblNgayLap.Name = "lblNgayLap";
            this.lblNgayLap.Size = new System.Drawing.Size(75, 21);
            this.lblNgayLap.TabIndex = 10;
            this.lblNgayLap.Text = "Ngày lập:";
            // 
            // txtNguoiLap
            // 
            this.txtNguoiLap.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtNguoiLap.Location = new System.Drawing.Point(420, 75);
            this.txtNguoiLap.Name = "txtNguoiLap";
            this.txtNguoiLap.Size = new System.Drawing.Size(200, 29);
            this.txtNguoiLap.TabIndex = 9;
            // 
            // lblNguoiLap
            // 
            this.lblNguoiLap.AutoSize = true;
            this.lblNguoiLap.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblNguoiLap.Location = new System.Drawing.Point(325, 80);
            this.lblNguoiLap.Name = "lblNguoiLap";
            this.lblNguoiLap.Size = new System.Drawing.Size(82, 21);
            this.lblNguoiLap.TabIndex = 8;
            this.lblNguoiLap.Text = "Người lập:";
            // 
            // dtpDenNgay
            // 
            this.dtpDenNgay.CustomFormat = "dd/MM/yyyy";
            this.dtpDenNgay.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.dtpDenNgay.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpDenNgay.Location = new System.Drawing.Point(120, 75);
            this.dtpDenNgay.Name = "dtpDenNgay";
            this.dtpDenNgay.Size = new System.Drawing.Size(180, 29);
            this.dtpDenNgay.TabIndex = 7;
            // 
            // lblDenNgay
            // 
            this.lblDenNgay.AutoSize = true;
            this.lblDenNgay.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblDenNgay.Location = new System.Drawing.Point(15, 80);
            this.lblDenNgay.Name = "lblDenNgay";
            this.lblDenNgay.Size = new System.Drawing.Size(79, 21);
            this.lblDenNgay.TabIndex = 6;
            this.lblDenNgay.Text = "Đến ngày:";
            // 
            // dtpTuNgay
            // 
            this.dtpTuNgay.CustomFormat = "dd/MM/yyyy";
            this.dtpTuNgay.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.dtpTuNgay.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpTuNgay.Location = new System.Drawing.Point(740, 30);
            this.dtpTuNgay.Name = "dtpTuNgay";
            this.dtpTuNgay.Size = new System.Drawing.Size(190, 29);
            this.dtpTuNgay.TabIndex = 5;
            // 
            // lblTuNgay
            // 
            this.lblTuNgay.AutoSize = true;
            this.lblTuNgay.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblTuNgay.Location = new System.Drawing.Point(645, 35);
            this.lblTuNgay.Name = "lblTuNgay";
            this.lblTuNgay.Size = new System.Drawing.Size(68, 21);
            this.lblTuNgay.TabIndex = 4;
            this.lblTuNgay.Text = "Từ ngày:";
            // 
            // cboPB_KH
            // 
            this.cboPB_KH.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboPB_KH.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.cboPB_KH.FormattingEnabled = true;
            this.cboPB_KH.Location = new System.Drawing.Point(420, 30);
            this.cboPB_KH.Name = "cboPB_KH";
            this.cboPB_KH.Size = new System.Drawing.Size(200, 29);
            this.cboPB_KH.TabIndex = 3;
            // 
            // lblPB_KH
            // 
            this.lblPB_KH.AutoSize = true;
            this.lblPB_KH.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblPB_KH.Location = new System.Drawing.Point(325, 35);
            this.lblPB_KH.Name = "lblPB_KH";
            this.lblPB_KH.Size = new System.Drawing.Size(89, 21);
            this.lblPB_KH.TabIndex = 2;
            this.lblPB_KH.Text = "Phòng ban:";
            // 
            // txtMaKH
            // 
            this.txtMaKH.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtMaKH.Location = new System.Drawing.Point(120, 30);
            this.txtMaKH.Name = "txtMaKH";
            this.txtMaKH.Size = new System.Drawing.Size(180, 29);
            this.txtMaKH.TabIndex = 1;
            // 
            // lblMaKH
            // 
            this.lblMaKH.AutoSize = true;
            this.lblMaKH.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblMaKH.Location = new System.Drawing.Point(15, 35);
            this.lblMaKH.Name = "lblMaKH";
            this.lblMaKH.Size = new System.Drawing.Size(60, 21);
            this.lblMaKH.TabIndex = 0;
            this.lblMaKH.Text = "Mã KH:";
            // 
            // tabChamCong
            // 
            this.tabChamCong.Controls.Add(this.dgvChamCong);
            this.tabChamCong.Controls.Add(this.grpThongTinCC);
            this.tabChamCong.Location = new System.Drawing.Point(4, 32);
            this.tabChamCong.Name = "tabChamCong";
            this.tabChamCong.Padding = new System.Windows.Forms.Padding(3);
            this.tabChamCong.Size = new System.Drawing.Size(992, 559);
            this.tabChamCong.TabIndex = 1;
            this.tabChamCong.Text = "2. Chấm công định kỳ";
            this.tabChamCong.UseVisualStyleBackColor = true;
            // 
            // dgvChamCong
            // 
            this.dgvChamCong.AllowUserToAddRows = false;
            this.dgvChamCong.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvChamCong.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvChamCong.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.dgvChamCong.Location = new System.Drawing.Point(15, 220);
            this.dgvChamCong.Name = "dgvChamCong";
            this.dgvChamCong.ReadOnly = true;
            this.dgvChamCong.RowHeadersWidth = 35;
            this.dgvChamCong.RowTemplate.Height = 24;
            this.dgvChamCong.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvChamCong.Size = new System.Drawing.Size(960, 320);
            this.dgvChamCong.TabIndex = 1;
            this.dgvChamCong.SelectionChanged += new System.EventHandler(this.dgvChamCong_SelectionChanged);
            // 
            // grpThongTinCC
            // 
            this.grpThongTinCC.Controls.Add(this.btnLamMoiCC);
            this.grpThongTinCC.Controls.Add(this.btnXoaCC);
            this.grpThongTinCC.Controls.Add(this.btnSuaCC);
            this.grpThongTinCC.Controls.Add(this.btnGhiNhanCC);
            this.grpThongTinCC.Controls.Add(this.txtNghiKhongPhep);
            this.grpThongTinCC.Controls.Add(this.lblNghiKhongPhep);
            this.grpThongTinCC.Controls.Add(this.txtNghiCoPhep);
            this.grpThongTinCC.Controls.Add(this.lblNghiCoPhep);
            this.grpThongTinCC.Controls.Add(this.txtDiLam);
            this.grpThongTinCC.Controls.Add(this.lblDiLam);
            this.grpThongTinCC.Controls.Add(this.txtCongChuan);
            this.grpThongTinCC.Controls.Add(this.lblCongChuan);
            this.grpThongTinCC.Controls.Add(this.cboNam);
            this.grpThongTinCC.Controls.Add(this.lblNam);
            this.grpThongTinCC.Controls.Add(this.cboThang);
            this.grpThongTinCC.Controls.Add(this.lblThang);
            this.grpThongTinCC.Controls.Add(this.cboNV_CC);
            this.grpThongTinCC.Controls.Add(this.lblNV_CC);
            this.grpThongTinCC.Controls.Add(this.txtMaCC);
            this.grpThongTinCC.Controls.Add(this.lblMaCC);
            this.grpThongTinCC.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.grpThongTinCC.Location = new System.Drawing.Point(15, 10);
            this.grpThongTinCC.Name = "grpThongTinCC";
            this.grpThongTinCC.Size = new System.Drawing.Size(960, 195);
            this.grpThongTinCC.TabIndex = 0;
            this.grpThongTinCC.TabStop = false;
            this.grpThongTinCC.Text = "Ghi nhận ngày công tháng của Ban chấm công";
            // 
            // btnLamMoiCC
            // 
            this.btnLamMoiCC.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnLamMoiCC.Location = new System.Drawing.Point(600, 145);
            this.btnLamMoiCC.Name = "btnLamMoiCC";
            this.btnLamMoiCC.Size = new System.Drawing.Size(110, 35);
            this.btnLamMoiCC.TabIndex = 19;
            this.btnLamMoiCC.Text = "Làm mới";
            this.btnLamMoiCC.UseVisualStyleBackColor = true;
            this.btnLamMoiCC.Click += new System.EventHandler(this.btnLamMoiCC_Click);
            // 
            // btnXoaCC
            // 
            this.btnXoaCC.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnXoaCC.ForeColor = System.Drawing.Color.DarkRed;
            this.btnXoaCC.Location = new System.Drawing.Point(475, 145);
            this.btnXoaCC.Name = "btnXoaCC";
            this.btnXoaCC.Size = new System.Drawing.Size(110, 35);
            this.btnXoaCC.TabIndex = 18;
            this.btnXoaCC.Text = "Xóa";
            this.btnXoaCC.UseVisualStyleBackColor = true;
            this.btnXoaCC.Click += new System.EventHandler(this.btnXoaCC_Click);
            // 
            // btnSuaCC
            // 
            this.btnSuaCC.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.btnSuaCC.Location = new System.Drawing.Point(345, 145);
            this.btnSuaCC.Name = "btnSuaCC";
            this.btnSuaCC.Size = new System.Drawing.Size(115, 35);
            this.btnSuaCC.TabIndex = 17;
            this.btnSuaCC.Text = "Cập nhật";
            this.btnSuaCC.UseVisualStyleBackColor = true;
            this.btnSuaCC.Click += new System.EventHandler(this.btnSuaCC_Click);
            // 
            // btnGhiNhanCC
            // 
            this.btnGhiNhanCC.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.btnGhiNhanCC.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.btnGhiNhanCC.Location = new System.Drawing.Point(175, 145);
            this.btnGhiNhanCC.Name = "btnGhiNhanCC";
            this.btnGhiNhanCC.Size = new System.Drawing.Size(155, 35);
            this.btnGhiNhanCC.TabIndex = 16;
            this.btnGhiNhanCC.Text = "+ Chốt công";
            this.btnGhiNhanCC.UseVisualStyleBackColor = true;
            this.btnGhiNhanCC.Click += new System.EventHandler(this.btnGhiNhanCC_Click);
            // 
            // txtNghiKhongPhep
            // 
            this.txtNghiKhongPhep.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtNghiKhongPhep.Location = new System.Drawing.Point(830, 85);
            this.txtNghiKhongPhep.Name = "txtNghiKhongPhep";
            this.txtNghiKhongPhep.Size = new System.Drawing.Size(100, 29);
            this.txtNghiKhongPhep.TabIndex = 15;
            this.txtNghiKhongPhep.Text = "0";
            // 
            // lblNghiKhongPhep
            // 
            this.lblNghiKhongPhep.AutoSize = true;
            this.lblNghiKhongPhep.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblNghiKhongPhep.Location = new System.Drawing.Point(735, 90);
            this.lblNghiKhongPhep.Name = "lblNghiKhongPhep";
            this.lblNghiKhongPhep.Size = new System.Drawing.Size(89, 21);
            this.lblNghiKhongPhep.TabIndex = 14;
            this.lblNghiKhongPhep.Text = "Nghỉ K.phép:";
            // 
            // txtNghiCoPhep
            // 
            this.txtNghiCoPhep.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtNghiCoPhep.Location = new System.Drawing.Point(600, 85);
            this.txtNghiCoPhep.Name = "txtNghiCoPhep";
            this.txtNghiCoPhep.Size = new System.Drawing.Size(100, 29);
            this.txtNghiCoPhep.TabIndex = 13;
            this.txtNghiCoPhep.Text = "0";
            // 
            // lblNghiCoPhep
            // 
            this.lblNghiCoPhep.AutoSize = true;
            this.lblNghiCoPhep.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblNghiCoPhep.Location = new System.Drawing.Point(510, 90);
            this.lblNghiCoPhep.Name = "lblNghiCoPhep";
            this.lblNghiCoPhep.Size = new System.Drawing.Size(86, 21);
            this.lblNghiCoPhep.TabIndex = 12;
            this.lblNghiCoPhep.Text = "Nghỉ phép:";
            // 
            // txtDiLam
            // 
            this.txtDiLam.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtDiLam.Location = new System.Drawing.Point(365, 85);
            this.txtDiLam.Name = "txtDiLam";
            this.txtDiLam.Size = new System.Drawing.Size(110, 29);
            this.txtDiLam.TabIndex = 11;
            this.txtDiLam.Text = "26";
            // 
            // lblDiLam
            // 
            this.lblDiLam.AutoSize = true;
            this.lblDiLam.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblDiLam.Location = new System.Drawing.Point(280, 90);
            this.lblDiLam.Name = "lblDiLam";
            this.lblDiLam.Size = new System.Drawing.Size(81, 21);
            this.lblDiLam.TabIndex = 10;
            this.lblDiLam.Text = "Số đi làm:";
            // 
            // txtCongChuan
            // 
            this.txtCongChuan.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtCongChuan.Location = new System.Drawing.Point(120, 85);
            this.txtCongChuan.Name = "txtCongChuan";
            this.txtCongChuan.Size = new System.Drawing.Size(130, 29);
            this.txtCongChuan.TabIndex = 9;
            this.txtCongChuan.Text = "26";
            // 
            // lblCongChuan
            // 
            this.lblCongChuan.AutoSize = true;
            this.lblCongChuan.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblCongChuan.Location = new System.Drawing.Point(15, 90);
            this.lblCongChuan.Name = "lblCongChuan";
            this.lblCongChuan.Size = new System.Drawing.Size(100, 21);
            this.lblCongChuan.TabIndex = 8;
            this.lblCongChuan.Text = "Công chuẩn:";
            // 
            // cboNam
            // 
            this.cboNam.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboNam.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.cboNam.FormattingEnabled = true;
            this.cboNam.Location = new System.Drawing.Point(830, 30);
            this.cboNam.Name = "cboNam";
            this.cboNam.Size = new System.Drawing.Size(100, 29);
            this.cboNam.TabIndex = 7;
            // 
            // lblNam
            // 
            this.lblNam.AutoSize = true;
            this.lblNam.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblNam.Location = new System.Drawing.Point(775, 35);
            this.lblNam.Name = "lblNam";
            this.lblNam.Size = new System.Drawing.Size(47, 21);
            this.lblNam.TabIndex = 6;
            this.lblNam.Text = "Năm:";
            // 
            // cboThang
            // 
            this.cboThang.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboThang.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.cboThang.FormattingEnabled = true;
            this.cboThang.Location = new System.Drawing.Point(670, 30);
            this.cboThang.Name = "cboThang";
            this.cboThang.Size = new System.Drawing.Size(80, 29);
            this.cboThang.TabIndex = 5;
            // 
            // lblThang
            // 
            this.lblThang.AutoSize = true;
            this.lblThang.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblThang.Location = new System.Drawing.Point(610, 35);
            this.lblThang.Name = "lblThang";
            this.lblThang.Size = new System.Drawing.Size(56, 21);
            this.lblThang.TabIndex = 4;
            this.lblThang.Text = "Tháng:";
            // 
            // cboNV_CC
            // 
            this.cboNV_CC.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboNV_CC.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.cboNV_CC.FormattingEnabled = true;
            this.cboNV_CC.Location = new System.Drawing.Point(365, 30);
            this.cboNV_CC.Name = "cboNV_CC";
            this.cboNV_CC.Size = new System.Drawing.Size(220, 29);
            this.cboNV_CC.TabIndex = 3;
            // 
            // lblNV_CC
            // 
            this.lblNV_CC.AutoSize = true;
            this.lblNV_CC.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblNV_CC.Location = new System.Drawing.Point(280, 35);
            this.lblNV_CC.Name = "lblNV_CC";
            this.lblNV_CC.Size = new System.Drawing.Size(84, 21);
            this.lblNV_CC.TabIndex = 2;
            this.lblNV_CC.Text = "Nhân viên:";
            // 
            // txtMaCC
            // 
            this.txtMaCC.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtMaCC.Location = new System.Drawing.Point(120, 30);
            this.txtMaCC.Name = "txtMaCC";
            this.txtMaCC.Size = new System.Drawing.Size(130, 29);
            this.txtMaCC.TabIndex = 1;
            // 
            // lblMaCC
            // 
            this.lblMaCC.AutoSize = true;
            this.lblMaCC.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblMaCC.Location = new System.Drawing.Point(15, 35);
            this.lblMaCC.Name = "lblMaCC";
            this.lblMaCC.Size = new System.Drawing.Size(61, 21);
            this.lblMaCC.TabIndex = 0;
            this.lblMaCC.Text = "Mã CC:";
            // 
            // tabPhuTroi
            // 
            this.tabPhuTroi.Controls.Add(this.grpChiTietPT);
            this.tabPhuTroi.Controls.Add(this.dgvPhieuPT);
            this.tabPhuTroi.Controls.Add(this.grpPhieuPT);
            this.tabPhuTroi.Location = new System.Drawing.Point(4, 32);
            this.tabPhuTroi.Name = "tabPhuTroi";
            this.tabPhuTroi.Padding = new System.Windows.Forms.Padding(3);
            this.tabPhuTroi.Size = new System.Drawing.Size(992, 559);
            this.tabPhuTroi.TabIndex = 2;
            this.tabPhuTroi.Text = "3. Phiếu & Chi tiết phụ trội";
            this.tabPhuTroi.UseVisualStyleBackColor = true;
            // 
            // grpChiTietPT
            // 
            this.grpChiTietPT.Controls.Add(this.btnXoaCTPT);
            this.grpChiTietPT.Controls.Add(this.btnThemCTPT);
            this.grpChiTietPT.Controls.Add(this.txtCongViec);
            this.grpChiTietPT.Controls.Add(this.lblCongViec);
            this.grpChiTietPT.Controls.Add(this.txtSoGioPT);
            this.grpChiTietPT.Controls.Add(this.lblSoGioPT);
            this.grpChiTietPT.Controls.Add(this.cboNV_PT);
            this.grpChiTietPT.Controls.Add(this.lblNV_PT);
            this.grpChiTietPT.Controls.Add(this.dgvChiTietPT);
            this.grpChiTietPT.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.grpChiTietPT.Location = new System.Drawing.Point(510, 160);
            this.grpChiTietPT.Name = "grpChiTietPT";
            this.grpChiTietPT.Size = new System.Drawing.Size(470, 385);
            this.grpChiTietPT.TabIndex = 2;
            this.grpChiTietPT.TabStop = false;
            this.grpChiTietPT.Text = "Danh sách Nhân viên làm thêm (Chi tiết)";
            // 
            // btnXoaCTPT
            // 
            this.btnXoaCTPT.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnXoaCTPT.Location = new System.Drawing.Point(380, 75);
            this.btnXoaCTPT.Name = "btnXoaCTPT";
            this.btnXoaCTPT.Size = new System.Drawing.Size(75, 30);
            this.btnXoaCTPT.TabIndex = 8;
            this.btnXoaCTPT.Text = "Xóa";
            this.btnXoaCTPT.UseVisualStyleBackColor = true;
            this.btnXoaCTPT.Click += new System.EventHandler(this.btnXoaCTPT_Click);
            // 
            // btnThemCTPT
            // 
            this.btnThemCTPT.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btnThemCTPT.ForeColor = System.Drawing.Color.DarkGreen;
            this.btnThemCTPT.Location = new System.Drawing.Point(295, 75);
            this.btnThemCTPT.Name = "btnThemCTPT";
            this.btnThemCTPT.Size = new System.Drawing.Size(75, 30);
            this.btnThemCTPT.TabIndex = 7;
            this.btnThemCTPT.Text = "+ Thêm";
            this.btnThemCTPT.UseVisualStyleBackColor = true;
            this.btnThemCTPT.Click += new System.EventHandler(this.btnThemCTPT_Click);
            // 
            // txtCongViec
            // 
            this.txtCongViec.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtCongViec.Location = new System.Drawing.Point(95, 75);
            this.txtCongViec.Name = "txtCongViec";
            this.txtCongViec.Size = new System.Drawing.Size(185, 27);
            this.txtCongViec.TabIndex = 6;
            // 
            // lblCongViec
            // 
            this.lblCongViec.AutoSize = true;
            this.lblCongViec.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblCongViec.Location = new System.Drawing.Point(10, 80);
            this.lblCongViec.Name = "lblCongViec";
            this.lblCongViec.Size = new System.Drawing.Size(78, 20);
            this.lblCongViec.TabIndex = 5;
            this.lblCongViec.Text = "Công việc:";
            // 
            // txtSoGioPT
            // 
            this.txtSoGioPT.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtSoGioPT.Location = new System.Drawing.Point(380, 30);
            this.txtSoGioPT.Name = "txtSoGioPT";
            this.txtSoGioPT.Size = new System.Drawing.Size(75, 27);
            this.txtSoGioPT.TabIndex = 4;
            this.txtSoGioPT.Text = "4";
            // 
            // lblSoGioPT
            // 
            this.lblSoGioPT.AutoSize = true;
            this.lblSoGioPT.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblSoGioPT.Location = new System.Drawing.Point(325, 35);
            this.lblSoGioPT.Name = "lblSoGioPT";
            this.lblSoGioPT.Size = new System.Drawing.Size(55, 20);
            this.lblSoGioPT.TabIndex = 3;
            this.lblSoGioPT.Text = "Số giờ:";
            // 
            // cboNV_PT
            // 
            this.cboNV_PT.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboNV_PT.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.cboNV_PT.FormattingEnabled = true;
            this.cboNV_PT.Location = new System.Drawing.Point(95, 30);
            this.cboNV_PT.Name = "cboNV_PT";
            this.cboNV_PT.Size = new System.Drawing.Size(215, 28);
            this.cboNV_PT.TabIndex = 2;
            // 
            // lblNV_PT
            // 
            this.lblNV_PT.AutoSize = true;
            this.lblNV_PT.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblNV_PT.Location = new System.Drawing.Point(10, 35);
            this.lblNV_PT.Name = "lblNV_PT";
            this.lblNV_PT.Size = new System.Drawing.Size(78, 20);
            this.lblNV_PT.TabIndex = 1;
            this.lblNV_PT.Text = "Nhân viên:";
            // 
            // dgvChiTietPT
            // 
            this.dgvChiTietPT.AllowUserToAddRows = false;
            this.dgvChiTietPT.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvChiTietPT.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvChiTietPT.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.dgvChiTietPT.Location = new System.Drawing.Point(15, 120);
            this.dgvChiTietPT.Name = "dgvChiTietPT";
            this.dgvChiTietPT.ReadOnly = true;
            this.dgvChiTietPT.RowHeadersWidth = 30;
            this.dgvChiTietPT.RowTemplate.Height = 24;
            this.dgvChiTietPT.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvChiTietPT.Size = new System.Drawing.Size(440, 250);
            this.dgvChiTietPT.TabIndex = 0;
            // 
            // dgvPhieuPT
            // 
            this.dgvPhieuPT.AllowUserToAddRows = false;
            this.dgvPhieuPT.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvPhieuPT.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPhieuPT.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.dgvPhieuPT.Location = new System.Drawing.Point(15, 170);
            this.dgvPhieuPT.Name = "dgvPhieuPT";
            this.dgvPhieuPT.ReadOnly = true;
            this.dgvPhieuPT.RowHeadersWidth = 30;
            this.dgvPhieuPT.RowTemplate.Height = 24;
            this.dgvPhieuPT.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvPhieuPT.Size = new System.Drawing.Size(480, 375);
            this.dgvPhieuPT.TabIndex = 1;
            this.dgvPhieuPT.SelectionChanged += new System.EventHandler(this.dgvPhieuPT_SelectionChanged);
            // 
            // grpPhieuPT
            // 
            this.grpPhieuPT.Controls.Add(this.btnLamMoiPPT);
            this.grpPhieuPT.Controls.Add(this.btnXoaPPT);
            this.grpPhieuPT.Controls.Add(this.btnLapPPT);
            this.grpPhieuPT.Controls.Add(this.txtNguoiXacNhan);
            this.grpPhieuPT.Controls.Add(this.lblNguoiXacNhan);
            this.grpPhieuPT.Controls.Add(this.txtHeSo);
            this.grpPhieuPT.Controls.Add(this.lblHeSo);
            this.grpPhieuPT.Controls.Add(this.cboHinhThucPT);
            this.grpPhieuPT.Controls.Add(this.lblHinhThucPT);
            this.grpPhieuPT.Controls.Add(this.dtpNgayPT);
            this.grpPhieuPT.Controls.Add(this.lblNgayPT);
            this.grpPhieuPT.Controls.Add(this.cboPB_PPT);
            this.grpPhieuPT.Controls.Add(this.lblPB_PPT);
            this.grpPhieuPT.Controls.Add(this.txtMaPPT);
            this.grpPhieuPT.Controls.Add(this.lblMaPPT);
            this.grpPhieuPT.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.grpPhieuPT.Location = new System.Drawing.Point(15, 10);
            this.grpPhieuPT.Name = "grpPhieuPT";
            this.grpPhieuPT.Size = new System.Drawing.Size(965, 145);
            this.grpPhieuPT.TabIndex = 0;
            this.grpPhieuPT.TabStop = false;
            this.grpPhieuPT.Text = "Thông tin Phiếu ghi nhận phụ trội";
            // 
            // btnLamMoiPPT
            // 
            this.btnLamMoiPPT.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnLamMoiPPT.Location = new System.Drawing.Point(845, 100);
            this.btnLamMoiPPT.Name = "btnLamMoiPPT";
            this.btnLamMoiPPT.Size = new System.Drawing.Size(100, 32);
            this.btnLamMoiPPT.TabIndex = 14;
            this.btnLamMoiPPT.Text = "Làm mới";
            this.btnLamMoiPPT.UseVisualStyleBackColor = true;
            this.btnLamMoiPPT.Click += new System.EventHandler(this.btnLamMoiPPT_Click);
            // 
            // btnXoaPPT
            // 
            this.btnXoaPPT.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnXoaPPT.ForeColor = System.Drawing.Color.DarkRed;
            this.btnXoaPPT.Location = new System.Drawing.Point(735, 100);
            this.btnXoaPPT.Name = "btnXoaPPT";
            this.btnXoaPPT.Size = new System.Drawing.Size(100, 32);
            this.btnXoaPPT.TabIndex = 13;
            this.btnXoaPPT.Text = "Xóa phiếu";
            this.btnXoaPPT.UseVisualStyleBackColor = true;
            this.btnXoaPPT.Click += new System.EventHandler(this.btnXoaPPT_Click);
            // 
            // btnLapPPT
            // 
            this.btnLapPPT.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btnLapPPT.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.btnLapPPT.Location = new System.Drawing.Point(600, 100);
            this.btnLapPPT.Name = "btnLapPPT";
            this.btnLapPPT.Size = new System.Drawing.Size(125, 32);
            this.btnLapPPT.TabIndex = 12;
            this.btnLapPPT.Text = "+ Lập phiếu";
            this.btnLapPPT.UseVisualStyleBackColor = true;
            this.btnLapPPT.Click += new System.EventHandler(this.btnLapPPT_Click);
            // 
            // txtNguoiXacNhan
            // 
            this.txtNguoiXacNhan.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtNguoiXacNhan.Location = new System.Drawing.Point(745, 65);
            this.txtNguoiXacNhan.Name = "txtNguoiXacNhan";
            this.txtNguoiXacNhan.Size = new System.Drawing.Size(200, 27);
            this.txtNguoiXacNhan.TabIndex = 11;
            // 
            // lblNguoiXacNhan
            // 
            this.lblNguoiXacNhan.AutoSize = true;
            this.lblNguoiXacNhan.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblNguoiXacNhan.Location = new System.Drawing.Point(645, 70);
            this.lblNguoiXacNhan.Name = "lblNguoiXacNhan";
            this.lblNguoiXacNhan.Size = new System.Drawing.Size(94, 20);
            this.lblNguoiXacNhan.TabIndex = 10;
            this.lblNguoiXacNhan.Text = "Người x.nhận:";
            // 
            // txtHeSo
            // 
            this.txtHeSo.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtHeSo.Location = new System.Drawing.Point(420, 65);
            this.txtHeSo.Name = "txtHeSo";
            this.txtHeSo.Size = new System.Drawing.Size(200, 27);
            this.txtHeSo.TabIndex = 9;
            this.txtHeSo.Text = "1.5";
            // 
            // lblHeSo
            // 
            this.lblHeSo.AutoSize = true;
            this.lblHeSo.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblHeSo.Location = new System.Drawing.Point(335, 70);
            this.lblHeSo.Name = "lblHeSo";
            this.lblHeSo.Size = new System.Drawing.Size(51, 20);
            this.lblHeSo.TabIndex = 8;
            this.lblHeSo.Text = "Hệ số:";
            // 
            // cboHinhThucPT
            // 
            this.cboHinhThucPT.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboHinhThucPT.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.cboHinhThucPT.FormattingEnabled = true;
            this.cboHinhThucPT.Items.AddRange(new object[] {
            "Tăng ca ngày thường",
            "Ngày lễ",
            "Ngày nghỉ"});
            this.cboHinhThucPT.Location = new System.Drawing.Point(105, 65);
            this.cboHinhThucPT.Name = "cboHinhThucPT";
            this.cboHinhThucPT.Size = new System.Drawing.Size(200, 28);
            this.cboHinhThucPT.TabIndex = 7;
            // 
            // lblHinhThucPT
            // 
            this.lblHinhThucPT.AutoSize = true;
            this.lblHinhThucPT.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblHinhThucPT.Location = new System.Drawing.Point(15, 70);
            this.lblHinhThucPT.Name = "lblHinhThucPT";
            this.lblHinhThucPT.Size = new System.Drawing.Size(75, 20);
            this.lblHinhThucPT.TabIndex = 6;
            this.lblHinhThucPT.Text = "Hình thức:";
            // 
            // dtpNgayPT
            // 
            this.dtpNgayPT.CustomFormat = "dd/MM/yyyy";
            this.dtpNgayPT.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.dtpNgayPT.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpNgayPT.Location = new System.Drawing.Point(745, 25);
            this.dtpNgayPT.Name = "dtpNgayPT";
            this.dtpNgayPT.Size = new System.Drawing.Size(200, 27);
            this.dtpNgayPT.TabIndex = 5;
            // 
            // lblNgayPT
            // 
            this.lblNgayPT.AutoSize = true;
            this.lblNgayPT.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblNgayPT.Location = new System.Drawing.Point(645, 30);
            this.lblNgayPT.Name = "lblNgayPT";
            this.lblNgayPT.Size = new System.Drawing.Size(91, 20);
            this.lblNgayPT.TabIndex = 4;
            this.lblNgayPT.Text = "Ngày phụ trội:";
            // 
            // cboPB_PPT
            // 
            this.cboPB_PPT.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboPB_PPT.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.cboPB_PPT.FormattingEnabled = true;
            this.cboPB_PPT.Location = new System.Drawing.Point(420, 25);
            this.cboPB_PPT.Name = "cboPB_PPT";
            this.cboPB_PPT.Size = new System.Drawing.Size(200, 28);
            this.cboPB_PPT.TabIndex = 3;
            // 
            // lblPB_PPT
            // 
            this.lblPB_PPT.AutoSize = true;
            this.lblPB_PPT.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblPB_PPT.Location = new System.Drawing.Point(335, 30);
            this.lblPB_PPT.Name = "lblPB_PPT";
            this.lblPB_PPT.Size = new System.Drawing.Size(83, 20);
            this.lblPB_PPT.TabIndex = 2;
            this.lblPB_PPT.Text = "Phòng ban:";
            // 
            // txtMaPPT
            // 
            this.txtMaPPT.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtMaPPT.Location = new System.Drawing.Point(105, 25);
            this.txtMaPPT.Name = "txtMaPPT";
            this.txtMaPPT.Size = new System.Drawing.Size(200, 27);
            this.txtMaPPT.TabIndex = 1;
            // 
            // lblMaPPT
            // 
            this.lblMaPPT.AutoSize = true;
            this.lblMaPPT.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblMaPPT.Location = new System.Drawing.Point(15, 30);
            this.lblMaPPT.Name = "lblMaPPT";
            this.lblMaPPT.Size = new System.Drawing.Size(68, 20);
            this.lblMaPPT.TabIndex = 0;
            this.lblMaPPT.Text = "Mã phiếu:";
            // 
            // btnDong
            // 
            this.btnDong.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnDong.Location = new System.Drawing.Point(882, 655);
            this.btnDong.Name = "btnDong";
            this.btnDong.Size = new System.Drawing.Size(130, 40);
            this.btnDong.TabIndex = 2;
            this.btnDong.Text = "Đóng";
            this.btnDong.UseVisualStyleBackColor = true;
            this.btnDong.Click += new System.EventHandler(this.btnDong_Click);
            // 
            // FrmChamCong_PhuTroi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1024, 705);
            this.Controls.Add(this.btnDong);
            this.Controls.Add(this.tabChamCongPhuTroi);
            this.Controls.Add(this.lblTieuDe);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Kế hoạch - Chấm công - Phụ trội";
            this.Load += new System.EventHandler(this.FrmChamCong_PhuTroi_Load);
            this.tabChamCongPhuTroi.ResumeLayout(false);
            this.tabKeHoach.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvKeHoach)).EndInit();
            this.grpThongTinKH.ResumeLayout(false);
            this.grpThongTinKH.PerformLayout();
            this.tabChamCong.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvChamCong)).EndInit();
            this.grpThongTinCC.ResumeLayout(false);
            this.grpThongTinCC.PerformLayout();
            this.tabPhuTroi.ResumeLayout(false);
            this.grpChiTietPT.ResumeLayout(false);
            this.grpChiTietPT.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvChiTietPT)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPhieuPT)).EndInit();
            this.grpPhieuPT.ResumeLayout(false);
            this.grpPhieuPT.PerformLayout();
            this.ResumeLayout(false);
        }

        private System.Windows.Forms.Label lblTieuDe;
        private System.Windows.Forms.TabControl tabChamCongPhuTroi;
        private System.Windows.Forms.TabPage tabKeHoach;
        private System.Windows.Forms.TabPage tabChamCong;
        private System.Windows.Forms.TabPage tabPhuTroi;
        private System.Windows.Forms.Button btnDong;
        private System.Windows.Forms.GroupBox grpThongTinKH;
        private System.Windows.Forms.TextBox txtMaKH;
        private System.Windows.Forms.Label lblMaKH;
        private System.Windows.Forms.ComboBox cboPB_KH;
        private System.Windows.Forms.Label lblPB_KH;
        private System.Windows.Forms.DateTimePicker dtpTuNgay;
        private System.Windows.Forms.Label lblTuNgay;
        private System.Windows.Forms.DateTimePicker dtpDenNgay;
        private System.Windows.Forms.Label lblDenNgay;
        private System.Windows.Forms.TextBox txtNguoiLap;
        private System.Windows.Forms.Label lblNguoiLap;
        private System.Windows.Forms.DateTimePicker dtpNgayLap;
        private System.Windows.Forms.Label lblNgayLap;
        private System.Windows.Forms.Button btnLapKH;
        private System.Windows.Forms.Button btnSuaKH;
        private System.Windows.Forms.Button btnXoaKH;
        private System.Windows.Forms.Button btnLamMoiKH;
        private System.Windows.Forms.DataGridView dgvKeHoach;
        private System.Windows.Forms.GroupBox grpThongTinCC;
        private System.Windows.Forms.TextBox txtMaCC;
        private System.Windows.Forms.Label lblMaCC;
        private System.Windows.Forms.ComboBox cboNV_CC;
        private System.Windows.Forms.Label lblNV_CC;
        private System.Windows.Forms.ComboBox cboThang;
        private System.Windows.Forms.Label lblThang;
        private System.Windows.Forms.ComboBox cboNam;
        private System.Windows.Forms.Label lblNam;
        private System.Windows.Forms.TextBox txtCongChuan;
        private System.Windows.Forms.Label lblCongChuan;
        private System.Windows.Forms.TextBox txtDiLam;
        private System.Windows.Forms.Label lblDiLam;
        private System.Windows.Forms.TextBox txtNghiCoPhep;
        private System.Windows.Forms.Label lblNghiCoPhep;
        private System.Windows.Forms.TextBox txtNghiKhongPhep;
        private System.Windows.Forms.Label lblNghiKhongPhep;
        private System.Windows.Forms.Button btnGhiNhanCC;
        private System.Windows.Forms.Button btnSuaCC;
        private System.Windows.Forms.Button btnXoaCC;
        private System.Windows.Forms.Button btnLamMoiCC;
        private System.Windows.Forms.DataGridView dgvChamCong;
        private System.Windows.Forms.GroupBox grpPhieuPT;
        private System.Windows.Forms.TextBox txtMaPPT;
        private System.Windows.Forms.Label lblMaPPT;
        private System.Windows.Forms.ComboBox cboPB_PPT;
        private System.Windows.Forms.Label lblPB_PPT;
        private System.Windows.Forms.DateTimePicker dtpNgayPT;
        private System.Windows.Forms.Label lblNgayPT;
        private System.Windows.Forms.ComboBox cboHinhThucPT;
        private System.Windows.Forms.Label lblHinhThucPT;
        private System.Windows.Forms.TextBox txtHeSo;
        private System.Windows.Forms.Label lblHeSo;
        private System.Windows.Forms.TextBox txtNguoiXacNhan;
        private System.Windows.Forms.Label lblNguoiXacNhan;
        private System.Windows.Forms.Button btnLapPPT;
        private System.Windows.Forms.Button btnXoaPPT;
        private System.Windows.Forms.Button btnLamMoiPPT;
        private System.Windows.Forms.DataGridView dgvPhieuPT;
        private System.Windows.Forms.GroupBox grpChiTietPT;
        private System.Windows.Forms.ComboBox cboNV_PT;
        private System.Windows.Forms.Label lblNV_PT;
        private System.Windows.Forms.TextBox txtSoGioPT;
        private System.Windows.Forms.Label lblSoGioPT;
        private System.Windows.Forms.TextBox txtCongViec;
        private System.Windows.Forms.Label lblCongViec;
        private System.Windows.Forms.Button btnThemCTPT;
        private System.Windows.Forms.Button btnXoaCTPT;
        private System.Windows.Forms.DataGridView dgvChiTietPT;
    }
}