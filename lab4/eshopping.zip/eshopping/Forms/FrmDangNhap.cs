﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using eshopping.Data;
using eshopping.Models;

namespace eshopping.Forms
{
    public partial class FrmDangNhap : Form
    {
        public FrmDangNhap()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string user = txtUser.Text.Trim();
            string pass = txtPass.Text.Trim();

            if (string.IsNullOrEmpty(user) || string.IsNullOrEmpty(pass))
            {
                MessageBox.Show("Vui lòng nhập tên đăng nhập và mật khẩu.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                string sql = "SELECT MaKhachHang, TenDangNhap, HoTen, Email, SoDienThoai, DiaChi FROM KhachHang WHERE TenDangNhap = @u AND MatKhauHash = @p";
                SqlParameter[] pars = {
                    new SqlParameter("@u", user),
                    new SqlParameter("@p", pass)
                };

                DataTable dt = Db.ExecuteQuery(sql, pars);
                if (dt.Rows.Count > 0)
                {
                    DataRow r = dt.Rows[0];
                    CurrentSession.User = new KhachHangSession
                    {
                        MaKhachHang = Convert.ToInt32(r["MaKhachHang"]),
                        TenDangNhap = r["TenDangNhap"].ToString(),
                        HoTen = r["HoTen"].ToString(),
                        Email = r["Email"].ToString(),
                        SoDienThoai = r["SoDienThoai"].ToString(),
                        DiaChi = r["DiaChi"].ToString()
                    };

                    MessageBox.Show($"Chào mừng {CurrentSession.User.HoTen} đã quay lại!", "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    // Mở màn hình Mua sắm
                    var frmMua = new FrmMuaSam();
                    this.Hide();
                    frmMua.ShowDialog();
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Sai tên đăng nhập hoặc mật khẩu!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi kết nối cơ sở dữ liệu: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnMoDangKy_Click(object sender, EventArgs e)
        {
            var frmDk = new FrmDangKy();
            frmDk.ShowDialog();
        }
    }
}