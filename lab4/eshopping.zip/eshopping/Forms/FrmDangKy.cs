﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;
using eshopping.Data;

namespace eshopping.Forms
{
    public partial class FrmDangKy : Form
    {
        public FrmDangKy()
        {
            InitializeComponent();
        }

        private void btnDangKy_Click(object sender, EventArgs e)
        {
            // Kiểm tra các trường bắt buộc
            if (string.IsNullOrWhiteSpace(txtHoTen.Text) ||
                string.IsNullOrWhiteSpace(txtCMND.Text) ||
                string.IsNullOrWhiteSpace(txtSdt.Text) ||
                string.IsNullOrWhiteSpace(txtEmail.Text) ||
                string.IsNullOrWhiteSpace(txtDiaChi.Text) ||
                string.IsNullOrWhiteSpace(txtUser.Text) ||
                string.IsNullOrWhiteSpace(txtPass.Text))
            {
                MessageBox.Show("Vui lòng điền đầy đủ tất cả thông tin đăng ký.", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                // Kiểm tra trùng tên đăng nhập hoặc email
                string checkSql = "SELECT COUNT(*) FROM KhachHang WHERE TenDangNhap = @u OR Email = @e OR CMND_Passport = @cmnd";
                SqlParameter[] checkPars = {
                    new SqlParameter("@u", txtUser.Text.Trim()),
                    new SqlParameter("@e", txtEmail.Text.Trim()),
                    new SqlParameter("@cmnd", txtCMND.Text.Trim())
                };

                int tonTai = Convert.ToInt32(Db.ExecuteScalar(checkSql, checkPars));
                if (tonTai > 0)
                {
                    MessageBox.Show("Tên đăng nhập, Email hoặc CMND/Passport đã tồn tại trong hệ thống!", "Trùng thông tin", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Thực hiện lưu tài khoản mới
                string sql = @"INSERT INTO KhachHang (TenDangNhap, MatKhauHash, HoTen, NgaySinh, CMND_Passport, DiaChi, SoDienThoai, Email)
                               VALUES (@u, @p, @name, @dob, @cmnd, @addr, @phone, @email)";
                SqlParameter[] pars = {
                    new SqlParameter("@u", txtUser.Text.Trim()),
                    new SqlParameter("@p", txtPass.Text.Trim()),
                    new SqlParameter("@name", txtHoTen.Text.Trim()),
                    new SqlParameter("@dob", dtpNgaySinh.Value.Date),
                    new SqlParameter("@cmnd", txtCMND.Text.Trim()),
                    new SqlParameter("@addr", txtDiaChi.Text.Trim()),
                    new SqlParameter("@phone", txtSdt.Text.Trim()),
                    new SqlParameter("@email", txtEmail.Text.Trim())
                };

                Db.ExecuteNonQuery(sql, pars);
                MessageBox.Show("Đăng ký tài khoản thành công! Bạn có thể dùng tài khoản này để đăng nhập.", "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi đăng ký: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnHuy_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}