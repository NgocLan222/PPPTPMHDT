﻿using System;
using System.Windows.Forms;
using eshopping.Models;
using eshopping.Services;

namespace eshopping.Forms
{
    public partial class FrmThanhToan : Form
    {
        private readonly DatHangService _service = new DatHangService();
        private readonly int _maPhieuDat;
        private readonly decimal _tongThanhToan;
        private readonly string _emailKhach;

        public FrmThanhToan(int maPhieuDat, decimal tongThanhToan, NguoiNhan nguoiNhan, string tenLoaiGiao, string emailKhach)
        {
            InitializeComponent();
            _maPhieuDat = maPhieuDat;
            _tongThanhToan = tongThanhToan;
            _emailKhach = emailKhach;

            cboLoaiThe.SelectedIndex = 0;

            // Hiển thị rõ mã phiếu đặt hàng vừa được lập
            lblTomTatNguoiNhan.Text = $"Mã đơn hàng: #{_maPhieuDat} | Người nhận: {nguoiNhan.HoTen} ({nguoiNhan.SoDienThoai})";
            lblTomTatGiaoHang.Text = $"Địa chỉ giao: {nguoiNhan.DiaChi}, {nguoiNhan.KhuVuc} ({tenLoaiGiao})";
            lblTomTatSoTien.Text = $"Số tiền thanh toán: {_tongThanhToan:N0} đ";
        }

        private void btnThanhToan_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtSoThe.Text) ||
                string.IsNullOrWhiteSpace(txtMaCSV.Text) ||
                string.IsNullOrWhiteSpace(txtNgayHetHan.Text) ||
                string.IsNullOrWhiteSpace(txtTenChuThe.Text))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ thông tin thẻ tín dụng.", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var the = new ThongTinThe
            {
                LoaiThe = cboLoaiThe.SelectedItem.ToString(),
                SoThe = txtSoThe.Text.Trim(),
                NgayHetHan = txtNgayHetHan.Text.Trim(),
                TenChuThe = txtTenChuThe.Text.Trim(),
                MaCSV = txtMaCSV.Text.Trim()
            };

            // Thanh toán cho mã phiếu đặt hàng
            var ketQua = _service.XuLyThanhToan(_maPhieuDat, _tongThanhToan, _emailKhach, the);

            if (ketQua.ThanhCong)
            {
                MessageBox.Show(
                    $"GIAO DỊCH HOÀN TẤT THÀNH CÔNG!\n\n" +
                    $"Mã đơn hàng: #{_maPhieuDat}\n" +
                    $"Tổng số tiền đã thanh toán: {_tongThanhToan:N0} đ\n" +
                    $"Thư xác nhận đã được gửi đến email: {_emailKhach}\n\n" +
                    $"Cảm ơn bạn đã mua hàng tại e-Shopping!",
                    "Thành công",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information
                );

                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            else
            {
                MessageBox.Show(ketQua.ThongBao, "Lỗi thanh toán", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnQuayLai_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }
    }
}