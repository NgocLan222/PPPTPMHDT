﻿namespace eshopping.Forms
{
    partial class FrmMuaSam
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code
        private void InitializeComponent()
        {
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblHello = new System.Windows.Forms.Label();
            this.lblLocNhom = new System.Windows.Forms.Label();
            this.cboNhomSanPham = new System.Windows.Forms.ComboBox();
            this.grpSanPham = new System.Windows.Forms.GroupBox();
            this.dgvSanPham = new System.Windows.Forms.DataGridView();
            this.grpChiTiet = new System.Windows.Forms.GroupBox();
            this.lblTenSP = new System.Windows.Forms.Label();
            this.lblGiaBan = new System.Windows.Forms.Label();
            this.lblHangSX = new System.Windows.Forms.Label();
            this.lblTinhTrang = new System.Windows.Forms.Label();
            this.lblThongSoTitle = new System.Windows.Forms.Label();
            this.txtThongSo = new System.Windows.Forms.TextBox();
            this.lblMoTaTitle = new System.Windows.Forms.Label();
            this.txtMoTa = new System.Windows.Forms.TextBox();
            this.lblSoLuongMua = new System.Windows.Forms.Label();
            this.numSoLuong = new System.Windows.Forms.NumericUpDown();
            this.btnThemVaoGio = new System.Windows.Forms.Button();
            this.grpGioHang = new System.Windows.Forms.GroupBox();
            this.dgvGioHang = new System.Windows.Forms.DataGridView();
            this.btnXoaKhoiGio = new System.Windows.Forms.Button();
            this.lblTongTienTamTinh = new System.Windows.Forms.Label();
            this.btnTienHanhDatHang = new System.Windows.Forms.Button();
            this.grpSanPham.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSanPham)).BeginInit();
            this.grpChiTiet.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numSoLuong)).BeginInit();
            this.grpGioHang.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvGioHang)).BeginInit();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.lblTitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(59)))), ((int)(((byte)(93)))));
            this.lblTitle.Location = new System.Drawing.Point(20, 15);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(262, 21);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "DANH MỤC HÀNG & GIỎ HÀNG";
            // 
            // lblHello
            // 
            this.lblHello.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblHello.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Italic);
            this.lblHello.Location = new System.Drawing.Point(620, 15);
            this.lblHello.Name = "lblHello";
            this.lblHello.Size = new System.Drawing.Size(340, 20);
            this.lblHello.TabIndex = 1;
            this.lblHello.Text = "Xin chào: ...";
            this.lblHello.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblLocNhom
            // 
            this.lblLocNhom.AutoSize = true;
            this.lblLocNhom.Location = new System.Drawing.Point(20, 48);
            this.lblLocNhom.Name = "lblLocNhom";
            this.lblLocNhom.Size = new System.Drawing.Size(147, 17);
            this.lblLocNhom.TabIndex = 2;
            this.lblLocNhom.Text = "Chọn nhóm sản phẩm:";
            // 
            // cboNhomSanPham
            // 
            this.cboNhomSanPham.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboNhomSanPham.FormattingEnabled = true;
            this.cboNhomSanPham.Location = new System.Drawing.Point(175, 45);
            this.cboNhomSanPham.Name = "cboNhomSanPham";
            this.cboNhomSanPham.Size = new System.Drawing.Size(280, 25);
            this.cboNhomSanPham.TabIndex = 3;
            this.cboNhomSanPham.SelectedIndexChanged += new System.EventHandler(this.cboNhomSanPham_SelectedIndexChanged);
            // 
            // grpSanPham
            // 
            this.grpSanPham.Controls.Add(this.dgvSanPham);
            this.grpSanPham.Location = new System.Drawing.Point(20, 80);
            this.grpSanPham.Name = "grpSanPham";
            this.grpSanPham.Size = new System.Drawing.Size(435, 250);
            this.grpSanPham.TabIndex = 4;
            this.grpSanPham.TabStop = false;
            this.grpSanPham.Text = "Sản phẩm trong nhóm";
            // 
            // dgvSanPham
            // 
            this.dgvSanPham.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvSanPham.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSanPham.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvSanPham.Location = new System.Drawing.Point(3, 21);
            this.dgvSanPham.MultiSelect = false;
            this.dgvSanPham.Name = "dgvSanPham";
            this.dgvSanPham.ReadOnly = true;
            this.dgvSanPham.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvSanPham.Size = new System.Drawing.Size(429, 226);
            this.dgvSanPham.TabIndex = 0;
            this.dgvSanPham.SelectionChanged += new System.EventHandler(this.dgvSanPham_SelectionChanged);
            // 
            // grpChiTiet
            // 
            this.grpChiTiet.Controls.Add(this.btnThemVaoGio);
            this.grpChiTiet.Controls.Add(this.numSoLuong);
            this.grpChiTiet.Controls.Add(this.lblSoLuongMua);
            this.grpChiTiet.Controls.Add(this.txtMoTa);
            this.grpChiTiet.Controls.Add(this.lblMoTaTitle);
            this.grpChiTiet.Controls.Add(this.txtThongSo);
            this.grpChiTiet.Controls.Add(this.lblThongSoTitle);
            this.grpChiTiet.Controls.Add(this.lblTinhTrang);
            this.grpChiTiet.Controls.Add(this.lblHangSX);
            this.grpChiTiet.Controls.Add(this.lblGiaBan);
            this.grpChiTiet.Controls.Add(this.lblTenSP);
            this.grpChiTiet.Location = new System.Drawing.Point(470, 80);
            this.grpChiTiet.Name = "grpChiTiet";
            this.grpChiTiet.Size = new System.Drawing.Size(490, 250);
            this.grpChiTiet.TabIndex = 5;
            this.grpChiTiet.TabStop = false;
            this.grpChiTiet.Text = "Chi tiết sản phẩm đang chọn";
            // 
            // lblTenSP
            // 
            this.lblTenSP.AutoSize = true;
            this.lblTenSP.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.lblTenSP.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(59)))), ((int)(((byte)(93)))));
            this.lblTenSP.Location = new System.Drawing.Point(15, 25);
            this.lblTenSP.Name = "lblTenSP";
            this.lblTenSP.Size = new System.Drawing.Size(100, 17);
            this.lblTenSP.TabIndex = 0;
            this.lblTenSP.Text = "Tên: [Chưa chọn]";
            // 
            // lblGiaBan
            // 
            this.lblGiaBan.AutoSize = true;
            this.lblGiaBan.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.lblGiaBan.ForeColor = System.Drawing.Color.Crimson;
            this.lblGiaBan.Location = new System.Drawing.Point(15, 50);
            this.lblGiaBan.Name = "lblGiaBan";
            this.lblGiaBan.Size = new System.Drawing.Size(65, 17);
            this.lblGiaBan.TabIndex = 1;
            this.lblGiaBan.Text = "Giá bán: -";
            // 
            // lblHangSX
            // 
            this.lblHangSX.AutoSize = true;
            this.lblHangSX.Location = new System.Drawing.Point(230, 25);
            this.lblHangSX.Name = "lblHangSX";
            this.lblHangSX.Size = new System.Drawing.Size(91, 17);
            this.lblHangSX.TabIndex = 2;
            this.lblHangSX.Text = "Hãng SX: -";
            // 
            // lblTinhTrang
            // 
            this.lblTinhTrang.AutoSize = true;
            this.lblTinhTrang.Location = new System.Drawing.Point(230, 50);
            this.lblTinhTrang.Name = "lblTinhTrang";
            this.lblTinhTrang.Size = new System.Drawing.Size(78, 17);
            this.lblTinhTrang.TabIndex = 3;
            this.lblTinhTrang.Text = "Tình trạng: -";
            // 
            // lblThongSoTitle
            // 
            this.lblThongSoTitle.AutoSize = true;
            this.lblThongSoTitle.Location = new System.Drawing.Point(15, 75);
            this.lblThongSoTitle.Name = "lblThongSoTitle";
            this.lblThongSoTitle.Size = new System.Drawing.Size(120, 17);
            this.lblThongSoTitle.TabIndex = 4;
            this.lblThongSoTitle.Text = "Thông số kỹ thuật:";
            // 
            // txtThongSo
            // 
            this.txtThongSo.BackColor = System.Drawing.Color.White;
            this.txtThongSo.Location = new System.Drawing.Point(15, 95);
            this.txtThongSo.Multiline = true;
            this.txtThongSo.Name = "txtThongSo";
            this.txtThongSo.ReadOnly = true;
            this.txtThongSo.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtThongSo.Size = new System.Drawing.Size(460, 45);
            this.txtThongSo.TabIndex = 5;
            // 
            // lblMoTaTitle
            // 
            this.lblMoTaTitle.AutoSize = true;
            this.lblMoTaTitle.Location = new System.Drawing.Point(15, 145);
            this.lblMoTaTitle.Name = "lblMoTaTitle";
            this.lblMoTaTitle.Size = new System.Drawing.Size(46, 17);
            this.lblMoTaTitle.TabIndex = 6;
            this.lblMoTaTitle.Text = "Mô tả:";
            // 
            // txtMoTa
            // 
            this.txtMoTa.BackColor = System.Drawing.Color.White;
            this.txtMoTa.Location = new System.Drawing.Point(15, 165);
            this.txtMoTa.Multiline = true;
            this.txtMoTa.Name = "txtMoTa";
            this.txtMoTa.ReadOnly = true;
            this.txtMoTa.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtMoTa.Size = new System.Drawing.Size(460, 40);
            this.txtMoTa.TabIndex = 7;
            // 
            // lblSoLuongMua
            // 
            this.lblSoLuongMua.AutoSize = true;
            this.lblSoLuongMua.Location = new System.Drawing.Point(15, 218);
            this.lblSoLuongMua.Name = "lblSoLuongMua";
            this.lblSoLuongMua.Size = new System.Drawing.Size(64, 17);
            this.lblSoLuongMua.TabIndex = 8;
            this.lblSoLuongMua.Text = "Số lượng:";
            // 
            // numSoLuong
            // 
            this.numSoLuong.Location = new System.Drawing.Point(85, 215);
            this.numSoLuong.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
            this.numSoLuong.Name = "numSoLuong";
            this.numSoLuong.Size = new System.Drawing.Size(65, 25);
            this.numSoLuong.TabIndex = 9;
            this.numSoLuong.Value = new decimal(new int[] { 1, 0, 0, 0 });
            // 
            // btnThemVaoGio
            // 
            this.btnThemVaoGio.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(59)))), ((int)(((byte)(93)))));
            this.btnThemVaoGio.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnThemVaoGio.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btnThemVaoGio.ForeColor = System.Drawing.Color.White;
            this.btnThemVaoGio.Location = new System.Drawing.Point(165, 212);
            this.btnThemVaoGio.Name = "btnThemVaoGio";
            this.btnThemVaoGio.Size = new System.Drawing.Size(310, 30);
            this.btnThemVaoGio.TabIndex = 10;
            this.btnThemVaoGio.Text = "+ ĐƯA VÀO GIỎ HÀNG HIỆN TẠI";
            this.btnThemVaoGio.UseVisualStyleBackColor = false;
            this.btnThemVaoGio.Click += new System.EventHandler(this.btnThemVaoGio_Click);
            // 
            // grpGioHang
            // 
            this.grpGioHang.Controls.Add(this.dgvGioHang);
            this.grpGioHang.Controls.Add(this.btnXoaKhoiGio);
            this.grpGioHang.Controls.Add(this.lblTongTienTamTinh);
            this.grpGioHang.Location = new System.Drawing.Point(20, 340);
            this.grpGioHang.Name = "grpGioHang";
            this.grpGioHang.Size = new System.Drawing.Size(940, 210);
            this.grpGioHang.TabIndex = 6;
            this.grpGioHang.TabStop = false;
            this.grpGioHang.Text = "Giỏ hàng hiện tại (Cập nhật số lượng / Bỏ sản phẩm)";
            // 
            // dgvGioHang
            // 
            this.dgvGioHang.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvGioHang.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvGioHang.Location = new System.Drawing.Point(15, 25);
            this.dgvGioHang.MultiSelect = false;
            this.dgvGioHang.Name = "dgvGioHang";
            this.dgvGioHang.ReadOnly = true;
            this.dgvGioHang.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvGioHang.Size = new System.Drawing.Size(910, 135);
            this.dgvGioHang.TabIndex = 0;
            // 
            // btnXoaKhoiGio
            // 
            this.btnXoaKhoiGio.BackColor = System.Drawing.Color.DarkRed;
            this.btnXoaKhoiGio.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnXoaKhoiGio.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btnXoaKhoiGio.ForeColor = System.Drawing.Color.White;
            this.btnXoaKhoiGio.Location = new System.Drawing.Point(15, 168);
            this.btnXoaKhoiGio.Name = "btnXoaKhoiGio";
            this.btnXoaKhoiGio.Size = new System.Drawing.Size(150, 30);
            this.btnXoaKhoiGio.TabIndex = 1;
            this.btnXoaKhoiGio.Text = "Xóa khỏi giỏ hàng";
            this.btnXoaKhoiGio.UseVisualStyleBackColor = false;
            this.btnXoaKhoiGio.Click += new System.EventHandler(this.btnXoaKhoiGio_Click);
            // 
            // lblTongTienTamTinh
            // 
            this.lblTongTienTamTinh.AutoSize = true;
            this.lblTongTienTamTinh.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.lblTongTienTamTinh.ForeColor = System.Drawing.Color.Crimson;
            this.lblTongTienTamTinh.Location = new System.Drawing.Point(620, 172);
            this.lblTongTienTamTinh.Name = "lblTongTienTamTinh";
            this.lblTongTienTamTinh.Size = new System.Drawing.Size(188, 20);
            this.lblTongTienTamTinh.TabIndex = 2;
            this.lblTongTienTamTinh.Text = "Tổng tạm tính: 0 đ";
            // 
            // btnTienHanhDatHang
            // 
            this.btnTienHanhDatHang.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(59)))), ((int)(((byte)(93)))));
            this.btnTienHanhDatHang.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTienHanhDatHang.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.btnTienHanhDatHang.ForeColor = System.Drawing.Color.White;
            this.btnTienHanhDatHang.Location = new System.Drawing.Point(645, 560);
            this.btnTienHanhDatHang.Name = "btnTienHanhDatHang";
            this.btnTienHanhDatHang.Size = new System.Drawing.Size(315, 45);
            this.btnTienHanhDatHang.TabIndex = 7;
            this.btnTienHanhDatHang.Text = "TIẾN HÀNH ĐẶT HÀNG >>";
            this.btnTienHanhDatHang.UseVisualStyleBackColor = false;
            this.btnTienHanhDatHang.Click += new System.EventHandler(this.btnTienHanhDatHang_Click);
            // 
            // FrmMuaSam
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(980, 620);
            this.Controls.Add(this.btnTienHanhDatHang);
            this.Controls.Add(this.grpGioHang);
            this.Controls.Add(this.grpChiTiet);
            this.Controls.Add(this.grpSanPham);
            this.Controls.Add(this.cboNhomSanPham);
            this.Controls.Add(this.lblLocNhom);
            this.Controls.Add(this.lblHello);
            this.Controls.Add(this.lblTitle);
            this.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.Name = "FrmMuaSam";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "e-SHOPPING - Mua sắm & Giỏ hàng";
            this.Load += new System.EventHandler(this.FrmMuaSam_Load);
            this.grpSanPham.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvSanPham)).EndInit();
            this.grpChiTiet.ResumeLayout(false);
            this.grpChiTiet.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numSoLuong)).EndInit();
            this.grpGioHang.ResumeLayout(false);
            this.grpGioHang.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvGioHang)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }
        #endregion

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblHello;
        private System.Windows.Forms.Label lblLocNhom;
        private System.Windows.Forms.ComboBox cboNhomSanPham;
        private System.Windows.Forms.GroupBox grpSanPham;
        private System.Windows.Forms.DataGridView dgvSanPham;
        private System.Windows.Forms.GroupBox grpChiTiet;
        private System.Windows.Forms.Label lblTenSP;
        private System.Windows.Forms.Label lblGiaBan;
        private System.Windows.Forms.Label lblHangSX;
        private System.Windows.Forms.Label lblTinhTrang;
        private System.Windows.Forms.Label lblThongSoTitle;
        private System.Windows.Forms.TextBox txtThongSo;
        private System.Windows.Forms.Label lblMoTaTitle;
        private System.Windows.Forms.TextBox txtMoTa;
        private System.Windows.Forms.Label lblSoLuongMua;
        private System.Windows.Forms.NumericUpDown numSoLuong;
        private System.Windows.Forms.Button btnThemVaoGio;
        private System.Windows.Forms.GroupBox grpGioHang;
        private System.Windows.Forms.DataGridView dgvGioHang;
        private System.Windows.Forms.Button btnXoaKhoiGio;
        private System.Windows.Forms.Label lblTongTienTamTinh;
        private System.Windows.Forms.Button btnTienHanhDatHang;
    }
}