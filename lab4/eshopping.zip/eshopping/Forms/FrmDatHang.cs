﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using eshopping.Models;
using eshopping.Services;

namespace eshopping.Forms
{
    public partial class FrmDatHang : Form
    {
        private readonly DatHangService _service = new DatHangService();
        private List<ItemGioHang> _gioHang;
        private decimal _tongTienHang = 0;
        private decimal _phiGiaoHang = 0;
        private decimal _tongThanhToan = 0;

        public FrmDatHang(List<ItemGioHang> gioHang)
        {
            InitializeComponent();
            _gioHang = gioHang ?? new List<ItemGioHang>();

            cboKhuVuc.SelectedIndex = 0;
            NapDanhSachLoaiGiaoHang();

            if (CurrentSession.User != null)
            {
                txtNguoiNhanTen.Text = CurrentSession.User.HoTen;
                txtNguoiNhanDiaChi.Text = CurrentSession.User.DiaChi;
                txtNguoiNhanSdt.Text = CurrentSession.User.SoDienThoai;
            }

            HienThiGioHang();
            CapNhatChiPhi();
        }

        private void NapDanhSachLoaiGiaoHang()
        {
            try
            {
                DataTable dt = _service.LayDanhSachLoaiGiaoHang();
                cboLoaiGiaoHang.DataSource = dt;
                cboLoaiGiaoHang.DisplayMember = "TenLoai";
                cboLoaiGiaoHang.ValueMember = "MaLoaiGiaoHang";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi nạp hình thức giao hàng: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void HienThiGioHang()
        {
            dgvGioHang.DataSource = null;
            var display = _gioHang.Select(item => new
            {
                Mã_SP = item.SanPham.MaSanPham,
                Tên_Sản_Phẩm = item.SanPham.TenSanPham,
                Đơn_Giá = item.SanPham.GiaHienHanh.ToString("N0") + " đ",
                Số_Lượng = item.SoLuong,
                Thành_Tiền = item.ThanhTien.ToString("N0") + " đ"
            }).ToList();
            dgvGioHang.DataSource = display;
        }

        private void CapNhatChiPhi()
        {
            if (cboLoaiGiaoHang.SelectedValue == null) return;
            int maLoaiGiao;
            if (!int.TryParse(cboLoaiGiaoHang.SelectedValue.ToString(), out maLoaiGiao)) return;

            _tongTienHang = _gioHang.Sum(x => x.ThanhTien);
            string khuVuc = cboKhuVuc.SelectedItem?.ToString() ?? "";
            _phiGiaoHang = _service.TinhPhiGiaoHang(maLoaiGiao, khuVuc, _tongTienHang);
            _tongThanhToan = _tongTienHang + _phiGiaoHang;

            lblTienHang.Text = $"Tiền hàng: {_tongTienHang:N0} đ";
            lblPhiGiao.Text = $"Phí giao hàng: {_phiGiaoHang:N0} đ";
            lblTongCong.Text = $"Tổng trị giá: {_tongThanhToan:N0} đ";

            if (_tongTienHang >= 5000000)
                lblThongBaoFreeship.Text = "Đơn hàng >= 5.000.000 đ: Miễn phí chuyển phát nhanh trong ngày!";
            else if (_tongTienHang >= 1000000)
                lblThongBaoFreeship.Text = "Đơn hàng >= 1.000.000 đ: Miễn phí chuyển phát nhanh!";
            else
                lblThongBaoFreeship.Text = "Chưa đủ điều kiện miễn phí vận chuyển.";
        }

        private void cboLoaiGiaoHang_SelectedIndexChanged(object sender, EventArgs e) => CapNhatChiPhi();
        private void cboKhuVuc_SelectedIndexChanged(object sender, EventArgs e) => CapNhatChiPhi();

        private void btnChuyenSangThanhToan_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtNguoiNhanTen.Text) ||
                string.IsNullOrWhiteSpace(txtNguoiNhanDiaChi.Text) ||
                string.IsNullOrWhiteSpace(txtNguoiNhanSdt.Text))
            {
                MessageBox.Show("Vui lòng điền đầy đủ thông tin người nhận hàng.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                var nguoiNhan = new NguoiNhan
                {
                    HoTen = txtNguoiNhanTen.Text.Trim(),
                    DiaChi = txtNguoiNhanDiaChi.Text.Trim(),
                    KhuVuc = cboKhuVuc.SelectedItem.ToString(),
                    SoDienThoai = txtNguoiNhanSdt.Text.Trim()
                };

                int maLoaiGiao = Convert.ToInt32(cboLoaiGiaoHang.SelectedValue);

                // THỰC HIỆN LẬP PHIẾU ĐẶT HÀNG NGAY VÀO SQL SERVER
                int maPhieuDat = _service.LapPhieuDatHang(
                    CurrentSession.User.MaKhachHang,
                    maLoaiGiao,
                    nguoiNhan,
                    _gioHang,
                    _tongTienHang,
                    _phiGiaoHang,
                    _tongThanhToan
                );

                // Mở màn hình thanh toán cho chính phiếu đặt hàng vừa lập
                var frmPay = new FrmThanhToan(maPhieuDat, _tongThanhToan, nguoiNhan, cboLoaiGiaoHang.Text, CurrentSession.User.Email);
                this.Hide();
                var dialogResult = frmPay.ShowDialog();

                if (dialogResult == DialogResult.OK)
                {
                    this.DialogResult = DialogResult.OK;
                    this.Close();
                }
                else
                {
                    this.Show();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi lập phiếu đặt hàng: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}