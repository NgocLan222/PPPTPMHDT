﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Windows.Forms;
using eshopping.Data;
using eshopping.Models;

namespace eshopping.Forms
{
    public partial class FrmMuaSam : Form
    {
        private List<ItemGioHang> _gioHang = new List<ItemGioHang>();
        private DataTable _dtSanPhamHienTai;

        public FrmMuaSam()
        {
            InitializeComponent();
        }

        private void FrmMuaSam_Load(object sender, EventArgs e)
        {
            if (CurrentSession.User != null)
            {
                lblHello.Text = $"Khách hàng: {CurrentSession.User.HoTen} ({CurrentSession.User.Email})";
            }
            NapDanhSachNhomSanPham();
        }

        private void NapDanhSachNhomSanPham()
        {
            try
            {
                string sql = "SELECT MaNhom, TenNhom FROM NhomSanPham";
                DataTable dt = Db.ExecuteQuery(sql);
                cboNhomSanPham.DataSource = dt;
                cboNhomSanPham.DisplayMember = "TenNhom";
                cboNhomSanPham.ValueMember = "MaNhom";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi tải danh mục nhóm sản phẩm: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void cboNhomSanPham_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cboNhomSanPham.SelectedValue == null) return;
            int maNhom;
            if (!int.TryParse(cboNhomSanPham.SelectedValue.ToString(), out maNhom)) return;

            TaiSanPhamTheoNhom(maNhom);
        }

        private void TaiSanPhamTheoNhom(int maNhom)
        {
            try
            {
                string sql = "SELECT MaSanPham, TenSanPham, NhaSanXuat, GiaHienHanh, TinhTrangHang, ThongSoKyThuat, MoTa FROM SanPham WHERE MaNhom = @ma";
                SqlParameter[] pars = { new SqlParameter("@ma", maNhom) };
                _dtSanPhamHienTai = Db.ExecuteQuery(sql, pars);

                dgvSanPham.DataSource = _dtSanPhamHienTai;
                if (dgvSanPham.Columns.Contains("ThongSoKyThuat")) dgvSanPham.Columns["ThongSoKyThuat"].Visible = false;
                if (dgvSanPham.Columns.Contains("MoTa")) dgvSanPham.Columns["MoTa"].Visible = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi tải danh sách sản phẩm: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dgvSanPham_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvSanPham.SelectedRows.Count == 0) return;

            var row = dgvSanPham.SelectedRows[0];
            lblTenSP.Text = "Tên: " + row.Cells["TenSanPham"].Value.ToString();
            lblHangSX.Text = "Hãng SX: " + row.Cells["NhaSanXuat"].Value.ToString();
            decimal gia = Convert.ToDecimal(row.Cells["GiaHienHanh"].Value);
            lblGiaBan.Text = "Giá bán: " + gia.ToString("N0") + " đ";
            lblTinhTrang.Text = "Tình trạng: " + row.Cells["TinhTrangHang"].Value.ToString();
            txtThongSo.Text = row.Cells["ThongSoKyThuat"].Value != DBNull.Value ? row.Cells["ThongSoKyThuat"].Value.ToString() : "Chưa có";
            txtMoTa.Text = row.Cells["MoTa"].Value != DBNull.Value ? row.Cells["MoTa"].Value.ToString() : "Chưa có";
        }

        private void btnThemVaoGio_Click(object sender, EventArgs e)
        {
            if (dgvSanPham.SelectedRows.Count == 0)
            {
                MessageBox.Show("Vui lòng chọn một sản phẩm.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var row = dgvSanPham.SelectedRows[0];
            string tinhTrang = row.Cells["TinhTrangHang"].Value.ToString();
            if (tinhTrang == "Hết hàng")
            {
                MessageBox.Show("Sản phẩm này hiện tại đã hết hàng!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string maSP = row.Cells["MaSanPham"].Value.ToString();
            string tenSP = row.Cells["TenSanPham"].Value.ToString();
            decimal gia = Convert.ToDecimal(row.Cells["GiaHienHanh"].Value);
            int soLuong = (int)numSoLuong.Value;

            var item = _gioHang.FirstOrDefault(x => x.SanPham.MaSanPham == maSP);
            if (item != null)
            {
                item.SoLuong += soLuong;
            }
            else
            {
                _gioHang.Add(new ItemGioHang
                {
                    SanPham = new SanPham { MaSanPham = maSP, TenSanPham = tenSP, GiaHienHanh = gia },
                    SoLuong = soLuong
                });
            }

            CapNhatHienThiGioHang();
        }

        private void CapNhatHienThiGioHang()
        {
            dgvGioHang.DataSource = null;
            var display = _gioHang.Select(x => new
            {
                Mã_SP = x.SanPham.MaSanPham,
                Tên_Sản_Phẩm = x.SanPham.TenSanPham,
                Đơn_Giá = x.SanPham.GiaHienHanh.ToString("N0") + " đ",
                Số_Lượng = x.SoLuong,
                Thành_Tiền = x.ThanhTien.ToString("N0") + " đ"
            }).ToList();

            dgvGioHang.DataSource = display;
            decimal tong = _gioHang.Sum(x => x.ThanhTien);
            lblTongTienTamTinh.Text = $"Tổng tạm tính: {tong:N0} đ";
        }

        private void btnXoaKhoiGio_Click(object sender, EventArgs e)
        {
            if (dgvGioHang.SelectedRows.Count == 0)
            {
                MessageBox.Show("Vui lòng chọn sản phẩm muốn xóa trong giỏ hàng.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string maSP = dgvGioHang.SelectedRows[0].Cells["Mã_SP"].Value.ToString();
            var item = _gioHang.FirstOrDefault(x => x.SanPham.MaSanPham == maSP);
            if (item != null)
            {
                _gioHang.Remove(item);
                CapNhatHienThiGioHang();
            }
        }

        private void btnTienHanhDatHang_Click(object sender, EventArgs e)
        {
            if (!_gioHang.Any())
            {
                MessageBox.Show("Giỏ hàng chưa có sản phẩm nào. Hãy chọn hàng trước!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Kiểm tra đăng nhập
            if (CurrentSession.User == null)
            {
                MessageBox.Show("Vui lòng đăng nhập để tiến hành đặt hàng.", "Yêu cầu đăng nhập", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                var frmLogin = new FrmDangNhap();
                frmLogin.ShowDialog();
                if (CurrentSession.User == null) return;
            }

            // Chuyển sang Form Đặt hàng
            var frmDatHang = new FrmDatHang(_gioHang);
            var dialogResult = frmDatHang.ShowDialog();

            // Nếu đơn hàng đã hoàn tất thanh toán ở bước sau, làm mới giỏ hàng
            if (dialogResult == DialogResult.OK)
            {
                _gioHang.Clear();
                CapNhatHienThiGioHang();
            }
        }
    }
    }