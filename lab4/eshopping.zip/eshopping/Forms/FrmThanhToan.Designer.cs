﻿namespace eshopping.Forms
{
    partial class FrmThanhToan
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code
        private void InitializeComponent()
        {
            this.lblHeader = new System.Windows.Forms.Label();
            this.grpTomTat = new System.Windows.Forms.GroupBox();
            this.lblTomTatNguoiNhan = new System.Windows.Forms.Label();
            this.lblTomTatGiaoHang = new System.Windows.Forms.Label();
            this.lblTomTatSoTien = new System.Windows.Forms.Label();
            this.grpThe = new System.Windows.Forms.GroupBox();
            this.lblLoaiThe = new System.Windows.Forms.Label();
            this.cboLoaiThe = new System.Windows.Forms.ComboBox();
            this.lblSoThe = new System.Windows.Forms.Label();
            this.txtSoThe = new System.Windows.Forms.TextBox();
            this.lblCSV = new System.Windows.Forms.Label();
            this.txtMaCSV = new System.Windows.Forms.TextBox();
            this.lblHanThe = new System.Windows.Forms.Label();
            this.txtNgayHetHan = new System.Windows.Forms.TextBox();
            this.lblChuThe = new System.Windows.Forms.Label();
            this.txtTenChuThe = new System.Windows.Forms.TextBox();
            this.lblGhiChuBaoMat = new System.Windows.Forms.Label();
            this.btnThanhToan = new System.Windows.Forms.Button();
            this.btnQuayLai = new System.Windows.Forms.Button();
            this.grpTomTat.SuspendLayout();
            this.grpThe.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblHeader
            // 
            this.lblHeader.AutoSize = true;
            this.lblHeader.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.lblHeader.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(59)))), ((int)(((byte)(93)))));
            this.lblHeader.Location = new System.Drawing.Point(20, 15);
            this.lblHeader.Name = "lblHeader";
            this.lblHeader.Size = new System.Drawing.Size(207, 21);
            this.lblHeader.TabIndex = 0;
            this.lblHeader.Text = "THANH TOÁN ĐƠN HÀNG";
            // 
            // grpTomTat
            // 
            this.grpTomTat.Controls.Add(this.lblTomTatNguoiNhan);
            this.grpTomTat.Controls.Add(this.lblTomTatGiaoHang);
            this.grpTomTat.Controls.Add(this.lblTomTatSoTien);
            this.grpTomTat.Location = new System.Drawing.Point(20, 45);
            this.grpTomTat.Name = "grpTomTat";
            this.grpTomTat.Size = new System.Drawing.Size(590, 105);
            this.grpTomTat.TabIndex = 1;
            this.grpTomTat.TabStop = false;
            this.grpTomTat.Text = "Tóm tắt đơn hàng";
            // 
            // lblTomTatNguoiNhan
            // 
            this.lblTomTatNguoiNhan.AutoSize = true;
            this.lblTomTatNguoiNhan.Location = new System.Drawing.Point(15, 25);
            this.lblTomTatNguoiNhan.Name = "lblTomTatNguoiNhan";
            this.lblTomTatNguoiNhan.Size = new System.Drawing.Size(89, 17);
            this.lblTomTatNguoiNhan.TabIndex = 0;
            this.lblTomTatNguoiNhan.Text = "Người nhận: ...";
            // 
            // lblTomTatGiaoHang
            // 
            this.lblTomTatGiaoHang.AutoSize = true;
            this.lblTomTatGiaoHang.Location = new System.Drawing.Point(15, 50);
            this.lblTomTatGiaoHang.Name = "lblTomTatGiaoHang";
            this.lblTomTatGiaoHang.Size = new System.Drawing.Size(81, 17);
            this.lblTomTatGiaoHang.TabIndex = 1;
            this.lblTomTatGiaoHang.Text = "Giao hàng: ...";
            // 
            // lblTomTatSoTien
            // 
            this.lblTomTatSoTien.AutoSize = true;
            this.lblTomTatSoTien.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.lblTomTatSoTien.ForeColor = System.Drawing.Color.Crimson;
            this.lblTomTatSoTien.Location = new System.Drawing.Point(15, 75);
            this.lblTomTatSoTien.Name = "lblTomTatSoTien";
            this.lblTomTatSoTien.Size = new System.Drawing.Size(188, 20);
            this.lblTomTatSoTien.TabIndex = 2;
            this.lblTomTatSoTien.Text = "Số tiền thanh toán: 0 đ";
            // 
            // grpThe
            // 
            this.grpThe.Controls.Add(this.lblLoaiThe);
            this.grpThe.Controls.Add(this.cboLoaiThe);
            this.grpThe.Controls.Add(this.lblSoThe);
            this.grpThe.Controls.Add(this.txtSoThe);
            this.grpThe.Controls.Add(this.lblCSV);
            this.grpThe.Controls.Add(this.txtMaCSV);
            this.grpThe.Controls.Add(this.lblHanThe);
            this.grpThe.Controls.Add(this.txtNgayHetHan);
            this.grpThe.Controls.Add(this.lblChuThe);
            this.grpThe.Controls.Add(this.txtTenChuThe);
            this.grpThe.Controls.Add(this.lblGhiChuBaoMat);
            this.grpThe.Location = new System.Drawing.Point(20, 160);
            this.grpThe.Name = "grpThe";
            this.grpThe.Size = new System.Drawing.Size(590, 205);
            this.grpThe.TabIndex = 2;
            this.grpThe.TabStop = false;
            this.grpThe.Text = "Thông tin thẻ thanh toán";
            // 
            // lblLoaiThe
            // 
            this.lblLoaiThe.AutoSize = true;
            this.lblLoaiThe.Location = new System.Drawing.Point(20, 32);
            this.lblLoaiThe.Name = "lblLoaiThe";
            this.lblLoaiThe.Size = new System.Drawing.Size(58, 17);
            this.lblLoaiThe.TabIndex = 0;
            this.lblLoaiThe.Text = "Loại thẻ:";
            // 
            // cboLoaiThe
            // 
            this.cboLoaiThe.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboLoaiThe.FormattingEnabled = true;
            this.cboLoaiThe.Items.AddRange(new object[] {
            "VISA",
            "Master",
            "Discover",
            "American Express"});
            this.cboLoaiThe.Location = new System.Drawing.Point(110, 28);
            this.cboLoaiThe.Name = "cboLoaiThe";
            this.cboLoaiThe.Size = new System.Drawing.Size(160, 25);
            this.cboLoaiThe.TabIndex = 1;
            // 
            // lblSoThe
            // 
            this.lblSoThe.AutoSize = true;
            this.lblSoThe.Location = new System.Drawing.Point(290, 32);
            this.lblSoThe.Name = "lblSoThe";
            this.lblSoThe.Size = new System.Drawing.Size(49, 17);
            this.lblSoThe.TabIndex = 2;
            this.lblSoThe.Text = "Số thẻ:";
            // 
            // txtSoThe
            // 
            this.txtSoThe.Location = new System.Drawing.Point(345, 28);
            this.txtSoThe.Name = "txtSoThe";
            this.txtSoThe.Size = new System.Drawing.Size(225, 25);
            this.txtSoThe.TabIndex = 3;
            // 
            // lblCSV
            // 
            this.lblCSV.AutoSize = true;
            this.lblCSV.Location = new System.Drawing.Point(20, 75);
            this.lblCSV.Name = "lblCSV";
            this.lblCSV.Size = new System.Drawing.Size(58, 17);
            this.lblCSV.TabIndex = 4;
            this.lblCSV.Text = "Mã CSV:";
            // 
            // txtMaCSV
            // 
            this.txtMaCSV.Location = new System.Drawing.Point(110, 71);
            this.txtMaCSV.Name = "txtMaCSV";
            this.txtMaCSV.Size = new System.Drawing.Size(160, 25);
            this.txtMaCSV.TabIndex = 5;
            // 
            // lblHanThe
            // 
            this.lblHanThe.AutoSize = true;
            this.lblHanThe.Location = new System.Drawing.Point(290, 75);
            this.lblHanThe.Name = "lblHanThe";
            this.lblHanThe.Size = new System.Drawing.Size(88, 17);
            this.lblHanThe.TabIndex = 6;
            this.lblHanThe.Text = "Hạn (MM/YY):";
            // 
            // txtNgayHetHan
            // 
            this.txtNgayHetHan.Location = new System.Drawing.Point(385, 71);
            this.txtNgayHetHan.Name = "txtNgayHetHan";
            this.txtNgayHetHan.Size = new System.Drawing.Size(185, 25);
            this.txtNgayHetHan.TabIndex = 7;
            // 
            // lblChuThe
            // 
            this.lblChuThe.AutoSize = true;
            this.lblChuThe.Location = new System.Drawing.Point(20, 118);
            this.lblChuThe.Name = "lblChuThe";
            this.lblChuThe.Size = new System.Drawing.Size(78, 17);
            this.lblChuThe.TabIndex = 8;
            this.lblChuThe.Text = "Tên chủ thẻ:";
            // 
            // txtTenChuThe
            // 
            this.txtTenChuThe.Location = new System.Drawing.Point(110, 114);
            this.txtTenChuThe.Name = "txtTenChuThe";
            this.txtTenChuThe.Size = new System.Drawing.Size(460, 25);
            this.txtTenChuThe.TabIndex = 9;
            // 
            // lblGhiChuBaoMat
            // 
            this.lblGhiChuBaoMat.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Italic);
            this.lblGhiChuBaoMat.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.lblGhiChuBaoMat.Location = new System.Drawing.Point(20, 155);
            this.lblGhiChuBaoMat.Name = "lblGhiChuBaoMat";
            this.lblGhiChuBaoMat.Size = new System.Drawing.Size(550, 30);
            this.lblGhiChuBaoMat.TabIndex = 10;
            this.lblGhiChuBaoMat.Text = "Thông tin thanh toán được bảo mật theo tiêu chuẩn quốc tế.";
            // 
            // btnThanhToan
            // 
            this.btnThanhToan.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(59)))), ((int)(((byte)(93)))));
            this.btnThanhToan.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnThanhToan.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnThanhToan.ForeColor = System.Drawing.Color.White;
            this.btnThanhToan.Location = new System.Drawing.Point(400, 380);
            this.btnThanhToan.Name = "btnThanhToan";
            this.btnThanhToan.Size = new System.Drawing.Size(210, 40);
            this.btnThanhToan.TabIndex = 3;
            this.btnThanhToan.Text = "Thanh toán ngay";
            this.btnThanhToan.UseVisualStyleBackColor = false;
            this.btnThanhToan.Click += new System.EventHandler(this.btnThanhToan_Click);
            // 
            // btnQuayLai
            // 
            this.btnQuayLai.BackColor = System.Drawing.Color.Gray;
            this.btnQuayLai.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnQuayLai.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnQuayLai.ForeColor = System.Drawing.Color.White;
            this.btnQuayLai.Location = new System.Drawing.Point(265, 380);
            this.btnQuayLai.Name = "btnQuayLai";
            this.btnQuayLai.Size = new System.Drawing.Size(125, 40);
            this.btnQuayLai.TabIndex = 4;
            this.btnQuayLai.Text = "Quay lại";
            this.btnQuayLai.UseVisualStyleBackColor = false;
            this.btnQuayLai.Click += new System.EventHandler(this.btnQuayLai_Click);
            // 
            // FrmThanhToan
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(634, 440);
            this.Controls.Add(this.btnQuayLai);
            this.Controls.Add(this.btnThanhToan);
            this.Controls.Add(this.grpThe);
            this.Controls.Add(this.grpTomTat);
            this.Controls.Add(this.lblHeader);
            this.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "FrmThanhToan";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "e-SHOPPING - Thanh toán trực tuyến";
            this.grpTomTat.ResumeLayout(false);
            this.grpTomTat.PerformLayout();
            this.grpThe.ResumeLayout(false);
            this.grpThe.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();
        }
        #endregion

        private System.Windows.Forms.Label lblHeader;
        private System.Windows.Forms.GroupBox grpTomTat;
        private System.Windows.Forms.Label lblTomTatNguoiNhan;
        private System.Windows.Forms.Label lblTomTatGiaoHang;
        private System.Windows.Forms.Label lblTomTatSoTien;
        private System.Windows.Forms.GroupBox grpThe;
        private System.Windows.Forms.Label lblLoaiThe;
        private System.Windows.Forms.ComboBox cboLoaiThe;
        private System.Windows.Forms.Label lblSoThe;
        private System.Windows.Forms.TextBox txtSoThe;
        private System.Windows.Forms.Label lblCSV;
        private System.Windows.Forms.TextBox txtMaCSV;
        private System.Windows.Forms.Label lblHanThe;
        private System.Windows.Forms.TextBox txtNgayHetHan;
        private System.Windows.Forms.Label lblChuThe;
        private System.Windows.Forms.TextBox txtTenChuThe;
        private System.Windows.Forms.Label lblGhiChuBaoMat;
        private System.Windows.Forms.Button btnThanhToan;
        private System.Windows.Forms.Button btnQuayLai;
    }
}