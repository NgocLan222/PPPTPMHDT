﻿namespace eshopping.Forms
{
    partial class FrmDatHang
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code
        private void InitializeComponent()
        {
            this.lblHeader = new System.Windows.Forms.Label();
            this.dgvGioHang = new System.Windows.Forms.DataGridView();
            this.grpNguoiNhan = new System.Windows.Forms.GroupBox();
            this.lblHoTen = new System.Windows.Forms.Label();
            this.txtNguoiNhanTen = new System.Windows.Forms.TextBox();
            this.lblDiaChi = new System.Windows.Forms.Label();
            this.txtNguoiNhanDiaChi = new System.Windows.Forms.TextBox();
            this.lblKhuVuc = new System.Windows.Forms.Label();
            this.cboKhuVuc = new System.Windows.Forms.ComboBox();
            this.lblSdt = new System.Windows.Forms.Label();
            this.txtNguoiNhanSdt = new System.Windows.Forms.TextBox();
            this.grpGiaoHang = new System.Windows.Forms.GroupBox();
            this.lblLoaiPhieu = new System.Windows.Forms.Label();
            this.cboLoaiGiaoHang = new System.Windows.Forms.ComboBox();
            this.lblThongBaoFreeship = new System.Windows.Forms.Label();
            this.lblTienHang = new System.Windows.Forms.Label();
            this.lblPhiGiao = new System.Windows.Forms.Label();
            this.lblTongCong = new System.Windows.Forms.Label();
            this.btnChuyenSangThanhToan = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvGioHang)).BeginInit();
            this.grpNguoiNhan.SuspendLayout();
            this.grpGiaoHang.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblHeader
            // 
            this.lblHeader.AutoSize = true;
            this.lblHeader.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.lblHeader.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(59)))), ((int)(((byte)(93)))));
            this.lblHeader.Location = new System.Drawing.Point(20, 15);
            this.lblHeader.Name = "lblHeader";
            this.lblHeader.Size = new System.Drawing.Size(193, 21);
            this.lblHeader.TabIndex = 0;
            this.lblHeader.Text = "THÔNG TIN ĐẶT HÀNG";
            // 
            // dgvGioHang
            // 
            this.dgvGioHang.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvGioHang.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvGioHang.Location = new System.Drawing.Point(20, 45);
            this.dgvGioHang.Name = "dgvGioHang";
            this.dgvGioHang.ReadOnly = true;
            this.dgvGioHang.Size = new System.Drawing.Size(830, 145);
            this.dgvGioHang.TabIndex = 1;
            // 
            // grpNguoiNhan
            // 
            this.grpNguoiNhan.Controls.Add(this.lblHoTen);
            this.grpNguoiNhan.Controls.Add(this.txtNguoiNhanTen);
            this.grpNguoiNhan.Controls.Add(this.lblDiaChi);
            this.grpNguoiNhan.Controls.Add(this.txtNguoiNhanDiaChi);
            this.grpNguoiNhan.Controls.Add(this.lblKhuVuc);
            this.grpNguoiNhan.Controls.Add(this.cboKhuVuc);
            this.grpNguoiNhan.Controls.Add(this.lblSdt);
            this.grpNguoiNhan.Controls.Add(this.txtNguoiNhanSdt);
            this.grpNguoiNhan.Location = new System.Drawing.Point(20, 205);
            this.grpNguoiNhan.Name = "grpNguoiNhan";
            this.grpNguoiNhan.Size = new System.Drawing.Size(405, 220);
            this.grpNguoiNhan.TabIndex = 2;
            this.grpNguoiNhan.TabStop = false;
            this.grpNguoiNhan.Text = "Thông tin người nhận";
            // 
            // lblHoTen
            // 
            this.lblHoTen.AutoSize = true;
            this.lblHoTen.Location = new System.Drawing.Point(15, 32);
            this.lblHoTen.Name = "lblHoTen";
            this.lblHoTen.Size = new System.Drawing.Size(50, 17);
            this.lblHoTen.TabIndex = 0;
            this.lblHoTen.Text = "Họ tên:";
            // 
            // txtNguoiNhanTen
            // 
            this.txtNguoiNhanTen.Location = new System.Drawing.Point(115, 28);
            this.txtNguoiNhanTen.Name = "txtNguoiNhanTen";
            this.txtNguoiNhanTen.Size = new System.Drawing.Size(270, 25);
            this.txtNguoiNhanTen.TabIndex = 1;
            // 
            // lblDiaChi
            // 
            this.lblDiaChi.AutoSize = true;
            this.lblDiaChi.Location = new System.Drawing.Point(15, 75);
            this.lblDiaChi.Name = "lblDiaChi";
            this.lblDiaChi.Size = new System.Drawing.Size(50, 17);
            this.lblDiaChi.TabIndex = 2;
            this.lblDiaChi.Text = "Địa chỉ:";
            // 
            // txtNguoiNhanDiaChi
            // 
            this.txtNguoiNhanDiaChi.Location = new System.Drawing.Point(115, 71);
            this.txtNguoiNhanDiaChi.Name = "txtNguoiNhanDiaChi";
            this.txtNguoiNhanDiaChi.Size = new System.Drawing.Size(270, 25);
            this.txtNguoiNhanDiaChi.TabIndex = 3;
            // 
            // lblKhuVuc
            // 
            this.lblKhuVuc.AutoSize = true;
            this.lblKhuVuc.Location = new System.Drawing.Point(15, 118);
            this.lblKhuVuc.Name = "lblKhuVuc";
            this.lblKhuVuc.Size = new System.Drawing.Size(58, 17);
            this.lblKhuVuc.TabIndex = 4;
            this.lblKhuVuc.Text = "Khu vực:";
            // 
            // cboKhuVuc
            // 
            this.cboKhuVuc.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboKhuVuc.FormattingEnabled = true;
            this.cboKhuVuc.Items.AddRange(new object[] {
            "Nội thành TP.HCM",
            "Ngoại thành TP.HCM (+20.000 đ)",
            "Các tỉnh thành khác (+20.000 đ)"});
            this.cboKhuVuc.Location = new System.Drawing.Point(115, 114);
            this.cboKhuVuc.Name = "cboKhuVuc";
            this.cboKhuVuc.Size = new System.Drawing.Size(270, 25);
            this.cboKhuVuc.TabIndex = 5;
            this.cboKhuVuc.SelectedIndexChanged += new System.EventHandler(this.cboKhuVuc_SelectedIndexChanged);
            // 
            // lblSdt
            // 
            this.lblSdt.AutoSize = true;
            this.lblSdt.Location = new System.Drawing.Point(15, 162);
            this.lblSdt.Name = "lblSdt";
            this.lblSdt.Size = new System.Drawing.Size(70, 17);
            this.lblSdt.TabIndex = 6;
            this.lblSdt.Text = "Điện thoại:";
            // 
            // txtNguoiNhanSdt
            // 
            this.txtNguoiNhanSdt.Location = new System.Drawing.Point(115, 158);
            this.txtNguoiNhanSdt.Name = "txtNguoiNhanSdt";
            this.txtNguoiNhanSdt.Size = new System.Drawing.Size(270, 25);
            this.txtNguoiNhanSdt.TabIndex = 7;
            // 
            // grpGiaoHang
            // 
            this.grpGiaoHang.Controls.Add(this.lblLoaiPhieu);
            this.grpGiaoHang.Controls.Add(this.cboLoaiGiaoHang);
            this.grpGiaoHang.Controls.Add(this.lblThongBaoFreeship);
            this.grpGiaoHang.Controls.Add(this.lblTienHang);
            this.grpGiaoHang.Controls.Add(this.lblPhiGiao);
            this.grpGiaoHang.Controls.Add(this.lblTongCong);
            this.grpGiaoHang.Location = new System.Drawing.Point(445, 205);
            this.grpGiaoHang.Name = "grpGiaoHang";
            this.grpGiaoHang.Size = new System.Drawing.Size(405, 220);
            this.grpGiaoHang.TabIndex = 3;
            this.grpGiaoHang.TabStop = false;
            this.grpGiaoHang.Text = "Phương thức giao hàng";
            // 
            // lblLoaiPhieu
            // 
            this.lblLoaiPhieu.AutoSize = true;
            this.lblLoaiPhieu.Location = new System.Drawing.Point(15, 32);
            this.lblLoaiPhieu.Name = "lblLoaiPhieu";
            this.lblLoaiPhieu.Size = new System.Drawing.Size(71, 17);
            this.lblLoaiPhieu.TabIndex = 0;
            this.lblLoaiPhieu.Text = "Loại phiếu:";
            // 
            // cboLoaiGiaoHang
            // 
            this.cboLoaiGiaoHang.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboLoaiGiaoHang.FormattingEnabled = true;
            this.cboLoaiGiaoHang.Location = new System.Drawing.Point(100, 28);
            this.cboLoaiGiaoHang.Name = "cboLoaiGiaoHang";
            this.cboLoaiGiaoHang.Size = new System.Drawing.Size(285, 25);
            this.cboLoaiGiaoHang.TabIndex = 1;
            this.cboLoaiGiaoHang.SelectedIndexChanged += new System.EventHandler(this.cboLoaiGiaoHang_SelectedIndexChanged);
            // 
            // lblThongBaoFreeship
            // 
            this.lblThongBaoFreeship.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Italic);
            this.lblThongBaoFreeship.ForeColor = System.Drawing.Color.DarkGreen;
            this.lblThongBaoFreeship.Location = new System.Drawing.Point(15, 68);
            this.lblThongBaoFreeship.Name = "lblThongBaoFreeship";
            this.lblThongBaoFreeship.Size = new System.Drawing.Size(370, 38);
            this.lblThongBaoFreeship.TabIndex = 2;
            // 
            // lblTienHang
            // 
            this.lblTienHang.AutoSize = true;
            this.lblTienHang.Location = new System.Drawing.Point(15, 118);
            this.lblTienHang.Name = "lblTienHang";
            this.lblTienHang.Size = new System.Drawing.Size(89, 17);
            this.lblTienHang.TabIndex = 3;
            this.lblTienHang.Text = "Tiền hàng: 0 đ";
            // 
            // lblPhiGiao
            // 
            this.lblPhiGiao.AutoSize = true;
            this.lblPhiGiao.Location = new System.Drawing.Point(15, 145);
            this.lblPhiGiao.Name = "lblPhiGiao";
            this.lblPhiGiao.Size = new System.Drawing.Size(78, 17);
            this.lblPhiGiao.TabIndex = 4;
            this.lblPhiGiao.Text = "Phí giao: 0 đ";
            // 
            // lblTongCong
            // 
            this.lblTongCong.AutoSize = true;
            this.lblTongCong.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.lblTongCong.ForeColor = System.Drawing.Color.Crimson;
            this.lblTongCong.Location = new System.Drawing.Point(15, 175);
            this.lblTongCong.Name = "lblTongCong";
            this.lblTongCong.Size = new System.Drawing.Size(125, 20);
            this.lblTongCong.TabIndex = 5;
            this.lblTongCong.Text = "Tổng trị giá: 0 đ";
            // 
            // btnChuyenSangThanhToan
            // 
            this.btnChuyenSangThanhToan.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(59)))), ((int)(((byte)(93)))));
            this.btnChuyenSangThanhToan.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnChuyenSangThanhToan.Font = new System.Drawing.Font("Segoe UI", 10.5F, System.Drawing.FontStyle.Bold);
            this.btnChuyenSangThanhToan.ForeColor = System.Drawing.Color.White;
            this.btnChuyenSangThanhToan.Location = new System.Drawing.Point(610, 445);
            this.btnChuyenSangThanhToan.Name = "btnChuyenSangThanhToan";
            this.btnChuyenSangThanhToan.Size = new System.Drawing.Size(240, 42);
            this.btnChuyenSangThanhToan.TabIndex = 4;
            this.btnChuyenSangThanhToan.Text = "Tiếp tục thanh toán >>";
            this.btnChuyenSangThanhToan.UseVisualStyleBackColor = false;
            this.btnChuyenSangThanhToan.Click += new System.EventHandler(this.btnChuyenSangThanhToan_Click);
            // 
            // FrmDatHang
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(874, 510);
            this.Controls.Add(this.btnChuyenSangThanhToan);
            this.Controls.Add(this.grpGiaoHang);
            this.Controls.Add(this.grpNguoiNhan);
            this.Controls.Add(this.dgvGioHang);
            this.Controls.Add(this.lblHeader);
            this.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "FrmDatHang";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "e-SHOPPING - Lập phiếu đặt hàng";
            ((System.ComponentModel.ISupportInitialize)(this.dgvGioHang)).EndInit();
            this.grpNguoiNhan.ResumeLayout(false);
            this.grpNguoiNhan.PerformLayout();
            this.grpGiaoHang.ResumeLayout(false);
            this.grpGiaoHang.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();
        }
        #endregion

        private System.Windows.Forms.Label lblHeader;
        private System.Windows.Forms.DataGridView dgvGioHang;
        private System.Windows.Forms.GroupBox grpNguoiNhan;
        private System.Windows.Forms.Label lblHoTen;
        private System.Windows.Forms.TextBox txtNguoiNhanTen;
        private System.Windows.Forms.Label lblDiaChi;
        private System.Windows.Forms.TextBox txtNguoiNhanDiaChi;
        private System.Windows.Forms.Label lblKhuVuc;
        private System.Windows.Forms.ComboBox cboKhuVuc;
        private System.Windows.Forms.Label lblSdt;
        private System.Windows.Forms.TextBox txtNguoiNhanSdt;
        private System.Windows.Forms.GroupBox grpGiaoHang;
        private System.Windows.Forms.Label lblLoaiPhieu;
        private System.Windows.Forms.ComboBox cboLoaiGiaoHang;
        private System.Windows.Forms.Label lblThongBaoFreeship;
        private System.Windows.Forms.Label lblTienHang;
        private System.Windows.Forms.Label lblPhiGiao;
        private System.Windows.Forms.Label lblTongCong;
        private System.Windows.Forms.Button btnChuyenSangThanhToan;
    }
}