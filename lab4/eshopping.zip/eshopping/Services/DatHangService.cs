﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text.RegularExpressions;
using eshopping.Data;
using eshopping.Models;

namespace eshopping.Services
{
    public class DatHangService
    {
        public DataTable LayDanhSachLoaiGiaoHang()
        {
            string sql = "SELECT MaLoaiGiaoHang, TenLoai, PhiCoBan, ThoiGianXuLy FROM LoaiGiaoHang";
            return Db.ExecuteQuery(sql);
        }

        // Tính cước theo loại giao hàng + khu vực nhận hàng + xét freeship
        public decimal TinhPhiGiaoHang(int maLoaiGiaoHang, string khuVuc, decimal tongTienHang)
        {
            string sql = "SELECT PhiCoBan FROM LoaiGiaoHang WHERE MaLoaiGiaoHang = @ma";
            SqlParameter[] pars = { new SqlParameter("@ma", maLoaiGiaoHang) };
            object result = Db.ExecuteScalar(sql, pars);
            decimal phiCoBan = result != null ? Convert.ToDecimal(result) : 0;

            decimal phuPhiKhuVuc = 0;
            if (!string.IsNullOrWhiteSpace(khuVuc))
            {
                string kv = khuVuc.ToLower();
                if (kv.Contains("ngoại thành") || kv.Contains("huyện") || kv.Contains("tỉnh"))
                {
                    phuPhiKhuVuc = 20000;
                }
            }

            decimal tongPhi = phiCoBan + phuPhiKhuVuc;

            // BR02: Miễn phí vận chuyển
            if (tongTienHang >= 5000000 && maLoaiGiaoHang == 3) return 0;
            if (tongTienHang >= 1000000 && maLoaiGiaoHang == 2) return 0;

            return tongPhi;
        }

        // ==============================================================
        // USE CASE 5: LẬP PHIẾU ĐẶT HÀNG (Ghi nhận đơn với trạng thái Chờ thanh toán)
        // ==============================================================
        public int LapPhieuDatHang(
            int maKhachHang,
            int maLoaiGiaoHang,
            NguoiNhan nguoiNhan,
            List<ItemGioHang> gioHang,
            decimal tongTienHang,
            decimal phiGiaoHang,
            decimal tongThanhToan)
        {
            using (var conn = Db.GetConnection())
            using (var trans = conn.BeginTransaction())
            {
                try
                {
                    // 1. Tạo Phiếu đặt hàng ở trạng thái 'Chờ thanh toán'
                    string sqlPhieu = @"INSERT INTO PhieuDatHang (MaKhachHang, MaLoaiGiaoHang, TongTienHang, PhiGiaoHang, TongThanhToan, TrangThai)
                                        OUTPUT INSERTED.MaPhieuDat
                                        VALUES (@MaKH, @MaLoai, @TienHang, @PhiGiao, @TongTien, N'Chờ thanh toán')";
                    int maPhieu;
                    using (var cmd = new SqlCommand(sqlPhieu, conn, trans))
                    {
                        cmd.Parameters.AddWithValue("@MaKH", maKhachHang);
                        cmd.Parameters.AddWithValue("@MaLoai", maLoaiGiaoHang);
                        cmd.Parameters.AddWithValue("@TienHang", tongTienHang);
                        cmd.Parameters.AddWithValue("@PhiGiao", phiGiaoHang);
                        cmd.Parameters.AddWithValue("@TongTien", tongThanhToan);
                        maPhieu = (int)cmd.ExecuteScalar();
                    }

                    // 2. Lưu Người nhận hàng (BR04)
                    string sqlNguoiNhan = @"INSERT INTO NguoiNhanHang (MaPhieuDat, HoTenNguoiNhan, DiaChiGiao, KhuVucGiao, SoDienThoai)
                                            VALUES (@MaPhieu, @HoTen, @DiaChi, @KhuVuc, @Sdt)";
                    using (var cmd = new SqlCommand(sqlNguoiNhan, conn, trans))
                    {
                        cmd.Parameters.AddWithValue("@MaPhieu", maPhieu);
                        cmd.Parameters.AddWithValue("@HoTen", nguoiNhan.HoTen);
                        cmd.Parameters.AddWithValue("@DiaChi", nguoiNhan.DiaChi);
                        cmd.Parameters.AddWithValue("@KhuVuc", nguoiNhan.KhuVuc);
                        cmd.Parameters.AddWithValue("@Sdt", nguoiNhan.SoDienThoai);
                        cmd.ExecuteNonQuery();
                    }

                    // 3. Lưu Chi tiết sản phẩm trong đơn
                    foreach (var item in gioHang)
                    {
                        string sqlChiTiet = @"INSERT INTO ChiTietDatHang (MaPhieuDat, MaSanPham, SoLuong, DonGia)
                                              VALUES (@MaPhieu, @MaSP, @SL, @Gia)";
                        using (var cmd = new SqlCommand(sqlChiTiet, conn, trans))
                        {
                            cmd.Parameters.AddWithValue("@MaPhieu", maPhieu);
                            cmd.Parameters.AddWithValue("@MaSP", item.SanPham.MaSanPham);
                            cmd.Parameters.AddWithValue("@SL", item.SoLuong);
                            cmd.Parameters.AddWithValue("@Gia", item.SanPham.GiaHienHanh);
                            cmd.ExecuteNonQuery();
                        }
                    }

                    trans.Commit();
                    return maPhieu; // Trả về mã phiếu đặt vừa lập thành công
                }
                catch (Exception)
                {
                    trans.Rollback();
                    throw;
                }
            }
        }

        // Kiểm tra định dạng thẻ tín dụng (BR03)
        public (bool IsValid, string Message) KiemTraDinhDangThe(ThongTinThe the)
        {
            if (the == null) return (false, "Chưa nhập thông tin thẻ.");
            if (string.IsNullOrWhiteSpace(the.SoThe) || !Regex.IsMatch(the.SoThe, @"^\d+$"))
                return (false, "Số thẻ phải là các chữ số.");
            if (string.IsNullOrWhiteSpace(the.MaCSV) || !Regex.IsMatch(the.MaCSV, @"^\d+$"))
                return (false, "Mã CSV phải là các chữ số.");

            string loai = the.LoaiThe?.Trim();
            if (loai == "American Express")
            {
                if (the.SoThe.Length != 15) return (false, "Thẻ American Express yêu cầu đúng 15 chữ số.");
                if (the.MaCSV.Length != 4) return (false, "Thẻ American Express yêu cầu mã CSV đúng 4 chữ số.");
            }
            else if (loai == "VISA" || loai == "Master" || loai == "Discover")
            {
                if (the.SoThe.Length != 16) return (false, $"Thẻ {loai} yêu cầu đúng 16 chữ số.");
                if (the.MaCSV.Length != 3) return (false, $"Thẻ {loai} yêu cầu mã CSV đúng 3 chữ số.");
            }
            else
            {
                return (false, "Loại thẻ không được hỗ trợ.");
            }

            return (true, "Thẻ hợp lệ.");
        }

        // ==============================================================
        // USE CASE 6: THANH TOÁN (Cập nhật phiếu thành 'Đã thanh toán', lưu giao dịch)
        // ==============================================================
        public (bool ThanhCong, string ThongBao) XuLyThanhToan(int maPhieuDat, decimal tongThanhToan, string emailKhach, ThongTinThe the)
        {
            var checkThe = KiemTraDinhDangThe(the);
            if (!checkThe.IsValid)
            {
                return (false, checkThe.Message);
            }

            decimal tiLeLePhi = the.LoaiThe == "American Express" ? 0.025m : 0.015m;
            decimal lePhi = Math.Round(tongThanhToan * tiLeLePhi, 0);
            string txnId = "TXN" + DateTime.Now.ToString("yyyyMMddHHmmss");

            using (var conn = Db.GetConnection())
            using (var trans = conn.BeginTransaction())
            {
                try
                {
                    // 1. Cập nhật trạng thái phiếu đặt hàng sang 'Đã thanh toán'
                    string sqlUpdate = "UPDATE PhieuDatHang SET TrangThai = N'Đã thanh toán' WHERE MaPhieuDat = @MaPhieu";
                    using (var cmd = new SqlCommand(sqlUpdate, conn, trans))
                    {
                        cmd.Parameters.AddWithValue("@MaPhieu", maPhieuDat);
                        cmd.ExecuteNonQuery();
                    }

                    // 2. Ghi nhận giao dịch thanh toán
                    string soTheMasked = "************" + the.SoThe.Substring(the.SoThe.Length - 4);
                    string sqlPay = @"INSERT INTO GiaoDichThanhToan (MaPhieuDat, LoaiThe, SoTheMasked, TenChuThe, LePhi, SoTienThanhToan, MaGiaoDichNgoai, TrangThai)
                                      VALUES (@MaPhieu, @LoaiThe, @Masked, @TenChu, @LePhi, @SoTien, @TxnId, 'SUCCESS')";
                    using (var cmd = new SqlCommand(sqlPay, conn, trans))
                    {
                        cmd.Parameters.AddWithValue("@MaPhieu", maPhieuDat);
                        cmd.Parameters.AddWithValue("@LoaiThe", the.LoaiThe);
                        cmd.Parameters.AddWithValue("@Masked", soTheMasked);
                        cmd.Parameters.AddWithValue("@TenChu", the.TenChuThe);
                        cmd.Parameters.AddWithValue("@LePhi", lePhi);
                        cmd.Parameters.AddWithValue("@SoTien", tongThanhToan);
                        cmd.Parameters.AddWithValue("@TxnId", txnId);
                        cmd.ExecuteNonQuery();
                    }

                    trans.Commit();

                    // 3. Gửi email xác nhận (ẩn thông tin thẻ)
                    if (!string.IsNullOrWhiteSpace(emailKhach))
                    {
                        System.Diagnostics.Debug.WriteLine($"[EMAIL] Xác nhận đơn hàng #{maPhieuDat} đã thanh toán thành công qua thẻ {the.LoaiThe} ({soTheMasked}).");
                    }

                    return (true, "Thanh toán thành công!");
                }
                catch (Exception ex)
                {
                    trans.Rollback();
                    return (false, "Lỗi khi xử lý thanh toán: " + ex.Message);
                }
            }
        }
    }
}