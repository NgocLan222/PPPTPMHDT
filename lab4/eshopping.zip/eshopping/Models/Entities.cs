﻿using System.Collections.Generic;

namespace eshopping.Models
{
    public class SanPham
    {
        public string MaSanPham { get; set; }
        public string TenSanPham { get; set; }
        public decimal GiaHienHanh { get; set; }
    }

    public class ItemGioHang
    {
        public SanPham SanPham { get; set; }
        public int SoLuong { get; set; }
        public decimal ThanhTien => SanPham.GiaHienHanh * SoLuong;
    }

    public class NguoiNhan
    {
        public string HoTen { get; set; }
        public string DiaChi { get; set; }
        public string KhuVuc { get; set; }
        public string SoDienThoai { get; set; }
    }

    public class ThongTinThe
    {
        public string LoaiThe { get; set; }
        public string SoThe { get; set; }
        public string NgayHetHan { get; set; }
        public string TenChuThe { get; set; }
        public string MaCSV { get; set; }
    }

    // Đóng gói thông tin phiếu đặt hàng để chuyển sang bước thanh toán
    public class DonHangTam
    {
        public int MaKhachHang { get; set; }
        public string EmailKhachHang { get; set; }
        public int MaLoaiGiaoHang { get; set; }
        public string TenLoaiGiaoHang { get; set; }
        public NguoiNhan ThongTinNguoiNhan { get; set; }
        public List<ItemGioHang> DanhSachSanPham { get; set; }
        public decimal TongTienHang { get; set; }
        public decimal PhiGiaoHang { get; set; }
        public decimal TongThanhToan { get; set; }
    }

    public class KetQuaThanhToan
    {
        public int MaPhieuDat { get; set; }
        public decimal TongThanhToan { get; set; }
        public bool ThanhCong { get; set; }
        public string ThongBao { get; set; }
    }
}