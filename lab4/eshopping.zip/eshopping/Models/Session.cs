﻿namespace eshopping.Models
{
    public class KhachHangSession
    {
        public int MaKhachHang { get; set; }
        public string TenDangNhap { get; set; }
        public string HoTen { get; set; }
        public string Email { get; set; }
        public string SoDienThoai { get; set; }
        public string DiaChi { get; set; }
    }

    public static class CurrentSession
    {
        public static KhachHangSession User { get; set; }
    }
}