﻿using System;
using System.Windows.Forms;
using eshopping.Forms;

namespace eshopping
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // Bắt đầu từ màn hình Đăng nhập (UC2)
            Application.Run(new FrmDangNhap());
        }
    }
}