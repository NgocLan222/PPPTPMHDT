﻿using System;
using System.Configuration; // Thư viện đọc file App.config
using System.Data;
using System.Data.SqlClient;

namespace eshopping.Data
{
    public static class Db
    {
        // Đọc chuỗi kết nối động từ thẻ connectionStrings trong App.config
        private static readonly string ConnectionString =
            ConfigurationManager.ConnectionStrings["eShoppingDB"].ConnectionString;

        // 1. Mở và lấy kết nối
        public static SqlConnection GetConnection()
        {
            var conn = new SqlConnection(ConnectionString);
            if (conn.State == ConnectionState.Closed)
            {
                conn.Open();
            }
            return conn;
        }

        // 2. Thực thi SELECT trả về DataTable (đổ lên dgv, combobox)
        public static DataTable ExecuteQuery(string sql, SqlParameter[] parameters = null)
        {
            var dt = new DataTable();
            using (var conn = GetConnection())
            using (var cmd = new SqlCommand(sql, conn))
            {
                if (parameters != null)
                {
                    cmd.Parameters.AddRange(parameters);
                }
                using (var da = new SqlDataAdapter(cmd))
                {
                    da.Fill(dt);
                }
            }
            return dt;
        }

        // 3. Thực thi INSERT, UPDATE, DELETE
        public static int ExecuteNonQuery(string sql, SqlParameter[] parameters = null)
        {
            using (var conn = GetConnection())
            using (var cmd = new SqlCommand(sql, conn))
            {
                if (parameters != null)
                {
                    cmd.Parameters.AddRange(parameters);
                }
                return cmd.ExecuteNonQuery();
            }
        }

        // 4. Lấy 1 giá trị đơn lẻ (COUNT, MAX, IDENTITY vừa thêm)
        public static object ExecuteScalar(string sql, SqlParameter[] parameters = null)
        {
            using (var conn = GetConnection())
            using (var cmd = new SqlCommand(sql, conn))
            {
                if (parameters != null)
                {
                    cmd.Parameters.AddRange(parameters);
                }
                return cmd.ExecuteScalar();
            }
        }
    }
}